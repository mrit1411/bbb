import {  EC2Client,  paginateDescribeInstances,  DescribeRegionsCommand,} from "@aws-sdk/client-ec2";
import {  CloudWatchClient,  paginateDescribeAlarms,} from "@aws-sdk/client-cloudwatch";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";

/**
 * ENV VARS
 *  - TAG_KEY                 (required)
 *  - TAG_VALUE               (required)
 *  - MIN_RUNNING_AGE_SECONDS (optional; default "3600")
 *  - NAME_DELIMITER          (optional; default ":")
 *  - MATCH_ONLY_TAGGED       (optional; default "true")
 *  - PREFER_DIMENSIONS       (optional; default "true")
 *  - REGIONS_MODE            (optional; default "enabled") -> "enabled" | "all"
 *  - REGIONS_CONCURRENCY     (optional; default "5") -> max regions processed in parallel
 *  - DISCOVERY_REGION        (optional; default "us-east-1") -> used for DescribeRegions
 *
 * NOTES:
 *  - "enabled" returns regions available to your account (recommended).
 *  - "all" attempts to return all regions (may include regions you can't access).
 */

const TAG_KEY = process.env.TAG_KEY;
const TAG_VALUE = process.env.TAG_VALUE;
const SNS_TOPIC = process.env.SNS_TOPIC;

const MIN_RUNNING_AGE_SECONDS = Number(process.env.MIN_RUNNING_AGE_SECONDS ?? "3600");
const NAME_DELIMITER = process.env.NAME_DELIMITER || ":";

const MATCH_ONLY_TAGGED = (process.env.MATCH_ONLY_TAGGED ?? "true").toLowerCase() === "true";
const PREFER_DIMENSIONS = (process.env.PREFER_DIMENSIONS ?? "true").toLowerCase() === "true";

const REGIONS_MODE = (process.env.REGIONS_MODE ?? "enabled").toLowerCase(); // enabled | all
const REGIONS_CONCURRENCY = Math.max(1, Number(process.env.REGIONS_CONCURRENCY ?? "5"));
const DISCOVERY_REGION = process.env.DISCOVERY_REGION || process.env.AWS_REGION;

const snsclient = new SNSClient({ region: DISCOVERY_REGION });

function assertEnv() {
  if (!TAG_KEY || !TAG_VALUE) throw new Error("Missing required env vars TAG_KEY and/or TAG_VALUE");
  if (!Number.isFinite(MIN_RUNNING_AGE_SECONDS) || MIN_RUNNING_AGE_SECONDS < 0) {
    throw new Error("MIN_RUNNING_AGE_SECONDS must be a non-negative number");
  }
}

/** Simple concurrency limiter */
async function runWithConcurrency(items, limit, workerFn) {
  const results = [];
  let idx = 0;

  const workers = new Array(Math.min(limit, items.length)).fill(0).map(async () => {
    while (idx < items.length) {
      const current = items[idx++];
      results.push(await workerFn(current));
    }
  });

  await Promise.all(workers);
  return results;
}

/** Discover regions */
async function listRegions() {
  const ec2 = new EC2Client({ region: DISCOVERY_REGION });

  const cmd = new DescribeRegionsCommand({
    // AllRegions: true may include regions not enabled for your account.
    AllRegions: REGIONS_MODE === "all",
  });

  const res = await ec2.send(cmd);
  const regions = (res.Regions ?? [])
    .map(r => r.RegionName)
    .filter(Boolean);

  // De-duplicate and sort for stable output
  return [...new Set(regions)].sort();
}

/** EC2 instances: tagged, running, and older than minAgeSeconds */
async function getRunningInstanceIdsByTagOlderThan(region, tagKey, tagValue, minAgeSeconds) {
  const ec2Client = new EC2Client({ region });

  const nowMs = Date.now();
  const minAgeMs = minAgeSeconds * 1000;

  const ids = [];
  const paginator = paginateDescribeInstances(
    { client: ec2Client, pageSize: 1000 },
    {
      Filters: [
        { Name: `tag:${tagKey}`, Values: [tagValue] },
        { Name: "instance-state-name", Values: ["running"] },
      ],
    }
  );

  for await (const page of paginator) {
    for (const reservation of page.Reservations ?? []) {
      for (const instance of reservation.Instances ?? []) {
        const id = instance.InstanceId;
        const launchTimeMs = instance.LaunchTime ? new Date(instance.LaunchTime).getTime() : null;

        if (id && launchTimeMs && (nowMs - launchTimeMs) >= minAgeMs) {
          ids.push(id);
        }
      }
    }
  }

  return ids;
}

/** CloudWatch Metric alarms in INSUFFICIENT_DATA (composite alarms ignored) */
async function getInsufficientDataMetricAlarms(region) {
  const cwClient = new CloudWatchClient({ region });

  const alarms = [];
  const paginator = paginateDescribeAlarms(
    { client: cwClient, pageSize: 100 },
    { StateValue: "INSUFFICIENT_DATA" }
  );

  for await (const page of paginator) {
    alarms.push(...(page.MetricAlarms ?? []));
  }

  return alarms;
}

function splitAlarmName(alarmName, delimiter = ":") {
  return String(alarmName ?? "").split(delimiter)[0];
}

function extractInstanceIdFromDimensions(alarm) {
  const dims = alarm?.Dimensions;
  if (!Array.isArray(dims)) return null;
  const match = dims.find(d => d?.Name === "InstanceId" && typeof d?.Value === "string");
  return match?.Value ?? null;
}

function extractInstanceIdFromAlarmNameParts(parts) {
  return parts.find(p => typeof p === "string" && p.startsWith("i-")) || null;
}

/** Process one region: returns alarm ARNs (optionally filtered) */
async function processRegion(region) {
  try {
    // 1) Eligible instances (tag + running > 1h)
    const eligibleInstanceIds = await getRunningInstanceIdsByTagOlderThan(
      region,
      TAG_KEY,
      TAG_VALUE,
      MIN_RUNNING_AGE_SECONDS
    );
    const eligibleSet = new Set(eligibleInstanceIds);

    // 2) INSUFFICIENT_DATA metric alarms
    const alarms = await getInsufficientDataMetricAlarms(region);

    // 3) Infer instanceId and filter (optional) -> return AlarmArn only
    const alarmArns = [];

    for (const alarm of alarms) {
      const alarmArn = alarm?.AlarmArn;
      if (!alarmArn) continue;

      let instanceId = null;

      // if (PREFER_DIMENSIONS) {
      //   instanceId = extractInstanceIdFromDimensions(alarm);
      // }
      // if (!instanceId) {
      //   const parts = splitAlarmName(alarm?.AlarmName, NAME_DELIMITER);
      //   instanceId = extractInstanceIdFromAlarmNameParts(parts);
      // }
      const split_instanceId = splitAlarmName(alarm?.AlarmName, NAME_DELIMITER);

      if (MATCH_ONLY_TAGGED) {
        // if (instanceId && eligibleSet.has(instanceId)) {
        //   alarmArns.push(alarmArn);
        // }
        if (split_instanceId){ // && eligibleSet.has(instanceId)) {
          for (const instance of eligibleSet){
            if (split_instanceId.startsWith(instance)){
              alarmArns.push(alarmArn);
            }
          }
        }
      } else {
        alarmArns.push(alarmArn);
      }
    }

    return {
      region,
      eligibleInstanceCount: eligibleInstanceIds.length,
      insufficientMetricAlarmCount: alarms.length,
      returnedAlarmArnCount: alarmArns.length,
      alarmArns,
      error: null,
    };
  } catch (err) {
    // If a region isn't enabled/accessible, you may get auth or endpoint errors.
    return {
      region,
      eligibleInstanceCount: 0,
      insufficientMetricAlarmCount: 0,
      returnedAlarmArnCount: 0,
      alarmArns: [],
      error: err?.message || String(err),
    };
  }
}

export const lambda_handler = async (event = {}) => {
  assertEnv();

  console.log("Event:", JSON.stringify(event));
  console.log(
    JSON.stringify({
      TAG_KEY,
      TAG_VALUE,
      MIN_RUNNING_AGE_SECONDS,
      NAME_DELIMITER,
      MATCH_ONLY_TAGGED,
      PREFER_DIMENSIONS,
      REGIONS_MODE,
      REGIONS_CONCURRENCY,
      DISCOVERY_REGION,
    })
  );

  // Discover regions
  const regions = await listRegions();
  console.log(`Discovered ${regions.length} region(s): ${regions.join(", ")}`);

  // Process all regions with a concurrency limit
  const perRegion = await runWithConcurrency(regions, REGIONS_CONCURRENCY, processRegion);

  // Flatten & unique alarm ARNs
  const allArns = perRegion.flatMap(r => r.alarmArns);
  const uniqueArns = [...new Set(allArns)];

  // Also gather regional errors (useful when REGIONS_MODE=all)
  const regionErrors = perRegion
    .filter(r => r.error)
    .map(r => ({ region: r.region, error: r.error }));

  if (uniqueArns.length>0){
    const indexedItems_list = uniqueArns.map((item, index) => Number(index)+1 +". "+item+'\n');
    var str = `Hello Team,
        Below are the arns of the Alarms which are in Insufficient Data state. `;
    var message = str + '\n\n' +'*'.repeat(50)+'\n'+ indexedItems_list.join('\n') + '\n'+'*'.repeat(50)
    // var message = str + '\n\n' + uniqueArns.join('\n')
    const command = new PublishCommand({
        TopicArn: SNS_TOPIC,
        Message: message,
        Subject: "CloudWatch Alarms Insufficient Data"
    });
    try {
    const data = await snsclient.send(command);
    return data;
    } catch (err) {
        console.error(err);
    }
  }

  const response = {
    tagFilter: { key: TAG_KEY, value: TAG_VALUE },
    minRunningAgeSeconds: MIN_RUNNING_AGE_SECONDS,
    delimiter: NAME_DELIMITER,
    matchOnlyTagged: MATCH_ONLY_TAGGED,
    preferDimensions: PREFER_DIMENSIONS,
    regionsMode: REGIONS_MODE,
    regionsProcessed: regions.length,
    perRegionSummary: perRegion.map(r => ({
      region: r.region,
      eligibleInstanceCount: r.eligibleInstanceCount,
      insufficientMetricAlarmCount: r.insufficientMetricAlarmCount,
      returnedAlarmArnCount: r.returnedAlarmArnCount,
      error: r.error,
    })),
    totalAlarmArnCount: allArns.length,
    uniqueAlarmArnCount: uniqueArns.length,
    alarmArns: uniqueArns, // <-- FINAL OUTPUT: list of alarm ARNs
    regionErrors,
  };

  console.log("Response:", JSON.stringify(response, null, 2));

  return {
    statusCode: 200,
    headers: { "content-type": "application/json" },
    body: JSON.stringify(response),
  };
};
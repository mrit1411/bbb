module "ccs_aws_backup_monitoring" {
  for_each    = toset(var.regions)
  source      = "../modules/aws_cloudwatch_event_rule"
  description = "EventRule for monitoring AWS Backup Failures, Abortions and Expiration alerts for this Region. alerts will go to targerted SNS Topic"
  region      = each.key
  event_pattern = jsonencode({
    source = ["aws.backup"]
    detail = {
      state = ["FAILED", "EXPIRED"]
    }
  })
  eventbridge_target_id  = "CCSAWSBackupMonitoring"
  eventbridge_target_arn = data.terraform_remote_state.infra.outputs.splunk_forwarder_sns_topic_arns[each.key]
  context                = "AWSBackupMonitoring"
}

module "backup_reports_automation_trigger_monthly" {
  for_each               = toset(var.regions)
  source                 = "../modules/aws_cloudwatch_event_rule"
  description            = "EventRule for triggering CCS Backup Report Lambda Function to generate monthly backup reports"
  region                 = each.key
  schedule               = var.backup_report_generation_schedule_monthly
  eventbridge_target_id  = "BackupReports"
  eventbridge_target_arn = module.backup_reports_lambda_function[each.key].arn
  input                  = "{\"ReportingPeriod\": [\"BeginningOfTheMonth\"]}"
  context                = "BackupReportsTriggerMonthly"
}

module "backup_reports_automation_trigger_weekly" {
  for_each               = toset(var.regions)
  source                 = "../modules/aws_cloudwatch_event_rule"
  description            = "EventRule for triggering CCS Backup Report Lambda Function to generate weekly backup reports"
  region                 = each.key
  schedule               = var.backup_report_generation_schedule_weekly
  eventbridge_target_id  = "BackupReports"
  eventbridge_target_arn = module.backup_reports_lambda_function[each.key].arn
  input                  = "{\"ReportingPeriod\": [\"LastWeek\"]}"
  context                = "BackupReportsTriggerWeekly"
}

module "backup_reports_automation_trigger_daily" {
  for_each               = toset(var.regions)
  source                 = "../modules/aws_cloudwatch_event_rule"
  description            = "EventRule for triggering CCS Backup Report Lambda Function to generate daily backup reports"
  region                 = each.key
  schedule               = var.backup_report_generation_schedule_daily
  eventbridge_target_id  = "BackupReports"
  eventbridge_target_arn = module.backup_reports_lambda_function[each.key].arn
  input                  = "{\"ReportingPeriod\": [\"Yesterday\"]}"
  context                = "BackupReportsTriggerDaily"

}

module "delete_snapshot_based_on_tag_event_rule" {
  for_each               = toset(var.regions)
  source                 = "../modules/aws_cloudwatch_event_rule"
  description            = "CCS EventRule that will trigger the CCS LambdaDeleteSnapshotBasedOnTag lambda with one-day interval"
  region                 = each.key
  schedule               = "rate(1 day)"
  eventbridge_target_id  = "LambdaDeleteSnapshotBasedOnTag"
  eventbridge_target_arn = module.delete_snapshot_based_on_tag_lambda_function[each.key].arn
  context                = "DeleteSnapshotBasedOnTagEventRule"
}

module "backup_url_user_credentials" {
  source = "../modules/aws_iam_access_key"
  user   = module.backup_report_url_iam_user.name
}

module "aws_resource_backup_role" {
  source              = "../modules/aws_iam_role"
  description         = "Role created by CCS Backup Solution Deployment. used for Backup and Restore actions to/from default deployed AWS Backup Vault"
  resource_type       = "Backup"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup", "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForRestores"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "PolicytorestoreEC2withinstanceprofiles"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/restore_ec2_with_instance_profiles.tpl.json", {
        aws_account_id = data.aws_caller_identity.current.account_id
      })
    }
  }
  context = "AWSResourceBackupRole"
}

module "lambda_backup_reports_iam_role" {
  source              = "../modules/aws_iam_role"
  description         = "Role created by CCS Backup Solution Deployment. used by the CCSBackupReports Lambda Function to generate backup reports,store in S3 and publish URL to SNS"
  resource_type       = "Lambda"
  context             = "Backup-Reports"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/ResourceGroupsandTagEditorReadOnlyAccess"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaBackupReportsInstantPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/lambda_backup_reports_instant_policy.tpl.json", {
        backup_reports_sns_topic_arn = flatten([for r in var.regions : [
          module.backup_reports_sns_topic[r].sns_topic_arn
        ]
        ]),
        s3_bucket_backup_reports_bucket_arns = flatten([for r in var.regions : [
          "arn:aws:s3:::${module.backup_reports_s3_bucket[r].bucket_id}",
          "arn:aws:s3:::${module.backup_reports_s3_bucket[r].bucket_id}/*"
        ]
        ])
      })
    }
    policy1 = {
      inline_policy_name = "BackupReportURLUserSecretKeyAccess-${data.aws_region.current.region}"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/backup_report_url_user_secret_key_access.tpl.json", {
        backup_url_credentials_stored = flatten([for r in var.regions : [
          module.backup_url_credentials_stored[r].secret_id
        ]
        ])
      })
    }
  }

}

module "ssm_automation_backup_instance_iam_role" {
  source              = "../modules/aws_iam_role"
  description         = "Role created by CCS Backup Solution Deployment. used by the SSM SSMAutomationDocumentBackupInstanceLinux and SSMAutomationDocumentBackupInstanceWindows automation docs to execute SSM automation"
  resource_type       = "SSM"
  context             = "SSMAutomationBackupInstance"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonSSMAutomationRole"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "SSMAutomationBackupInstancePolicy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/ssm_automation_backup_instance_policy.json")
    }
  }

}

module "lambda_delete_snapshot_based_on_tag_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by COS Backup Solution Deployment. Role used in Lambda function for delete EBS snapshots containing \"DeleteOn\" tag."
  resource_type = "Lambda"
  context       = "LambdaDeleteSnapshotBasedOnTag"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaDeleteSnapshotBasedOnTagPolicy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_delete_snapshot_based_on_tag_policy.json")
    }
  }

}

module "backup_report_url_iam_user" {
  source           = "../modules/aws_iam_user"
  policy_base_name = "Backup"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "BackupS3Access"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObjectAcl",
          "s3:GetObject",
          "s3:AbortMultipartUpload",
          "s3:PutObjectAcl"
        ]
        Resource = flatten([
          for r in var.regions : [
            "arn:aws:s3:::${module.backup_reports_s3_bucket[r].bucket_id}",
            "arn:aws:s3:::${module.backup_reports_s3_bucket[r].bucket_id}/*"
          ]
        ])

      }
    ]
  })
  user_name = "BackupReportURLUser"

}

module "backup_reports_lambda_function" {
  for_each                 = toset(var.regions)
  source                   = "../modules/aws_lambda_function"
  description              = "CCS Developed Lambda Function.will generate a Backup report when triggered, place into an S3 bucket and send an presigned URL to the topic ARN. triggered automatically through  daily,weekly and/or monthly EventBridge rules"
  handler                  = "lambda_backup_reports_jobs.lambda_handler"
  lambda_function_filename = "lambda_backup_reports"
  role                     = module.lambda_backup_reports_iam_role.role_arn
  timeout                  = 900
  memory_size              = 128
  region                   = each.key
  env_variables = {
    SNS_TOPIC_ARN          = module.backup_reports_sns_topic[each.key].sns_topic_arn
    S3_LINK_EXPIRATION     = var.backup_link_validity
    S3_BUCKET              = module.backup_reports_s3_bucket[each.key].bucket_id
    BACKUP_REPORTING_KEY   = var.backup_tags_condition_key
    BACKUP_REPORTING_VALUE = var.backup_tags_condition_value
    ReportingPeriod        = "BeginningOfTheMonth"
    BackupPeriodStart      = ""
    BackupPeriodEnd        = ""
  }
}

module "delete_snapshot_based_on_tag_lambda_function" {
  for_each                 = toset(var.regions)
  source                   = "../modules/aws_lambda_function"
  description              = "CCS Lambda Function. Lambda function delete snapshots that have a \"DeleteOn\" tag containing the current day formatted as YYYY-MM-DD"
  handler                  = "lambda_tag_based_ebs_snapshot_deletion.lambda_handler"
  lambda_function_filename = "lambda_tag_based_ebs_snapshot_deletion"
  role                     = module.lambda_delete_snapshot_based_on_tag_iam_role.role_arn
  timeout                  = 600
  memory_size              = 128
  region                   = each.key
}

module "monthly_event_bridge_permission_invoke_reporting_lambda" {
  for_each      = toset(var.regions)
  source        = "../modules/aws_lambda_permission"
  function_name = module.backup_reports_lambda_function[each.key].arn
  source_arn    = module.backup_reports_automation_trigger_monthly[each.key].arn
  region        = each.key
}

module "weekly_event_bridge_permission_invoke_reporting_lambda" {
  for_each      = toset(var.regions)
  source        = "../modules/aws_lambda_permission"
  function_name = module.backup_reports_lambda_function[each.key].arn
  source_arn    = module.backup_reports_automation_trigger_weekly[each.key].arn
  region        = each.key

}

module "daily_event_bridge_permission_invoke_reporting_lambda" {
  for_each      = toset(var.regions)
  source        = "../modules/aws_lambda_permission"
  function_name = module.backup_reports_lambda_function[each.key].arn
  source_arn    = module.backup_reports_automation_trigger_daily[each.key].arn
  region        = each.key

}

module "delete_snapshot_based_on_tag_permission_invoke_lambda" {
  for_each      = toset(var.regions)
  source        = "../modules/aws_lambda_permission"
  function_name = module.delete_snapshot_based_on_tag_lambda_function[each.key].arn
  source_arn    = module.delete_snapshot_based_on_tag_event_rule[each.key].arn
  region        = each.key

}

module "backup_reports_s3_bucket" {
  for_each         = toset(var.regions)
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.backup_reports_bucket_name
  region           = each.key
}

module "backup_reports_s3_bucket_encryption_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_s3_bucket_server_side_encryption_configuration"
  bucket   = module.backup_reports_s3_bucket[each.key].bucket_id
  region   = each.key
}

module "backup_reports_s3_bucket_policy" {
  for_each = toset(var.regions)
  source   = "../modules/aws_s3_bucket_policy"
  bucket   = module.backup_reports_s3_bucket[each.key].bucket_id
  region   = each.key
}

module "backup_url_credentials_stored" {
  for_each    = toset(var.regions)
  source      = "../modules/aws_secretsmanager_secret"
  region      = each.key
  context     = "backup-report"
  description = "Deployed by CCS backup solution. Secret contains the API key for BackupReportURLUser. credentials are used by backup report SSM automation doc when generating signed URL"
  secret_string_wo = jsonencode({
    ACCESS_KEY = module.backup_url_user_credentials.access_key_id
    SECRET_KEY = module.backup_url_user_credentials.secret_access_key
  })
  secret_string_wo_version = 1
}

module "backup_reports_sns_topic" {
  for_each = toset(var.regions)
  source   = "../modules/aws_sns_topic"
  name     = var.backup_reports_sns_topic_name
  region   = each.key
}

module "backup_reports_sns_topic_subscription" {
  for_each  = toset(var.regions)
  source    = "../modules/aws_sns_topic_subscription"
  topic_arn = module.backup_reports_sns_topic[each.key].sns_topic_arn
  endpoint  = var.backup_report_recipient
  region    = each.key
}

module "backup_linux_instance_ssm_automation_document" {
  source      = "../modules/aws_ssm_document"
  name        = "CCS-SSMAutomationDocumentBackupInstanceLinux"
  target_type = "/AWS::EC2::Instance"
  content = templatefile("../modules/aws_ssm_document/ssm_documents/create_linux_backup.tpl.json", {
    ssm_automation_backup_instance_iam_role_arn          = module.ssm_automation_backup_instance_iam_role.role_arn,
    infra_run_command_linux_ssm_automation_document_name = data.terraform_remote_state.infra.outputs.infra_run_command_linux_ssm_automation_document,
    infra_create_backup_ssm_automation_document_name     = data.terraform_remote_state.infra.outputs.infra_create_backup_ssm_automation_document
  })
  document_type = "Automation"
}

module "backup_windows_instance_ssm_automation_document" {
  source      = "../modules/aws_ssm_document"
  name        = "CCS-SSMAutomationDocumentBackupInstanceWindows"
  target_type = "/AWS::EC2::Instance"
  content = templatefile("../modules/aws_ssm_document/ssm_documents/create_windows_backup.tpl.json", {
    ssm_automation_backup_instance_iam_role_arn       = module.ssm_automation_backup_instance_iam_role.role_arn,
    infra_run_command_windows_ssm_automation_document = data.terraform_remote_state.infra.outputs.infra_run_command_windows_ssm_automation_document,
    infra_create_backup_ssm_automation_document_name  = data.terraform_remote_state.infra.outputs.infra_create_backup_ssm_automation_document
    }
  )
  document_type = "Automation"
}

module "backup_vault" {
  for_each = toset(var.regions)
  source   = "../modules/aws_backup_vault"
  # name     = var.backup_vault_name
  context = "CCSBackupVault"
  tags     = var.backup_vault_tags
  region   = each.key
}

module "ccs_backup_plan" {
  for_each = toset(var.regions)
  source   = "../modules/aws_backup_plan"
  # name     = var.backup_plan_name
  context = "CCSBackupPlan"
  region   = each.key
  rules = [
    {
      rule_name         = var.backup_daily_rule_name
      schedule          = var.backup_daily_schedule_expression
      completion_window = var.backup_completion_window
      start_window      = var.backup_start_window
      target_vault_name = module.backup_vault[each.key].id
      delete_after      = var.backup_daily_delete_after_days
      recovery_point_tags = {
        Owner      = "${data.aws_caller_identity.current.account_id}:${each.key}"
        BackupPlan = "DailyBackup"
      }
    },
    {
      rule_name         = var.backup_weekly_rule_name
      schedule          = var.backup_weekly_schedule_expression
      completion_window = var.backup_completion_window
      start_window      = var.backup_start_window
      target_vault_name = module.backup_vault[each.key].id
      delete_after      = var.backup_weekly_delete_after_days
      recovery_point_tags = {
        Owner      = "${data.aws_caller_identity.current.account_id}:${each.key}"
        BackupPlan = "WeeklyBackup"
      }
    },
    {
      rule_name         = var.backup_monthly_rule_name
      schedule          = var.backup_monthly_schedule_expression
      completion_window = var.backup_completion_window
      start_window      = var.backup_start_window
      target_vault_name = module.backup_vault[each.key].id
      delete_after      = var.backup_monthly_delete_after_days
      recovery_point_tags = {
        Owner      = "${data.aws_caller_identity.current.account_id}:${each.key}"
        BackupPlan = "MonthlyBackup"
      }
    },
    {
      rule_name         = var.backup_yearly_rule_name
      schedule          = var.backup_yearly_schedule_expression
      completion_window = var.backup_completion_window
      start_window      = var.backup_start_window
      target_vault_name = module.backup_vault[each.key].id
      delete_after      = var.backup_yearly_delete_after_days
      recovery_point_tags = {
        Owner      = "${data.aws_caller_identity.current.account_id}:${each.key}"
        BackupPlan = "YearlyBackup"
      }
    }
  ]
  tags = var.backup_plan_tags
}

module "backup_selection" {
  for_each     = toset(var.regions)
  source       = "../modules/aws_backup_selection"
  # name         = var.backup_selection_name
  context      = "CCSBackupSelection"
  plan_id      = module.ccs_backup_plan[each.key].id
  region       = each.key
  iam_role_arn = module.aws_resource_backup_role.role_arn
  selection_tags = [
    {
      type  = "STRINGEQUALS"
      key   = var.backup_tags_condition_key
      value = var.backup_tags_condition_value
    },
    {
      type  = "STRINGEQUALS"
      key   = "ccs_managed"
      value = "yes"
    }
  ]
}

resource "aws_instance" "ubuntu_ec2" {
  for_each      = toset(var.regions)
  ami           = "resolve:ssm:/aws/service/canonical/ubuntu/server/22.04/stable/current/amd64/hvm/ebs-gp2/ami-id" # Replace with the Ubuntu AMI ID for your region
  region        = each.key
  instance_type = "t3.micro" # Replace with your desired instance type
  # key_name      = "ccs_linux_test_key_pair"   # Replace with the name of your pre-existing key pair
  # iam_instance_profile = data.terraform_remote_state.infra.outputs.infra_ec2_instance_profile_name
  associate_public_ip_address = false

  tags = {
    Name                = "ccs-linux-bacup-test-${each.key}"
    ccs_backup          = "yes"
    ccs_dependency_type = "dependency"
    "Patch Group"       = "linux_default"
    ccs_managed         = "yes"
  }

  lifecycle {
    ignore_changes = [associate_public_ip_address]
  }
}

resource "aws_instance" "windows_ec2" {
  for_each      = toset(var.regions)
  ami           = "resolve:ssm:/aws/service/ami-windows-latest/Windows_Server-2022-English-Full-Base" # Replace with the Ubuntu AMI ID for your region
  region        = each.key
  instance_type = "t3.micro" # Replace with your desired instance type
  # key_name      = "ccs_windows_test_key_pair"   # Replace with the name of your pre-existing key pair
  # iam_instance_profile = data.terraform_remote_state.infra.outputs.infra_ec2_instance_profile_name
  associate_public_ip_address = false

  tags = {
    Name                = "ccs-windows-backup-test-${each.key}"
    ccs_backup          = "yes"
    ccs_dependency_type = "dependency"
    "Patch Group"       = "windows_default"
    ccs_managed         = "yes"
  }

  lifecycle {
    ignore_changes = [associate_public_ip_address]
  }
}

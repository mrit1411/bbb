locals {
  compatible_runtime = title(replace(var.python_runtime, ".", ""))
  pandas_layer_version = {"python3.13"=7,"python3.12"=22,"python3.11"=26,"python3.10"=29}
  pandas_layer_arn = {"eu-central-1"="arn:aws:lambda:eu-central-1:336392948345:layer:AWSSDKPandas-Python313:7", "us-east-1"="arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python313:7", "ap-east-1"="arn:aws:lambda:ap-east-1:839552336658:layer:AWSSDKPandas-Python313:7", "eu-west-2"="arn:aws:lambda:eu-west-2:336392948345:layer:AWSSDKPandas-Python313:7"}
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_backup_plan.backup_plan](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/backup_plan) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_backup_setting_resource_type"></a> [backup\_setting\_resource\_type](#input\_backup\_setting\_resource\_type) | The type of AWS resource to be backed up. For VSS Windows backups, the only supported resource type is Amazon EC2. Valid values: EC2. | `string` | `"EC2"` | no |
| <a name="input_backup_setting_windows_vss"></a> [backup\_setting\_windows\_vss](#input\_backup\_setting\_windows\_vss) | Indicates whether to use Windows VSS for backups. Valid values: true, false. | `bool` | `false` | no |
| <a name="input_name"></a> [name](#input\_name) | The display name of a backup plan. | `string` | n/a | yes |
| <a name="input_rules"></a> [rules](#input\_rules) | A list of rules for the backup plan. A rule object specifies a scheduled task that is used to back up a selection of resources. Each rule must contain the following attributes:<br/>    - rule\_name: The name of the rule.<br/>    - schedule: A CRON expression specifying when AWS Backup initiates a backup job.<br/>    - completion\_window: The amount of time in minutes AWS Backup attempts a backup before canceling the job and returning an error.<br/>    - start\_window: The amount of time in minutes before beginning a backup.<br/>    - target\_vault\_name: The name of a logical container where backups are stored.<br/>    - delete\_after: Specifies the number of days after creation that a recovery point is deleted.<br/>    - recovery\_point\_tags: Metadata that you can assign to help organize the resources that you create. | <pre>list(object({<br/>    rule_name           = string<br/>    schedule            = string<br/>    completion_window   = number<br/>    start_window        = number<br/>    target_vault_name   = string<br/>    delete_after        = number<br/>    recovery_point_tags = map(string)<br/>  }))</pre> | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to assign to the backup plan. | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |

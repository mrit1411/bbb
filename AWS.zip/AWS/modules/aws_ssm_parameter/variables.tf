variable "name" {
  description = "Name of the parameter. If the name contains a path (e.g., any forward slashes (/)), it must be fully qualified with a leading forward slash (/)."
  type        = string
}

variable "type" {
  description = "Type of the parameter. Valid types are String, StringList and SecureString."
  type        = string
  default     = "String"

  validation {
    condition     = contains(["String", "StringList", "SecureString"], var.type)
    error_message = "Type must be one of String, StringList, or SecureString."
  }
}

variable "tier" {
  description = "Parameter tier to assign to the parameter. Valid tiers are Standard, Advanced, and Intelligent-Tiering. Downgrading an Advanced tier parameter to Standard will recreate the resource."
  type        = string

  validation {
    condition     = contains(["Standard", "Advanced", "Intelligent-Tiering"], var.tier)
    error_message = "Tier must be one of Standard, Advanced, or Intelligent-Tiering."
  }
}

variable "description" {
  description = "Description of the SSM parameter"
  type        = string

}

variable "parameter_file" {
  description = "File name of the SSM parameter file"
  type        = string

}
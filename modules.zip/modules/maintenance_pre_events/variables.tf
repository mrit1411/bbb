variable "maintenance_configs" {
  description = "Map of maintenance configurations to wire to Event Grid."
  type = map(object({
    id                  = string
    name                = string
    location            = string
    resource_group_name = string
  }))
}

variable "webhook_uri" {
  description = "The URI of the webhook to be used as the endpoint for Event Grid subscriptions."
  type        = string
}

variable "tags" {
  description = "Tags for the resources"
  type        = map(string)
}
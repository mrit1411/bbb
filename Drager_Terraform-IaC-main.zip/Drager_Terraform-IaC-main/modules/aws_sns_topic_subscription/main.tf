resource "aws_sns_topic_subscription" "ns_topic_subscription" {
  for_each  = toset(var.endpoint)
  topic_arn = var.topic_arn
  endpoint  = each.value
  protocol  = var.protocol
  region    = var.region
}
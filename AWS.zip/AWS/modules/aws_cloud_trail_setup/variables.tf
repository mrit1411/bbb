variable "bucket_name" {
  description = "The name of the S3 bucket where CloudTrail logs will be stored."
  type        = string
  default     = "cloudtrail-logs-akash"
}
variable "cloudtrail_name" {
  description = "The name of the CloudTrail trail."
  type        = string
  default     = "CCS-cloudtrail"

}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_backup_selection.backup_selection](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/backup_selection) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_iam_role_arn"></a> [iam\_role\_arn](#input\_iam\_role\_arn) | The ARN of the IAM role that AWS Backup uses to authenticate when restoring and backing up the target resource. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The display name of a backup selection. | `string` | n/a | yes |
| <a name="input_plan_id"></a> [plan\_id](#input\_plan\_id) | The backup plan ID to be associated with the selection of resources. | `string` | n/a | yes |
| <a name="input_selection_tags"></a> [selection\_tags](#input\_selection\_tags) | Tag-based conditions used to specify a set of resources to assign to a backup plan. The selection\_tag configuration block supports the following attributes:<br/>  - type: An operation, such as STRINGEQUALS, that is applied to the key-value pair used to filter resources in a selection.<br/>  - key: Key for the filter.<br/>  - value: Value for the filter. | <pre>list(object({<br/>    type  = string<br/>    key   = string<br/>    value = string<br/>  }))</pre> | n/a | yes |

## Outputs

No outputs.

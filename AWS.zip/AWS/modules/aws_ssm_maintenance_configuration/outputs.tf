output "window_id" {
  description = "The ID of the maintenance window."
  value       = aws_ssm_maintenance_window.ssm_maintenance_window.id
}

output "window_target_id" {
  description = "The ID of the maintenance window."
  value       = aws_ssm_maintenance_window_target.ssm_maintenance_window_target.id
}

output "webhook_uri" {
  value = azurerm_automation_webhook.patching_exclude_current_month_runbook_webhook.uri
}

# output "webhook_uri_sql" {
#   value = azurerm_automation_webhook.patching_exclude_sql_current_month_runbook_webhook.uri
# }

resource "aws_sqs_queue_policy" "sqs_queue_policy" {
  region = var.region
  queue_url = var.sqs_queue_url
  policy = var.policy_json
}
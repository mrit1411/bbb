output "id" {
  value = aws_backup_vault.backup_vault.id
}

# ARN of the vault. Used as destination_vault_arn when another region's
# backup plan copies recovery points into this vault (cross-region copy).
output "arn" {
  value = aws_backup_vault.backup_vault.arn
}

windows_server_patch_baseline_name        = "CCS-windows-server-patch-baseline"
windows_server_patch_baseline_description = "Windows patch baseline installing critical and security updates. Deployed as part of CCS Patching Solution."
windows_server_approve_after_days         = 1
windows_server_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["CriticalUpdates", "SecurityUpdates"]
  },
  {
    key    = "MSRC_SEVERITY"
    values = ["Critical", "Important"]
  }
]
windows_server_patch_group = "WindowsServerPatchGroup"

suse_linux_patch_baseline_name        = "CCS-suse-linux-patch-baseline"
suse_linux_patch_baseline_description = "SUSE patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
suse_linux_approve_after_days         = 1
suse_linux_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Recommended"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
suse_linux_patch_group = "SuseLinuxPatchGroup"

rhel_patch_baseline_name        = "CCS-rhel-patch-baseline"
rhel_patch_baseline_description = "RHEL patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
rhel_approve_after_days         = 1
rhel_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Bugfix"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
rhel_patch_group = "RhelPatchGroup"

ubuntu_patch_baseline_name        = "CCS-ubuntu-patch-baseline"
ubuntu_patch_baseline_description = "Ubuntu patch baseline installing important and required updates. Deployed as part of CCS Patching Solution."
ubuntu_approve_after_days         = 1
ubuntu_patch_filters = [
  {
    key    = "PRIORITY"
    values = ["Important", "Required"]
  }
]
ubuntu_patch_group = "UbuntuPatchGroup"

centos_patch_baseline_name        = "CCS-centos-patch-baseline"
centos_patch_baseline_description = "CentOS patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
centos_approve_after_days         = 1
centos_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Bugfix"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
centos_patch_group = "CentosPatchGroup"

debian_linux_patch_baseline_name        = "CCS-debian-linux-patch-baseline"
debian_linux_patch_baseline_description = "Debian patch baseline installing security updates. Deployed as part of CCS Patching Solution."
debian_linux_approve_after_days         = 1
debian_linux_patch_filters = [
  {
    key    = "PRIORITY"
    values = ["Important", "Required"]
  }
]
debian_linux_patch_group = "DebianLinuxPatchGroup"

oracle_linux_patch_baseline_name        = "CCS-oracle-linux-patch-baseline"
oracle_linux_patch_baseline_description = "Oracle Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
oracle_linux_approve_after_days         = 1
oracle_linux_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Bugfix"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
oracle_linux_patch_group = "OracleLinuxPatchGroup"

amazon_linux_patch_baseline_name        = "CCS-amazon-linux-patch-baseline"
amazon_linux_patch_baseline_description = "Amazon Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
amazon_linux_approve_after_days         = 1
amazon_linux_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Bugfix"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
amazon_linux_patch_group = "AmazonLinuxPatchGroup"

amazon_linux_2_patch_baseline_name        = "CCS-amazon-linux-2-patch-baseline"
amazon_linux_2_patch_baseline_description = "Amazon Linux 2 patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
amazon_linux_2_approve_after_days         = 1
amazon_linux_2_patch_filters = [
  {
    key    = "CLASSIFICATION"
    values = ["Security", "Bugfix"]
  },
  {
    key    = "SEVERITY"
    values = ["Critical", "Important"]
  }
]
amazon_linux_2_patch_group = "AmazonLinux2PatchGroup"

patch_report_generation_schedule_monthly = "cron(59 23 L * ? *)"
# patch_report_generation_schedule_monthly = "rate(5 minutes)"
patch_reports_bucket_name = "ccs-patch-reports"
regions = ["eu-west-1", "us-east-1", "ap-south-1", "us-east-2", "ap-southeast-1", "eu-central-1"]
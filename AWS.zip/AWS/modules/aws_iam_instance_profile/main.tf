resource "aws_iam_instance_profile" "instance_profile" {
  name = local.name
  role = var.role
}
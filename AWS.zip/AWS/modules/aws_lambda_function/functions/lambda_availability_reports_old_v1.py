
import boto3
import csv
import io
import os
from datetime import datetime, timedelta, timezone

PERIOD_SECONDS = 3600  # 1-hour buckets
STATUS_NAMESPACE = 'AWS/EC2'
STATUS_METRIC = 'StatusCheckFailed'

# Fetch S3 bucket name from environment variables
s3_destination_bucket = os.environ.get('S3_BUCKET')

def lambda_handler(event, context):
    # ---------------------------------------------
    # 1. Define Reporting Window: Previous Calendar Month (UTC)
    # ---------------------------------------------
    now_utc = datetime.now(timezone.utc)
    first_of_this_month = now_utc.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    month_end = first_of_this_month - timedelta(microseconds=1)
    first_of_last_month = (first_of_this_month - timedelta(days=1)).replace(day=1)
    month_start = first_of_last_month.replace(hour=0, minute=0, second=0, microsecond=0)

    # ---------------------------------------------
    # 2. Get AWS Account ID Dynamically
    # ---------------------------------------------
    sts = boto3.client('sts')
    account_id = sts.get_caller_identity()['Account']

    # ---------------------------------------------
    # 3. Get All Regions
    # ---------------------------------------------
    ec2_global = boto3.client('ec2')
    regions = [r['RegionName'] for r in ec2_global.describe_regions()['Regions']]

    report_rows = []

    # ---------------------------------------------
    # 4. Loop Through Regions and Instances
    # ---------------------------------------------
    for region in regions:
        ec2 = boto3.client('ec2', region_name=region)
        cloudwatch = boto3.client('cloudwatch', region_name=region)

        reservations = ec2.describe_instances()['Reservations']

        for reservation in reservations:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                name_tag = next(
                    (t['Value'] for t in instance.get('Tags', []) if t['Key'] == 'Name'),
                    instance_id
                )
                launch_time = instance['LaunchTime']  # timezone-aware (UTC)

                # Adjust window for instance launch time
                # window_start = max(launch_time, month_start)
                window_start = month_start
                window_end = month_end
                if window_end <= window_start:
                    continue

                # ---------------------------------------------
                # 5. Fetch CloudWatch Metrics (Hourly)
                # ---------------------------------------------
                metric = cloudwatch.get_metric_statistics(
                    Namespace=STATUS_NAMESPACE,
                    MetricName=STATUS_METRIC,
                    Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                    StartTime=window_start,
                    EndTime=window_end,
                    Period=PERIOD_SECONDS,
                    Statistics=['Maximum']
                )

                datapoints = metric.get('Datapoints', [])
                total_hours = len(datapoints)

                if total_hours == 0:
                    # No data for this instance in the window
                    report_rows.append([
                        region, name_tag, instance_id,
                        window_start.date(), window_end.date(),
                        0, 0, 0, 0.0, 0.0
                    ])
                    continue

                # ---------------------------------------------
                # 6. Calculate Up/Down Hours and Percentages
                # ---------------------------------------------
                up_hours = sum(1 for dp in datapoints if dp.get('Maximum', 1) == 0)
                down_hours = sum(1 for dp in datapoints if dp.get('Maximum', 0) > 0)

                up_pct = round((up_hours / total_hours) * 100, 2)
                down_pct = round((down_hours / total_hours) * 100, 2)

                report_rows.append([
                    region, name_tag, instance_id,
                    window_start.date(), window_end.date(),
                    total_hours,
                    up_hours,
                    down_hours,
                    up_pct,
                    down_pct
                ])

    # ---------------------------------------------
    # 7. Write CSV
    # ---------------------------------------------
    csv_buffer = io.StringIO()
    writer = csv.writer(csv_buffer)
    writer.writerow([
        'Region', 'VM Name', 'Instance ID',
        'Start Date', 'End Date',
        'Total Hours', 'Up Hours', 'Down Hours', 'Up %', 'Down %'
    ])
    writer.writerows(report_rows)

    # ---------------------------------------------
    # 8. Generate Timestamped Filename
    # ---------------------------------------------
    now_ts = datetime.now(timezone.utc)
    date_part = now_ts.strftime('%Y%m%d_%H%M')
    micro_part = f"{now_ts.microsecond:06d}"
    filename = f"availability-report-{account_id}-{date_part}.{micro_part}.csv"

    # ---------------------------------------------
    # 9. Upload to S3
    # ---------------------------------------------
    s3_client = boto3.client('s3')
    s3_client.put_object(Bucket=s3_destination_bucket, Key=filename, Body=csv_buffer.getvalue())

    return {
        'statusCode': 200,
        'body': f'Report generated and uploaded to s3://{s3_destination_bucket}/{filename}',
        'total_instances': len(report_rows),
        'window_start_utc': month_start.isoformat(),
        'window_end_utc': month_end.isoformat()
    }

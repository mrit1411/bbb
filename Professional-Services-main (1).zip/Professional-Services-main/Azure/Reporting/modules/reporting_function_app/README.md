﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_application_insights.application_insights](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights) | resource |
| [azurerm_service_plan.app_service_plan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |
| [azurerm_windows_function_app.reporting_function_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_function_app) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_blob_url"></a> [blob\_url](#input\_blob\_url) | The URL of the splunk integration function zip blob which should be used for this Windows Splunk Integration Function App. | `string` | n/a | yes |
| <a name="input_client_certificate_enabled"></a> [client\_certificate\_enabled](#input\_client\_certificate\_enabled) | Should the Splunk Integration Function App use Client Certificates. | `bool` | `false` | no |
| <a name="input_client_id"></a> [client\_id](#input\_client\_id) | Client ID of the Reporting Function UMI | `string` | n/a | yes |
| <a name="input_context"></a> [context](#input\_context) | The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_daily_memory_time_quota"></a> [daily\_memory\_time\_quota](#input\_daily\_memory\_time\_quota) | The amount of memory in gigabyte-seconds that your application is allowed to consume per day. Setting this value only affects Splunk Integration Function Apps under the consumption plan. | `number` | `0` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_functions_extension_version"></a> [functions\_extension\_version](#input\_functions\_extension\_version) | The version of the Azure Functions runtime to use. | `string` | `"~4"` | no |
| <a name="input_https_only"></a> [https\_only](#input\_https\_only) | Can the Splunk Integration Function App only be accessed via HTTPS?. | `bool` | `false` | no |
| <a name="input_index"></a> [index](#input\_index) | The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure Region where the Windows Splunk Integration Function App should exist. Changing this forces a new Windows Splunk Integration Function App to be created. | `string` | n/a | yes |
| <a name="input_maximum_elastic_worker_count"></a> [maximum\_elastic\_worker\_count](#input\_maximum\_elastic\_worker\_count) | The maximum number of workers that can be allocated to this App Service Plan. | `number` | `1` | no |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_per_site_scaling_enabled"></a> [per\_site\_scaling\_enabled](#input\_per\_site\_scaling\_enabled) | Enabled? | `string` | `"true"` | no |
| <a name="input_powershell_core_version"></a> [powershell\_core\_version](#input\_powershell\_core\_version) | The version of PowerShell Core to use. | `string` | `"7.4"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the Windows Splunk Integration Function App should exist. Changing this forces a new Windows Splunk Integration Function App to be created. | `string` | n/a | yes |
| <a name="input_service_plan_os_type"></a> [service\_plan\_os\_type](#input\_service\_plan\_os\_type) | The operating system type of the Splunk Integration App Service Plan. Changing this forces a new Service Plan to be created. | `string` | `"Windows"` | no |
| <a name="input_service_plan_sku_name"></a> [service\_plan\_sku\_name](#input\_service\_plan\_sku\_name) | The SKU name of the Splunk Integration App Service Plan. | `string` | `"Y1"` | no |
| <a name="input_storage_account_access_key"></a> [storage\_account\_access\_key](#input\_storage\_account\_access\_key) | The access key which will be used to access the backend storage account for the Splunk Integration Function App. Conflicts with storage\_uses\_managed\_identity. | `string` | n/a | yes |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | The backend storage account name which will be used by this Splunk Integration Function App. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | n/a | yes |
| <a name="input_user_assigned_identity_ids"></a> [user\_assigned\_identity\_ids](#input\_user\_assigned\_identity\_ids) | The list of user assigned identity IDs to assign to the Splunk Integration Function App. Changing this forces a new Windows Splunk Integration Function App to be created. | `list(string)` | n/a | yes |
| <a name="input_user_assigned_identity_resource_id"></a> [user\_assigned\_identity\_resource\_id](#input\_user\_assigned\_identity\_resource\_id) | The resource ID of the user assigned identity to assign to the Splunk Integration Function App. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_function_app_id"></a> [function\_app\_id](#output\_function\_app\_id) | The ID of the Azure Function App |
| <a name="output_function_app_principal_id"></a> [function\_app\_principal\_id](#output\_function\_app\_principal\_id) | The principal ID for the Azure service principal |
| <a name="output_service_plan_id"></a> [service\_plan\_id](#output\_service\_plan\_id) | The ID of the App Service Plan. |

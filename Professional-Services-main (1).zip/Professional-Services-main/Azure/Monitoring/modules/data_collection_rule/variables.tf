variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}

variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment)
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "resource_group_name" {
  description = "The name of the Resource Group where the Data Collection Rule should exist. Changing this forces a new Data Collection Rule to be created."
  type        = string
}

variable "location" {
  description = "The Azure Region where the Data Collection Rule should exist. Changing this forces a new Data Collection Rule to be created."
  type        = string

  validation {
    condition     = contains(["norwayeast", "westeurope", "swedencentral"], var.location)
    error_message = "The supplied value is not in the accepted region list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "description" {
  description = "The description of the data collection rule."
  type        = string
}

variable "destination_log_analytics_workspace_name" {
  description = "The name of the Log Analytics workspace to which the data collection rule will send data.This name should be unique across all destinations regardless of type within the Data Collection Rule."
  type        = string
}

variable "workspace_resource_id" {
  description = "The resource ID of the Log Analytics workspace to which the data collection rule will send data."
  type        = string
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "data_sources" {
  description = "A list of data sources to be collected by the data collection rule."
  type = list(object({
    name                          = string
    type                          = string
    streams                       = list(string)
    sampling_frequency_in_seconds = optional(number)
    counter_specifiers = optional(list(string))
    x_path_queries = optional(list(string))
  }))

  default = [
    {
      name                          = "vm_perf_data_source"
      type                          = "performance_counter"
      streams                       = ["Microsoft-InsightsMetrics"]
      sampling_frequency_in_seconds = 60
      counter_specifiers            = ["\\VmInsights\\DetailedMetrics"]
    }
  ]
}

variable "data_flows" {
  description = "A list of data flows to be defined by the data collection rule."
  type = list(object({
    streams       = list(string)
    output_stream = optional(string)
    transform_kql = optional(string)
  }))

  default = [
    {
      streams       = ["Microsoft-InsightsMetrics"]
      output_stream = null
      transform_kql = null
    }
  ]
}
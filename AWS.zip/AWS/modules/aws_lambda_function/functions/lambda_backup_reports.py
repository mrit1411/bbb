import csv
import json
import os
import boto3
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from botocore.config import Config

backup_client = boto3.client('backup')
sns_client = boto3.client('sns')
rgsa_client = boto3.client('resourcegroupstaggingapi')

s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic_arn = os.environ.get('SNS_TOPIC_ARN')
backup_reporting_key = os.environ.get('BACKUP_REPORTING_KEY')
backup_reporting_value = os.environ.get('BACKUP_REPORTING_VALUE')

def lambda_handler(event, context):
    reporting_period = event['ReportingPeriod'][0]
    secret_response = json.loads(get_secret())
    s3_client = boto3.client("s3", config=Config(signature_version='s3v4'),
                         region_name=os.environ.get("AWS_REGION"),
                         aws_access_key_id=secret_response["ACCESS_KEY"],
                         aws_secret_access_key=secret_response["SECRET_KEY"])

    if reporting_period == "Yesterday":
        start_time = datetime.combine(datetime.today() - timedelta(days=1), datetime.min.time())
        end_time = datetime.combine(datetime.today() - timedelta(days=1), datetime.max.time())
    elif reporting_period == "LastWeek":
        start_time = datetime.combine(datetime.today() - timedelta(days=datetime.today().weekday(), weeks=1), datetime.min.time())
        end_time = datetime.combine(start_time + timedelta(days=6), datetime.max.time())
    elif reporting_period == "BeginningOfTheMonth":
        start_time = datetime.combine(datetime.today().replace(day=1), datetime.min.time())
        end_time = datetime.combine(datetime.today(), datetime.max.time())
    elif reporting_period == "BeginningOfTheYear":
        start_time = datetime.combine(datetime.today().replace(month=1, day=1), datetime.min.time())
        end_time = datetime.combine(datetime.today(), datetime.max.time())
    elif reporting_period == "CustomPeriod":
        start_time = datetime.combine(datetime.strptime(event['BackupPeriodStart'], '%Y-%m-%d'), datetime.min.time())
        end_time = datetime.combine(datetime.strptime(event['BackupPeriodEnd'], '%Y-%m-%d'), datetime.max.time())
    print("Creating report for period between " + str(start_time) + " and " + str(end_time))

    fieldnames = ["Policy", "BackupVaultName", "State", "CreationDate", "CompletionDate", "ResourceArn", "ResourceType", "ResourceName"]
    filename = "backup-report-" + context.invoked_function_arn.split(":")[3] + "-" + context.invoked_function_arn.split(":")[4] + "-" + reporting_period + "-" + datetime.today().strftime("%Y%m%d_%H%M.%f") + ".csv"

    try:
        with open('/tmp/file.csv', 'w+') as temp_file:
            csvdata = csv.DictWriter(temp_file, fieldnames=fieldnames, extrasaction='ignore')
            csvdata.writeheader()
            csvdata.writerows(get_backup_jobs(backup_client, rgsa_client, backup_reporting_key, backup_reporting_value, start_time, end_time))
            print("Report file name: " + filename)
    except Exception as e:
            print("Error preparing csv report: %s" % e)

    try:
        print("Upload report to S3 bucket: " + s3_destination_bucket)
        s3_client.upload_file("/tmp/file.csv", s3_destination_bucket, filename)

        print("Generate URL link to backup reports")
        presigned_url = s3_client.generate_presigned_url('get_object',  Params={'Bucket': s3_destination_bucket, 'Key': filename}, ExpiresIn=s3_presigned_link_expiration)
        print("Send message")
        sns_client.publish(TargetArn=s3_sns_topic_arn, Message="Link to backup reports (link is valid for " + str(int(int(s3_presigned_link_expiration)/3600)) + " hours): " + presigned_url, MessageStructure='string' )
    except ClientError as e:
        print("Unexpected error: %s" % e)

    return 0

def get_backup_jobs(backup_client, rgsa_client, backup_reporting_key, backup_reporting_value, start_time, end_time):
    valut_list = rgsa_client.get_resources(
        TagFilters=[{'Key': backup_reporting_key, 'Values': [backup_reporting_value]}],
        ResourceTypeFilters=['backup:backup-vault']
    )
    for vault in valut_list['ResourceTagMappingList']:
        backup_response = backup_client.list_backup_jobs(ByBackupVaultName=vault['ResourceARN'].split(":")[6], ByCreatedAfter=start_time, ByCreatedBefore=end_time)
        try:
            backuplist += backup_response['BackupJobs']
        except NameError:
            backuplist = []
            backuplist += backup_response['BackupJobs']
        for ind, row in enumerate(backuplist):
            if 'CreatedBy' in row:
                backup_plan = backup_client.get_backup_plan(
                    BackupPlanId=row['CreatedBy']['BackupPlanId'],
                    VersionId=row['CreatedBy']['BackupPlanVersion']
                )
                backuplist[ind]['Policy'] = backup_plan['BackupPlan']['BackupPlanName']
            if row['ResourceType'] == "RDS":
                backuplist[ind]['InstanceName'] = row['ResourceArn'].split(":")[6]
            else:
                resourceid = row['ResourceArn'].split("/")[1]
                backuplist[ind]['ResourceName'] = get_resource_name(resourceid)
    return backuplist

def get_secret():
    region_name = os.environ.get("AWS_REGION")
    secret_name = f"cos-backup-user-{region_name}"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        return get_secret_value_response['SecretString']
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e

def get_resource_name(resourceid):
    ec2_client = boto3.client('ec2')
    efs_client = boto3.client('efs')
    
    resource_name = 'resource not named'
    try:
        resource_type = resourceid.split('-')[0]
        if resource_type == 'i':
            response = ec2_client.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [resourceid]
                    },
                    {
                        'Name': 'key',
                        'Values': ["Name"]
                    }
                ]
            )
            for Tag in response['Tags']:
                if Tag['Key'] == 'Name':
                    resource_name = Tag['Value']
        elif resource_type == 'vol':
            response=ec2_client.describe_volumes(Filters=[
                    {
                        'Name': 'tag-key',
                        'Values': ["Name"]
                    }
                ],
                VolumeIds = [resourceid,])
            for Tag in response['Volumes'][0]['Tags']:
                if Tag['Key'] == 'Name':
                    resource_name = Tag['Value']
        elif resource_type == 'fs':
            response = efs_client.describe_file_systems(
                FileSystemId = resourceid)
            for Tag in response['FileSystems'][0]['Tags']:
                if Tag['Key'] == 'Name':
                    resource_name = Tag['Value']
    except IndexError as e:
        print('Resource not named')
    finally:
        return resource_name
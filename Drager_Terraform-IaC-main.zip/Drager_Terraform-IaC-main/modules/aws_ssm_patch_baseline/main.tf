resource "aws_ssm_patch_baseline" "ssm_patch_baseline" {
  for_each                          = { for baseline in var.patch_baseline : baseline.name => baseline }
  name                              = each.value.name
  operating_system                  = each.value.os
  description                       = each.value.description
  region                            = var.region
  approved_patches_compliance_level = "MEDIUM"
  approved_patches                  = try(each.value.approved_patches, null)

  dynamic "approval_rule" {
    for_each = try(each.value.approval_rules[*], [])
    content {
      approve_after_days = approval_rule.value.approve_after_days
      compliance_level   = "MEDIUM"

      dynamic "patch_filter" {
        for_each = try(approval_rule.value.patch_filters[*], [])
        content {
          key    = patch_filter.value.key
          values = patch_filter.value.values
        }
      }
    }
  }
}


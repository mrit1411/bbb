variable "region" {
  description = "The AWS region where the SQS queue will be created."
  type        = string
  default = "us-east-1"
}

variable "name" {
  description = "The name of the SQS queue."
  type        = string
  
}
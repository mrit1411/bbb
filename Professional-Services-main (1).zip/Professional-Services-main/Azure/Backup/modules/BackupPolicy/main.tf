resource "azurerm_backup_policy_vm" "standard_backup_policy" {

  for_each = var.create_standard_policy ? var.resource_group_name_map : {}
  # count = var.standard_policy != null ? 1 : 0
  name                           = var.standard_policy_name
  resource_group_name            = each.value
  recovery_vault_name            = "${var.recovery_vault_name_prefix}${lower(each.key)}"
  timezone                       = coalesce(try(var.standard_policy.timezone, null), "UTC")
  instant_restore_retention_days = try(var.standard_policy.instant_restore_retention_days, null)
  policy_type                    = var.standard_backup_policy_type
  backup {
    frequency = var.standard_policy.schedule_frequency # "Daily" or "Weekly"
    time      = var.standard_policy.schedule_time      # "HH:mm"
    weekdays  = var.standard_policy.schedule_frequency == "Weekly" ? try(var.standard_policy.weekdays, null) : null
  }

  dynamic "retention_daily" {
    for_each = try(var.standard_policy.retention_daily, null) != null ? [1] : []
    content {
      count = var.standard_policy.retention_daily
    }
  }

  dynamic "retention_weekly" {
    for_each = try(var.standard_policy.retention_weekly, null) != null ? [1] : []
    content {
      count    = var.standard_policy.retention_weekly.count
      weekdays = var.standard_policy.retention_weekly.weekdays
    }
  }

  dynamic "retention_monthly" {
    for_each = try(var.standard_policy.retention_monthly, null) != null ? [1] : []
    content {
      count    = var.standard_policy.retention_monthly.count
      weeks    = try(var.standard_policy.retention_monthly.weeks, null)
      weekdays = try(var.standard_policy.retention_monthly.weekdays, null)
      days     = try(var.standard_policy.retention_monthly.days, null)
    }
  }

  dynamic "retention_yearly" {
    for_each = try(var.standard_policy.retention_yearly, null) != null ? [1] : []
    content {
      count    = var.standard_policy.retention_yearly.count
      months   = var.standard_policy.retention_yearly.months
      weeks    = try(var.standard_policy.retention_yearly.weeks, null)
      weekdays = try(var.standard_policy.retention_yearly.weekdays, null)
      days     = try(var.standard_policy.retention_yearly.days, null)
    }
  }
}


resource "azurerm_backup_policy_vm" "enhanced_backup_policy" {

  for_each = var.create_enhanced_policy ? var.resource_group_name_map : {}
  # count = var.enhanced_policy != null ? 1 : 0
  name                           = var.enhanced_policy_name
  resource_group_name            = each.value
  recovery_vault_name            = "${var.recovery_vault_name_prefix}${lower(each.key)}"
  timezone                       = coalesce(try(var.enhanced_policy.timezone, null), "UTC")
  instant_restore_retention_days = try(var.enhanced_policy.instant_restore_retention_days, null)
  policy_type                    = var.enhanced_backup_policy_type
  backup {
    frequency     = var.enhanced_policy.schedule_frequency                                                                   # "Daily" or "Weekly"
    time          = var.enhanced_policy.schedule_time                                                                        # "HH:mm"
    hour_interval = var.enhanced_policy.schedule_frequency == "Hourly" ? try(var.enhanced_policy.hour_interval, null) : null # Added new line
    hour_duration = var.enhanced_policy.schedule_frequency == "Hourly" ? try(var.enhanced_policy.hour_duration, null) : null # added new line
    weekdays      = var.enhanced_policy.schedule_frequency == "Weekly" ? try(var.enhanced_policy.weekdays, null) : null
  }

  dynamic "retention_daily" {
    for_each = try(var.enhanced_policy.retention_daily, null) != null ? [1] : []
    content {
      count = var.enhanced_policy.retention_daily
    }
  }

  dynamic "retention_weekly" {
    for_each = try(var.enhanced_policy.retention_weekly, null) != null ? [1] : []
    content {
      count    = var.enhanced_policy.retention_weekly.count
      weekdays = var.enhanced_policy.retention_weekly.weekdays
    }
  }

  dynamic "retention_monthly" {
    for_each = try(var.enhanced_policy.retention_monthly, null) != null ? [1] : []
    content {
      count    = var.enhanced_policy.retention_monthly.count
      weeks    = try(var.enhanced_policy.retention_monthly.weeks, null)
      weekdays = try(var.enhanced_policy.retention_monthly.weekdays, null)
      days     = try(var.enhanced_policy.retention_monthly.days, null)
    }
  }

  dynamic "retention_yearly" {
    for_each = try(var.enhanced_policy.retention_yearly, null) != null ? [1] : []
    content {
      count    = var.enhanced_policy.retention_yearly.count
      months   = var.enhanced_policy.retention_yearly.months
      weeks    = try(var.enhanced_policy.retention_yearly.weeks, null)
      weekdays = try(var.enhanced_policy.retention_yearly.weekdays, null)
      days     = try(var.enhanced_policy.retention_yearly.days, null)
    }
  }
}

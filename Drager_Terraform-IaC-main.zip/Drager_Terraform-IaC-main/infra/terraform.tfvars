snow_secret_arn = { "eu-central-1" : "arn:aws:secretsmanager:eu-central-1:626717216171:secret:ccs-Draeger-Transition-snow-eu-central-1-lyB332",
  "eu-west-2" : "arn:aws:secretsmanager:eu-west-2:626717216171:secret:ccs-Draeger-Transition-snow-eu-west-2-qFTMDH",
  "us-east-1" : "arn:aws:secretsmanager:us-east-1:626717216171:secret:ccs-Draeger-Transition-snow-us-east-1-GQTpra",
"ap-east-1" : "arn:aws:secretsmanager:ap-east-1:626717216171:secret:ccs-Draeger-Transition-snow-ap-east-1-kFd8ko" }
api_company_name = "testcompany"
regions          = ["eu-central-1", "eu-west-2", "us-east-1", "ap-east-1"]
variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}

variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment) # self hosted non production
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "location" {
  description = "The location of the Splunk Integration Key Vault. Changing this forces a new resource to be created."
  type        = string

  validation {
    condition     = contains(["norwayeast", "westeurope", "swedencentral"], var.location)
    error_message = "The supplied value is not in the accepted region list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "resource_group_name" {
  description = "The name of the resource group in which to create the Splunk Integration Key Vault. Changing this forces a new resource to be created."
  type        = string
}

variable "sku_name" {
  description = "The SKU name of the Splunk Integration Key Vault."
  type        = string
  default     = "standard"

  validation {
    condition     = contains(["standard", "premium"], var.sku_name)
    error_message = "sku_name must be either standard or premium. ${var.sku_name} does not fit."
  }
}

variable "tenant_id" {
  description = "The Azure Active Directory tenant ID that should be used for authenticating requests to the Splunk Integration Key Vault."
  type        = string
}

variable "object_id" {
  description = "The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault. The object ID must be unique for the list of access policies."
  type        = string
}

variable "vm_mi_object_id" {
  description = "The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault. The object ID must be unique for the list of access policies."
  type        = string
}

variable "enabled_for_deployment" {
  description = "Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault."
  type        = bool
  default     = true
}

variable "enabled_for_disk_encryption" {
  description = "Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys."
  type        = bool
  default     = true
}

variable "enabled_for_template_deployment" {
  description = "Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault."
  type        = bool
  default     = true
}

variable "enable_rbac_authorization" {
  type        = bool
  default     = true
  description = "(Optional) Use RBAC access control for the key vault. Defaults to true"
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(string)
}

# PROD Environment variables for Splunk Integration Key Vault

variable "splunk_integration_prod_client_id_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client ID. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_prod_client_id_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client ID. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "splunk_integration_prod_client_secret_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client secret. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_prod_client_secret_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client secret. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

# TEST Environment variables for Splunk Integration Key Vault

variable "splunk_integration_test_client_id_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client ID. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_test_client_id_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client ID. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "splunk_integration_test_client_secret_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client secret. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_test_client_secret_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client secret. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "public_network_access_enabled" {
  type        = bool
  default     = null
  description = "(Optional) Boolean flag to specify whether the key vault is reachable without a private endpoint."
}

variable "network_acl_bypass" {
  type        = string
  default     = "None"
  description = "Specifies which traffic can bypass the network rules. Possible values are AzureServices and None"

  validation {
    condition     = contains(["None", "AzureServices"], var.network_acl_bypass)
    error_message = "network_acl_buypass is not a valid entry. Possible values are AzureServices and None"
  }
}

variable "network_acl_default_action" {
  type        = string
  default     = "Deny"
  description = "The Default Action to use when no rules match from network_acl_ip_rules / network_acl_virtual_network_subnet_ids. Possible values are Allow and Deny"

  validation {
    condition     = contains(["Allow", "Deny"], var.network_acl_default_action)
    error_message = "network_acl_default_action is not a valid entry. Possible values are Allow and Deny"
  }
}

variable "network_acl_ip_rules" {
  type        = list(string)
  default     = []
  description = "The list of allowed ips"
}

variable "network_acl_virtual_network_subnet_ids" {
  type        = list(string)
  default     = ["/subscriptions/d1cde075-76c2-413c-a703-5228ccbab1fa/resourceGroups/acf-p-noe-Network-01-org-rg/providers/Microsoft.Network/virtualNetworks/ps-p-noe-01-org-vnt/subnets/platformsvcs-snt"]
  description = "The list of allowed subnet ids"
}

variable "soft_delete_retention_days" {
  type        = number
  default     = 7
  description = "The number of days to retain deleted objects, must be between 7 and 90 days."

  validation {
    condition     = var.soft_delete_retention_days >= 7
    error_message = "Soft delete must be greater than or equal to 7 days"
  }
  validation {
    condition     = var.soft_delete_retention_days <= 90
    error_message = "Soft delete must be less than or equal to 90 days"
  }
}

variable "purge_protection_enabled" {
  type        = bool
  description = "Should the key vault be purge protected. NB! Can not remove purge protection after being enabled."
  default     = false
}

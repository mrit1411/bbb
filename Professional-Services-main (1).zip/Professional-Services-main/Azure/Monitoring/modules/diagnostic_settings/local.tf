locals {
  # diagnostic_setting = csvdecode(file(var.diagnostic_settings_csv_path))
  diagnostic_settings = {}
}

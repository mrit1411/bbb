{
    "Reservations": [
        {
            "ReservationId": "r-0a8fd473ce75e1d13",
            "OwnerId": "471112573064",
            "Groups": [],
            "Instances": [
                {
                    "Architecture": "x86_64",
                    "BlockDeviceMappings": [
                        {
                            "DeviceName": "/dev/sda1",
                            "Ebs": {
                                "AttachTime": "2025-07-09 14:18:07+00:00",
                                "DeleteOnTermination": true,
                                "Status": "attached",
                                "VolumeId": "vol-02df0b5ef4d140567"
                            }
                        }
                    ],
                    "ClientToken": "39051ad6-e301-4eea-b8a4-8c94b6297fca",
                    "EbsOptimized": true,
                    "EnaSupport": true,
                    "Hypervisor": "xen",
                    "IamInstanceProfile": {
                        "Arn": "arn:aws:iam::471112573064:instance-profile/EC2-Access-Role",
                        "Id": "AIPAW3MD7MCEFG3NHX4YR"
                    },
                    "NetworkInterfaces": [
                        {
                            "Attachment": {
                                "AttachTime": "2025-07-09 14:18:06+00:00",
                                "AttachmentId": "eni-attach-0f737243d3c43b66d",
                                "DeleteOnTermination": true,
                                "DeviceIndex": 0,
                                "Status": "attached",
                                "NetworkCardIndex": 0
                            },
                            "Description": "",
                            "Groups": [
                                {
                                    "GroupId": "sg-071c61ea367294cb5",
                                    "GroupName": "launch-wizard-2"
                                }
                            ],
                            "Ipv6Addresses": [],
                            "MacAddress": "0a:ff:da:56:03:81",
                            "NetworkInterfaceId": "eni-053a9ce314e96de14",
                            "OwnerId": "471112573064",
                            "PrivateDnsName": "ip-172-31-22-53.ec2.internal",
                            "PrivateIpAddress": "172.31.22.53",
                            "PrivateIpAddresses": [
                                {
                                    "Primary": true,
                                    "PrivateDnsName": "ip-172-31-22-53.ec2.internal",
                                    "PrivateIpAddress": "172.31.22.53"
                                }
                            ],
                            "SourceDestCheck": true,
                            "Status": "in-use",
                            "SubnetId": "subnet-037461bea7780c8b1",
                            "VpcId": "vpc-03e5c5fc93e620ede",
                            "InterfaceType": "interface",
                            "Operator": {
                                "Managed": false
                            }
                        }
                    ],
                    "RootDeviceName": "/dev/sda1",
                    "RootDeviceType": "ebs",
                    "SecurityGroups": [
                        {
                            "GroupId": "sg-071c61ea367294cb5",
                            "GroupName": "launch-wizard-2"
                        }
                    ],
                    "SourceDestCheck": true,
                    "StateReason": {
                        "Code": "Client.UserInitiatedShutdown",
                        "Message": "Client.UserInitiatedShutdown: User initiated shutdown"
                    },
                    "Tags": [
                        {
                            "Key": "ccs_managed",
                            "Value": "yes"
                        },
                        {
                            "Key": "Name",
                            "Value": "terraform-vm"
                        },
                        {
                            "Key": "Backup",
                            "Value": "true"
                        }
                    ],
                    "VirtualizationType": "hvm",
                    "CpuOptions": {
                        "CoreCount": 1,
                        "ThreadsPerCore": 2
                    },
                    "CapacityReservationSpecification": {
                        "CapacityReservationPreference": "open"
                    },
                    "HibernationOptions": {
                        "Configured": false
                    },
                    "MetadataOptions": {
                        "State": "applied",
                        "HttpTokens": "required",
                        "HttpPutResponseHopLimit": 2,
                        "HttpEndpoint": "enabled",
                        "HttpProtocolIpv6": "disabled",
                        "InstanceMetadataTags": "disabled"
                    },
                    "EnclaveOptions": {
                        "Enabled": false
                    },
                    "BootMode": "uefi-preferred",
                    "PlatformDetails": "Linux/UNIX",
                    "UsageOperation": "RunInstances",
                    "UsageOperationUpdateTime": "2025-07-09 14:18:06+00:00",
                    "PrivateDnsNameOptions": {
                        "HostnameType": "ip-name",
                        "EnableResourceNameDnsARecord": true,
                        "EnableResourceNameDnsAAAARecord": false
                    },
                    "MaintenanceOptions": {
                        "AutoRecovery": "default",
                        "RebootMigration": "default"
                    },
                    "CurrentInstanceBootMode": "uefi",
                    "NetworkPerformanceOptions": {
                        "BandwidthWeighting": "default"
                    },
                    "Operator": {
                        "Managed": false
                    },
                    "InstanceId": "i-0d32f032db70972d7",
                    "ImageId": "ami-0a7d80731ae1b2435",
                    "State": {
                        "Code": 80,
                        "Name": "stopped"
                    },
                    "PrivateDnsName": "ip-172-31-22-53.ec2.internal",
                    "PublicDnsName": "",
                    "StateTransitionReason": "User initiated (2025-08-25 12:31:56 GMT)",
                    "KeyName": "terraform-vm-key",
                    "AmiLaunchIndex": 0,
                    "ProductCodes": [],
                    "InstanceType": "t3.small",
                    "LaunchTime": "2025-07-09 14:18:06+00:00",
                    "Placement": {
                        "AvailabilityZoneId": "use1-az4",
                        "GroupName": "",
                        "Tenancy": "default",
                        "AvailabilityZone": "us-east-1d"
                    },
                    "Monitoring": {
                        "State": "disabled"
                    },
                    "SubnetId": "subnet-037461bea7780c8b1",
                    "VpcId": "vpc-03e5c5fc93e620ede",
                    "PrivateIpAddress": "172.31.22.53"
                }
            ]
        },
        {
            "ReservationId": "r-0c5b722316e4d3190",
            "OwnerId": "471112573064",
            "Groups": [],
            "Instances": [
                {
                    "Architecture": "x86_64",
                    "BlockDeviceMappings": [
                        {
                            "DeviceName": "/dev/sda1",
                            "Ebs": {
                                "AttachTime": "2025-09-27 07:11:45+00:00",
                                "DeleteOnTermination": true,
                                "Status": "attached",
                                "VolumeId": "vol-0e2067d10bf7075db"
                            }
                        }
                    ],
                    "ClientToken": "terraform-20250927071143512000000002",
                    "EbsOptimized": false,
                    "EnaSupport": true,
                    "Hypervisor": "xen",
                    "IamInstanceProfile": {
                        "Arn": "arn:aws:iam::471112573064:instance-profile/CCSEC2InstanceProfileforSSMManagement-us-east-1",
                        "Id": "AIPAW3MD7MCEGD3BSGO6X"
                    },
                    "NetworkInterfaces": [
                        {
                            "Association": {
                                "IpOwnerId": "amazon",
                                "PublicDnsName": "ec2-3-92-56-209.compute-1.amazonaws.com",
                                "PublicIp": "3.92.56.209"
                            },
                            "Attachment": {
                                "AttachTime": "2025-09-27 07:11:44+00:00",
                                "AttachmentId": "eni-attach-00928521ea75d8acb",
                                "DeleteOnTermination": true,
                                "DeviceIndex": 0,
                                "Status": "attached",
                                "NetworkCardIndex": 0
                            },
                            "Description": "",
                            "Groups": [
                                {
                                    "GroupId": "sg-0702ffb92ed1e94ab",
                                    "GroupName": "default"
                                }
                            ],
                            "Ipv6Addresses": [],
                            "MacAddress": "0a:ff:fa:f8:2e:95",
                            "NetworkInterfaceId": "eni-08f35ff68a0aaed50",
                            "OwnerId": "471112573064",
                            "PrivateDnsName": "ip-172-31-16-25.ec2.internal",
                            "PrivateIpAddress": "172.31.16.25",
                            "PrivateIpAddresses": [
                                {
                                    "Association": {
                                        "IpOwnerId": "amazon",
                                        "PublicDnsName": "ec2-3-92-56-209.compute-1.amazonaws.com",
                                        "PublicIp": "3.92.56.209"
                                    },
                                    "Primary": true,
                                    "PrivateDnsName": "ip-172-31-16-25.ec2.internal",
                                    "PrivateIpAddress": "172.31.16.25"
                                }
                            ],
                            "SourceDestCheck": true,
                            "Status": "in-use",
                            "SubnetId": "subnet-037461bea7780c8b1",
                            "VpcId": "vpc-03e5c5fc93e620ede",
                            "InterfaceType": "interface",
                            "Operator": {
                                "Managed": false
                            }
                        }
                    ],
                    "RootDeviceName": "/dev/sda1",
                    "RootDeviceType": "ebs",
                    "SecurityGroups": [
                        {
                            "GroupId": "sg-0702ffb92ed1e94ab",
                            "GroupName": "default"
                        }
                    ],
                    "SourceDestCheck": true,
                    "Tags": [
                        {
                            "Key": "ccs_dependency_type",
                            "Value": "dependency"
                        },
                        {
                            "Key": "Name",
                            "Value": "ccs-windows-test"
                        },
                        {
                            "Key": "ccs_backup",
                            "Value": "yes"
                        },
                        {
                            "Key": "Patch Group",
                            "Value": "windows_default"
                        },
                        {
                            "Key": "ccs_managed",
                            "Value": "yes"
                        }
                    ],
                    "VirtualizationType": "hvm",
                    "CpuOptions": {
                        "CoreCount": 1,
                        "ThreadsPerCore": 2
                    },
                    "CapacityReservationSpecification": {
                        "CapacityReservationPreference": "open"
                    },
                    "HibernationOptions": {
                        "Configured": false
                    },
                    "MetadataOptions": {
                        "State": "applied",
                        "HttpTokens": "required",
                        "HttpPutResponseHopLimit": 2,
                        "HttpEndpoint": "enabled",
                        "HttpProtocolIpv6": "disabled",
                        "InstanceMetadataTags": "disabled"
                    },
                    "EnclaveOptions": {
                        "Enabled": false
                    },
                    "BootMode": "uefi",
                    "PlatformDetails": "Windows",
                    "UsageOperation": "RunInstances:0002",
                    "UsageOperationUpdateTime": "2025-09-27 07:11:44+00:00",
                    "PrivateDnsNameOptions": {
                        "HostnameType": "ip-name",
                        "EnableResourceNameDnsARecord": false,
                        "EnableResourceNameDnsAAAARecord": false
                    },
                    "MaintenanceOptions": {
                        "AutoRecovery": "default",
                        "RebootMigration": "default"
                    },
                    "CurrentInstanceBootMode": "uefi",
                    "NetworkPerformanceOptions": {
                        "BandwidthWeighting": "default"
                    },
                    "Operator": {
                        "Managed": false
                    },
                    "InstanceId": "i-0fc6eded37c4cd3fe",
                    "ImageId": "ami-0e3c2921641a4a215",
                    "State": {
                        "Code": 16,
                        "Name": "running"
                    },
                    "PrivateDnsName": "ip-172-31-16-25.ec2.internal",
                    "PublicDnsName": "ec2-3-92-56-209.compute-1.amazonaws.com",
                    "StateTransitionReason": "",
                    "KeyName": "ccs_windows_test_key_pair",
                    "AmiLaunchIndex": 0,
                    "ProductCodes": [],
                    "InstanceType": "t3.micro",
                    "LaunchTime": "2025-09-27 07:11:44+00:00",
                    "Placement": {
                        "AvailabilityZoneId": "use1-az4",
                        "GroupName": "",
                        "Tenancy": "default",
                        "AvailabilityZone": "us-east-1d"
                    },
                    "Platform": "windows",
                    "Monitoring": {
                        "State": "disabled"
                    },
                    "SubnetId": "subnet-037461bea7780c8b1",
                    "VpcId": "vpc-03e5c5fc93e620ede",
                    "PrivateIpAddress": "172.31.16.25",
                    "PublicIpAddress": "3.92.56.209"
                }
            ]
        },
        {
            "ReservationId": "r-001bedc5715376e36",
            "OwnerId": "471112573064",
            "Groups": [],
            "Instances": [
                {
                    "Architecture": "x86_64",
                    "BlockDeviceMappings": [
                        {
                            "DeviceName": "/dev/sda1",
                            "Ebs": {
                                "AttachTime": "2025-09-27 07:11:35+00:00",
                                "DeleteOnTermination": true,
                                "Status": "attached",
                                "VolumeId": "vol-04c5931b3221a4ae9"
                            }
                        }
                    ],
                    "ClientToken": "terraform-20250927071133233600000001",
                    "EbsOptimized": false,
                    "EnaSupport": true,
                    "Hypervisor": "xen",
                    "IamInstanceProfile": {
                        "Arn": "arn:aws:iam::471112573064:instance-profile/CCSEC2InstanceProfileforSSMManagement-us-east-1",
                        "Id": "AIPAW3MD7MCEGD3BSGO6X"
                    },
                    "NetworkInterfaces": [
                        {
                            "Association": {
                                "IpOwnerId": "amazon",
                                "PublicDnsName": "ec2-18-207-143-39.compute-1.amazonaws.com",
                                "PublicIp": "18.207.143.39"
                            },
                            "Attachment": {
                                "AttachTime": "2025-09-27 07:11:34+00:00",
                                "AttachmentId": "eni-attach-03a3f438f0bd91563",
                                "DeleteOnTermination": true,
                                "DeviceIndex": 0,
                                "Status": "attached",
                                "NetworkCardIndex": 0
                            },
                            "Description": "",
                            "Groups": [
                                {
                                    "GroupId": "sg-0702ffb92ed1e94ab",
                                    "GroupName": "default"
                                }
                            ],
                            "Ipv6Addresses": [],
                            "MacAddress": "0a:ff:e1:34:7a:8f",
                            "NetworkInterfaceId": "eni-078055b69ac54ad58",
                            "OwnerId": "471112573064",
                            "PrivateDnsName": "ip-172-31-28-170.ec2.internal",
                            "PrivateIpAddress": "172.31.28.170",
                            "PrivateIpAddresses": [
                                {
                                    "Association": {
                                        "IpOwnerId": "amazon",
                                        "PublicDnsName": "ec2-18-207-143-39.compute-1.amazonaws.com",
                                        "PublicIp": "18.207.143.39"
                                    },
                                    "Primary": true,
                                    "PrivateDnsName": "ip-172-31-28-170.ec2.internal",
                                    "PrivateIpAddress": "172.31.28.170"
                                }
                            ],
                            "SourceDestCheck": true,
                            "Status": "in-use",
                            "SubnetId": "subnet-037461bea7780c8b1",
                            "VpcId": "vpc-03e5c5fc93e620ede",
                            "InterfaceType": "interface",
                            "Operator": {
                                "Managed": false
                            }
                        }
                    ],
                    "RootDeviceName": "/dev/sda1",
                    "RootDeviceType": "ebs",
                    "SecurityGroups": [
                        {
                            "GroupId": "sg-0702ffb92ed1e94ab",
                            "GroupName": "default"
                        }
                    ],
                    "SourceDestCheck": true,
                    "Tags": [
                        {
                            "Key": "ccs_managed",
                            "Value": "yes"
                        },
                        {
                            "Key": "Patch Group",
                            "Value": "linux_default"
                        },
                        {
                            "Key": "ccs_dependency_type",
                            "Value": "dependency"
                        },
                        {
                            "Key": "Name",
                            "Value": "ccs-linux-test"
                        },
                        {
                            "Key": "ccs_backup",
                            "Value": "yes"
                        }
                    ],
                    "VirtualizationType": "hvm",
                    "CpuOptions": {
                        "CoreCount": 1,
                        "ThreadsPerCore": 2
                    },
                    "CapacityReservationSpecification": {
                        "CapacityReservationPreference": "open"
                    },
                    "HibernationOptions": {
                        "Configured": false
                    },
                    "MetadataOptions": {
                        "State": "applied",
                        "HttpTokens": "required",
                        "HttpPutResponseHopLimit": 2,
                        "HttpEndpoint": "enabled",
                        "HttpProtocolIpv6": "disabled",
                        "InstanceMetadataTags": "disabled"
                    },
                    "EnclaveOptions": {
                        "Enabled": false
                    },
                    "BootMode": "uefi-preferred",
                    "PlatformDetails": "Linux/UNIX",
                    "UsageOperation": "RunInstances",
                    "UsageOperationUpdateTime": "2025-09-27 07:11:34+00:00",
                    "PrivateDnsNameOptions": {
                        "HostnameType": "ip-name",
                        "EnableResourceNameDnsARecord": false,
                        "EnableResourceNameDnsAAAARecord": false
                    },
                    "MaintenanceOptions": {
                        "AutoRecovery": "default",
                        "RebootMigration": "default"
                    },
                    "CurrentInstanceBootMode": "uefi",
                    "NetworkPerformanceOptions": {
                        "BandwidthWeighting": "default"
                    },
                    "Operator": {
                        "Managed": false
                    },
                    "InstanceId": "i-0f7f2dbf65e7a5f7c",
                    "ImageId": "ami-0360c520857e3138f",
                    "State": {
                        "Code": 16,
                        "Name": "running"
                    },
                    "PrivateDnsName": "ip-172-31-28-170.ec2.internal",
                    "PublicDnsName": "ec2-18-207-143-39.compute-1.amazonaws.com",
                    "StateTransitionReason": "",
                    "KeyName": "ccs_linux_test_key_pair",
                    "AmiLaunchIndex": 0,
                    "ProductCodes": [],
                    "InstanceType": "t3.micro",
                    "LaunchTime": "2025-09-27 07:11:34+00:00",
                    "Placement": {
                        "AvailabilityZoneId": "use1-az4",
                        "GroupName": "",
                        "Tenancy": "default",
                        "AvailabilityZone": "us-east-1d"
                    },
                    "Monitoring": {
                        "State": "enabled"
                    },
                    "SubnetId": "subnet-037461bea7780c8b1",
                    "VpcId": "vpc-03e5c5fc93e620ede",
                    "PrivateIpAddress": "172.31.28.170",
                    "PublicIpAddress": "18.207.143.39"
                }
            ]
        }
    ],
    "ResponseMetadata": {
        "RequestId": "306826f1-e38a-45b1-8642-6106d27342d8",
        "HTTPStatusCode": 200,
        "HTTPHeaders": {
            "x-amzn-requestid": "306826f1-e38a-45b1-8642-6106d27342d8",
            "cache-control": "no-cache, no-store",
            "strict-transport-security": "max-age=31536000; includeSubDomains",
            "vary": "accept-encoding",
            "content-type": "text/xml;charset=UTF-8",
            "transfer-encoding": "chunked",
            "date": "Mon, 29 Sep 2025 10:37:46 GMT",
            "server": "AmazonEC2"
        },
        "RetryAttempts": 0
    }
}
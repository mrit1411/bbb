
import os
import csv
import io
import logging
from datetime import datetime
from itertools import islice

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

# --------------- Configuration ---------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
OUTPUT_BUCKET = os.environ.get('S3_BUCKET')  # REQUIRED
OUTPUT_KEY = os.getenv("OUTPUT_KEY")  # optional
TAG_FILTER_KEY = os.environ.get('TAGS_CONDITION_KEY')
TAG_FILTER_VAL = os.environ.get('TAGS_CONDITION_VALUE')

# CSV columns (fixed order) — replaced cpu_cores with vcpu
CSV_HEADERS = [
    "instance_id",
    "name",
    "state",
    "region",
    "os",
    "instance_type",
    "environment",
    "vcpu",
    "memory_mib",
    "zone",
    "application_id",
    "application_owner",
    "business_owner",
    "business_unit",
    "cost_center",
]

# Boto retry behavior
BOTO_CONFIG = Config(
    retries={"max_attempts": 10, "mode": "standard"},
    user_agent_extra="ec2-ccs-managed-inventory/1.1"
)

logging.getLogger().setLevel(LOG_LEVEL)
logger = logging.getLogger(__name__)


# --------------- Helpers ---------------

def chunked(iterable, size):
    """Yield successive size-chunks from iterable."""
    it = iter(iterable)
    while True:
        batch = list(islice(it, size))
        if not batch:
            break
        yield batch


def tags_to_dict(tags):
    """Convert AWS tag list [{'Key':..., 'Value':...}] to {key: value} dict."""
    t = {}
    if tags:
        for tag in tags:
            key = tag.get("Key")
            val = tag.get("Value")
            if key is not None:
                t[key] = val
    return t


def get_tag_value(tagdict, key, fallback_keys=None):
    """Get tag value by key, optionally trying a list of fallback tag keys."""
    if not tagdict:
        return ""
    if key in tagdict and tagdict[key] is not None:
        return tagdict[key]
    if fallback_keys:
        for k in fallback_keys:
            if k in tagdict and tagdict[k] is not None:
                return tagdict[k]
    return ""


def list_enabled_regions():
    """Return a list of region names that are 'opt-in-not-required' or 'opted-in'."""
    ec2 = boto3.client("ec2", config=BOTO_CONFIG)
    resp = ec2.describe_regions(AllRegions=True)
    regions = []
    for r in resp.get("Regions", []):
        status = r.get("OptInStatus", "opt-in-not-required")
        if status in ("opt-in-not-required", "opted-in"):
            regions.append(r["RegionName"])
    regions.sort()
    return regions


def fetch_instance_type_info(ec2_client, instance_types):
    """
    Batch-fetch instance type info for memory and default vCPU/cores/threads.
    Returns: dict instance_type -> dict with keys MemoryMiB, DefaultVCpus, DefaultCores, DefaultThreadsPerCore
    """
    info = {}
    for batch in chunked(sorted(instance_types), 100):
        resp = ec2_client.describe_instance_types(InstanceTypes=batch)
        for it in resp.get("InstanceTypes", []):
            t = it.get("InstanceType")
            mem_mib = None
            if it.get("MemoryInfo") and "SizeInMiB" in it["MemoryInfo"]:
                mem_mib = it["MemoryInfo"]["SizeInMiB"]
            vcpu = None
            cores = None
            threads_per_core = None
            if "VCpuInfo" in it:
                vcpu = it["VCpuInfo"].get("DefaultVCpus")
                cores = it["VCpuInfo"].get("DefaultCores")  # best-effort
                threads_per_core = it["VCpuInfo"].get("DefaultThreadsPerCore")  # best-effort
            info[t] = {
                "MemoryMiB": mem_mib,
                "DefaultVCpus": vcpu,
                "DefaultCores": cores,
                "DefaultThreadsPerCore": threads_per_core,
            }
    return info


def fetch_image_os_info(ec2_client, image_ids):
    """
    Batch-fetch image platform details for OS detection.
    Returns: dict image_id -> OS string (e.g., 'Windows', 'Linux/UNIX', 'Ubuntu', 'Red Hat Enterprise Linux', or 'Unknown')
    """
    os_map = {}
    for batch in chunked(sorted(image_ids), 100):
        try:
            resp = ec2_client.describe_images(ImageIds=batch)
        except ClientError as e:
            # Some old/deregistered AMIs may cause NotFound; skip those
            logger.warning("describe_images error for batch of %d: %s", len(batch), e)
            resp = {"Images": []}
        for img in resp.get("Images", []):
            img_id = img.get("ImageId")
            plat_details = (img.get("PlatformDetails") or "").strip()
            platform = (img.get("Platform") or "").strip()  # 'windows' in some cases
            if plat_details:
                os_map[img_id] = plat_details
            elif platform.lower() == "windows":
                os_map[img_id] = "Windows"
            else:
                os_map[img_id] = "Unknown"
    for img_id in image_ids:
        if img_id not in os_map:
            os_map[img_id] = "Unknown"
    return os_map


def derive_vcpu(instance, itype_info):
    """
    Determine vCPU count:
    - If instance CpuOptions has both CoreCount and ThreadsPerCore -> CoreCount * ThreadsPerCore
    - Else use instance-type DefaultVCpus
    """
    cpu_opts = instance.get("CpuOptions") or {}
    core_count = cpu_opts.get("CoreCount")
    threads_per_core = cpu_opts.get("ThreadsPerCore")
    try:
        if core_count is not None and threads_per_core is not None:
            return int(core_count) * int(threads_per_core)
    except Exception:
        pass

    itype = instance.get("InstanceType")
    meta = itype_info.get(itype, {}) if itype else {}
    vcpu = meta.get("DefaultVCpus")
    return vcpu if vcpu is not None else None


def deduce_os_string(instance, image_os_map):
    """
    Try instance-level Platform, then AMI-derived PlatformDetails, else Unknown.
    """
    platform = (instance.get("Platform") or "").strip().lower()
    if platform == "windows":
        return "Windows"
    img_id = instance.get("ImageId")
    if img_id:
        return image_os_map.get(img_id, "Unknown")
    return "Unknown"


def make_csv(records):
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=CSV_HEADERS, extrasaction="ignore")
    writer.writeheader()
    for r in records:
        writer.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in CSV_HEADERS})
    return buf.getvalue()


# --------------- Main logic ---------------

def collect_region_inventory(region):
    """
    Collect inventory for one region.
    Returns: list of dicts with CSV headers.
    """
    logger.info("Scanning region: %s", region)
    ec2 = boto3.client("ec2", region_name=region, config=BOTO_CONFIG)

    paginator = ec2.get_paginator("describe_instances")
    filters = [{"Name": f"tag:{TAG_FILTER_KEY}", "Values": [TAG_FILTER_VAL]}]

    instances = []
    instance_types = set()
    image_ids = set()

    # Fetch instances with the tag
    for page in paginator.paginate(Filters=filters):
        for res in page.get("Reservations", []):
            for inst in res.get("Instances", []):
                instances.append(inst)
                if inst.get("InstanceType"):
                    instance_types.add(inst["InstanceType"])
                if inst.get("ImageId"):
                    image_ids.add(inst["ImageId"])

    if not instances:
        logger.info("No instances with %s=%s in region %s", TAG_FILTER_KEY, TAG_FILTER_VAL, region)
        return []

    # Batch metadata
    itype_info = fetch_instance_type_info(ec2, instance_types) if instance_types else {}
    image_os = fetch_image_os_info(ec2, image_ids) if image_ids else {}

    results = []
    for inst in instances:
        tags = tags_to_dict(inst.get("Tags"))
        # Extract requested tag values (gracefully handle missing)
        name = get_tag_value(tags, "Name")
        environment = get_tag_value(tags, "Environment")
        application_id = get_tag_value(tags, "Application ID")
        application_owner = get_tag_value(tags, "Application Owner")
        business_owner = get_tag_value(tags, "Business Owner")
        business_unit = get_tag_value(tags, "Business Unit")
        cost_center = get_tag_value(tags, "Cost Center", fallback_keys=["CostCenter"])

        state = (inst.get("State") or {}).get("Name", "")
        az = (inst.get("Placement") or {}).get("AvailabilityZone", "")
        itype = inst.get("InstanceType", "")
        iid = inst.get("InstanceId", "")
        region_name = region
        os_str = deduce_os_string(inst, image_os)

        # vCPU & memory
        vcpu = derive_vcpu(inst, itype_info)
        mem_mib = None
        if itype in itype_info and itype_info[itype].get("MemoryMiB") is not None:
            mem_mib = itype_info[itype]["MemoryMiB"]

        record = {
            "instance_id": iid,
            "name": name,
            "state": state,
            "region": region_name,
            "os": os_str,
            "instance_type": itype,
            "environment": environment,
            "vcpu": vcpu if vcpu is not None else "",
            "memory_mib": mem_mib if mem_mib is not None else "",
            "zone": az,
            "application_id": application_id,
            "application_owner": application_owner,
            "business_owner": business_owner,
            "business_unit": business_unit,
            "cost_center": cost_center,
        }
        results.append(record)

    logger.info("Region %s: collected %d instances", region, len(results))
    return results


def lambda_handler(event, context):
    if not OUTPUT_BUCKET:
        raise RuntimeError("Environment variable OUTPUT_BUCKET is required")

    # Default key if not provided
    if not OUTPUT_KEY:
        now = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        key = f"ec2-ccs-managed-{now}.csv"
    else:
        key = OUTPUT_KEY

    total_records = 0
    all_records = []

    try:
        regions = list_enabled_regions()
    except Exception as e:
        logger.exception("Failed to list regions: %s", e)
        raise

    for region in regions:
        try:
            recs = collect_region_inventory(region)
            all_records.extend(recs)
            total_records += len(recs)
        except (ClientError, BotoCoreError) as e:
            logger.exception("Error scanning region %s: %s", region, e)
            # Continue to next region without failing the whole run

    csv_body = make_csv(all_records)

    s3 = boto3.client("s3", config=BOTO_CONFIG)
    s3.put_object(
        Bucket=OUTPUT_BUCKET,
        Key=key,
        Body=csv_body.encode("utf-8"),
        ContentType="text/csv"
    )

    msg = {
        "message": "EC2 inventory generated",
        "records": total_records,
        "regions_scanned": len(regions),
        "s3_bucket": OUTPUT_BUCKET,
        "s3_key": key
    }
    logger.info(msg)
    return msg


# For local debugging (optional)
if __name__ == "__main__":
    print(lambda_handler({}, None))
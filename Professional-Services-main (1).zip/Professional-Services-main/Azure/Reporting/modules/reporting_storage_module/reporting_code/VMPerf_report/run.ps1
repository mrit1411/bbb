using namespace System.Net

# Input bindings are passed in via param block.
param($Timer)

Import-Module Az.OperationalInsights

$subscriptions = Get-AzSubscription

# $dataResults='"Computer","OSType","Average_CPU_Utilisation","Maximum_CPU_Utilisation","Average_free_Memory","Maximum_free_Memory","Minimum_free_Memory","Free_Disk_Space_Percent","Free_Disk_Space_MB","InstanceName"'
# $dataResults= '"Computer","Resource_Group","Subscription","OSType","Start","End","Average_CPU_Utilisation","Maximum_CPU_Utilisation","Average_MEM_Free_GB","Maximum_MEM_Free_GB","Minimum_MEM_Free_GB"'
$dataResults= '"Computer","Resource_Group","Subscription_Name","OS_Type","Average_CPU_Utilisation","Maximum_CPU_Utilisation","Minimum_CPU_Utilisation","Average_MEM_Free_GB","Maximum_MEM_Free_GB","Minimum_MEM_Free_GB","Disk_Size_GB", "Disk_Free_Min_GB", "Disk_Max_Used_GB", "Disk_Free_Per_Cent", "Instance"'

$n = 10
$b = ($subscriptions.count)/$n
$c = [math]::ceiling($b)
Write-Host($b,$c,$subscriptions.count)
$e = @()
$d = @()
foreach ($subscription in $subscriptions) {
    $e += '"'+$subscription+ '"'
}
for (($i=0); $i -lt $c; $i++) {
    $d += $e[($i*$n)..(($i*$n)+$n-1)] -join ","
}


foreach ($s in $d){
Write-Host($s)
$query = @"
let timeRangeEnd = (startofmonth(now()));
let timeRangeStart = startofmonth(timeRangeEnd - 1s);
//let timeRangeEnd = datetime(8,29,2025);
//let timeRangeStart = datetime(8,1,2025);
let OSType = Heartbeat
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
//| extend Computer = tostring(split(Computer,".")[0])
| extend Computer = toupper(tostring(split(_ResourceId,"/")[-1]))
| summarize arg_max(TimeGenerated, *) by Computer, OSType,_ResourceId;
let Average_CPU_Utilisation = InsightsMetrics
| where Namespace == 'Processor' and Name == 'UtilizationPercentage'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Average_CPU_Utilisation = round(avg(Val),2) by _ResourceId;
///Average_CPU_Utilisation
let Maximum_CPU_Utilisation = InsightsMetrics
| where Namespace == 'Processor' and Name == 'UtilizationPercentage'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Maximum_CPU_Utilisation = round(max(Val),2) by _ResourceId;
///Maximum_CPU_Utilisation
let Minimum_CPU_Utilisation = InsightsMetrics
| where Namespace == 'Processor' and Name == 'UtilizationPercentage'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Minimum_CPU_Utilisation = round(min(Val),2) by _ResourceId;
///Minimum_CPU_Utilisation
let Average_MEM_Free_GB = InsightsMetrics
| where Namespace == 'Memory' and Name == 'AvailableMB'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Average_MEM_Free_GB = round(avg(Val)/1024,2) by _ResourceId;
///Average_MEM_Free_GB
let Maximum_MEM_Free_GB = InsightsMetrics
| where Namespace == 'Memory' and Name == 'AvailableMB'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Maximum_MEM_Free_GB = round(max(Val)/1024,2) by _ResourceId;
///Maximum_MEM_Free_GB
let Minimum_MEM_Free_GB = InsightsMetrics
| where Namespace == 'Memory' and Name == 'AvailableMB'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| summarize Minimum_MEM_Free_GB = round(min(Val)/1024,2) by _ResourceId;
///Minimum_MEM_Free_GB
let Disk_Free_Min_GB = InsightsMetrics
| where Namespace == 'LogicalDisk' and Name == 'FreeSpaceMB'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| extend (Instance) = tostring(todynamic(Tags).["vm.azm.ms/mountId"])
| summarize Disk_Free_Min_GB = round(min(Val)/1024,2) by  Instance,_ResourceId;
///Disk_Free_Min_GB
let Disk_Free_Per_Cent = InsightsMetrics
| where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage'
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| extend (Instance) = tostring(todynamic(Tags).["vm.azm.ms/mountId"])
| summarize Disk_Free_Per_Cent = round(min(Val),2) by  Instance,_ResourceId;
///Disk_Free_Per_Cent
let Disk_Size_GB = InsightsMetrics
| where Namespace == 'LogicalDisk' and Name == "FreeSpaceMB" 
| where TimeGenerated >= timeRangeStart and TimeGenerated  <= timeRangeEnd
// | where TimeGenerated > ago(15d)
| extend SubscriptionId = split(_ResourceId,"/")[2]
| where SubscriptionId in ($s)
| extend (Instance) = tostring(todynamic(Tags).["vm.azm.ms/mountId"])
| summarize  (Disk_Size_GB) = round(max((todecimal(tostring(todynamic(Tags).["vm.azm.ms/diskSizeMB"]))))/1024,2) by  Instance,_ResourceId;
///Disk_Size_GB 
arg("").resources
    | where type == "microsoft.compute/virtualmachines"
    | where tags.ccs_managed == "yes"
    | extend id_lower = tolower(id)
    | project id_lower,subscriptionId
    | join (
Disk_Free_Min_GB | extend id_lower = tolower(_ResourceId)
) on id_lower
| join kind=inner Average_CPU_Utilisation on _ResourceId
| join kind=inner Maximum_CPU_Utilisation on _ResourceId
| join kind=inner Minimum_CPU_Utilisation on _ResourceId
| join kind=inner Average_MEM_Free_GB on _ResourceId
| join kind=inner Maximum_MEM_Free_GB on _ResourceId
| join kind=inner Minimum_MEM_Free_GB on _ResourceId
| join kind=inner Disk_Free_Per_Cent on Instance,_ResourceId
| join kind=inner Disk_Size_GB  on Instance,_ResourceId
| join kind=inner OSType on _ResourceId
| extend Resource_Group = array_strcat(split(_ResourceId,"/",4),"")
| extend  Disk_Max_Used_GB = round((Disk_Size_GB - Disk_Free_Min_GB),2)
| lookup (
    arg("").resourcecontainers
    | where ['type'] == "microsoft.resources/subscriptions"
    | project subscriptionId, sub_name=name
) on subscriptionId
| distinct Computer, Resource_Group, sub_name, OSType, Average_CPU_Utilisation, Maximum_CPU_Utilisation, Minimum_CPU_Utilisation, Average_MEM_Free_GB, Maximum_MEM_Free_GB, Minimum_MEM_Free_GB, Disk_Size_GB, Disk_Free_Min_GB, Disk_Max_Used_GB, Disk_Free_Per_Cent, Instance//, Disk_Size_GB,Disk_Free_Min_GB, Disk_Max_Used_GB, Disk_Free_Per_Cent, Instance
//| where Instance !in ("/mnt","/boot/efi","/boot") and Instance !contains "/snap" and Instance !contains "/sys/"
//| project Computer, Resource_Group, Subscription, OSType, Start = timeRangeStart, End = timeRangeEnd, Average_CPU_Utilisation, Maximum_CPU_Utilisation, Average_MEM_Free_GB, Maximum_MEM_Free_GB, Minimum_MEM_Free_GB//, Disk_Size_GB,Disk_Free_Min_GB, Disk_Max_Used_GB, Disk_Free_Per_Cent, Instance
| project Computer, Resource_Group, sub_name, OSType, Average_CPU_Utilisation, Maximum_CPU_Utilisation, Minimum_CPU_Utilisation, Average_MEM_Free_GB, Maximum_MEM_Free_GB, Minimum_MEM_Free_GB, Disk_Size_GB, Disk_Free_Min_GB, Disk_Max_Used_GB, Disk_Free_Per_Cent, Instance//, Disk_Size_GB,Disk_Free_Min_GB, Disk_Max_Used_GB, Disk_Free_Per_Cent, Instance
"@

try {
        $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId "c885dbec-434d-4ece-a9d1-e65a03b0e080" -Query $query -ErrorAction Stop

        $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
        foreach($record in $queryResult)
        {
            $record = $record | ConvertTo-csv
            for($i=1;$i -lt $record.Count; $i++)
            {
                $dataResults += "`n" + $record[$i]
            }
        }
    }
    Catch {
        Write-Host "An error occurred:"
        Write-Host $_
    }
}
Push-OutputBinding -Name outputBlob -Value $dataResults
resource "aws_backup_selection" "backup_selection" {
  name         = local.name
  plan_id      = var.plan_id
  iam_role_arn = var.iam_role_arn
  region = var.region

  dynamic "selection_tag" {
    for_each = var.selection_tags
    content {
      type  = selection_tag.value.type
      key   = selection_tag.value.key
      value = selection_tag.value.value
    }
  }
}
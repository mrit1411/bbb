resource "aws_ssm_patch_group" "ssm_patch_group" {
  for_each = { for baseline in var.patch_baseline : baseline.name => baseline }

  baseline_id = each.value.id
  patch_group = var.patch_group
  region      = var.region
}

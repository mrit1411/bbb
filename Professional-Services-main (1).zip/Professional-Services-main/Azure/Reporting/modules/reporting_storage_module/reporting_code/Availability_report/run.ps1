# Input bindings are passed in via param block.
param($Timer)

# Set-AzContext -Subscription "a9153bcd-0649-4f52-9ad7-5fc4cb49a99e"
# Update-AzConfig -DefaultSubscriptionForLogin "a9153bcd-0649-4f52-9ad7-5fc4cb49a99e"

Import-Module Az.OperationalInsights
$subscriptions = Get-AzSubscription

# $dataResults='"From","To","Subscription","Resource_Group","Resource_Name","Down","Availability_Rate","Total_Hours","Total_Available_Hours"'
$dataResults='From,To,Subscription,Resource_Group,Resource_Name,Down,Availability_Rate,Total_Hours,Total_Available_Hours'


foreach ($subscription in $subscriptions){
    Write-Host($subscription)

# $query = @"
# let timeRangeEnd = (startofmonth(now()) - 1s);
# let timeRangeStart = startofmonth(timeRangeEnd);
# arg("").resources
#     | where type == "microsoft.compute/virtualmachines"
#     | where tags.cos_managed == "yes"
#     | extend id_lower = tolower(id)
#     | project id_lower
#     | join (
# //let timeRangeEnd = (startofmonth(now()) - 1s);
# //let timeRangeStart = startofmonth(timeRangeEnd);
# Heartbeat
# | where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
# | join kind=inner (
#     Heartbeat
#     | where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
#     | summarize arg_min(TimeGenerated, *) by _ResourceId 
#     | extend first_occurance = TimeGenerated
# ) on _ResourceId
# | where TimeGenerated > first_occurance and TimeGenerated < timeRangeEnd
# | extend Resource=tolower(iff(isempty(_ResourceId), Resource, _ResourceId))
# | summarize heartbeat_per_hour=count() by bin_at(TimeGenerated, 1m, timeRangeStart), _ResourceId,ResourceGroup, first_occurance
# | extend available_per_hour=iff(heartbeat_per_hour>0, true, false)
# | extend RG = tolower(ResourceGroup)
# | summarize total_available_hours=countif(available_per_hour==true) by _ResourceId,RG, first_occurance
# | extend total_number_of_buckets=round((timeRangeEnd-first_occurance)/1m,2)
# | extend round(availability_rate=total_available_hours*100/total_number_of_buckets,1)
# | extend round(down= 100 - availability_rate,2)
# | extend From=timeRangeStart
# | extend To=timeRangeEnd
# | extend total_available_hours = round(todouble(total_available_hours)/60,1)
# | order by availability_rate asc
# | extend id_lower = tolower(_ResourceId)
# ) on id_lower
# | project From, To, RG, _ResourceId, down, availability_rate, total_available_hours
# "@

$query = @"
//let timeRangeEnd = (startofmonth(now()) - 1s);
//let timeRangeStart = startofmonth(timeRangeEnd);
let timeRangeEnd = (startofmonth(now()));
let timeRangeStart = startofmonth(timeRangeEnd - 1s);
arg("").resources
    | where type == "microsoft.compute/virtualmachines"
    | where tags.cos_managed == "yes"
    | extend id_lower = tolower(id)
    | project id_lower
    | join (
//let timeRangeEnd = (startofmonth(now()) - 1s);
//let timeRangeStart = startofmonth(timeRangeEnd);
Heartbeat
| where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
| join kind=inner (
    Heartbeat
    | where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
    | where TimeGenerated > timeRangeStart and TimeGenerated < timeRangeEnd
    | summarize arg_min(TimeGenerated, *) by _ResourceId 
    | extend first_occurance = TimeGenerated
) on _ResourceId
| where TimeGenerated > first_occurance and TimeGenerated < timeRangeEnd
| extend Resource=tolower(iff(isempty(_ResourceId), Resource, _ResourceId))
| summarize heartbeat_per_hour=count() by bin_at(TimeGenerated, 1m, timeRangeStart), _ResourceId,ResourceGroup, first_occurance,SubscriptionId
| extend available_per_hour=iff(heartbeat_per_hour>0, true, false)
| extend RG = tolower(ResourceGroup)
| summarize total_available_hours=countif(available_per_hour==true) by _ResourceId,RG, first_occurance,SubscriptionId
| extend total_number_of_buckets=round((timeRangeEnd-first_occurance)/1m,2)
| extend round(availability_rate=total_available_hours*100/total_number_of_buckets,1)
| extend round(down= 100 - availability_rate,2)
| extend From=timeRangeStart
| extend To=timeRangeEnd
| extend total_available_hours = round(todouble(total_available_hours)/60,1)
| order by availability_rate asc
| extend id_lower = tolower(_ResourceId)
| extend Computer = tostring(split(_ResourceId,"/")[8])
) on id_lower
| lookup (
    arg("").resourcecontainers
    | where ['type'] == "microsoft.resources/subscriptions" //and subscriptionId == "d99dc9e8-f62f-442a-80da-e90bc5a7443b"
    | project SubscriptionId=subscriptionId, sub_name=name
) on SubscriptionId
| extend Total_Hours = datetime_diff('hour',timeRangeEnd , timeRangeStart)
| project From, To, sub_name, RG, Computer, down, availability_rate, Total_Hours,total_available_hours
"@

try {
        $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId "7561e063-f8c0-40c6-9583-e866baffea3c" -Query $query -ErrorAction Stop
        # $querytoken = $queryLAW.SkipToken
        # Write-Host("Query Token: " + $querytoken)

        $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
        foreach($record in $queryResult)
        {
            $record = $record | ConvertTo-csv
            for($i=1;$i -lt $record.Count; $i++)
            {
                $dataResults += "`n" + $record[$i]
            }
        }
    }
    Catch {
        Write-Host "An error occurred:"
        Write-Host $_
    }
}

Push-OutputBinding -Name outputBlob -Value $dataResults




# using namespace System.Net

# # Input bindings are passed in via param block.
# param($Request, $TriggerMetadata)

# # Set-AzContext -Subscription "a9153bcd-0649-4f52-9ad7-5fc4cb49a99e"
# # Update-AzConfig -DefaultSubscriptionForLogin "a9153bcd-0649-4f52-9ad7-5fc4cb49a99e"

# # Input bindings are passed in via param block.
# # param($Timer)

# Import-Module Az.OperationalInsights
# $subscriptions = Get-AzSubscription

# # $dataResults = @()
# $dataResults='"From","To", "RG","Resource", "down", "availability_rate","total_available_hours"'


# foreach ($subscription in $subscriptions){
#     Write-Host($subscription)

# $query = @"
# let timeRangeEnd = (startofmonth(now()) - 1s);
# let timeRangeStart = startofmonth(timeRangeEnd);
# Heartbeat
# | where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
# | join kind=inner (
#     Heartbeat
#     | where ResourceType == "virtualMachines" and SubscriptionId == "$subscription"//"d99dc9e8-f62f-442a-80da-e90bc5a7443b"//"$subscription"
#     | summarize arg_min(TimeGenerated, *) by _ResourceId 
#     | extend first_occurance = TimeGenerated
# ) on _ResourceId
# | where TimeGenerated > first_occurance and TimeGenerated < timeRangeEnd
# | extend Resource=tolower(iff(isempty(_ResourceId), Resource, _ResourceId))
# | summarize heartbeat_per_hour=count() by bin_at(TimeGenerated, 1m, timeRangeStart), _ResourceId,ResourceGroup, first_occurance
# | extend available_per_hour=iff(heartbeat_per_hour>0, true, false)
# | extend RG = tolower(ResourceGroup)
# | summarize total_available_hours=countif(available_per_hour==true) by _ResourceId,RG, first_occurance
# | extend total_number_of_buckets=round((timeRangeEnd-first_occurance)/1m,2)
# | extend round(availability_rate=total_available_hours*100/total_number_of_buckets,1)
# | extend round(down= 100 - availability_rate,2)
# | extend From=timeRangeStart
# | extend To=timeRangeEnd
# | extend total_available_hours = round(todouble(total_available_hours)/60,1)
# | order by availability_rate asc
# | project From, To, RG, _ResourceId, down, availability_rate, total_available_hours
# "@

# # if ($subscription -eq "5007735a-6865-47ea-924a-336497d3e92e"){
# #     Write-Host($query)
# # }

# # $allLogAnalyticsWorkspaces = @()
# # $subscriptions = get-azcontext -ListAvailable
# # foreach($subscription in $subscriptions)
# # {
# #     $allLogAnalyticsWorkspaces += (Get-AzOperationalInsightsWorkspace -DefaultProfile $subscription) 
# # }
# # $dataResults='"From","To", "RG","Resource", "down", "availability_rate","total_available_hours"'

# # foreach($logAnalyticsWorkspace in $allLogAnalyticsWorkspaces.CustomerId)
# # {
# #     try {
# #         Write-Host $logAnalyticsWorkspace
# #         $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId $logAnalyticsWorkspace -Query $query -ErrorAction Stop
# #         $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
# #         foreach($record in $queryResult)
# #         {
# #             $record = $record | ConvertTo-csv
# #             for($i=1;$i -lt $record.Count; $i++)
# #             {
# #                 $dataResults += "`n" + $record[$i]
# #             }
# #         }
# #     }
# #     Catch {
# #         Write-Host "An error occurred:"
# #         Write-Host $_
# #     }
# # }
# # $context = Set-AzContext -Subscription "a9153bcd-0649-4f52-9ad7-5fc4cb49a99e"
# $allLogAnalyticsWorkspaces = (Get-AzOperationalInsightsWorkspace) 
# Write-Host($allLogAnalyticsWorkspaces | ConvertTo-json -Depth 10)

# foreach($logAnalyticsWorkspace in $allLogAnalyticsWorkspaces.CustomerId)
# {
#     try {
#         Write-Host $logAnalyticsWorkspace
#         $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId $logAnalyticsWorkspace -Query $query -ErrorAction Stop
#         $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
#         foreach($record in $queryResult)
#         {
#             $record = $record | ConvertTo-csv
#             for($i=1;$i -lt $record.Count; $i++)
#             {
#                 $dataResults += "`n" + $record[$i]
#             }
#         }
#     }
#     Catch {
#         Write-Host "An error occurred:"
#         Write-Host $_
#     }
# }

# # try {
# #         $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId "7561e063-f8c0-40c6-9583-e866baffea3c" -Query $query -ErrorAction Stop

# #         Write-Host($queryLAW | ConvertTo-json -Depth 10)
# #         $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
# #         foreach($record in $queryResult)
# #         {
# #             $record = $record | ConvertTo-csv
# #             for($i=1;$i -lt $record.Count; $i++)
# #             {
# #                 $dataResults += "`n" + $record[$i]
# #             }
# #         }
# #     }
# #     Catch {
# #         Write-Host "An error occurred:"
# #         Write-Host $_
# #     }
# }

# Push-OutputBinding -Name outputBlob -Value $dataResults
 
#!/bin/sh

# Get IMDSv2 token
TOKEN=$(curl -X PUT "http://169.254.169.254/latest/api/token"  -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" -s)

# Get Instance ID
INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)
region=$(curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone | sed -e 's/.$//')

# Get uptime in seconds
UPTIME=$(awk '{print int($1)}' /proc/uptime)

# Publish to CloudWatch
aws cloudwatch put-metric-data --namespace "Custom/Uptime" --region ${region} --metric-data "MetricName=InstanceUptimeSeconds,Value=$UPTIME,Unit=Seconds,Dimensions=[{Name=InstanceId,Value=$INSTANCE_ID}]"

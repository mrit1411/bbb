resource "azurerm_policy_definition" "policy_definition" {
  name         = lower(var.name)
  display_name = var.display_name
  policy_type  = var.policy_type
  mode         = var.mode
  description  = var.description
  policy_rule  = file("./${path.module}/${var.policy_rule_filename}")
  parameters   = file("./${path.module}/${var.policy_parameters_filename}")
}

resource "azurerm_subscription_policy_assignment" "policy_assignment" {
  name                 = "${lower(var.name)}-asgnmnt"
  policy_definition_id = azurerm_policy_definition.policy_definition.id
  subscription_id      = var.subscription_id
  description          = var.description

  identity {
    type         = "UserAssigned"
    identity_ids = var.user_assigned_identity_ids
  }

  location = var.location

  parameters = var.policy_assignment_parameters != null ? var.policy_assignment_parameters : ""
}
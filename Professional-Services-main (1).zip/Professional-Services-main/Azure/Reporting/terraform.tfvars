location            = "westeurope"
resource_group_name = "rg-prd-eaf-euw"
tags = {
  "ccs_managed" = "yes"
}
reporting_function_zip_name = "reporting_azure_integration_func"
reporting_function_zip_path = "./modules/reporting_storage_module/reporting.zip"
environment                 = "Prod"
org                         = "org"
context                     = "report"

reporting_function_user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/tftest-main"]
client_id = "bf66120a-2670-45d5-abcc-2d8cb3d8dec7"

client_id_resource_id = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/tftest-main"
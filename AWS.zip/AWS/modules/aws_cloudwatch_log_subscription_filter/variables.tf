variable "name" {
  description = "A name for the subscription filter"
  type        = string
}

variable "destination_arn" {
  description = "The ARN of the destination to deliver matching log events to. Kinesis stream or Lambda function ARN."
  type        = string
}

variable "filter_pattern" {
  description = "A valid CloudWatch Logs filter pattern for subscribing to a filtered stream of log events. Use empty string \"\" to match everything."
  type        = string
  default     = ""
}

variable "log_group_name" {
  description = "The name of the log group to associate the subscription filter with"
  type        = string
}

variable "role_arn" {
  description = "The ARN of an IAM role that grants Amazon CloudWatch Logs permissions to deliver ingested log events to the destination."
  type        = string
}
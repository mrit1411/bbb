output "eventbridge_rule_id" {
  value = aws_cloudwatch_event_rule.cloudwatch_event_rule.id
}

output "arn" {
  value = aws_cloudwatch_event_rule.cloudwatch_event_rule.arn
}
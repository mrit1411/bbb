locals {
  name = "CCS-${var.name}-topic-${var.region}"
}
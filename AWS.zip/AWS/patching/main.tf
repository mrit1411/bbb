module "windows_default_patch_group" {
  source = "../modules/aws_ssm_patch_group"

  patch_group = "windows_default"
}

module "linux_default_patch_group" {
  source = "../modules/aws_ssm_patch_group"

  patch_group = "linux_default"
}

module "modify_alarms_iam_role" {
  source = "../modules/aws_iam_role"

  description         = "Role created by CCS Patching Solution Deployment. Created for the AWS-ConfigureCloudWatchOnEC2Instance SSM Documents to assume. Grants permissions to enable and disable EC2 alarm actions"
  context             = "Modify-CloudWatch-Alarms"
  resource_type       = "SSM"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonSSMAutomationRole"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "ModifyAlarms"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/modify_alarms.json")
    }
  }

}

module "task_publish_sns_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Used by Automation Docs to publish to Patching Results SNS Topic"
  context       = "Task-Publish-SNS"
  resource_type = "SSM"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "TaskPublishSNSPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/task_publish_sns_policy.tpl.json", {
        results_patching_sns_topic_arn = module.results_patching_sns_topic.sns_topic_arn
      })
    }
  }

}

module "results_patching_sns_topic" {
  source = "../modules/aws_sns_topic"
  name   = var.results_patching_sns_topic_name

}

module "result_patching_topic_lambda_subscription" {
  source = "../modules/aws_sns_topic_subscription"

  topic_arn = module.results_patching_sns_topic.sns_topic_arn
  endpoint  = module.report_patching_details_lambda_function.arn
  protocol  = "lambda"
}

module "report_patching_details_lambda_function" {
  
  source = "../modules/aws_lambda_function"

  description              = "CCS Lambda Function that will generate instant compliance patch reports after a patching cycle has completed and send to SNS Topic arn variable"
  handler                  = "lambda_instant_patching_report.lambda_handler"
  region = "us-east-1"
  lambda_function_filename = "lambda_instant_patching_report"
  role                     = module.lambda_patching_instant_role.role_arn
  timeout                  = 10
  memory_size              = 128
  env_variables = {
    SNS_TOPIC_ARN = ""
    log_level     = var.log_level
  }

}

module "sns_permission_invoke_lambda" {
  
  source = "../modules/aws_lambda_permission"

  function_name = module.report_patching_details_lambda_function.arn
  principal     = "sns.amazonaws.com"
  source_arn    = module.results_patching_sns_topic.sns_topic_arn
  region                   = "us-east-1"

}

module "lambda_patching_instant_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Usedby CCS-Patching-instant-report-lambda to generate patching compliance information and send to SNOW SNS Topic"
  resource_type = "lambda"
  path          = "/service-role/"
  context       = "Lambda-Patching-Instant-Role"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaPatchingInstantPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/lambda_patching_instant_policy.tpl.json", {
        snow_sns_topic_arn = ""
      })
    }
  }
}

module "patch_reports_s3_bucket" {
  
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.patch_reports_bucket_name
  region                   = "us-east-1"
}

module "patch_reports_s3_bucket_encryption_configuration" {
  
  source = "../modules/aws_s3_bucket_server_side_encryption_configuration"
  bucket = module.patch_reports_s3_bucket.bucket_id
  region                   = "us-east-1"
}

module "patch_reports_s3_bucket_policy" {
  
  source = "../modules/aws_s3_bucket_policy"
  bucket = module.patch_reports_s3_bucket.bucket_id
  region                   = "us-east-1"
}

module "patch_report_eventbridge_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Created for the Patch Report Eventbridge to assume. Grants permissions to run SSM Documents."
  context       = "Patch-Report-Eventbridge"
  resource_type = "events"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "PatchReportEventBridgePolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/patch_report_eventbridge_policy.tpl.json", {
        patch_report_ssm_iam_role_arn = module.patch_report_ssm_iam_role.role_arn
      })
    }
  }
}

module "patch_report_ssm_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Created for the AWS-ExportPatchReportToS3 SSM Documents to assume. Grants permissions to create and manage patch reports"
  context       = "Patch-Report-SSM"
  resource_type = "SSM"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "PatchReportSSMPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/patch_report_ssm_policy.tpl.json", {
        patch_report_s3_bucket_id = module.patch_reports_s3_bucket.bucket_id,
        account_id                = data.aws_caller_identity.current.account_id
      })
    }
  }

}

module "patch_report_monthly_trigger" {
  
  source = "../modules/aws_cloudwatch_event_rule"

  description            = "Event rule to trigger the patch report generation monthly"
  schedule               = var.patch_report_generation_schedule_monthly
  region                   = "us-east-1"
  eventbridge_target_id  = "PatchReports"
  eventbridge_target_arn = "arn:aws:ssm:us-east-1:${data.aws_caller_identity.current.account_id}:automation-definition/AWS-ExportPatchReportToS3"

  input = jsonencode({
    assumeRole   = [module.patch_report_ssm_iam_role.role_arn],
    reportName   = ["PatchReport"],
    s3BucketName = [module.patch_reports_s3_bucket.bucket_id],
    targets      = ["instanceids=*"]
  })

  context                     = "Patch-Report-Monthly-Trigger"
  eventbridge_target_role_arn = module.patch_report_eventbridge_iam_role.role_arn
}

module "windows_default_maintenance_configuration" {
  source = "../modules/aws_ssm_maintenance_configuration"

  window_name               = "windows-default-maintenance-window"
  window_description        = "Default Windows Maintenance Window for monthly maintenance on second Saturday at 2 AM UTC"
  window_schedule           = "cron(0 2 ? * 7#2 *)" // Example cron expression for maintenance on second Saturday of every month at 2 AM UTC
  #window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2025-09-24T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  window_target_name        = "default-windows-target"
  window_target_description = "Default Windows target for maintenance window, targets Windows EC2 with ccs_managed:yes tag and ccs_schedule:windows_default tag"
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["windows_default"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic.sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}

module "linux_default_maintenance_configuration" {
  source = "../modules/aws_ssm_maintenance_configuration"

  window_name               = "linux-default-maintenance-window"
  window_description        = "Default Linux Maintenance Window for quarterly maintenance one day after every third wednesday at 2 AM UTC"
  # window_schedule           = "cron(0 2 ? * 3#3 *)" // Example cron expression for maintenance on third Thursday of every third month at 2 AM UTC
  window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2025-10-30T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  window_target_name        = "default-linux-target"
  window_target_description = "Default Linux target for maintenance window, targets Linux EC2 with ccs_managed:yes tag and ccs_schedule:linux_default tag"
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["app2"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic.sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}
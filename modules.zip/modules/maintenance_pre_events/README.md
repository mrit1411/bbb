﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_eventgrid_system_topic.maintenance_pre_event_topic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/eventgrid_system_topic) | resource |
| [azurerm_eventgrid_system_topic_event_subscription.maintenance_pre_event_subscription](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/eventgrid_system_topic_event_subscription) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_maintenance_configs"></a> [maintenance\_configs](#input\_maintenance\_configs) | Map of maintenance configurations to wire to Event Grid. | <pre>map(object({<br/>    id                  = string<br/>    name                = string<br/>    location            = string<br/>    resource_group_name = string<br/>  }))</pre> | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the resources | `map(string)` | n/a | yes |
| <a name="input_webhook_uri"></a> [webhook\_uri](#input\_webhook\_uri) | The URI of the webhook to be used as the endpoint for Event Grid subscriptions. | `string` | n/a | yes |

## Outputs

No outputs.

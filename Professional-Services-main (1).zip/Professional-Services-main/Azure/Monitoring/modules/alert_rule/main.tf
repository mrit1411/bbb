resource "azurerm_monitor_scheduled_query_rules_alert_v2" "alert_rule" {
  name                = var.name
  display_name        = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  criteria {
    operator                = var.operator
    threshold               = var.threshold
    time_aggregation_method = var.time_aggregation_method
    metric_measure_column   = var.time_aggregation_method == "Count" ? null : var.metric_measure_column
    resource_id_column      = var.resource_id_column
    query                   = var.query
    failing_periods {
      minimum_failing_periods_to_trigger_alert = var.minimum_failing_periods
      number_of_evaluation_periods             = var.number_of_evaluation_periods
    }
dynamic "dimension" {
  for_each = length(var.dimensions) > 0 ? var.dimensions : (
    var.dimension_name != "" ?
    [{
      name     = var.dimension_name
      operator = var.dimension_operator
      values   = var.dimension_values
    }] : []
  )

  content {
    name     = dimension.value.name
    operator = dimension.value.operator
    values   = dimension.value.values
  }
}
  }
  scopes               = var.scopes
  severity             = var.severity
  evaluation_frequency = var.evaluation_frequency
  window_duration      = var.window_duration
  description          = var.description
  auto_mitigation_enabled = var.auto_mitigation_enabled
  action {
    action_groups = var.action_group_id
  }
  dynamic "identity" {
  for_each = var.identity == null ? [] : [var.identity]

  content {
    type         = identity.value.type
    identity_ids = identity.value.identity_ids
  }
}
  enabled = var.enabled
  tags    = var.tags
  lifecycle {
    ignore_changes = [tags]
  }


}

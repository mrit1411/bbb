resource "aws_iam_user" "iam_user" {
  name = var.user_name
}

resource "aws_iam_user_policy" "iam_user_policy" {
  name   = local.policy_name
  user   = aws_iam_user.iam_user.name
  policy = var.policy
}

# resource "aws_iam_user_policy_attachment" "iam_user_policy_attachment" {
#   user       = aws_iam_user.iam_user.name
#   policy_arn = aws_iam_user_policy.iam_user_policy.arn
# }
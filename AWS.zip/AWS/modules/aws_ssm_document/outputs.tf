output "name" {
  value = aws_ssm_document.ssm_document.name
}
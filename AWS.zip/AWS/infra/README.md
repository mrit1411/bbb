<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 6.3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 6.3.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ccs_snow_api_listner_iam_role"></a> [ccs\_snow\_api\_listner\_iam\_role](#module\_ccs\_snow\_api\_listner\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_ccs_snow_listner_lambda_function"></a> [ccs\_snow\_listner\_lambda\_function](#module\_ccs\_snow\_listner\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_ccs_snow_listner_lambda_permission"></a> [ccs\_snow\_listner\_lambda\_permission](#module\_ccs\_snow\_listner\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_ccs_snow_listner_lambda_sns_subscription"></a> [ccs\_snow\_listner\_lambda\_sns\_subscription](#module\_ccs\_snow\_listner\_lambda\_sns\_subscription) | ../modules/aws_sns_topic_subscription | n/a |
| <a name="module_ccs_snow_secret"></a> [ccs\_snow\_secret](#module\_ccs\_snow\_secret) | ../modules/aws_secretsmanager_secret | n/a |
| <a name="module_create_backup_ssm_automation_document"></a> [create\_backup\_ssm\_automation\_document](#module\_create\_backup\_ssm\_automation\_document) | ../modules/aws_ssm_document | n/a |
| <a name="module_enable_ssm_association"></a> [enable\_ssm\_association](#module\_enable\_ssm\_association) | ../modules/aws_ssm_association | n/a |
| <a name="module_run_command_linux_ssm_automation_document"></a> [run\_command\_linux\_ssm\_automation\_document](#module\_run\_command\_linux\_ssm\_automation\_document) | ../modules/aws_ssm_document | n/a |
| <a name="module_run_command_windows_ssm_automation_document"></a> [run\_command\_windows\_ssm\_automation\_document](#module\_run\_command\_windows\_ssm\_automation\_document) | ../modules/aws_ssm_document | n/a |
| <a name="module_snow_sns_topic"></a> [snow\_sns\_topic](#module\_snow\_sns\_topic) | ../modules/aws_sns_topic | n/a |
| <a name="module_snow_sns_topic_policy"></a> [snow\_sns\_topic\_policy](#module\_snow\_sns\_topic\_policy) | ../modules/aws_sns_topic_policy | n/a |
| <a name="module_ssm_automation_backup_iam_role"></a> [ssm\_automation\_backup\_iam\_role](#module\_ssm\_automation\_backup\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_ssm_automation_create_backup_iam_role"></a> [ssm\_automation\_create\_backup\_iam\_role](#module\_ssm\_automation\_create\_backup\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_ssm_automation_run_command_iam_role"></a> [ssm\_automation\_run\_command\_iam\_role](#module\_ssm\_automation\_run\_command\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_ssm_management_ec2_iam_role"></a> [ssm\_management\_ec2\_iam\_role](#module\_ssm\_management\_ec2\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_ssm_management_ec2_instance_profile"></a> [ssm\_management\_ec2\_instance\_profile](#module\_ssm\_management\_ec2\_instance\_profile) | ../modules/aws_iam_instance_profile | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_api_company_name"></a> [api\_company\_name](#input\_api\_company\_name) | CCS-SNOW Lambda will populate the Company field in ServiceNow with this value. this must reflect the exact name of the intended company in ServiceNow | `string` | n/a | yes |
| <a name="input_log_level"></a> [log\_level](#input\_log\_level) | Allows various details of lambda events to be logged. Value must be in range:<0- no logging, 1- production, 2- dev, 3 maximum logging> | `number` | `3` | no |
| <a name="input_snow_client_id"></a> [snow\_client\_id](#input\_snow\_client\_id) | Provide the iPaaS API authentication ID. stored in Secret Manager. used by CCS-SNOW Lambda to authenticate with iPaaS cloud native endpoint | `string` | n/a | yes |
| <a name="input_snow_client_secret"></a> [snow\_client\_secret](#input\_snow\_client\_secret) | Provide the iPaaS API authentication secret. stored in Secret Manager. Used by CCS-SNOW Lambda to authenticate with iPaaS cloud native endpoint | `string` | n/a | yes |
| <a name="input_snow_sns_topic_name"></a> [snow\_sns\_topic\_name](#input\_snow\_sns\_topic\_name) | Provide name for SNS Topic that will be created and linked to CCS ServiceNow Lambda | `string` | `"SNOW-Monitoring"` | no |
| <a name="input_ssm_management_ec2_instance_profile_name"></a> [ssm\_management\_ec2\_instance\_profile\_name](#input\_ssm\_management\_ec2\_instance\_profile\_name) | Name of the SSM Management EC2 Instance Profile | `string` | `"CCSEC2InstanceProfileforSSMManagement"` | no |
| <a name="input_tags_condition_key"></a> [tags\_condition\_key](#input\_tags\_condition\_key) | Resources with this Tag Key will be managed by CCS Monitoring and SSM | `string` | `"ccs_managed"` | no |
| <a name="input_tags_condition_value"></a> [tags\_condition\_value](#input\_tags\_condition\_value) | Resources with this Tag Value will be managed by CCS Monitoring and SSM | `string` | `"yes"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_infra_create_backup_ssm_automation_document"></a> [infra\_create\_backup\_ssm\_automation\_document](#output\_infra\_create\_backup\_ssm\_automation\_document) | n/a |
| <a name="output_infra_run_command_linux_ssm_automation_document"></a> [infra\_run\_command\_linux\_ssm\_automation\_document](#output\_infra\_run\_command\_linux\_ssm\_automation\_document) | n/a |
| <a name="output_infra_run_command_windows_ssm_automation_document"></a> [infra\_run\_command\_windows\_ssm\_automation\_document](#output\_infra\_run\_command\_windows\_ssm\_automation\_document) | n/a |
| <a name="output_infra_snow_sns_topic"></a> [infra\_snow\_sns\_topic](#output\_infra\_snow\_sns\_topic) | n/a |
<!-- END_TF_DOCS -->
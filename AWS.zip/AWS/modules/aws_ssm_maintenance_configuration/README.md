﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_maintenance_window.ssm_maintenance_window](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window) | resource |
| [aws_ssm_maintenance_window_target.ssm_maintenance_window_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window_target) | resource |
| [aws_ssm_maintenance_window_task.disable_alarms_task](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window_task) | resource |
| [aws_ssm_maintenance_window_task.enable_alarms_task](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window_task) | resource |
| [aws_ssm_maintenance_window_task.patching_task](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window_task) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_unassociated_targets"></a> [allow\_unassociated\_targets](#input\_allow\_unassociated\_targets) | Whether targets must be registered with the Maintenance Window before tasks can be defined for those targets. | `bool` | `false` | no |
| <a name="input_disable_alarms_task_arn"></a> [disable\_alarms\_task\_arn](#input\_disable\_alarms\_task\_arn) | ARN of the task that disables EC2 CloudWatch alarms. | `string` | `"AWS-ConfigureCloudWatchOnEC2Instance"` | no |
| <a name="input_disable_alarms_task_description"></a> [disable\_alarms\_task\_description](#input\_disable\_alarms\_task\_description) | Description of the task that disables EC2 CloudWatch alarms. | `string` | `"Task will trigger the AWS-ConfigureCloudWatchOnEC2Instance SSM Automation doc. Disabling EC2 CloudWatch Alarms"` | no |
| <a name="input_disable_alarms_task_max_concurrency"></a> [disable\_alarms\_task\_max\_concurrency](#input\_disable\_alarms\_task\_max\_concurrency) | The maximum number of targets this task can be run for in parallel. | `number` | `1` | no |
| <a name="input_disable_alarms_task_max_errors"></a> [disable\_alarms\_task\_max\_errors](#input\_disable\_alarms\_task\_max\_errors) | The maximum number of errors allowed before this task stops being scheduled. | `number` | `1` | no |
| <a name="input_disable_alarms_task_name"></a> [disable\_alarms\_task\_name](#input\_disable\_alarms\_task\_name) | Name of the task that disables EC2 CloudWatch alarms. | `string` | `"Disable-Cloudwatch-Alarms"` | no |
| <a name="input_disable_alarms_task_priority"></a> [disable\_alarms\_task\_priority](#input\_disable\_alarms\_task\_priority) | The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel. | `number` | `10` | no |
| <a name="input_disable_alarms_task_target_key"></a> [disable\_alarms\_task\_target\_key](#input\_disable\_alarms\_task\_target\_key) | The key for the target. | `string` | `"WindowTargetIds"` | no |
| <a name="input_disable_alarms_task_type"></a> [disable\_alarms\_task\_type](#input\_disable\_alarms\_task\_type) | The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN\_COMMAND or STEP\_FUNCTIONS. | `string` | `"AUTOMATION"` | no |
| <a name="input_enable_alarms_task_arn"></a> [enable\_alarms\_task\_arn](#input\_enable\_alarms\_task\_arn) | ARN of the task that enables EC2 CloudWatch alarms. | `string` | `"AWS-ConfigureCloudWatchOnEC2Instance"` | no |
| <a name="input_enable_alarms_task_description"></a> [enable\_alarms\_task\_description](#input\_enable\_alarms\_task\_description) | Description of the task that enables EC2 CloudWatch alarms. | `string` | `"Task will trigger the AWS-ConfigureCloudWatchOnEC2Instance SSM Automation doc. Enabling EC2 CloudWatch Alarms"` | no |
| <a name="input_enable_alarms_task_max_concurrency"></a> [enable\_alarms\_task\_max\_concurrency](#input\_enable\_alarms\_task\_max\_concurrency) | The maximum number of targets this task can be run for in parallel. | `number` | `1` | no |
| <a name="input_enable_alarms_task_max_errors"></a> [enable\_alarms\_task\_max\_errors](#input\_enable\_alarms\_task\_max\_errors) | The maximum number of errors allowed before this task stops being scheduled. | `number` | `1` | no |
| <a name="input_enable_alarms_task_name"></a> [enable\_alarms\_task\_name](#input\_enable\_alarms\_task\_name) | Name of the task that enables EC2 CloudWatch alarms. | `string` | `"Enable-Cloudwatch-Alarms"` | no |
| <a name="input_enable_alarms_task_priority"></a> [enable\_alarms\_task\_priority](#input\_enable\_alarms\_task\_priority) | The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel. | `number` | `90` | no |
| <a name="input_enable_alarms_task_target_key"></a> [enable\_alarms\_task\_target\_key](#input\_enable\_alarms\_task\_target\_key) | The key for the target. | `string` | `"WindowTargetIds"` | no |
| <a name="input_enable_alarms_task_type"></a> [enable\_alarms\_task\_type](#input\_enable\_alarms\_task\_type) | The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN\_COMMAND or STEP\_FUNCTIONS. | `string` | `"AUTOMATION"` | no |
| <a name="input_modify_alarms_task_assume_role_arn"></a> [modify\_alarms\_task\_assume\_role\_arn](#input\_modify\_alarms\_task\_assume\_role\_arn) | The ARN of the IAM role that allows the Automation to perform actions on your behalf. | `string` | n/a | yes |
| <a name="input_owner_information"></a> [owner\_information](#input\_owner\_information) | User-provided value to be included in any Amazon CloudWatch Events events raised while running tasks for these targets in this Maintenance Window. | `string` | `"CCS AWS IaaS "` | no |
| <a name="input_patching_task_arn"></a> [patching\_task\_arn](#input\_patching\_task\_arn) | The ARN of the task to execute. | `string` | `"AWS-RunPatchBaseline"` | no |
| <a name="input_patching_task_description"></a> [patching\_task\_description](#input\_patching\_task\_description) | The description of the maintenance window task. | `string` | `"Task that applies patches to EC2 instances."` | no |
| <a name="input_patching_task_max_concurrency"></a> [patching\_task\_max\_concurrency](#input\_patching\_task\_max\_concurrency) | The maximum number of targets this task can be run for in parallel. | `number` | `10` | no |
| <a name="input_patching_task_max_errors"></a> [patching\_task\_max\_errors](#input\_patching\_task\_max\_errors) | The maximum number of errors allowed before this task stops being scheduled. | `number` | `1` | no |
| <a name="input_patching_task_name"></a> [patching\_task\_name](#input\_patching\_task\_name) | The name of the maintenance window task. | `string` | `"Patch-EC2-Instances"` | no |
| <a name="input_patching_task_parameter_name"></a> [patching\_task\_parameter\_name](#input\_patching\_task\_parameter\_name) | The name of the parameter for the task. | `string` | `"Operation"` | no |
| <a name="input_patching_task_parameter_values"></a> [patching\_task\_parameter\_values](#input\_patching\_task\_parameter\_values) | The values of the parameter for the task. | `list(string)` | <pre>[<br/>  "Install"<br/>]</pre> | no |
| <a name="input_patching_task_priority"></a> [patching\_task\_priority](#input\_patching\_task\_priority) | The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel. | `number` | `20` | no |
| <a name="input_patching_task_target_key"></a> [patching\_task\_target\_key](#input\_patching\_task\_target\_key) | The key for the target. | `string` | `"WindowTargetIds"` | no |
| <a name="input_patching_task_type"></a> [patching\_task\_type](#input\_patching\_task\_type) | The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN\_COMMAND or STEP\_FUNCTIONS. | `string` | `"RUN_COMMAND"` | no |
| <a name="input_window_cutoff"></a> [window\_cutoff](#input\_window\_cutoff) | The number of hours before the end of the Maintenance Window that Systems Manager stops scheduling new tasks for execution. | `number` | `1` | no |
| <a name="input_window_description"></a> [window\_description](#input\_window\_description) | A description of the Maintenance Window. Should be between 3 and 128 characters. | `string` | n/a | yes |
| <a name="input_window_duration"></a> [window\_duration](#input\_window\_duration) | The duration of the Maintenance Window in hours. | `number` | `2` | no |
| <a name="input_window_end_date"></a> [window\_end\_date](#input\_window\_end\_date) | Timestamp in ISO-8601 extended format when to no longer run the maintenance window. | `string` | n/a | yes |
| <a name="input_window_name"></a> [window\_name](#input\_window\_name) | The name of the maintenance window. | `string` | n/a | yes |
| <a name="input_window_schedule"></a> [window\_schedule](#input\_window\_schedule) | The schedule of the Maintenance Window in the form of a cron or rate expression. | `string` | n/a | yes |
| <a name="input_window_schedule_timezone"></a> [window\_schedule\_timezone](#input\_window\_schedule\_timezone) | Timezone for schedule in Internet Assigned Numbers Authority (IANA) Time Zone Database format. For example: America/Los\_Angeles, etc/UTC, or Asia/Seoul. | `string` | `"UTC"` | no |
| <a name="input_window_start_date"></a> [window\_start\_date](#input\_window\_start\_date) | Timestamp in ISO-8601 extended format when to begin the maintenance window. | `string` | n/a | yes |
| <a name="input_window_target_name"></a> [window\_target\_name](#input\_window\_target\_name) | The name of the target for the maintenance window target. | `string` | n/a | yes |
| <a name="input_window_target_resource_type"></a> [window\_target\_resource\_type](#input\_window\_target\_resource\_type) | The type of target being registered with the Maintenance Window. Possible values are INSTANCE and RESOURCE\_GROUP. | `string` | `"INSTANCE"` | no |
| <a name="input_window_targets"></a> [window\_targets](#input\_window\_targets) | A map of target definitions for the maintenance window target. | <pre>list(object({<br/>    key    = string<br/>    values = list(string)<br/>  }))</pre> | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_window_id"></a> [window\_id](#output\_window\_id) | The ID of the maintenance window. |
| <a name="output_window_target_id"></a> [window\_target\_id](#output\_window\_target\_id) | The ID of the maintenance window. |

resource "aws_glue_crawler" "glue_crawler" {
  name          = local.name
  configuration = var.configuration

  s3_target {
    path       = var.s3_target_path
    exclusions = var.exclusions
  }

  role          = var.role
  database_name = var.database_name
}
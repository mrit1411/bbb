variable "dashboard_workbook_display_name" {
  description = "Specifies the user-defined name (display name) of the workbook."
  type        = string

}

variable "name" {
  description = "Name of the deployment"
  type        = string
  default     = "azure_dashboard1"
}

variable "workbook_name" {
  description = "Name of the workbook JSON file"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
}

variable "location" {
  description = "The location in which the Dashboard will be deployed."
  type        = string
}
tags = {
  "ccs_managed" = "yes"
}

resource_group_name = "CISSpark-App"
location            = "South India"

windows_maintenance_configs = {
  "test_config" = {
    name                 = "test_window"
    location             = "South India"
    resource_group_name  = "CISSpark-App"
    reboot               = true
    start_date_time      = "2025-12-11 16:17"
    expiration_date_time = "2025-12-11 17:30"
    kb_numbers_windows   = ["KB4589208"]
    #classifications_windows   = []
  }

  "test_config_2" = {
    name                 = "test_window_2"
    location             = "South India"
    resource_group_name  = "CISSpark-App"
    reboot               = false
    start_date_time      = "2025-12-12 16:17"
    expiration_date_time = "2025-12-12 17:30"
    kb_numbers_windows   = ["KB4589208"]
    #classifications_windows   = []
  }
}

sub_id = "fb63f824-3311-4bd9-bd21-54708346da51"

sub_b_id = "63efd7f0-f279-403a-acf5-666ed15b72ab"
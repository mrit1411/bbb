patch_report_generation_schedule_monthly = "cron(59 23 L * ? *)"
# patch_report_generation_schedule_monthly = "rate(5 minutes)"
patch_reports_bucket_name = "patch-reports"
# regions                   = ["eu-west-1", "us-east-1", "ap-south-1", "us-east-2", "ap-southeast-1", "eu-central-1"]
regions = ["eu-central-1", "us-east-1", "ap-east-1", "eu-west-2"]

periodic_patching_report_recipient = ["ajith.k@capgemini.com","manjunath.n1@capgemini.com"]

windows_baseline = [
  {
    name        = "CCS-windows-server-patch-baseline"
    description = "Windows patch baseline installing critical and security updates. Deployed as part of CCS Patching Solution."
    os          = "WINDOWS"
    approval_rules = {
      approve_after_days = 1
      patch_filters = [
        {
          key = "CLASSIFICATION"
          # values = ["CriticalUpdates", "SecurityUpdates"]
          values = ["SecurityUpdates"]
        },
        {
          key = "MSRC_SEVERITY"
          # values = ["Critical", "Important"]
          values = ["Critical"]
        }
      ]
    }
  }
]

linux_baseline = [
  {
    name             = "CCS-suse-linux-patch-baseline"
    description      = "SUSE patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "SUSE"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-rhel-patch-baseline"
    description      = "RHEL patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "REDHAT_ENTERPRISE_LINUX"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-ubuntu-patch-baseline"
    description      = "Ubuntu patch baseline installing important and required updates. Deployed as part of CCS Patching Solution."
    os               = "UBUNTU"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-centos-patch-baseline"
    description      = "CentOS patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "CENTOS"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-debian-linux-patch-baseline"
    description      = "Debian patch baseline installing security updates. Deployed as part of CCS Patching Solution."
    os               = "DEBIAN"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-oracle-linux-patch-baseline"
    description      = "Oracle Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "ORACLE_LINUX"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-amazon-linux-patch-baseline"
    description      = "Amazon Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "AMAZON_LINUX"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  },
  {
    name             = "CCS-amazon-linux-2-patch-baseline"
    description      = "Amazon Linux 2 patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
    os               = "AMAZON_LINUX_2"
    approved_patches = ["kernel*", "microcode*", "sudo*"]
    approval_rules   = []
    # approval_rules = [{
    # approve_after_days = 1
    # patch_filters = [
    #   {
    #     key    = "CLASSIFICATION"
    #     values = ["Security", "Bugfix"]
    #   },
    #   {
    #     key    = "SEVERITY"
    #     values = ["Critical", "Important"]
    #   }
    # ]
    # }]
  }
]


terraform {
  required_version = ">= 1.6"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.50"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = "84f2d25e-f251-4492-8df9-77cf3b48a151"
}

# provider "azurerm" {
#   alias           = "sub1"
#   features        {}
#   subscription_id = "fb63f824-3311-4bd9-bd21-54708346da51"
# }

provider "azurerm" {
  alias = "sub1"
  features {}
  subscription_id = "84f2d25e-f251-4492-8df9-77cf3b48a151"

}

provider "azurerm" {
  alias = "sub2"
  features {}
  subscription_id = "63efd7f0-f279-403a-acf5-666ed15b72ab"
}
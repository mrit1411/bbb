﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_lambda_layer_version.lambda_layer_version](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_layer_version) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_compatible_runtimes"></a> [compatible\_runtimes](#input\_compatible\_runtimes) | List of Runtimes this layer is compatible with. Up to 15 runtimes can be specified. | `list(string)` | <pre>[<br/>  "python3.12"<br/>]</pre> | no |
| <a name="input_description"></a> [description](#input\_description) | Description of what your Lambda Layer does. | `string` | n/a | yes |
| <a name="input_filename"></a> [filename](#input\_filename) | The path to the zip file containing the Lambda Layer code. | `string` | n/a | yes |
| <a name="input_layer_name"></a> [layer\_name](#input\_layer\_name) | Unique name for your Lambda Layer. | `string` | n/a | yes |

## Outputs

No outputs.

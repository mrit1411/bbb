variable "name" {
  description = "Name of the maintenance configuration"
  type        = string
}

variable "location" {
  description = "Location of the maintenance configuration"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
}

variable "reboot" {
  description = "Reboot option for the maintenance configuration"
  type        = bool
  default = false
}

variable "time_zone" {
  description = "Time zone for the maintenance configuration"
  type        = string
  default     = "Eastern Standard Time"
}

variable "tags" {
  description = "Tags for the maintenance configuration"
  type        = map(string)
}

variable "classifications_windows" {
  description = "Windows classifications to include"
  type        = list(string)
  default     = []
}

variable "classifications_linux" {
  description = "Linux classifications to include"
  type        = list(string)
  default     = ["Security", "Critical"]
}

variable "kb_numbers_windows" {
  description = "KB numbers to include for Windows"
  type        = list(string)
  default     = null
}

variable "start_date_time" {
  description = "Effective start date of the maintenance window in YYYY-MM-DD hh:mm format."
  type        = string
  default = "2026-01-08 18:15"
}

variable "expiration_date_time" {
  description = "Effective expiration date of the maintenance window in YYYY-MM-DD hh:mm format."
  type        = string
  default = "2099-01-06 19:15"
}

variable "recur_every" {
  description = "The rate at which a maintenance window is expected to recur. The rate can be expressed as daily, weekly, or monthly schedules."
  type        = string
  default     = "Day"
}

variable "duration" {
  description = "The duration of the maintenance window in HH:mm format."
  type        = string
  default     = "02:59"
}

variable "is_reference" {
  description = "Marks this maintenance configuration as the source-of-truth patch run for the month"
  type        = bool
  default     = false
}
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 6.3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 6.3.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_availability_report_sns_topic"></a> [availability\_report\_sns\_topic](#module\_availability\_report\_sns\_topic) | ../modules/aws_sns_topic | n/a |
| <a name="module_availability_report_sns_topic_subscription"></a> [availability\_report\_sns\_topic\_subscription](#module\_availability\_report\_sns\_topic\_subscription) | ../modules/aws_sns_topic_subscription | n/a |
| <a name="module_availability_report_url_user"></a> [availability\_report\_url\_user](#module\_availability\_report\_url\_user) | ../modules/aws_iam_user | n/a |
| <a name="module_availability_reports_automation_trigger_monthly"></a> [availability\_reports\_automation\_trigger\_monthly](#module\_availability\_reports\_automation\_trigger\_monthly) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_availability_reports_lambda_function"></a> [availability\_reports\_lambda\_function](#module\_availability\_reports\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_availability_reports_lambda_permission"></a> [availability\_reports\_lambda\_permission](#module\_availability\_reports\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_availability_url_credentials_stored"></a> [availability\_url\_credentials\_stored](#module\_availability\_url\_credentials\_stored) | ../modules/aws_secretsmanager_secret | n/a |
| <a name="module_availability_url_user_credentials"></a> [availability\_url\_user\_credentials](#module\_availability\_url\_user\_credentials) | ../modules/aws_iam_access_key | n/a |
| <a name="module_collectd_config_ssm_parameter"></a> [collectd\_config\_ssm\_parameter](#module\_collectd\_config\_ssm\_parameter) | ../modules/aws_ssm_parameter | n/a |
| <a name="module_create_alarms_event_rule"></a> [create\_alarms\_event\_rule](#module\_create\_alarms\_event\_rule) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_create_cloud_watch_alarms_for_instances_lambda_function"></a> [create\_cloud\_watch\_alarms\_for\_instances\_lambda\_function](#module\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_create_cloud_watch_alarms_for_instances_lambda_permission"></a> [create\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission](#module\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_cw_agent_update_ssm_association"></a> [cw\_agent\_update\_ssm\_association](#module\_cw\_agent\_update\_ssm\_association) | ../modules/aws_ssm_association | n/a |
| <a name="module_event_report_url_user"></a> [event\_report\_url\_user](#module\_event\_report\_url\_user) | ../modules/aws_iam_user | n/a |
| <a name="module_events_report_sns_topic"></a> [events\_report\_sns\_topic](#module\_events\_report\_sns\_topic) | ../modules/aws_sns_topic | n/a |
| <a name="module_events_report_sns_topic_subscription"></a> [events\_report\_sns\_topic\_subscription](#module\_events\_report\_sns\_topic\_subscription) | ../modules/aws_sns_topic_subscription | n/a |
| <a name="module_events_reports_automation_trigger_monthly"></a> [events\_reports\_automation\_trigger\_monthly](#module\_events\_reports\_automation\_trigger\_monthly) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_events_reports_lambda_function"></a> [events\_reports\_lambda\_function](#module\_events\_reports\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_events_reports_lambda_permission"></a> [events\_reports\_lambda\_permission](#module\_events\_reports\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_events_url_credentials_stored"></a> [events\_url\_credentials\_stored](#module\_events\_url\_credentials\_stored) | ../modules/aws_secretsmanager_secret | n/a |
| <a name="module_events_url_user_credentials"></a> [events\_url\_user\_credentials](#module\_events\_url\_user\_credentials) | ../modules/aws_iam_access_key | n/a |
| <a name="module_lambda_availability_reports_iam_role"></a> [lambda\_availability\_reports\_iam\_role](#module\_lambda\_availability\_reports\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_lambda_create_cloudwatch_alarms_iam_role"></a> [lambda\_create\_cloudwatch\_alarms\_iam\_role](#module\_lambda\_create\_cloudwatch\_alarms\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_lambda_events_reports_iam_role"></a> [lambda\_events\_reports\_iam\_role](#module\_lambda\_events\_reports\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_lambda_performance_reports_iam_role"></a> [lambda\_performance\_reports\_iam\_role](#module\_lambda\_performance\_reports\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_lambda_terminate_cloudwatch_alarms_iam_role"></a> [lambda\_terminate\_cloudwatch\_alarms\_iam\_role](#module\_lambda\_terminate\_cloudwatch\_alarms\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_linux_ssm_parameter"></a> [linux\_ssm\_parameter](#module\_linux\_ssm\_parameter) | ../modules/aws_ssm_parameter | n/a |
| <a name="module_performance_report_automation_trigger_monthly"></a> [performance\_report\_automation\_trigger\_monthly](#module\_performance\_report\_automation\_trigger\_monthly) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_performance_report_sns_topic"></a> [performance\_report\_sns\_topic](#module\_performance\_report\_sns\_topic) | ../modules/aws_sns_topic | n/a |
| <a name="module_performance_report_sns_topic_subscription"></a> [performance\_report\_sns\_topic\_subscription](#module\_performance\_report\_sns\_topic\_subscription) | ../modules/aws_sns_topic_subscription | n/a |
| <a name="module_performance_report_url_user"></a> [performance\_report\_url\_user](#module\_performance\_report\_url\_user) | ../modules/aws_iam_user | n/a |
| <a name="module_performance_reports_lambda_function"></a> [performance\_reports\_lambda\_function](#module\_performance\_reports\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_performance_reports_lambda_permission"></a> [performance\_reports\_lambda\_permission](#module\_performance\_reports\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_performance_url_credentials_stored"></a> [performance\_url\_credentials\_stored](#module\_performance\_url\_credentials\_stored) | ../modules/aws_secretsmanager_secret | n/a |
| <a name="module_performance_url_user_credentials"></a> [performance\_url\_user\_credentials](#module\_performance\_url\_user\_credentials) | ../modules/aws_iam_access_key | n/a |
| <a name="module_s3_bucket_availability_reports"></a> [s3\_bucket\_availability\_reports](#module\_s3\_bucket\_availability\_reports) | ../modules/aws_s3_bucket | n/a |
| <a name="module_s3_bucket_events_reports"></a> [s3\_bucket\_events\_reports](#module\_s3\_bucket\_events\_reports) | ../modules/aws_s3_bucket | n/a |
| <a name="module_s3_bucket_performance_reports"></a> [s3\_bucket\_performance\_reports](#module\_s3\_bucket\_performance\_reports) | ../modules/aws_s3_bucket | n/a |
| <a name="module_tag_based_create_alarms_event_rule"></a> [tag\_based\_create\_alarms\_event\_rule](#module\_tag\_based\_create\_alarms\_event\_rule) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_tag_based_create_cloud_watch_alarms_for_instances_lambda_function"></a> [tag\_based\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_function](#module\_tag\_based\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_tag_based_create_cloud_watch_alarms_for_instances_lambda_permission"></a> [tag\_based\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission](#module\_tag\_based\_create\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_terminate_alarms_event_rule"></a> [terminate\_alarms\_event\_rule](#module\_terminate\_alarms\_event\_rule) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_terminate_cloud_watch_alarms_for_instances_lambda_function"></a> [terminate\_cloud\_watch\_alarms\_for\_instances\_lambda\_function](#module\_terminate\_cloud\_watch\_alarms\_for\_instances\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_terminate_cloud_watch_alarms_for_instances_lambda_permission"></a> [terminate\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission](#module\_terminate\_cloud\_watch\_alarms\_for\_instances\_lambda\_permission) | ../modules/aws_lambda_permission | n/a |
| <a name="module_windows_ssm_parameter"></a> [windows\_ssm\_parameter](#module\_windows\_ssm\_parameter) | ../modules/aws_ssm_parameter | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/region) | data source |
| [terraform_remote_state.infra](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_CWAgentUpdateAssociation"></a> [CWAgentUpdateAssociation](#input\_CWAgentUpdateAssociation) | Name of the CloudWatch Agent update association | `string` | n/a | yes |
| <a name="input_account_name"></a> [account\_name](#input\_account\_name) | Enter the name of Client. | `string` | `"TestClient"` | no |
| <a name="input_additional_regions"></a> [additional\_regions](#input\_additional\_regions) | Set of additional AWS regions for replication | `set(string)` | n/a | yes |
| <a name="input_availability_link_validity"></a> [availability\_link\_validity](#input\_availability\_link\_validity) | Enter how long in seconds the AWS Availability Report notification link will be valid for (86400 - 24h, 604800 - 7 days) | `number` | `604800` | no |
| <a name="input_availability_report_generation_schedule_monthly"></a> [availability\_report\_generation\_schedule\_monthly](#input\_availability\_report\_generation\_schedule\_monthly) | Enter the schedule for Monthly AWS Availability report generation. AWS CRON expression specifying when the Availability EventBridge Rule will initiate the generation of monthly AWS Availability reports. by default (01:30 AM first day of every month) | `string` | `"cron(30 1 1 * ? *)"` | no |
| <a name="input_availability_report_recipient"></a> [availability\_report\_recipient](#input\_availability\_report\_recipient) | Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Availability Reports | `string` | `"akarsh.a.srivastava@capgemini.com"` | no |
| <a name="input_availability_report_sns_topic_name"></a> [availability\_report\_sns\_topic\_name](#input\_availability\_report\_sns\_topic\_name) | Enter the name for the SNS Topic that will be created and used by the Availability report lambda to email monthly AWS Availability reports | `string` | `"Availability-Reports"` | no |
| <a name="input_availability_report_url_user"></a> [availability\_report\_url\_user](#input\_availability\_report\_url\_user) | IAM user for AvailabilityReportURLUser | `string` | `"AvailabilityReportURLUser"` | no |
| <a name="input_availability_reports_bucket_name"></a> [availability\_reports\_bucket\_name](#input\_availability\_reports\_bucket\_name) | Enter the name of the S3 bucket that will be created and used to store monthly AWS Availability reports | `string` | `"ccs-availability-reports-bucket"` | no |
| <a name="input_availability_url_user_credentials"></a> [availability\_url\_user\_credentials](#input\_availability\_url\_user\_credentials) | iam user for AvailabilityURLUserCredentials | `string` | `"AvailabilityURLUserCredentials"` | no |
| <a name="input_collectd_config_ssm_parameter_name"></a> [collectd\_config\_ssm\_parameter\_name](#input\_collectd\_config\_ssm\_parameter\_name) | Name of the SSM parameter for collectd config | `string` | n/a | yes |
| <a name="input_collectd_config_ssm_parameter_type"></a> [collectd\_config\_ssm\_parameter\_type](#input\_collectd\_config\_ssm\_parameter\_type) | Type of the collectd config parameter (String, SecureString, StringList) | `string` | n/a | yes |
| <a name="input_collectd_config_ssm_parameter_value"></a> [collectd\_config\_ssm\_parameter\_value](#input\_collectd\_config\_ssm\_parameter\_value) | Value of the collectd config parameter | `string` | n/a | yes |
| <a name="input_engagements"></a> [engagements](#input\_engagements) | List of engagements for the response plan | `list(string)` | `[]` | no |
| <a name="input_event_report_url_user"></a> [event\_report\_url\_user](#input\_event\_report\_url\_user) | IAM user for EventsReportURLUser | `string` | `"EventsReportURLUser"` | no |
| <a name="input_events_report_generation_schedule_monthly"></a> [events\_report\_generation\_schedule\_monthly](#input\_events\_report\_generation\_schedule\_monthly) | Enter the schedule for Monthly AWS Events report generation. AWS CRON expression specifying when the Events EventBridge Rule will initiate the generation of monthly AWS Events reports. by default (01:30 AM first day of every month) | `string` | `"cron(30 1 1 * ? *)"` | no |
| <a name="input_events_report_recipient"></a> [events\_report\_recipient](#input\_events\_report\_recipient) | Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Events Reports | `string` | `"akarsh.a.srivastava@capgemini.com"` | no |
| <a name="input_events_report_sns_topic_name"></a> [events\_report\_sns\_topic\_name](#input\_events\_report\_sns\_topic\_name) | Enter the name for the SNS Topic that will be created and used by the Events report lambda to email monthly AWS Events reports | `string` | `"Events-Reports"` | no |
| <a name="input_events_reports_bucket_name"></a> [events\_reports\_bucket\_name](#input\_events\_reports\_bucket\_name) | Enter the name of the S3 bucket that will be created and used to store monthly AWS Events reports | `string` | `"ccs-events-reports-bucket"` | no |
| <a name="input_events_url_user_credentials"></a> [events\_url\_user\_credentials](#input\_events\_url\_user\_credentials) | iam user for EventsURLUserCredentials | `string` | `"EventsURLUserCredentials"` | no |
| <a name="input_incident_impact"></a> [incident\_impact](#input\_incident\_impact) | Impact severity level for the incident (1 to 5) | `number` | n/a | yes |
| <a name="input_incident_summary"></a> [incident\_summary](#input\_incident\_summary) | Summary of what the incident response plan handles | `string` | n/a | yes |
| <a name="input_incident_tags"></a> [incident\_tags](#input\_incident\_tags) | Tags specific to incident response plan | `map(string)` | `{}` | no |
| <a name="input_incident_title"></a> [incident\_title](#input\_incident\_title) | Title for the incident response plan | `string` | n/a | yes |
| <a name="input_linux_ssm_parameter_name"></a> [linux\_ssm\_parameter\_name](#input\_linux\_ssm\_parameter\_name) | Name of the Linux SSM parameter | `string` | n/a | yes |
| <a name="input_linux_ssm_parameter_type"></a> [linux\_ssm\_parameter\_type](#input\_linux\_ssm\_parameter\_type) | Type of the Linux SSM parameter | `string` | n/a | yes |
| <a name="input_linux_ssm_parameter_value"></a> [linux\_ssm\_parameter\_value](#input\_linux\_ssm\_parameter\_value) | Value of the Linux SSM parameter | `string` | n/a | yes |
| <a name="input_logging_enabled"></a> [logging\_enabled](#input\_logging\_enabled) | Set to true if Incident Manager is already enabled | `bool` | `true` | no |
| <a name="input_monitoring_enabled"></a> [monitoring\_enabled](#input\_monitoring\_enabled) | Specifies if the CCS Incident Manager module and resources will be deployed. | `bool` | `true` | no |
| <a name="input_performace_report_generation_schedule_monthly"></a> [performace\_report\_generation\_schedule\_monthly](#input\_performace\_report\_generation\_schedule\_monthly) | Enter the schedule for Monthly AWS Performance report generation. AWS CRON expression specifying when the Performance EventBridge Rule will initiate the generation of monthly AWS Performance reports. by default (01:30 AM first day of every month) | `string` | `"cron(30 1 1 * ? *)"` | no |
| <a name="input_performance_report_recipient"></a> [performance\_report\_recipient](#input\_performance\_report\_recipient) | Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Performance Reports | `string` | `"akarsh.a.srivastava@capgemini.com"` | no |
| <a name="input_performance_report_sns_topic_name"></a> [performance\_report\_sns\_topic\_name](#input\_performance\_report\_sns\_topic\_name) | Enter the name for the SNS Topic that will be created and used by the Performance report lambda to email monthly AWS Performance reports | `string` | `"Performance-Reports"` | no |
| <a name="input_performance_report_url_user"></a> [performance\_report\_url\_user](#input\_performance\_report\_url\_user) | IAM user for PerformanceReportURLUser | `string` | `"PerformanceReportURLUser"` | no |
| <a name="input_performance_reports_bucket_name"></a> [performance\_reports\_bucket\_name](#input\_performance\_reports\_bucket\_name) | Enter the name of the S3 bucket that will be created and used to store monthly AWS Performance reports | `string` | `"ccs-performance-reports-bucket"` | no |
| <a name="input_performance_url_user_credentials"></a> [performance\_url\_user\_credentials](#input\_performance\_url\_user\_credentials) | iam user for PerformanceURLUserCredentials | `string` | `"PerformanceURLUserCredentials"` | no |
| <a name="input_primary_region"></a> [primary\_region](#input\_primary\_region) | Primary AWS region for incident replication | `string` | n/a | yes |
| <a name="input_replication_set_name"></a> [replication\_set\_name](#input\_replication\_set\_name) | Name for the replication set (deprecated, not used in latest Terraform block) | `string` | `"deprecated"` | no |
| <a name="input_response_actions"></a> [response\_actions](#input\_response\_actions) | List of response actions for the incident response plan | <pre>list(object({<br/>    ssm_automation = object({<br/>      document_name = string<br/>      role_arn      = string<br/>      parameters    = map(string)<br/>    })<br/>  }))</pre> | n/a | yes |
| <a name="input_response_plan_name"></a> [response\_plan\_name](#input\_response\_plan\_name) | Name of the incident response plan | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to apply to all applicable resources | `map(string)` | <pre>{<br/>  "Environment": "production",<br/>  "Owner": "infra-team"<br/>}</pre> | no |
| <a name="input_tags_condition_key"></a> [tags\_condition\_key](#input\_tags\_condition\_key) | Resources with this Tag Key will be managed by CCS Monitoring and SSM | `string` | `"ccs_managed"` | no |
| <a name="input_tags_condition_value"></a> [tags\_condition\_value](#input\_tags\_condition\_value) | Resources with this Tag Value will be managed by CCS Monitoring and SSM | `string` | `"yes"` | no |
| <a name="input_windows_ssm_parameter_name"></a> [windows\_ssm\_parameter\_name](#input\_windows\_ssm\_parameter\_name) | Name of the Windows SSM parameter | `string` | n/a | yes |
| <a name="input_windows_ssm_parameter_type"></a> [windows\_ssm\_parameter\_type](#input\_windows\_ssm\_parameter\_type) | Type of the Windows SSM parameter | `string` | n/a | yes |
| <a name="input_windows_ssm_parameter_value"></a> [windows\_ssm\_parameter\_value](#input\_windows\_ssm\_parameter\_value) | Value of the Windows SSM parameter | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
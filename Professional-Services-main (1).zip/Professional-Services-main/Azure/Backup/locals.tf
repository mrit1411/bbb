locals {

  standard_backup_map = {
    sub1 = {
      sub_id  = var.subscriptions["sub1"].subscription_id
      regions = module.backup_policy_sub1.standard_policy_ids
    }
  }

  enhanced_backup_map = {
    sub1 = {
      sub_id  = var.subscriptions["sub1"].subscription_id
      regions = module.backup_policy_sub1.enhanced_policy_ids
    }
  }
  flattened_standard_backup_map = {
    for item in flatten([
      for sub_key, sub_data in local.standard_backup_map : [
        for region, bp_id in sub_data.regions : {
          sub_key = sub_key
          sub_id  = sub_data.sub_id
          region  = region
          bp_id   = bp_id
        }
      ]
    ]) :

    "${item.sub_id}-${item.region}" => {
      sub_id = item.sub_id
      region = item.region
      bp_id  = item.bp_id
    }
  }

  flattened_enhanced_backup_map = {
    for item in flatten([
      for sub_key, sub_data in local.enhanced_backup_map : [
        for region, bp_id in sub_data.regions : {
          sub_key = sub_key
          sub_id  = sub_data.sub_id
          region  = region
          bp_id   = bp_id
        }
      ]
    ]) :

    "${item.sub_id}-${item.region}" => {
      sub_id = item.sub_id
      region = item.region
      bp_id  = item.bp_id
    }
  }
}
module "firehose_delivery_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "CCS Firehose Delivery Role IAM Role"
  resource_type = "Firehose"
  context       = "Logging"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "FirehoseDeliveryRolePolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/firehose_delivery_role_policy.tpl.json", {
        kinesis_athena_bucket_name = module.kinesis_athena_bucket.bucket_id,
        lambda_convert_logs_arn    = module.convert_logs_to_json_lambda_function.arn
      })
    }
  }
}

module "lambda_log_group_subscription_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Lambda log group subscription IAM Role"
  context       = "Logging"
  resource_type = "Lambda"
  path          = "/service-role/"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = ["lambda.amazonaws.com", "logs.${data.aws_region.current.region}.amazonaws.com"]
        }
        Action = "sts:AssumeRole"
      }
    ]
  })
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaLogGroupSubscriptionRolePolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/lambda_log_group_subscription_role_policy.tpl.json", {
        kinesis_firehose_delivery_stream_arn = module.kinesis_firehose_delivery_stream.arn
      })
    }
  }
}

module "glue_crawler_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Glue Crawler IAM Role"
  context       = "Logging"
  resource_type = "Glue"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "GlueCrawlerRolePolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/glue_crawler_role_policy.tpl.json", {
        kinesis_athena_bucket_name = module.kinesis_athena_bucket.bucket_id
      })
    }
  }
}

module "linux_ssm_parameter" {
  source = "../modules/aws_ssm_parameter"

  name        = "AmazonCloudWatch-ccslinuxloggingconfiguration"
  tier        = "Advanced"
  description = "Default cloudwatch configuration for Linux"
  parameter_file = templatefile("../modules/aws_ssm_parameter/parameters/linux_logging_ssm_parameter.tpl.json", {
    log_group_name = module.ec2_instance_cloudwatch_log_group.name
  })
}

module "windows_ssm_parameter" {
  source = "../modules/aws_ssm_parameter"

  name        = "AmazonCloudWatch-ccswindowsloggingconfiguration"
  tier        = "Advanced"
  description = "default cloudwatch setup configuration file for Windows"
  parameter_file = templatefile("../modules/aws_ssm_parameter/parameters/windows_logging_ssm_parameter.tpl.json", {
    log_group_name = module.ec2_instance_cloudwatch_log_group.name
  })
}

module "athena_workgroup" {
  source = "../modules/aws_athena_workgroup"

  client_name                        = var.client_name
  description                        = "Workgroup for logging module to allow query database which contains EC2 logs"
  publish_cloudwatch_metrics_enabled = false
  enforce_workgroup_configuration    = false
  output_location                    = "s3://${module.kinesis_athena_bucket.bucket_id}/Athena"
}

module "glue_crawler" {
  source = "../modules/aws_glue_crawler"

  client_name = var.client_name

  configuration = jsonencode({
    Version = 1.0
    Grouping = {
      TableLevelConfiguration = 1
      TableGroupingPolicy     = "CombineCompatibleSchemas"
    }
  })
  s3_target_path = "s3://${module.kinesis_athena_bucket.bucket_id}/"
  exclusions     = ["Athena/**", "kinesis-processing-failed/**"]
  role           = module.glue_crawler_iam_role.role_arn
  database_name  = "${var.client_name}db"
}

module "glue_scheduled_job_trigger" {
  source = "../modules/aws_glue_trigger"

  client_name  = var.client_name
  crawler_name = module.glue_crawler.id
  schedule     = "cron(0 8 * * ? *)"
}

module "convert_logs_to_json_lambda_function" {
  source = "../modules/aws_lambda_function"

  lambda_function_filename = "lambda_convert_logs_to_json"
  role                     = module.lambda_log_group_subscription_iam_role.role_arn
  description              = "Lambda to convert CloudWatch logs to JSON"
  handler                  = "lambda_convert_logs_to_json.lambda_handler"
  timeout                  = 300
  memory_size              = 128
}

module "ec2_instance_cloudwatch_log_group" {
  source = "../modules/aws_cloudwatch_log_group"

  name              = var.log_group_name
  retention_in_days = var.log_retention_in_days
}

module "firehose_cloudwatch_log_group" {
  source = "../modules/aws_cloudwatch_log_group"

  name = var.firehose_log_group_name
}

module "firehose_cloudwatch_log_stream" {
  source = "../modules/aws_cloudwatch_log_stream"

  name           = var.firehose_log_stream_name
  log_group_name = module.firehose_cloudwatch_log_group.name
}

module "firehose_subscription_filter" {
  source = "../modules/aws_cloudwatch_log_subscription_filter"

  name            = var.firehose_subscription_filter_name
  log_group_name  = module.ec2_instance_cloudwatch_log_group.name
  role_arn        = module.lambda_log_group_subscription_iam_role.role_arn
  destination_arn = module.kinesis_firehose_delivery_stream.arn
}

module "kinesis_firehose_delivery_stream" {
  source = "../modules/aws_kinesis_firehose_delivery_stream"

  name                       = var.kinesis_firehose_delivery_stream_name
  bucket_arn                 = module.kinesis_athena_bucket.bucket_arn
  prefix                     = var.kinesis_firehose_delivery_stream_prefix
  buffering_interval         = 60
  buffering_size             = 100
  cloudwatch_logging_enabled = true
  log_group_name             = module.firehose_cloudwatch_log_group.name
  log_stream_name            = module.firehose_cloudwatch_log_stream.name
  processing_enabled         = true
  processing_parameter_name  = "LambdaArn"
  processing_parameter_value = module.convert_logs_to_json_lambda_function.arn
  processor_type             = "Lambda"
  role_arn                   = module.firehose_delivery_iam_role.role_arn
  destination                = "extended_s3"
  compression_format         = "GZIP"
}

module "kinesis_athena_bucket" {
  source = "../modules/aws_s3_bucket"

  bucket_base_name = var.kinesis_athena_bucket_name
  rule_id          = "TransitionThenRemoveAfterDays"
  expiration_days  = 90
}
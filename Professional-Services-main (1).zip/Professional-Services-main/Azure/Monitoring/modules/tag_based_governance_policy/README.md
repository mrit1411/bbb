﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_management_group_policy_assignment.policy_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_group_policy_assignment) | resource |
| [azurerm_policy_definition.policy_definition](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/policy_definition) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | The description of the policy definition. | `string` | n/a | yes |
| <a name="input_display_name"></a> [display\_name](#input\_display\_name) | The display name of the policy definition. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure region where the policy assignment will be created. | `string` | n/a | yes |
| <a name="input_management_group_id"></a> [management\_group\_id](#input\_management\_group\_id) | The ID of the Management Group. Changing this forces a new Policy Assignment to be created. | `string` | n/a | yes |
| <a name="input_mode"></a> [mode](#input\_mode) | The policy resource manager mode that allows you to specify which resource types will be evaluated. | `string` | `"Indexed"` | no |
| <a name="input_name"></a> [name](#input\_name) | The name of the policy definition. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_policy_assignment_parameters"></a> [policy\_assignment\_parameters](#input\_policy\_assignment\_parameters) | The parameters for the policy assignment. | `string` | `""` | no |
| <a name="input_policy_parameters_filename"></a> [policy\_parameters\_filename](#input\_policy\_parameters\_filename) | The filename of the policy parameters JSON file. | `string` | n/a | yes |
| <a name="input_policy_rule_filename"></a> [policy\_rule\_filename](#input\_policy\_rule\_filename) | The filename of the policy rule JSON file. | `string` | n/a | yes |
| <a name="input_policy_type"></a> [policy\_type](#input\_policy\_type) | The policy type. Possible values are BuiltIn, Custom, NotSpecified and Static. Changing this forces a new resource to be created. | `string` | `"Custom"` | no |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | The ID of the Subscription where this Policy Assignment should be created. Changing this forces a new Policy Assignment to be created. | `string` | n/a | yes |
| <a name="input_user_assigned_identity_ids"></a> [user\_assigned\_identity\_ids](#input\_user\_assigned\_identity\_ids) | List of User Assigned Identity IDs to be used for the policy assignment. | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_assignment_id"></a> [assignment\_id](#output\_assignment\_id) | n/a |
| <a name="output_assignment_name"></a> [assignment\_name](#output\_assignment\_name) | n/a |
| <a name="output_definition_id"></a> [definition\_id](#output\_definition\_id) | n/a |

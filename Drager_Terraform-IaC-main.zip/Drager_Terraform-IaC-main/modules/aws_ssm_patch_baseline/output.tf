output "patch_baseline" {
  value = aws_ssm_patch_baseline.ssm_patch_baseline
}
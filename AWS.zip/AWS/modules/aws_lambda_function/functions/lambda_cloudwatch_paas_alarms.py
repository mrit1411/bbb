import boto3
import os

# Environment variables
TAG_KEY = os.environ['TagsConditionKey']
TAG_VALUE = os.environ['TagsConditionValue']
SNS_TOPIC_ARN = os.environ['SNOWSNSTopicARN']
COMPANY = os.environ.get('Company')

# AWS clients
rds = boto3.client('rds')
tagging = boto3.client('resourcegroupstaggingapi')
lambda_client = boto3.client('lambda')
elbv2 = boto3.client('elbv2')
cloudwatch = boto3.client('cloudwatch')

def lambda_handler(event, context):
    service = event.get('detail', {}).get('service', '').lower()
    resource_arns = event.get('resources', [])
# check if multiple resources are provided in the event
    if not service or not resource_arns:
        raise ValueError("Missing service or resource ARN in the event.")

    print(f"Received event for service: {service}, resources: {resource_arns}")

    for arn in resource_arns:
        match service:
            case 'rds':
                alarm_rds(arn)
            case 'lambda':
                alarm_lambda(arn)
            case 'elasticloadbalancing':
                alarm_alb(arn)
            case _:
                raise ValueError(f"Unsupported service: {service}")

    return {'statusCode': 200, 'body': f'Alarms created for {service} resources'}

def create_alarm(name, metric, namespace, statistic, period, evaluation_periods, dimensions, threshold, comparison, description,resourcename,tagslist):
    alarmname=f'CCS - {name}'
    # existing_alarms = cloudwatch.describe_alarms(AlarmNames=[alarmname])['MetricAlarms']
    # if existing_alarms:
    #     print(f"Alarm already exists: {name}")
    #     return
    tagslist.append({'Key': "ResourceName",'Value': resourcename})
    cloudwatch.put_metric_alarm(
        AlarmName=alarmname,
        MetricName=metric,
        Namespace=namespace,
        Statistic=statistic,
        Period=period,
        EvaluationPeriods=evaluation_periods,
        Threshold=threshold,
        ComparisonOperator=comparison,
        AlarmDescription=description,
        Dimensions=dimensions,
        AlarmActions=[SNS_TOPIC_ARN],
        OKActions=[SNS_TOPIC_ARN],
        Tags=tagslist
    )
    print(f"Created alarm: {name}")
# check alarm is gettings recreated if it already exists
def alarm_rds(arn):
    db_id = arn.split(':')[-1]
    db = rds.describe_db_instances(DBInstanceIdentifier=db_id)['DBInstances'][0]
    tags = getresourcetags(arn)
    allocated_bytes = db['AllocatedStorage'] * 1073741824
    threshold_bytes = allocated_bytes * 0.2

    create_alarm(
        f"{db_id}: RDS DB : High CPU utilisation alert", "CPUUtilization", "AWS/RDS", "Average", 300, 1,
        [{"Name": "DBInstanceIdentifier", "Value": db_id}],
        80, "GreaterThanThreshold", "High RDS CPU usage > 80% over 5 minutes",db_id,tags
    )
    create_alarm(
        f"{db_id}: RDS DB : Low Storage Space alert", "FreeStorageSpace", "AWS/RDS", "Average", 300, 1,
        [{"Name": "DBInstanceIdentifier", "Value": db_id}],
        threshold_bytes, "LessThanThreshold", "RDS storage > 80% used over 5 minutes",db_id,tags
    )
# the freestorage space alarm needs to be updated manually if the db storage is increased by removing and re-adding the tag

def alarm_lambda(arn):
    fn_name = arn.split(':')[-1]

    tags = getresourcetags(arn)

    create_alarm(
        f"{fn_name}: Lambda function : Errors alert", "Errors", "AWS/Lambda", "Sum", 300, 1,
        [{"Name": "FunctionName", "Value": fn_name}],
        0, "GreaterThanThreshold", "Lambda function has one or more errors over 5 minutes",fn_name,tags
    )

def alarm_alb(arn):
    lb = elbv2.describe_load_balancers(LoadBalancerArns=[arn])['LoadBalancers'][0]
    lb_name = lb['LoadBalancerName']
    lb_id = arn.split('/')[-1]
    lb_metric_id = f"app/{lb_name}/{lb_id}"

    tags = getresourcetags(arn)

    tg_response = elbv2.describe_target_groups(LoadBalancerArn=arn)
    for tg in tg_response['TargetGroups']:
        tg_name = tg['TargetGroupName']
        tg_id = tg['TargetGroupArn'].split('/')[-1]
        tg_metric_id = f"targetgroup/{tg_name}/{tg_id}"

        create_alarm(
            f"{lb_name} - ALB : {tg_name} - tg : Unhealthy hosts alert", "UnHealthyHostCount",
            "AWS/ApplicationELB", "Average", 300, 1,
            [
                {"Name": "TargetGroup", "Value": tg_metric_id},
                {"Name": "LoadBalancer", "Value": lb_metric_id}
            ],
            0, "GreaterThanThreshold", "ALB has unhealthy hosts over 5 minutes",lb_name,tags
        )

# def getresourcetags(arn):
#     response = tagging.get_resources(ResourceARNList=[arn])
#     tag = response['ResourceTagMappingList'][0]['Tags']
#     tag.append({'Key':'ccs_managed','Value':'yes'})
#     return tag
	
def getresourcetags(arn):
    try:
        response = tagging.get_resources(ResourceARNList=[arn])
        mappings = response.get('ResourceTagMappingList', [])
        tags = mappings[0].get('Tags',[]) if mappings else []
        tags.append({'Key':'ccs_managed','Value':'yes'})
        return tags
    except Exception as e:
        print(f"Error fetching tags for ARN {arn}: {e}")
        return [{'Key':'ccs_managed','Value':'yes'}]
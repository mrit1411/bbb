﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_lambda_function.lambda_function](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [archive_file.lambda_package](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | Description of what your Lambda Function does. | `string` | n/a | yes |
| <a name="input_env_variables"></a> [env\_variables](#input\_env\_variables) | Environment variables to pass to the Lambda function | `map(string)` | `{}` | no |
| <a name="input_handler"></a> [handler](#input\_handler) | Function entry point in your code | `string` | n/a | yes |
| <a name="input_lambda_function_filename"></a> [lambda\_function\_filename](#input\_lambda\_function\_filename) | The name of the Lambda function file without extension | `string` | n/a | yes |
| <a name="input_layers"></a> [layers](#input\_layers) | List of Lambda Layer Version ARNs (maximum of 5) to attach to your Lambda Function. | `list(string)` | `[]` | no |
| <a name="input_memory_size"></a> [memory\_size](#input\_memory\_size) | Amount of memory available to the function at runtime in MB. Valid between 128 and 10240. | `number` | n/a | yes |
| <a name="input_role"></a> [role](#input\_role) | ARN of the function's execution role. The role provides the function's identity and access to AWS services and resources. | `string` | n/a | yes |
| <a name="input_runtime"></a> [runtime](#input\_runtime) | The runtime environment for the Lambda function | `string` | `"python3.12"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to assign to the Lambda function. | `map(string)` | `{}` | no |
| <a name="input_timeout"></a> [timeout](#input\_timeout) | Amount of time your Lambda Function has to run in seconds. Valid between 1 and 900. | `number` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_arn"></a> [arn](#output\_arn) | n/a |

variable "layer_name" {
  description = "Unique name for your Lambda Layer."
  type        = string
}

variable "description" {
  description = "Description of what your Lambda Layer does."
  type        = string
}

variable "compatible_runtimes" {
  description = "List of Runtimes this layer is compatible with. Up to 15 runtimes can be specified."
  type        = list(string)
  default     = ["python3.12"]

  validation {
    condition     = length(var.compatible_runtimes) <= 15
    error_message = "You can specify up to 15 runtimes."
  }
}

variable "filename" {
  description = "The path to the zip file containing the Lambda Layer code."
  type        = string
}
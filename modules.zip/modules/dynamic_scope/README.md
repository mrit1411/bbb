﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_maintenance_assignment_dynamic_scope.dynamic_scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/maintenance_assignment_dynamic_scope) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | Azure Region | `string` | n/a | yes |
| <a name="input_maintenance_configuration_id"></a> [maintenance\_configuration\_id](#input\_maintenance\_configuration\_id) | The ID of the Maintenance Configuration Resource. Changing this forces a new Dynamic Maintenance Assignment to be created. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The name which should be used for this Dynamic Maintenance Assignment. Changing this forces a new Dynamic Maintenance Assignment to be created. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resource Group Name | `string` | n/a | yes |
| <a name="input_tag_filters"></a> [tag\_filters](#input\_tag\_filters) | A list of tag-based filters used to dynamically scope maintenance assignments. Each filter specifies a tag key and a list of acceptable values to target specific virtual machines. | <pre>list(object({<br/>    tag    = string<br/>    values = list(string)<br/>  }))</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |

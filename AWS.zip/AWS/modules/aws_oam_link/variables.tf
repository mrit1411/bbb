variable "oam_link_resource_types" {
  description = "List of resource types that the OAM link will monitor."
  type        = list(string)
  default     = ["AWS::CloudWatch::Metric", "AWS::Logs::LogGroup"]
}

variable "oam_sink_arn" {
  description = "The ARN of the OAM sink to which the link will send data."
  type        = string
}

variable "region" {
  description = "The AWS region where the OAM link will be created."
  type        = string
  default = "us-east-1"
}
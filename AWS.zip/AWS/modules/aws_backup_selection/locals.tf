locals {
    name = "CCS-${var.context}-BackupSelection-${var.region}"
}
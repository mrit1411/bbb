
resource "azurerm_policy_definition" "policy_definition" {
  name         = lower(var.name)
  display_name = var.display_name
  policy_type  = var.policy_type
  management_group_id = var.management_group_id
  mode         = var.mode
  description  = var.description
  policy_rule  = var.policy_rule_filename
  parameters   = file("./${path.module}/${var.policy_parameters_filename}")
}

resource "azurerm_management_group_policy_assignment" "policy_assignment" {
  name                 = "${lower(var.name)}-assignment"#-${each.key}"
  policy_definition_id = azurerm_policy_definition.policy_definition.id
  management_group_id  = var.management_group_id
  description          = var.description

  identity {
    type         = "UserAssigned"
    identity_ids = var.user_assigned_identity_ids
  }

  location = var.location

  parameters = var.policy_assignment_parameters != null ? var.policy_assignment_parameters : ""
}
output "name" {
  description = "Name of the log stream"
  value       = aws_cloudwatch_log_stream.cloudwatch_log_stream.name
}
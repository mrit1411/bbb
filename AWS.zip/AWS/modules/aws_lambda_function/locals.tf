locals {
  name = "CCS-Lambda-${var.lambda_function_filename}-${var.region}"
}
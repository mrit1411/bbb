variable "bucket_base_name" {
  description = "Name of the bucket. If omitted, Terraform will assign a random, unique name. Must be lowercase and less than or equal to 63 characters in length. The name must not be in the format [bucket_name]--[azid]--x-s3. Forces new resource."
  type        = string

  validation {
    condition     = length(var.bucket_base_name) > 2 && length(var.bucket_base_name) <= 63
    error_message = "Bucket name must be less than or equal to 63 characters in length"
  }

  validation {
    condition     = !can(regex("^[^\\s]+--[^\\s]+--x-s3$", var.bucket_base_name))
    error_message = "The bucket name must not be in the format [bucket_name]--[azid]--x-s3."
  }
}

variable "region" {
  description = "The AWS region where the S3 bucket will be created."
  type        = string
}

variable "force_destroy" {
  description = "Boolean that indicates all objects (including any locked objects) should be deleted from the bucket when the bucket is destroyed so that the bucket can be destroyed without error. These objects are not recoverable. This only deletes objects when the bucket is destroyed, not when setting this parameter to true. Once this parameter is set to true, there must be a successful terraform apply run before a destroy is required to update this value in the resource state. Without a successful terraform apply after this parameter is set, this flag will have no effect. If setting this field in the same operation that would require replacing the bucket or destroying the bucket, this flag will not work. Additionally when importing a bucket, a successful terraform apply is required to set this value in state before it will take effect on a destroy operation."
  type        = bool
  default     = false
}

variable "expiration_days" {
  description = "Lifetime, in days, of the objects that are subject to the rule. The value must be a non-zero positive integer."
  type        = number
  default     = 365

  validation {
    condition     = var.expiration_days > 0
    error_message = "The value must be a non-zero positive integer."
  }
}

variable "rule_id" {
  description = "Unique identifier for the rule. The value cannot be longer than 255 characters."
  type        = string
  default     = "removeafterdays"

  validation {
    condition     = length(var.rule_id) <= 255
    error_message = "The value cannot be longer than 255 characters."
  }
}

variable "rule_status" {
  description = "Whether the rule is currently being applied."
  type        = bool
  default     = true
}

variable "block_public_acls" {
  description = "Whether Amazon S3 should block public ACLs for this bucket. Enabling this setting does not affect existing policies or ACLs. When set to true causes the following behavior:\nPUT Bucket acl and PUT Object acl calls will fail if the specified ACL allows public access.\nPUT Object calls will fail if the request includes an object ACL."
  type        = bool
  default     = true
}

variable "block_public_policy" {
  description = "Whether Amazon S3 should block public bucket policies for this bucket. Enabling this setting does not affect the existing bucket policy. When set to true causes Amazon S3 to:\nReject calls to PUT Bucket policy if the specified bucket policy allows public access."
  type        = bool
  default     = true
}

variable "ignore_public_acls" {
  description = "Whether Amazon S3 should ignore public ACLs for this bucket. Enabling this setting does not affect the persistence of any existing ACLs and doesn't prevent new public ACLs from being set. When set to true causes Amazon S3 to:\nIgnore public ACLs on this bucket and any objects that it contains."
  type        = bool
  default     = true
}

variable "restrict_public_buckets" {
  description = "Whether Amazon S3 should restrict public bucket policies for this bucket. Enabling this setting does not affect the previously stored bucket policy, except that public and cross-account access within the public bucket policy, including non-public delegation to specific accounts, is blocked. When set to true:\nOnly the bucket owner and AWS Services can access this buckets if it has a public policy."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags for the resoruce"
  type        = map(string)

  default = {
    "ccs_managed" = "yes"
  }
}

variable "enable_transition" {
  description = "Whether to enable transition"
  type        = bool
  default     = false
}

variable "transition_in_days" {
  description = "Number of days after creation when objects are transitioned to the specified storage class. The value must be a positive integer."
  type        = number
  default     = 60
}

variable "transition_storage_class" {
  description = "Class of storage used to store the object. Valid Values: GLACIER, STANDARD_IA, ONEZONE_IA, INTELLIGENT_TIERING, DEEP_ARCHIVE, GLACIER_IR."
  type        = string
  default     = "STANDARD_IA"
}
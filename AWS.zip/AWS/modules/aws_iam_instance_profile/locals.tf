data "aws_region" "current" {}

locals {
  name = "${var.name}"
}
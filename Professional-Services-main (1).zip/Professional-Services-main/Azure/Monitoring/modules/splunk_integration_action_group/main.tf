resource "azurerm_monitor_action_group" "action_group" {
  name                = local.name
  resource_group_name = var.resource_group_name
  short_name          = var.short_name

  azure_function_receiver {
    name                     = var.azure_function_receiver_name
    function_app_resource_id = var.function_app_resource_id
    function_name            = var.function_name
    http_trigger_url         = "https://${var.function_app_name}.azurewebsites.net/api/${var.function_name}?code=${var.function_default_host_key}"
    use_common_alert_schema  = var.use_common_alert_schema
  }

  lifecycle {
    ignore_changes = [tags, azure_function_receiver["http_trigger_url"]]

  }

  tags = var.tags
}
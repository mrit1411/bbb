output "name" {
  description = "Name of the Log Group"
  value       = aws_cloudwatch_log_group.cloudwatch_log_group.name
}
variable "region" {
  description = "The AWS region where the OAM sink will be created."
  type        = string
  default = "us-east-1"
}

variable "source_account_ids" {
  description = "List of AWS account IDs that are allowed to create and update links to this OAM sink."
  type        = list(string)
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.key_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_key_vault_secret.client_id](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.client_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_context"></a> [context](#input\_context) | The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_enable_rbac_authorization"></a> [enable\_rbac\_authorization](#input\_enable\_rbac\_authorization) | Use RBAC access control for the key vault. Defaults to true | `bool` | `true` | no |
| <a name="input_enabled_for_deployment"></a> [enabled\_for\_deployment](#input\_enabled\_for\_deployment) | Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. | `bool` | `true` | no |
| <a name="input_enabled_for_disk_encryption"></a> [enabled\_for\_disk\_encryption](#input\_enabled\_for\_disk\_encryption) | Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. | `bool` | `true` | no |
| <a name="input_enabled_for_template_deployment"></a> [enabled\_for\_template\_deployment](#input\_enabled\_for\_template\_deployment) | Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. | `bool` | `true` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_index"></a> [index](#input\_index) | The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | The location of the Splunk Integration Key Vault. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_network_acl_bypass"></a> [network\_acl\_bypass](#input\_network\_acl\_bypass) | Specifies which traffic can bypass the network rules. Possible values are AzureServices and None | `string` | `"None"` | no |
| <a name="input_network_acl_default_action"></a> [network\_acl\_default\_action](#input\_network\_acl\_default\_action) | The Default Action to use when no rules match from network\_acl\_ip\_rules / network\_acl\_virtual\_network\_subnet\_ids. Possible values are Allow and Deny | `string` | `"Deny"` | no |
| <a name="input_network_acl_ip_rules"></a> [network\_acl\_ip\_rules](#input\_network\_acl\_ip\_rules) | The list of allowed ips | `list(string)` | `[]` | no |
| <a name="input_network_acl_virtual_network_subnet_ids"></a> [network\_acl\_virtual\_network\_subnet\_ids](#input\_network\_acl\_virtual\_network\_subnet\_ids) | The list of allowed subnet ids | `list(string)` | <pre>[<br/>  "/subscriptions/d1cde075-76c2-413c-a703-5228ccbab1fa/resourceGroups/acf-p-noe-Network-01-org-rg/providers/Microsoft.Network/virtualNetworks/ps-p-noe-01-org-vnt/subnets/platformsvcs-snt"<br/>]</pre> | no |
| <a name="input_object_id"></a> [object\_id](#input\_object\_id) | The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault. The object ID must be unique for the list of access policies. | `string` | n/a | yes |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | Boolean flag to specify whether the key vault is reachable without a private endpoint. | `bool` | `null` | no |
| <a name="input_purge_protection_enabled"></a> [purge\_protection\_enabled](#input\_purge\_protection\_enabled) | Should the key vault be purge protected. NB! Can not remove purge protection after being enabled. | `bool` | `false` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the Splunk Integration Key Vault. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | The SKU name of the Splunk Integration Key Vault. | `string` | `"standard"` | no |
| <a name="input_soft_delete_retention_days"></a> [soft\_delete\_retention\_days](#input\_soft\_delete\_retention\_days) | The number of days to retain deleted objects, must be between 7 and 90 days. | `number` | `7` | no |
| <a name="input_splunk_integration_client_id_secret_name"></a> [splunk\_integration\_client\_id\_secret\_name](#input\_splunk\_integration\_client\_id\_secret\_name) | The name of the Splunk Integration Key Vault secret for the client ID. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_splunk_integration_client_id_secret_value"></a> [splunk\_integration\_client\_id\_secret\_value](#input\_splunk\_integration\_client\_id\_secret\_value) | The value of the Splunk Integration Key Vault secret for the client ID. Changing this will create a new version of the Key Vault Secret. | `string` | n/a | yes |
| <a name="input_splunk_integration_client_secret_secret_name"></a> [splunk\_integration\_client\_secret\_secret\_name](#input\_splunk\_integration\_client\_secret\_secret\_name) | The name of the Splunk Integration Key Vault secret for the client secret. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_splunk_integration_client_secret_secret_value"></a> [splunk\_integration\_client\_secret\_secret\_value](#input\_splunk\_integration\_client\_secret\_secret\_value) | The value of the Splunk Integration Key Vault secret for the client secret. Changing this will create a new version of the Key Vault Secret. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | n/a | yes |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | The Azure Active Directory tenant ID that should be used for authenticating requests to the Splunk Integration Key Vault. | `string` | n/a | yes |
| <a name="input_vm_mi_object_id"></a> [vm\_mi\_object\_id](#input\_vm\_mi\_object\_id) | The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault. The object ID must be unique for the list of access policies. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_name"></a> [name](#output\_name) | n/a |

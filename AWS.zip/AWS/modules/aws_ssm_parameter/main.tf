resource "aws_ssm_parameter" "ssm_parameter" {
  name        = var.name
  value       = var.parameter_file
  type        = var.type
  tier        = var.tier
  description = var.description
}
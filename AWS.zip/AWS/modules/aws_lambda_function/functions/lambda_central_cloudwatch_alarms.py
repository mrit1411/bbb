import boto3
import os
import time
from botocore.exceptions import ClientError

cloudwatch = boto3.client('cloudwatch')
ec2 = boto3.resource('ec2')
ssm = boto3.client('ssm')
sns = boto3.client('sns')
sts = boto3.client('sts')
lmb = boto3.client('lambda')
client = boto3.client('ec2')

region = os.environ.get('AWS_REGION')
account_id = sts.get_caller_identity().get('Account')
sns_topic_arn = os.environ.get('SNOWSNSTopicARN')
ssm_managed_tag_name = os.environ.get('TagsConditionKey')
ssm_managed_tag_value = os.environ.get('TagsConditionValue')
ssm_managed_tag = 'tag:{}'.format(ssm_managed_tag_name)
monitoring_enabled = os.environ.get('MonitoringEnabled') == "true"
logging_enabled = os.environ.get('LoggingEnabled') == "true"

print('Lambda environment variables:')
print(" - AWS_REGION: {}".format(region))
print(" - SNOWSNSTopicARN: {}".format(sns_topic_arn))
print(" - TagsConditionKey: {}".format(ssm_managed_tag_name))
print(" - TagsConditionValue: {}".format(ssm_managed_tag_value))


def lambda_handler(event, context):
    print("Content of the trigger event: {}".format(event))
    event_detail = event.get('detail')
    print('')
    print("Content of the trigger event details: {}".format(event_detail))

    if (sns_topic_arn is not None):
        print(" - SNS topic ARN: {}".format(sns_topic_arn))

        instance_id = event["detail"]["instance-id"]
        print(" - Instance ID: {}".format(instance_id))
        source_account_id = event["account"]
        print(" - Account ID: {}".format(account_id))
        if (event_detail is None or instance_id == ''):
            print('')
            print("No EC2 instance ID passed with the event.")
            return False
            # Below function prepared for brownfield scenario:
            # print("No EC2 instance ID passed with the event. Deploying target: all {} tagged instances in {} region".format(ssm_managed_tag_name, region))
            # configure_os_monitoring(None, sns_topic_arn, ssm_managed_tag)
        else:
            print('')
            print("EC2 instance ID provided: {}. Configuring OS monitoring...".format(instance_id))
            configure_os_monitoring(instance_id, sns_topic_arn, ssm_managed_tag, account_id)


def configure_os_monitoring(instance_id, sns_topic_arn, ssm_managed_tag, account_id):
    if (instance_id is None):
        all_instances = boto3.client('ec2').describe_instances(Filters=[{'Name': 'instance-state-name', 'Values': ['running']},
                                                                        {'Name': ssm_managed_tag, 'Values': [ssm_managed_tag_value]}])
        all_instance_ids = []
        linux_instance_ids = []
        windows_instance_ids = []
        for reservation in all_instances["Reservations"]:
            for instance in reservation["Instances"]:
                if (instance.get('Platform') is None):
                    linux_instance_ids.append(instance["InstanceId"])
                else:
                    windows_instance_ids.append(instance["InstanceId"])
                    all_instance_ids.append(instance["InstanceId"])

        print("Installing and configuring CloudWatch agent on ec2 instances: {}".format(all_instance_ids))
        install_and_configure_cwagent(all_instance_ids)
        print("Sending command to Linux instances: {}".format(linux_instance_ids))
        send_run_command(linux_instance_ids, "linux")

        print("Sending command to Windows instances: {}".format(linux_instance_ids))
        send_run_command(windows_instance_ids, "windows")
        if monitoring_enabled:
            for instance in linux_instance_ids:
                print("Creating alarms for Linux ec2 instances {} ...".format(instance.id))
                create_alarms_for_linux_instance(instance, instance.id, sns_topic_arn, account_id)

            for instance in windows_instance_ids:
                print("Creating alarms for Windows ec2 instances {} ...".format(instance.id))
                create_alarms_for_windows_instance(instance, instance.id, sns_topic_arn, account_id)

    else:
        instance_id_filter = boto3.client('ec2').describe_instances(
            Filters=[
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                },
                {
                    'Name': ssm_managed_tag,
                    'Values': ['yes']
                }
            ],
            InstanceIds=[instance_id])
        try:
            instance_id = instance_id_filter['Reservations'][0]['Instances'][0]['InstanceId']
        except Exception as e:
            print(e)
            print("No instances with {} tag found. Aborting...".format(ssm_managed_tag))
            return False

        instance_id_object = ec2.Instance(instance_id)
        if (instance_id):
            print('')
            print("Waiting for ec2 instance {} to reach the state of 'passed'...".format(instance_id))
            ec2_instance_status_check(instance_id)

            print('')
            print("Installing and configuring CloudWatch agent on ec2 instance {} ...".format(instance_id))
            install_and_configure_cwagent(instance_id)
            if(instance_id_object.platform is None):
                print('')
                print("Sending command to Linux instance {}...".format(instance_id))
                send_run_command(instance_id, "linux")
                if monitoring_enabled:
                    print('')
                    print("Creating alarms for Linux ec2 instance {} ...".format(instance_id))
                    create_alarms_for_linux_instance(instance_id_object, instance_id, sns_topic_arn, account_id)
            else:
                print('')
                print("Sending command to Windows instance {} ...".format(instance_id))
                send_run_command(instance_id, "windows")
                if monitoring_enabled:
                    print('')
                    print("Creating alarms for Windows ec2 instance {} ...".format(instance_id))
                    create_alarms_for_windows_instance(instance_id_object, instance_id, sns_topic_arn, account_id)


def ec2_instance_status_check(instance_id):
    timeout = 60
    while True:
        instanceStatus = client.describe_instance_status(InstanceIds=[instance_id])
        status = instanceStatus['InstanceStatuses'][0]['InstanceStatus']['Details'][0]['Status']
        if (status == 'passed'):
            print(" - actual status: {}. Starting next step on ec2 instance {}...".format(status, instance_id))
            break
        else:
            print(" - actual status: {}. Waiting for ec2 instance {} to reach the state of 'passed'...".format(status, instance_id))
            print("   - timeout after: {} seconds".format(timeout))
            time.sleep(timeout)
            timeout = timeout - 10

        if (timeout == 0):
            print('')
            print("Timeout reached:")
            print(" - ec2 instance {} status: {}".format(instance_id, status))
            return False


def install_and_configure_cwagent(instanceId):
    timeout = 30
    while True:
        ssmagent_update_status = ssm.list_command_invocations(
            InstanceId=instanceId,
            Filters=[
                {
                    'key': 'DocumentName',
                    'value': 'AWS-UpdateSSMAgent'
                },
            ]
        )
        try:
            if ssmagent_update_status['CommandInvocations'][0]['Status'] == 'Success':
                print("SSM Agent finished updating")
                break
        except Exception as e:
            print("Did not find SSM agent update document")
            print(e)
            time.sleep(timeout)
            timeout = timeout - 10
        else:
            print("Waiting for SSM Agent to update")
            time.sleep(timeout)
            timeout = timeout - 10
        if (timeout == 0):
            print("SSM Agent did not perform update, skipping")
            break
    instance_id_object = ec2.Instance(instanceId)
    is_CWAgent_present = False
    if instance_id_object.platform is None:
        command_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName="AWS-RunShellScript",
            Parameters={
                'commands': [
                    'which amazon-cloudwatch-agent-ctl'
                ]
            })
        commandid = command_response['Command']['CommandId']
        time.sleep(5)
        check_command_status = ssm.get_command_invocation(
            InstanceId=instanceId,
            CommandId=commandid
        )
        is_CWAgent_present = check_command_status['Status'] == 'Success'
    else:
        command_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName="AWS-RunPowerShellScript",
            Parameters={
                'commands': [
                    "$ISAGENT = (TEST-PATH 'C:\\Program Files\\Amazon\\AmazonCloudWatchAgent\\amazon-cloudwatch-agent.exe')",
                    "if($ISAGENT -eq $False){THROW}"
                ]
            })
        commandid = command_response['Command']['CommandId']
        time.sleep(5)
        check_command_status = ssm.get_command_invocation(
            InstanceId=instanceId,
            CommandId=commandid
        )
        is_CWAgent_present = check_command_status['Status'] == 'Success'

    if is_CWAgent_present:
        print('CW Agent is already installed, starting uninstall process')
        uninstall_cwagent_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName='AWS-ConfigureAWSPackage',
            Parameters={
                "action": ["Uninstall"],
                "name": ["AmazonCloudWatchAgent"]
            }
        )
        timeout = 60
        uninstall_cwagent_commandid = uninstall_cwagent_response['Command']['CommandId']
        uninstall_cwagent_status = uninstall_cwagent_response['Command']['Status']
        while True:
            if uninstall_cwagent_status == 'Success':
                print("CW Agent uninstalled")
                break
            else:
                print("Waiting for CW Agent uninstallation to complete")
                time.sleep(timeout)
                timeout = timeout - 10
                uninstall_cwagent_response_invocation = ssm.get_command_invocation(
                    CommandId=uninstall_cwagent_commandid,
                    InstanceId=instanceId
                )
                uninstall_cwagent_status = uninstall_cwagent_response_invocation['Status']
            if (timeout == 0):
                print("CW Agent uninstallation did not complete")
                return False
    install_cwagent_response = ssm.send_command(
        InstanceIds=[instanceId],
        DocumentName='AWS-ConfigureAWSPackage',
        Parameters={
            "action": ["Install"],
            "name": ["AmazonCloudWatchAgent"]
        }
    )
    timeout = 60
    install_cwagent_commandid = install_cwagent_response['Command']['CommandId']
    install_cwagent_status = install_cwagent_response['Command']['Status']
    while True:
        if install_cwagent_status == 'Success':
            print("CW Agent installed")
            break
        else:
            print("Waiting for CW Agent installation to complete")
            time.sleep(timeout)
            timeout = timeout - 10
            install_cwagent_response_invocation = ssm.get_command_invocation(
                CommandId=install_cwagent_commandid,
                InstanceId=instanceId
            )
            install_cwagent_status = install_cwagent_response_invocation['Status']
        if (timeout == 0):
            print("CW Agent installation did not complete")
            return False
    print(" - CloudWatch agent installed on ec2 instance {}".format(instanceId))
    return True


def send_run_command(instance_ids, os):
    try:
        if(os == "windows"):
            if monitoring_enabled and logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunPowerShellScript',
                    Parameters={
                        'commands': [
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsmetricsconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                        ],
                        'executionTimeout': ['600']
                    })
            elif monitoring_enabled and not logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunPowerShellScript',
                    Parameters={
                        'commands': [
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsmetricsconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                        ],
                        'executionTimeout': ['600']
                    })
            elif not monitoring_enabled and logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunPowerShellScript',
                    Parameters={
                        'commands': [
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                        ],
                        'executionTimeout': ['600']
                    })
            print(' - runCommand sent successfully')
            return True

        if(os == 'linux'):
            if monitoring_enabled and logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunShellScript',
                    Parameters={
                        'commands': [
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxmetricsconfiguration',
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxloggingconfiguration',
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
                        ],
                        'executionTimeout': ['6000']
                    })
            elif monitoring_enabled and not logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunShellScript',
                    Parameters={
                        'commands': [
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxmetricsconfiguration',
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
                        ],
                        'executionTimeout': ['6000']
                    })
            elif not monitoring_enabled and logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunShellScript',
                    Parameters={
                        'commands': [
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxloggingconfiguration',
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
                        ],
                        'executionTimeout': ['6000']
                    })

            print(' - runCommand sent successfully')
            return True

    except ClientError as err:
        if 'ThrottlingException' in str(err):
            print("RunCommand throttled, automatically retrying...")
            send_run_command(instance_ids, os)
        else:
            print(" - run Command Failed!\n%s", str(err))
            return False


# def get_instance_type(instanceId):
#     instance_type = ''
#     response = client.describe_instances(InstanceIds=[instanceId, ])
#     instance_type = response['Reservations'][0]['Instances'][0]['InstanceType']
#     return instance_type


# def get_image_id(instanceId):
#     image_id = ''
#     response = client.describe_instances(InstanceIds=[instanceId, ])
#     image_id = response['Reservations'][0]['Instances'][0]['ImageId']
#     return image_id


def create_alarms_for_windows_instance(instance, instanceName, sns_topic_arn, account_id):
    # FIXME: remove redundant param
    instance_tags = get_instance_tags(instance)
    sql_server = is_sql_server(instance_tags)
    memory_alarm_dimensions = [
        {'Name': 'InstanceId', 'Value': instance.id},
        {'Name': 'objectname', 'Value': 'Memory'}
    ]
    diskNames = []
    max_retries = 5
    retry_delay = 120  # seconds

    for attempt in range(max_retries):
        metrics = cloudwatch.list_metrics(
            #Namespace='Windows System',
            Namespace='CWAgent',
            MetricName='DiskFree',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance.id}]
        )
    
        for metric in metrics['Metrics']:
            dimensions = metric['Dimensions']
            for dimension in dimensions:
                if(dimension['Name'] == 'instance'):
                    disk = dimension["Value"]
                    diskNames.append(disk)
    
        if diskNames:
            print(f"Found disk metrics after {attempt + 1} attempts")
            break
        else:
            print(f"No disk metrics found. Attempt {attempt + 1} of {max_retries}. Waiting {retry_delay} seconds...")
            time.sleep(retry_delay)

    print("creating OS Windows alarms for env: ", end='')
    if sql_server:
        print("sql server")
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=90, duration=30, account_id=account_id)
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=95, duration=30, account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=90, duration=30, dimensions=memory_alarm_dimensions, account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=95, duration=30, dimensions=memory_alarm_dimensions, account_id=account_id)
        for disk in diskNames:
            disk_dimensions = [
                {'Name': 'InstanceId', 'Value': instance.id},
                {'Name': 'instance', 'Value': disk},
                {'Name': 'objectname', 'Value': 'LogicalDisk'}
            ]
            create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=20, duration=5, dimensions=disk_dimensions, account_id=account_id)
            create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=10, duration=5, dimensions=disk_dimensions, account_id=account_id)
    else:
        print("non sql server")
        # create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=80, duration=30, account_id=account_id)
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=90, duration=30, account_id=account_id)
        # create_memory_alarm(instance_name=instanceName, threshold=80, duration=30, dimensions=memory_alarm_dimensions, account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=90, duration=30, dimensions=memory_alarm_dimensions, account_id=account_id)
        for disk in diskNames:
            disk_dimensions = [
                {'Name': 'InstanceId', 'Value': instance.id},
                {'Name': 'instance', 'Value': disk},
                {'Name': 'objectname', 'Value': 'LogicalDisk'}
            ]
            # create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=20, duration=5, dimensions=disk_dimensions, account_id=account_id)
            create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=10, duration=5, dimensions=disk_dimensions, account_id=account_id)

    create_system_uptime_alarm(instance, instanceName, account_id)

    print(f"avaliable metrics: {metrics}")
    print(f"avaliable disks alarms : {diskNames}")

    create_status_check_alarm(instance, instanceName)
    print(" - Windows alarms created")


def create_alarms_for_linux_instance(instance, instanceName, sns_topic_arn, account_id):
    # FIXME: remove redundant param
    instance_tags = get_instance_tags(instance)
    sql_server = is_sql_server(instance_tags)
    memory_alarm_dimensions = [{'Name': 'InstanceId', 'Value': instance.id}]

    # metrics = cloudwatch.list_metrics(
    #     Namespace='CWAgent',
    #     MetricName='disk_used_percent',
    #     Dimensions=[{'Name': 'InstanceId', 'Value': instance.id}]
    # )
    # deviceNames = []
    # for metric in metrics['Metrics']:
    #     data = {}
    #     dimensions = metric['Dimensions']
    #     for dimension in dimensions:
    #         if(dimension['Name'] == 'device'):
    #             data["device"] = dimension['Value']
    #         if(dimension['Name'] == 'path'):
    #             data["path"] = dimension['Value']
    #         if(dimension['Name'] == 'fstype'):
    #             data["fstype"] = dimension['Value']
    #     if "device" in data and data["fstype"] in ["xfs", "ext4"]:
    #         deviceNames.append(data)

    max_retries = 5
    retry_delay = 120  # seconds
    deviceNames = []
    
    for attempt in range(max_retries):
        metrics = cloudwatch.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance.id}]
        )
        
        # Process metrics to find disk devices
        for metric in metrics['Metrics']:
            data = {}
            dimensions = metric['Dimensions']
            for dimension in dimensions:
                if(dimension['Name'] == 'device'):
                    data["device"] = dimension['Value']
                if(dimension['Name'] == 'path'):
                    data["path"] = dimension['Value']
                if(dimension['Name'] == 'fstype'):
                    data["fstype"] = dimension['Value']
            if "device" in data and data["fstype"] in ["xfs", "ext4"]:
                deviceNames.append(data)
        
        if deviceNames:
            print(f"Found disk metrics after {attempt + 1} attempts")
            break
        else:
            print(f"No disk metrics found. Attempt {attempt + 1} of {max_retries}. Waiting {retry_delay} seconds...")
            time.sleep(retry_delay)
    
    if not deviceNames:
        print("Warning: No disk metrics available yet. Disk alarms will not be created. Please run this function again after a few minutes.")

    print("creating OS Linux alarms for env: ", end='')
    if sql_server:
        print("sql server")
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=90, duration=30, account_id=account_id)
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=95, duration=30, account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=90, duration=30, dimensions=memory_alarm_dimensions, metric_name="mem_used_percent", namespace="CWAgent", account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=95, duration=30, dimensions=memory_alarm_dimensions, metric_name="mem_used_percent", namespace="CWAgent", account_id=account_id)
        for deviceName in deviceNames:
            disk_dimensions = [
                {'Name': 'path', 'Value': deviceName["path"]},
                {'Name': 'InstanceId', 'Value': instance.id},
                {'Name': 'ImageId', 'Value': instance.image.id},
                {'Name': 'InstanceType', 'Value': instance.instance_type},
                {'Name': 'device', 'Value': deviceName["device"]},
                {'Name': 'fstype', 'Value': deviceName["fstype"]}
            ]
            create_disk_alarm_linux(instance_name=instanceName, disk=deviceName["path"], threshold=80, duration=5, dimensions=disk_dimensions, metric_name='disk_used_percent', namespace='CWAgent', account_id=account_id)
            create_disk_alarm_linux(instance_name=instanceName, disk=deviceName["path"], threshold=90, duration=5, dimensions=disk_dimensions, metric_name='disk_used_percent', namespace='CWAgent', account_id=account_id)

    else:
        print("non sql server")
        # create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=80, duration=30, account_id=account_id)
        create_cpu_alarm(instance=instance, instance_name=instanceName, threshold=90, duration=30, account_id=account_id)
        # create_memory_alarm(instance_name=instanceName, threshold=80, duration=30, dimensions=memory_alarm_dimensions, metric_name="mem_used_percent", namespace="CWAgent", account_id=account_id)
        create_memory_alarm(instance_name=instanceName, threshold=90, duration=30, dimensions=memory_alarm_dimensions, metric_name="mem_used_percent", namespace="CWAgent", account_id=account_id)
        for deviceName in deviceNames:
            disk_dimensions = [
                {'Name': 'path', 'Value': deviceName["path"]},
                {'Name': 'InstanceId', 'Value': instance.id},
                {'Name': 'ImageId', 'Value': instance.image.id},
                {'Name': 'InstanceType', 'Value': instance.instance_type},
                {'Name': 'device', 'Value': deviceName["device"]},
                {'Name': 'fstype', 'Value': deviceName["fstype"]}
            ]
            # create_disk_alarm_linux(instance_name=instanceName, disk=deviceName["path"], threshold=80, duration=5, dimensions=disk_dimensions, metric_name='disk_used_percent', namespace='CWAgent', account_id=account_id)
            create_disk_alarm_linux(instance_name=instanceName, disk=deviceName["path"], threshold=90, duration=5, dimensions=disk_dimensions, metric_name='disk_used_percent', namespace='CWAgent', account_id=account_id)

    # Metrics and dimentions can be found here  https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/viewing_metrics_with_cloudwatch.html#list-ec2-metrics-cli
    # SWAP monitoring is supported only by Linux https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/metrics-collected-by-CloudWatch-agent.html
    # I am guessing this one is correct acording to monitoring.json
    create_swap_alarm(instance_name=instanceName, threshold=85, duration=60, dimensions=memory_alarm_dimensions, metric_name='swap_used_percent', namespace="CWAgent", account_id=account_id)

    print(f"avaliable metrics: {metrics}")
    print(f"avaliable disks alarms : {deviceNames}")

    create_status_check_alarm(instance, instanceName, account_id)
    print(" - Linux alarms created")


# def get_instance_platform_name(instance_id):
#     response = ssm.describe_instance_information(
#         Filters=[
#             {
#                 'Key': 'InstanceIds',
#                 'Values': [instance_id]
#             },
#         ]
#     )
#     return response['InstanceInformationList'][0]['PlatformName'], response['InstanceInformationList'][0]['PlatformVersion']


def get_instance_tags(instance):
    return {tag["Key"].lower(): tag["Value"].lower() for tag in instance.tags}


def is_sql_server(instance_tags):
    environment_tag = instance_tags.get("ccs_sql")
    return environment_tag in ["yes"]


def create_cpu_alarm(account_id, instance, instance_name, threshold, duration=5, periods=5):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% CPU Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        # MetricName='CPUUtilization',
        # Namespace='AWS/EC2',
        # Period=int(periods * 60),
        # Statistic='Average',
        Threshold=threshold,
        AlarmDescription='The percentage of allocated EC2 compute units that are currently in use on the instance. This metric identifies the processing power required to run an application upon a selected instance. Depending on the instance type, tools in your operating system can show a lower percentage than CloudWatch when the instance is not allocated a full processor core.',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=[
        #     {
        #         'Name': 'InstanceId',
        #         'Value': instance.id
        #     }
        # ],
        Metrics=[
            {
                "Id": "cpu_utilization_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/EC2",
                        "MetricName": "CPUUtilization",
                        "Dimensions": [
                            {
                                "Name": "InstanceId",
                                "Value": instance.id
                            }
                        ]
                    },
                    "Period": int(periods * 60),
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"created cpu metric: {response}")


def create_memory_alarm(account_id, instance_name, threshold, dimensions, duration=5, periods=5, metric_name='MemoryUsed', namespace='CWAgent'):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% Memory Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        #MetricName=metric_name,
        #Namespace=namespace,
        #Period=int(periods * 60),
        #Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% Memory Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        #Dimensions=dimensions,
        Metrics=[
            {
                "Id": "memory_utilization_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": namespace,
                        "MetricName": metric_name,
                        "Dimensions": dimensions
                    },
                    "Period": int(periods * 60),
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"created memory metric: {response}")


def create_swap_alarm(account_id, instance_name, threshold, dimensions, duration=5, periods=5, metric_name='SwapUsed', namespace='CWAgent'):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% SWAP Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        # MetricName=metric_name,
        # Namespace=namespace,
        # Period=int(periods * 60),
        # Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% SWAP Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=dimensions,
        Metrics=[
            {
                "Id": "swap_utilization_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": namespace,
                        "MetricName": metric_name,
                        "Dimensions": dimensions
                    },
                    "Period": int(periods * 60),
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"create swap metric: {response}")


def create_disk_alarm_windows(account_id, instance_name, disk, threshold, dimensions, duration=5, periods=5, metric_name="DiskFree", namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: {disk}: EC2:Over {100-threshold}% Disk Utilization detected over a period of {duration} minutes',
        ComparisonOperator='LessThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        # Namespace=namespace,
        # MetricName=metric_name,
        # Period=int(periods * 60),
        # Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {100-threshold}% Disk Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=dimensions,
        Metrics=[
            {
                "Id": "windows_disk_utilization_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": namespace,
                        "MetricName": metric_name,
                        "Dimensions": dimensions
                    },
                    "Period": int(periods * 60),
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"create disk metric: {response}")

def create_disk_alarm_linux(account_id, instance_name, disk, threshold, dimensions, duration=5, periods=5, metric_name="disk_used_percent", namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: {disk}: EC2:Over {threshold}% Disk Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        # Namespace=namespace,
        # MetricName=metric_name,
        # Period=int(periods * 60),
        # Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% Disk Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=dimensions,
        Metrics=[
            {
                "Id": "linux_disk_utilization_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": namespace,
                        "MetricName": metric_name,
                        "Dimensions": dimensions
                    },
                    "Period": int(periods * 60),
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"create disk metric: {response}")


def create_system_uptime_alarm(account_id, instance, instance_name):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:System Uptime is less than 20 seconds',
        ComparisonOperator='LessThanThreshold',
        EvaluationPeriods=1,
        # MetricName='System System Up Time',
        # Namespace='CWAgent',
        # Period=300,
        # Statistic='Average',
        Threshold=20,
        AlarmDescription='System Uptime for instance is less than 20 seconds',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=[
        #     {
        #         'Name': 'InstanceId',
        #         'Value': instance.id
        #     },
        #     {
        #         'Name': 'objectname',
        #         'Value': 'System'
        #     }
        # ],
        Metrics=[
            {
                "Id": "system_uptime_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": "System System Up Time",
                        "Dimensions": [
                            {
                                "Name": "InstanceId",
                                "Value": instance.id
                            },
                            {
                                "Name": "objectname",
                                "Value": "System"
                            }
                        ]
                    },
                    "Period": 300,
                    "Stat": "Average"
                }
            }
        ]
    )
    print(f"create system uptime metric: {response}")


def create_status_check_alarm(account_id, instance, instance_name):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Status Check Fail detected',
        ComparisonOperator='GreaterThanThreshold',
        EvaluationPeriods=1,
        # MetricName='StatusCheckFailed',
        # Namespace='AWS/EC2',
        # Period=300,
        # Statistic='Sum',
        Threshold=1,
        AlarmDescription='Reports whether the instance has passed both the instance status check and the system status check in the last 5 minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        # Dimensions=[
        #     {
        #         'Name': 'InstanceId',
        #         'Value': instance.id
        #     }
        # ],
        Metrics=[
            {
                "Id": "status_check_timeseries",
                "ReturnData": True,
                "AccountId": account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/EC2",
                        "MetricName": "StatusCheckFailed",
                        "Dimensions": [
                            {
                                "Name": "InstanceId",
                                "Value": instance.id
                            }
                        ]
                    },
                    "Period": 300,
                    "Stat": "Sum"
                }
            }
        ]
    )
    print(f"create status check metric: {response}")
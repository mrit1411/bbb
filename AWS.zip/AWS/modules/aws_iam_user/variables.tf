variable "user_name" {
  description = "The name of the iam user"
  type        = string
}

variable "policy" {
  description = "The IAM policy document in JSON format"
  type        = string
}

variable "policy_base_name" {
  description = "The base name for the IAM policy"
  type        = string
}
variable "backup_report_generation_schedule_monthly" {
  description = "Enter the schedule for Monthly AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of monthly AWS Backup reports. by default (01:30 AM last day of every month)"
  type        = string
  default     = "cron(30 01 L * ? *)"
}

variable "backup_report_generation_schedule_weekly" {
  description = "Enter the schedule for Weekly AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of weekly AWS Backup reports.by default (01:30 on each monday)"
  type        = string
  default     = "cron(30 01 ? * 2 *)"

}

variable "backup_report_generation_schedule_daily" {
  description = "Enter the schedule for Daily AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of daily AWS Backup reports.by default (01:30 GMT everyday)"
  type        = string
  default     = "cron(30 01 * * ? *)"

}

variable "backup_link_validity" {
  description = "Enter how long in seconds the AWS Backup Report notification link will be valid for (86400 - 24h, 604800 - 7 days)"
  type        = number
  default     = 604800
}

variable "backup_tags_condition_key" {
  description = "Resources with this Tag Key will be backed up by deployed CCS AWS Backup rules"
  type        = string
  default     = "ccs_backup"
}

variable "backup_tags_condition_value" {
  description = "Resources with this Tag Value will be backed up by deployed CCS AWS Backup rules"
  type        = string
  default     = "yes"
}

variable "backup_reports_bucket_name" {
  description = "Enter the name of the S3 bucket that will be created and used to store monthly AWS Backup reports"
  type        = string
  default     = "ccs-backup-reports"
}

variable "backup_reports_sns_topic_name" {
  description = "Enter the name for the SNS Topic that will be created and used by the backup report lambda to email monthly AWS Backup reports"
  type        = string
  default     = "ccs-backup-reports"
}

variable "backup_report_recipient" {
  description = "Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Backup Reports"
  type        = string
  default     = "akarsh.a.srivastava@capgemini.com"
}

variable "backup_vault_name" {
  description = "Enter the name of the AWS Backup Vault that will be created and used to store backups"
  type        = string
  default     = "RegionalCCSBackupVault"
}

variable "backup_vault_tags" {
  description = "Enter the tags that will be applied to the AWS Backup Vault"
  type        = map(string)
  default = {
    ccs_backup = "yes"
  }
}

variable "backup_plan_name" {
  description = "Enter name for AWS Backup Plan that will be deployed."
  type        = string
  default     = "CCSBackupPlan"

}

variable "regions" {
  description = "Enter the AWS regions where the AWS resources will be deployed."
  type        = list(string)
}

variable "backup_daily_rule_name" {
  description = "Enter the name for the AWS Backup Daily Backup Rule that will be deployed"
  type        = string
  default     = "CCSDailyBackupRule"
}

variable "backup_weekly_rule_name" {
  description = "Enter the name for the AWS Backup Weekly Backup Rule that will be deployed"
  type        = string
  default     = "CCSWeeklyBackupRule"
}

variable "backup_monthly_rule_name" {
  description = "Enter the name for the AWS Backup Monthly Backup Rule that will be deployed"
  type        = string
  default     = "CCSMonthlyBackupRule"
}

variable "backup_yearly_rule_name" {
  description = "Enter the name for the AWS Backup Yearly Backup Rule that will be deployed"
  type        = string
  default     = "CCSYearlyBackupRule"
}

variable "backup_daily_schedule_expression" {
  description = "An AWS CRON expression specifying when AWS Backup initiates a Daily backup job. by default (03:04 AM MON-SAT)"
  type        = string
  # default     = "cron(4 3 ? * 2,3,4,5,6,7 *)"
  default = "cron(0 */1 * * ? *)" //Example cron for every 1 hour for testing purposes, change to above cron for production
}

variable "backup_completion_window" {
  description = "The amount of time in minutes AWS Backup attempts a backup before canceling the job and returning an error."
  type        = number
  default     = 1440
}

variable "backup_start_window" {
  description = "The amount of time in minutes before beginning a backup."
  type        = number
  default     = 120
}

variable "backup_daily_delete_after_days" {
  description = "Enter the amount of days that AWS Backup Daily Backups will be retained for."
  type        = number
  default     = 8
}

variable "backup_weekly_schedule_expression" {
  description = "An AWS CRON expression specifying when AWS Backup initiates a Weekly backup job. by default  (03:04 AM every Sunday)"
  type        = string
  default     = "cron(4 3 ? * 1 *)"
}

variable "backup_weekly_delete_after_days" {
  description = "Enter the amount of days that AWS Backup Weekly Backups will be retained for."
  type        = number
  default     = 35
}

variable "backup_monthly_schedule_expression" {
  description = "An AWS CRON expression specifying when AWS Backup initiates a Monthly backup job. by default (01:04 AM 28th of every month)"
  type        = string
  default     = "cron(04 1 28 * ? *)"
}

variable "backup_monthly_delete_after_days" {
  description = "Enter the amount of days that AWS Backup Monthly Backups will be retained for."
  type        = number
  default     = 396
}

variable "backup_yearly_schedule_expression" {
  description = "An AWS CRON expression specifying when AWS Backup initiates a Yearly backup job. by default (01:04 AM January 1st every year)"
  type        = string
  default     = "cron(4 1 1 1 ? *)"
}

variable "backup_yearly_delete_after_days" {
  description = "Enter the amount of days that AWS Backup Yearly Backups will be retained for."
  type        = number
  default     = 3650
}

variable "backup_plan_tags" {
  description = "A map of tags to assign to the backup plan."
  type        = map(string)
  default = {
    Owner = "CCS"
  }
}

variable "backup_selection_name" {
  description = "Enter the name for the AWS Backup resource selection that will be deployed"
  type        = string
  default     = "CCSSelectedResources"

}
import boto3
import os

# Environment variables
TAG_KEY = os.environ['TagsConditionKey']
TAG_VALUE = os.environ['TagsConditionValue']

# AWS clients
cloudwatch = boto3.client('cloudwatch')
lambda_client = boto3.client('lambda')
rds = boto3.client('rds')
elbv2 = boto3.client('elbv2')

def lambda_handler(event, context):
    detail = event.get('detail', {})
    event_name = detail.get('eventName')
    event_source = detail.get('eventSource')

    match (event_source, event_name):
        case ("lambda.amazonaws.com", "DeleteFunction20150331"):
            resource_id = event['detail']['requestParameters']['functionName']
            delete_tagged_alarms("FunctionName", resource_id)
        case ("rds.amazonaws.com", "DeleteDBInstance"):
            resource_id = event['detail']['requestParameters']['dBInstanceIdentifier']
            delete_tagged_alarms("DBInstanceIdentifier", resource_id)
        case ("elasticloadbalancing.amazonaws.com", "DeleteLoadBalancer"):
            lb_arn = event['detail']['requestParameters']['loadBalancerArn']
            lb_name = lb_arn.split('/')[-2]
            lb_id = lb_arn.split('/')[-1]
            metric_id = f"app/{lb_name}/{lb_id}"
            delete_tagged_alarms("LoadBalancer", metric_id)
        case _:
            print(f"Unsupported event: {event_source} - {event_name}")
            return {'statusCode': 400, 'body': 'Unsupported event type'}

    return {'statusCode': 200, 'body': 'Alarm deletion processed'}

def delete_tagged_alarms(dimension_name, dimension_value):
    paginator = cloudwatch.get_paginator('describe_alarms')
    for page in paginator.paginate():
        for alarm in page['MetricAlarms']:
            if any(dim['Name'] == dimension_name and dim['Value'] == dimension_value for dim in alarm.get('Dimensions', [])):
                alarm_name = alarm['AlarmName']
                alarm_arn = alarm.get('AlarmArn')
                if alarm_arn and alarm_has_required_tag(alarm_arn):
                    cloudwatch.delete_alarms(AlarmNames=[alarm_name])
                    print(f"Deleted alarm: {alarm_name}")
                else:
                    print(f"Alarm {alarm_name} does not have required tag or missing ARN")

def alarm_has_required_tag(alarm_arn):
    try:
        response = cloudwatch.list_tags_for_resource(ResourceARN=alarm_arn)
        tags = {tag['Key']: tag['Value'] for tag in response.get('Tags', [])}
        return tags.get(TAG_KEY) == TAG_VALUE
    except Exception as e:
        print(f"Error retrieving tags for alarm ARN {alarm_arn}: {e}")
        return False

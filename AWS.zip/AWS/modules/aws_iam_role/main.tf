resource "aws_iam_role" "iam_role" {
  description        = var.description
  name               = local.name
  assume_role_policy = var.assume_role_policy != "" ? var.assume_role_policy : local.default_assume_role_policy
  path               = var.path
}

resource "aws_iam_role_policy_attachments_exclusive" "iam_role_policy_attachments_exclusive" {
  role_name   = aws_iam_role.iam_role.name
  policy_arns = var.managed_policy_arns
}

resource "aws_iam_role_policy" "iam_role_policy" {
  for_each = var.inline_policies

  name   = each.value.inline_policy_name
  policy = each.value.inline_policy
  role   = aws_iam_role.iam_role.name
}
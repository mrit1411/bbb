﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_iam_instance_profile.instance_profile](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) | resource |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_name"></a> [name](#input\_name) | Name of the IAM Instance Profile. Can be a string of characters consisting of upper and lowercase alphanumeric characters and these special characters: \_, +, =, ,, ., @, -. Spaces are not allowed. The name must be unique, regardless of the path or role. In other words, if there are different role or path values but the same name as an existing instance profile, it will still cause an EntityAlreadyExists error. | `string` | n/a | yes |
| <a name="input_role"></a> [role](#input\_role) | The IAM role to associate with the instance profile. | `string` | n/a | yes |

## Outputs

No outputs.

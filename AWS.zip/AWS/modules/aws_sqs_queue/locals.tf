locals {
  name = "CCS-${var.name}"
}
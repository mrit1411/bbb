terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      version               = "4.22.0"
      configuration_aliases = [azurerm.security]
    }
  }
}

provider "azurerm" {
  features {}

  use_msi                         = true
  resource_provider_registrations = "none"
}

provider "azurerm" {
  alias = "security"
  features {}

  use_msi                         = true
  resource_provider_registrations = "none"
  #subscription_id                 = var.security_subscription_id
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_storage_account.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.deny](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_blob.blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_blob) | resource |
| [azurerm_storage_container.storage_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_storage_encryption_scope.storage_encryption_scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_encryption_scope) | resource |
| [archive_file.archive](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_kind"></a> [account\_kind](#input\_account\_kind) | Defines the Kind of account. Valid options are Storage, StorageV2, BlobStorage, FileStorage. Changing the account\_kind value from Storage to StorageV2 will not trigger a force new on the storage account, it will only upgrade the existing storage account from Storage to StorageV2 keeping the existing storage account in place.Changing this forces a new resource to be created. | `string` | `"StorageV2"` | no |
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | Defines the type of replication to use for this storage account. Changing this forces a new resource to be created when types LRS, GRS and RAGRS are changed to ZRS, GZRS or RAGZRS and vice versa. | `string` | `"GRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | Defines the Tier to use for this storage account. Changing this forces a new resource to be created. | `string` | `"Standard"` | no |
| <a name="input_allow_nested_items_to_be_public"></a> [allow\_nested\_items\_to\_be\_public](#input\_allow\_nested\_items\_to\_be\_public) | allow\_blob\_public\_access - defaults to false | `bool` | `false` | no |
| <a name="input_blob_name"></a> [blob\_name](#input\_blob\_name) | The name of the splunk integration function zip storage blob. Must be unique within the storage container the blob is located. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_container_access_type"></a> [container\_access\_type](#input\_container\_access\_type) | The access level to use for this container. Possible values are 'private', 'blob', 'container'. | `string` | `"private"` | no |
| <a name="input_context"></a> [context](#input\_context) | The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cross_tenant_replication_enabled"></a> [cross\_tenant\_replication\_enabled](#input\_cross\_tenant\_replication\_enabled) | n/a | `bool` | `false` | no |
| <a name="input_default_action"></a> [default\_action](#input\_default\_action) | n/a | `string` | `"Deny"` | no |
| <a name="input_deny_rules"></a> [deny\_rules](#input\_deny\_rules) | n/a | <pre>map(object({<br/>    subnets                 = list(string)<br/>    bypass                  = optional(list(string), [])<br/>    ip_rules                = list(string)<br/>    private_link_access_ids = optional(set(string), [])<br/>  }))</pre> | `{}` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_file_source"></a> [file\_source](#input\_file\_source) | An absolute path to splunk integration function zip on the local system. This field cannot be specified for Append blobs and cannot be specified if source\_content or source\_uri is specified. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_https_traffic_only_enabled"></a> [https\_traffic\_only\_enabled](#input\_https\_traffic\_only\_enabled) | Allows https traffic only to storage service if set to true. | `bool` | `true` | no |
| <a name="input_index"></a> [index](#input\_index) | The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_is_hns_enabled"></a> [is\_hns\_enabled](#input\_is\_hns\_enabled) | Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2 (see here for more information). Changing this forces a new resource to be created. | `string` | `false` | no |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the storage account. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | n/a | `bool` | `false` | no |
| <a name="input_storage_container_name"></a> [storage\_container\_name](#input\_storage\_container\_name) | The name of the Splunk Integration Function Container which should be created within the Storage Account. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_storage_encryption_scope_name"></a> [storage\_encryption\_scope\_name](#input\_storage\_encryption\_scope\_name) | Specifies the name of the Splunk Integration storage account encryption scope. Changing this forces a new encryption scope to be created. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(any)` | n/a | yes |
| <a name="input_type"></a> [type](#input\_type) | The type of the storage blob to be created. Possible values are Append, Block or Page. Changing this forces a new resource to be created. | `string` | `"Block"` | no |
| <a name="input_versioning_enabled"></a> [versioning\_enabled](#input\_versioning\_enabled) | Should versinoning be enabled on the storage account? Defaults to false. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_account_name"></a> [account\_name](#output\_account\_name) | n/a |
| <a name="output_blob_id"></a> [blob\_id](#output\_blob\_id) | n/a |
| <a name="output_blob_url"></a> [blob\_url](#output\_blob\_url) | n/a |
| <a name="output_container_id"></a> [container\_id](#output\_container\_id) | n/a |
| <a name="output_container_name"></a> [container\_name](#output\_container\_name) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_primary_access_key"></a> [primary\_access\_key](#output\_primary\_access\_key) | n/a |

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

data "terraform_remote_state" "infra" {
  backend = "local"
  config = {
    path = "../infra/terraform.tfstate"
  }
}
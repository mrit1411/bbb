
import boto3
import csv
import io
import os
from datetime import datetime, timedelta, timezone

PERIOD_SECONDS = 3600  # 1-hour buckets
STATUS_NAMESPACE = 'AWS/EC2'
STATUS_METRIC = 'StatusCheckFailed'

# Fetch S3 bucket name from environment variables
s3_destination_bucket = os.environ.get('S3_BUCKET')

TAG_KEY_ENV = 'AVAILABILITY_REPORTING_KEY'
TAG_VALUE_ENV = 'AVAILABILITY_REPORTING_VALUE'

def lambda_handler(event, context):
    # ---------------------------------------------
    # 1. Define Reporting Window: Previous Calendar Month (UTC)
    # ---------------------------------------------
    now_utc = datetime.now(timezone.utc)
    first_of_this_month = now_utc.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    month_end = first_of_this_month - timedelta(microseconds=1)
    first_of_last_month = (first_of_this_month - timedelta(days=1)).replace(day=1)
    month_start = first_of_last_month.replace(hour=0, minute=0, second=0, microsecond=0)

    # ---------------------------------------------
    # 2. Get AWS Account ID Dynamically
    # ---------------------------------------------
    sts = boto3.client('sts')
    account_id = sts.get_caller_identity()['Account']

    # ---------------------------------------------
    # 3. Get All Regions
    # ---------------------------------------------
    ec2_global = boto3.client('ec2')
    regions = [r['RegionName'] for r in ec2_global.describe_regions()['Regions']]

    # ---------------------------------------------
    # Read tag key/value from env (used as filter)
    # ---------------------------------------------
    tag_key = os.environ.get(TAG_KEY_ENV)
    tag_value = os.environ.get(TAG_VALUE_ENV)

    # If both present, we will use EC2 API filter to only retrieve matching instances.
    use_tag_filter = bool(tag_key and tag_value)

    report_rows = []

    # ---------------------------------------------
    # 4. Loop Through Regions and Instances
    # ---------------------------------------------
    for region in regions:
        ec2 = boto3.client('ec2', region_name=region)
        cloudwatch = boto3.client('cloudwatch', region_name=region)

        # Use paginator for safety and scale
        paginator = ec2.get_paginator('describe_instances')
        if use_tag_filter:
            filters = [{'Name': f'tag:{tag_key}', 'Values': [tag_value]}]
            page_iterator = paginator.paginate(Filters=filters)
        else:
            # If tag filter not provided, fall back to all instances
            page_iterator = paginator.paginate()

        # Iterate instances across all pages
        for page in page_iterator:
            reservations = page.get('Reservations', [])
            for reservation in reservations:
                for instance in reservation.get('Instances', []):
                    instance_id = instance['InstanceId']

                    # If no API filter (because envs missing), still defensively enforce tag filter here
                    # in case user wants *strict* behavior even when API filter wasn't applied.
                    if use_tag_filter:
                        tags = {t['Key']: t['Value'] for t in instance.get('Tags', [])}
                        if tags.get(tag_key) != tag_value:
                            continue  # skip non-matching instances

                    name_tag = next(
                        (t['Value'] for t in instance.get('Tags', []) if t['Key'] == 'Name'),
                        instance_id
                    )
                    launch_time = instance['LaunchTime']  # timezone-aware (UTC)

                    # Monitoring resolution: 1 min for detailed, 5 min for basic
                    monitoring_state = instance.get('Monitoring', {}).get('State', 'disabled')
                    minutes_per_sample = 1 if monitoring_state == 'enabled' else 5

                    # Use the full month window
                    window_start = month_start
                    window_end = month_end
                    if window_end <= window_start:
                        continue

                    # ---------------------------------------------
                    # 5. Fetch CloudWatch Metrics (Hourly, Sum + SampleCount)
                    # ---------------------------------------------
                    metric = cloudwatch.get_metric_statistics(
                        Namespace=STATUS_NAMESPACE,
                        MetricName=STATUS_METRIC,
                        Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                        StartTime=window_start,
                        EndTime=window_end,
                        Period=PERIOD_SECONDS,
                        Statistics=['Sum', 'SampleCount']
                    )

                    datapoints = metric.get('Datapoints', [])
                    if not datapoints:
                        # No data for this instance in the window
                        report_rows.append([
                            region, name_tag, instance_id,
                            window_start.date(), window_end.date(),
                            0, 0, 0, 0.0, 0.0
                        ])
                        continue

                    # Sort datapoints by timestamp
                    datapoints.sort(key=lambda d: d['Timestamp'])

                    # ---------------------------------------------
                    # 6. Calculate minutes from observed samples only
                    # ---------------------------------------------
                    total_observed_minutes = 0
                    total_failed_minutes = 0

                    for dp in datapoints:
                        failed_samples = int(round(dp.get('Sum', 0)))
                        observed_samples = int(round(dp.get('SampleCount', 0)))

                        # Defensive clamps
                        if failed_samples < 0:
                            failed_samples = 0
                        if observed_samples < 0:
                            observed_samples = 0
                        if failed_samples > observed_samples:
                            failed_samples = observed_samples  # binary metric safety

                        # Convert samples to minutes
                        failed_minutes = failed_samples * minutes_per_sample
                        observed_minutes = observed_samples * minutes_per_sample

                        # Cap per-hour minutes defensively (should not exceed 60)
                        if failed_minutes > 60:
                            failed_minutes = 60
                        if observed_minutes > 60:
                            observed_minutes = 60

                        total_failed_minutes += failed_minutes
                        total_observed_minutes += observed_minutes

                    # Up minutes = observed - failed
                    total_up_minutes = max(total_observed_minutes - total_failed_minutes, 0)

                    # Convert to hours (fractional) for CSV
                    total_hours = total_observed_minutes / 60.0
                    up_hours = total_up_minutes / 60.0
                    down_hours = total_failed_minutes / 60.0

                    # Percentages over observed minutes only
                    if total_observed_minutes > 0:
                        up_pct = round((total_up_minutes / total_observed_minutes) * 100, 2)
                        down_pct = round((total_failed_minutes / total_observed_minutes) * 100, 2)
                    else:
                        up_pct = 0.0
                        down_pct = 0.0

                    report_rows.append([
                        region, name_tag, instance_id,
                        window_start.date(), window_end.date(),
                        total_hours, up_hours, down_hours, up_pct, down_pct
                    ])

    # ---------------------------------------------
    # 7. Write CSV
    # ---------------------------------------------
    csv_buffer = io.StringIO()
    writer = csv.writer(csv_buffer)
    writer.writerow([
        'Region', 'VM Name', 'Instance ID',
        'Start Date', 'End Date',
        'Total Hours', 'Up Hours', 'Down Hours', 'Up %', 'Down %'
    ])
    writer.writerows(report_rows)

    # ---------------------------------------------
    # 8. Generate Timestamped Filename
    # ---------------------------------------------
    now_ts = datetime.now(timezone.utc)
    date_part = now_ts.strftime('%Y%m%d_%H%M')
    micro_part = f"{now_ts.microsecond:06d}"
    filename = f"availability-report-{account_id}-{date_part}.{micro_part}.csv"

    # ---------------------------------------------
    # 9. Upload to S3
    # ---------------------------------------------
    s3_client = boto3.client('s3')
    s3_client.put_object(Bucket=s3_destination_bucket, Key=filename, Body=csv_buffer.getvalue())

    return {
        'statusCode': 200,
        'body': (
            f"Report generated and uploaded to s3://{s3_destination_bucket}/{filename}. "
            + (f"Tag filter applied: {tag_key}={tag_value}" if use_tag_filter else "No tag filter applied.")
        ),
        'total_instances': len(report_rows),
        'window_start_utc': month_start.isoformat(),
        'window_end_utc': month_end.isoformat()
    }

variable "azure_policy_Backup_assignment_name" {
  description = "The name of the backup policy to be assigned"
  type        = string
}

variable "azure_policy_Backup_definition_name" {
  description = "The name of the backup policy to be created"
  type        = string
}

# New changes for backup tags
variable "backup_tag_name_standard" {
  description = "Tag name used for Standard Backup"
  type        = string
  default     = "ccs_backup_standard"
}

variable "backup_tag_name_enhanced" {
  description = "Tag name used for Enhanced Backup"
  type        = string
  default     = "ccs_backup_enhanced"

}


variable "backup_tag_name" {
  description = "The name of the tag used for Backup"
  type        = string
  default     = "ccs_backup"
}

variable "backup_tag_value" {
  description = "The value of the tag used for Backup"
  type        = string
  default     = "yes"
}

variable "policy_assignment_user_assigned_identity_ids" {
  description = "The user assigned identity IDs for the Monitoring policy"
  type        = list(string)
}


# variable "standard_backup_map" {
#   description = "Standard backup policy IDs by subscription and region"

#   type = map(object({
#     sub_id  = string
#     regions = map(string)
#   }))
# }

# variable "enhanced_backup_map" {
#   description = "Enhanced backup policy IDs by subscription and region"

#   type = map(object({
#     sub_id  = string
#     regions = map(string)
#   }))
# }



variable "policy_management_group_id" {
  description = "The management group ID for the policy assignment"
  type        = string
}


variable "subscriptions" {
  description = "Map of subscription configurations"

  type = map(object({
    subscription_id            = optional(string)
    resource_group_name_map    = map(string)
    recovery_vault_name_prefix = optional(string)

    standard_policy_name = optional(string)
    enhanced_policy_name = optional(string)

    standard_policy = optional(object({
      timezone           = optional(string)
      schedule_frequency = string
      schedule_time      = string
      weekdays           = optional(list(string))

      retention_daily = optional(number)

      retention_weekly               = optional(object({ count = number, weekdays = list(string) }))
      retention_monthly              = optional(object({ count = number, weeks = optional(list(string)), weekdays = optional(list(string)), monthdays = optional(list(number)), days = optional(list(number)) }))
      retention_yearly               = optional(object({ count = number, months = list(string), weeks = optional(list(string)), weekdays = optional(list(string)), days = optional(list(string)) }))
      instant_restore_retention_days = optional(number)
    }))

    enhanced_policy = optional(object({
      timezone                       = optional(string)
      schedule_frequency             = string
      schedule_time                  = string
      hour_interval                  = optional(number)
      hour_duration                  = optional(number)
      weekdays                       = optional(list(string))
      retention_daily                = optional(number)
      retention_weekly               = optional(object({ count = number, weekdays = list(string) }))
      retention_monthly              = optional(object({ count = number, weeks = optional(list(string)), weekdays = optional(list(string)), monthdays = optional(list(number)), days = optional(list(number)) }))
      retention_yearly               = optional(object({ count = number, months = list(string), weeks = optional(list(string)), weekdays = optional(list(string)), days = optional(list(string)) }))
      instant_restore_retention_days = optional(number)
    }))

    vault_sku          = optional(string)
    tags               = optional(map(string))
    backup_policy_type = optional(string)
  }))
}

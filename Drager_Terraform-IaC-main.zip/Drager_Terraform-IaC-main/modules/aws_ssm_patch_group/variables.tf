variable "patch_group" {
  description = "The name of the patch group that should be registered with the patch baseline."
  type        = string
}

variable "region" {
  type        = string
  description = "Region where the resource need to deployed."
}


variable "patch_baseline" {
  # type = list(map())
}
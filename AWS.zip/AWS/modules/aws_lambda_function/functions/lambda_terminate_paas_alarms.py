import boto3
import os
import logging
import time  # NEW
from botocore.exceptions import ClientError  # NEW

logger = logging.getLogger()
logger.setLevel(logging.INFO)

TAG_KEY = os.environ['TagsConditionKey']
TAG_VALUE = os.environ['TagsConditionValue']

# Bounded exponential recheck knobs (kept simple)
RECHECK_BASE_SECONDS = 30   # 30s, then doubles
RECHECK_MAX_ATTEMPTS = 2    # 30s, then 60s

# AWS clients
cloudwatch = boto3.client('cloudwatch')
lambda_client = boto3.client('lambda')
rds_client = boto3.client('rds')
elbv2_client = boto3.client('elbv2')

# Maps AWS service to CloudWatch dimension name
DIMENSION_MAP = {
    'lambda': 'FunctionName',
    'rds': 'DBInstanceIdentifier',
    'elasticloadbalancing': 'LoadBalancer'
}

def lambda_handler(event, context):
    resource_arn = event['resources'][0]
    service = event['detail']['service']

    dimension_name = DIMENSION_MAP.get(service)
    dimension_value = extract_dimension_value(service, resource_arn)

    logger.info(f"Checking if {service} resource '{dimension_value}' still exists...")

    exists, uncertain = resource_exists(service, resource_arn, dimension_value)

    # If still exists, re-check with bounded exponential backoff (30s, then 60s)
    if exists and RECHECK_MAX_ATTEMPTS > 0:
        for attempt in range(RECHECK_MAX_ATTEMPTS):
            delay = RECHECK_BASE_SECONDS * (2 ** attempt)
            msg = "Retrying because last check failed (uncertain)" if uncertain else "Resource exists. Rechecking"
            logger.info(f"{msg} in {delay}s (attempt {attempt+1}/{RECHECK_MAX_ATTEMPTS})...")
            time.sleep(delay)
            exists, uncertain = resource_exists(service, resource_arn, dimension_value)
            if not exists:
                break


    if exists:
        if uncertain:
            logger.warning(f"Skipping alarm cleanup for '{dimension_value}': existence UNCERTAIN after rechecks (errors occurred).")
            return {'statusCode': 202,'body': f"Skipped cleanup: existence uncertain for {dimension_value}"}
        else:
            logger.info(f"Resource '{dimension_value}' CONFIRMED to still exist after rechecks. Skipping alarm cleanup.")
            return {'statusCode': 202,'body': f"Resource confirmed to exist: {dimension_value}"}

    logger.info(f"Resource '{dimension_value}' no longer exists. Proceeding with alarm cleanup.")
    delete_tagged_alarms(dimension_name, dimension_value)
    return {'statusCode': 200, 'body': f"Decommission confirmed for {dimension_value}"}

def extract_dimension_value(service, arn):
    parts = arn.split('/')
    if service == 'lambda':
        return arn.split(':')[-1]  # function name (your event only tags functions, not aliases/versions)
    elif service == 'rds':
        return arn.split(':')[-1]  # DBInstanceIdentifier
    elif service == 'elasticloadbalancing':
        if len(parts) >= 3:       # FIXED: use '>=' (avoid HTML-escaped '&gt;=')
            lb_name = parts[-2]
            lb_id = parts[-1]
            return f"app/{lb_name}/{lb_id}"  # ALB metric format
    return None

def resource_exists(service, arn, name):
    """
    Return True unless we are confident the resource is gone.
    - If we hit service-specific *NotFound* codes, return False immediately (no retry).
    - Any other error (throttling, timeout, AccessDenied, region mismatch, etc.) ⇒ assume exists.
    """
    try:
        if service == 'lambda':
            lambda_client.get_function(FunctionName=name)  # NotFound -> ResourceNotFoundException
        elif service == 'rds':
            rds_client.describe_db_instances(DBInstanceIdentifier=name)  # NotFound -> DBInstanceNotFound
        elif service == 'elasticloadbalancing':
            elbv2_client.describe_load_balancers(LoadBalancerArns=[arn])  # NotFound -> LoadBalancerNotFound
        return True, False

    except ClientError as e:
        code = (e.response.get('Error') or {}).get('Code')

        # Terminal "gone" signals — safe to proceed with cleanup; no retries here.
        if (service == 'lambda' and code == 'ResourceNotFoundException') \
           or (service == 'rds' and code == 'DBInstanceNotFound') \
           or (service == 'elasticloadbalancing' and code in ('LoadBalancerNotFound', 'LoadBalancerNotFoundException')):
            logger.info(f"[existence-check] NotFound for {service} '{name}' (code={code})")
            return False,False

        # Any other error → assume exists to avoid accidental deletes.
        logger.warning(f"[existence-check] Non-NotFound error for {service} '{name}': {code} | {e}")
        return True,True

    except Exception as e:
        # Unknown/unexpected → assume exists
        logger.warning(f"[existence-check] Unexpected error for {service} '{name}': {e}")
        return True,True

def delete_tagged_alarms(dimension_name, dimension_value):
    paginator = cloudwatch.get_paginator('describe_alarms')
    for page in paginator.paginate(AlarmTypes=['MetricAlarm']):
        for alarm in page['MetricAlarms']:
            dimensions = alarm.get('Dimensions', [])
            if any(dim['Name'] == dimension_name and dim['Value'] == dimension_value for dim in dimensions):
                alarm_arn = alarm.get('AlarmArn')
                if alarm_arn and has_required_tag(alarm_arn):
                    try:
                        cloudwatch.delete_alarms(AlarmNames=[alarm['AlarmName']])
                        logger.info(f"Deleted alarm: {alarm['AlarmName']}")
                    except Exception as e:
                        logger.error(f"Failed to delete alarm '{alarm['AlarmName']}': {e}")

def has_required_tag(alarm_arn):
    try:
        tags = cloudwatch.list_tags_for_resource(ResourceARN=alarm_arn).get('Tags', [])
        return any(tag['Key'] == TAG_KEY and tag['Value'] == TAG_VALUE for tag in tags)
    except Exception as e:
        logger.error(f"Error retrieving tags for alarm ARN '{alarm_arn}': {e}")
        return False
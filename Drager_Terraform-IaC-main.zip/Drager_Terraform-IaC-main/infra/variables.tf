variable "tags_condition_key" {
  description = "Resources with this Tag Key will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "ccs_managed"
}

variable "tags_condition_value" {
  description = "Resources with this Tag Value will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "yes"
}

variable "ssm_management_ec2_instance_profile_name" {
  description = "Name of the SSM Management EC2 Instance Profile"
  type        = string
  default     = "CCSEC2InstanceProfileforSSMManagement"
}

variable "snow_sns_topic_name" {
  description = "Provide name for SNS Topic that will be created and linked to CCS ServiceNow Lambda"
  type        = string
  default     = "SNOW-Monitoring"

}

variable "api_company_name" {
  description = "CCS-SNOW Lambda will populate the Company field in ServiceNow with this value. this must reflect the exact name of the intended company in ServiceNow"
  type        = string

}

variable "log_level" {
  description = "Allows various details of lambda events to be logged. Value must be in range:<0- no logging, 1- production, 2- dev, 3 maximum logging>"
  type        = number
  default     = 3

  validation {
    condition     = var.log_level >= 0 && var.log_level <= 3
    error_message = "Log level must be between 0 and 3."
  }
}

variable "regions" {
  description = "List of regions to deploy the SNS topic for Splunk Forwarder"
  type        = list(string)

}

variable "snow_secret_arn" {
  description = "Arn of SNOW secret managers in all regions"
  type        = map(string)
}


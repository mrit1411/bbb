resource "aws_oam_link" "oam_link" {
  label_template = local.oam_link_label_template
  resource_types = var.oam_link_resource_types
  sink_identifier = var.oam_sink_arn
  region = var.region
}
data "azurerm_client_config" "current" {}

module "reporting_function_storage" {
  source              = "./modules/reporting_storage_module"
  resource_group_name = var.resource_group_name
  location            = var.location
  blob_name           = "${var.reporting_function_zip_name}.zip"
  file_source         = var.reporting_function_zip_path
  environment         = var.environment
  context             = var.context
  org                 = var.org
  tags                = var.tags
}

module "reporting_function_app" {
  source                             = "./modules/reporting_function_app"
  resource_group_name                = var.resource_group_name
  location                           = var.location
  storage_account_name               = module.reporting_function_storage.account_name
  storage_account_access_key         = module.reporting_function_storage.primary_access_key
  tags                               = var.tags
  blob_url                           = module.reporting_function_storage.blob_url
  user_assigned_identity_ids         = var.reporting_function_user_assigned_identity_ids
  user_assigned_identity_resource_id = var.client_id_resource_id
  environment                        = var.environment
  org                                = var.org
  context                            = var.context
  client_id                          = var.client_id
}

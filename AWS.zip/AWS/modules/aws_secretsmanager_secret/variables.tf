variable "name" {
  description = "The name of the secret."
  type        = string
  default     = ""

}

variable "description" {
  description = "Description of the secret."
  type        = string
}

variable "context" {
  description = "The context of the secret manager"
  type        = string
  default     = ""
}

variable "secret_string_wo_version" {
  description = "Used together with secret_string_wo to trigger an update. Increment this value when an update to secret_string_wo is required."
  type        = number
}

variable "secret_string_wo" {
  description = "A map of key-value pairs to store in the secret. This is used to store sensitive information like access keys or passwords."
  type        = string
  default     = ""

}

variable "region" {
  description = "The AWS region where the Secrets Manager secret is created."
  type        = string
}
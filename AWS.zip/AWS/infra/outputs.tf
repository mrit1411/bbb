output "infra_run_command_linux_ssm_automation_document" {
  value = module.run_command_linux_ssm_automation_document.name
}

output "infra_create_backup_ssm_automation_document" {
  value = module.create_backup_ssm_automation_document.name
}

output "infra_run_command_windows_ssm_automation_document" {
  value = module.run_command_windows_ssm_automation_document.name
}

# output "infra_snow_sns_topic" {
#   value = module.snow_sns_topic.sns_topic_arn
# }

output "splunk_forwarder_sns_topic_arns" {
  value = {
    for r in var.regions : r => module.splunk_forwarder_sns_topic[r].sns_topic_arn
  }
}

output "infra_ec2_instance_profile_name" {
  value = module.ssm_management_ec2_instance_profile.name

}
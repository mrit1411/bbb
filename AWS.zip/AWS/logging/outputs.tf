output "logging_ec2_instance_cloudwatch_log_group" {
  value = module.ec2_instance_cloudwatch_log_group.name
}
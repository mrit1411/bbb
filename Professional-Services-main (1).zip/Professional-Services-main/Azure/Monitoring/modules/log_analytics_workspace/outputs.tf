output "workspace_id" {
  value = azurerm_log_analytics_workspace.log_analytics_workspace.id
}

output "workspace_name" {
  value = azurerm_log_analytics_workspace.log_analytics_workspace.name
}
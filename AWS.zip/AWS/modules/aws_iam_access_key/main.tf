resource "aws_iam_access_key" "iam_access_key" {
  user   = var.user
  status = var.status ? "Active" : "Inactive"
}
resource "aws_backup_vault" "backup_vault" {
  name = local.name
  tags = var.tags
  region = var.region
}
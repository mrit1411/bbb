variable "patching_report_generation_date" {
  description = "Enter the schedule for AWS SSM Patch Manger report generation. AWS CRON expression specifying when the Patching EventBridge Rule will initiate the generation of monthly SSM Patch Manager reports (09:01 on the last day of each month)"
  type        = string
  default     = "cron(01 09 L * ? *)"
}

variable "windows_server_patch_baseline_name" {
  description = "Name of the Windows Server patch baseline."
  type        = string
}

variable "windows_server_patch_baseline_description" {
  description = "Description of the Windows Server patch baseline."
  type        = string
}

variable "windows_server_approve_after_days" {
  description = "Number of days after which patches are approved for Windows Server."
  type        = number
}

variable "windows_server_patch_filters" {
  description = "Patch filters for Windows Server."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "windows_server_patch_group" {
  description = "Patch group for the Windows Server patch baseline."
  type        = string
}

variable "suse_linux_patch_baseline_name" {
  description = "Name of the SUSE Linux patch baseline."
  type        = string
}

variable "suse_linux_patch_baseline_description" {
  description = "Description of the SUSE Linux patch baseline."
  type        = string
}

variable "suse_linux_approve_after_days" {
  description = "Number of days after which patches are approved for SUSE Linux."
  type        = number
}

variable "suse_linux_patch_filters" {
  description = "Patch filters for SUSE Linux."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "suse_linux_patch_group" {
  description = "Patch group for the SUSE Linux patch baseline."
  type        = string
}

variable "rhel_patch_baseline_name" {
  description = "Name of the RHEL patch baseline."
  type        = string
}

variable "rhel_patch_baseline_description" {
  description = "Description of the RHEL patch baseline."
  type        = string
}

variable "rhel_approve_after_days" {
  description = "Number of days after which patches are approved for RHEL."
  type        = number
}

variable "rhel_patch_filters" {
  description = "Patch filters for RHEL."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "rhel_patch_group" {
  description = "Patch group for the RHEL patch baseline."
  type        = string
}

variable "ubuntu_patch_baseline_name" {
  description = "Name of the Ubuntu patch baseline."
  type        = string
}

variable "ubuntu_patch_baseline_description" {
  description = "Description of the Ubuntu patch baseline."
  type        = string
}

variable "ubuntu_approve_after_days" {
  description = "Number of days after which patches are approved for Ubuntu."
  type        = number
}

variable "ubuntu_patch_filters" {
  description = "Patch filters for Ubuntu."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "ubuntu_patch_group" {
  description = "Patch group for the Ubuntu patch baseline."
  type        = string
}

variable "centos_patch_baseline_name" {
  description = "Name of the CentOS patch baseline."
  type        = string
}

variable "centos_patch_baseline_description" {
  description = "Description of the CentOS patch baseline."
  type        = string
}

variable "centos_approve_after_days" {
  description = "Number of days after which patches are approved for CentOS."
  type        = number
}

variable "centos_patch_filters" {
  description = "Patch filters for CentOS."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "centos_patch_group" {
  description = "Patch group for the CentOS patch baseline."
  type        = string
}

variable "debian_linux_patch_baseline_name" {
  description = "Name of the Debian Linux patch baseline."
  type        = string
}

variable "debian_linux_patch_baseline_description" {
  description = "Description of the Debian Linux patch baseline."
  type        = string
}

variable "debian_linux_approve_after_days" {
  description = "Number of days after which patches are approved for Debian Linux."
  type        = number
}

variable "debian_linux_patch_filters" {
  description = "Patch filters for Debian Linux."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "debian_linux_patch_group" {
  description = "Patch group for the Debian Linux patch baseline."
  type        = string
}

variable "oracle_linux_patch_baseline_name" {
  description = "Name of the Oracle Linux patch baseline."
  type        = string
}

variable "oracle_linux_patch_baseline_description" {
  description = "Description of the Oracle Linux patch baseline."
  type        = string
}

variable "oracle_linux_approve_after_days" {
  description = "Number of days after which patches are approved for Oracle Linux."
  type        = number
}

variable "oracle_linux_patch_filters" {
  description = "Patch filters for Oracle Linux."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "oracle_linux_patch_group" {
  description = "Patch group for the Oracle Linux patch baseline."
  type        = string
}

variable "amazon_linux_patch_baseline_name" {
  description = "Name of the Amazon Linux patch baseline."
  type        = string
}

variable "amazon_linux_patch_baseline_description" {
  description = "Description of the Amazon Linux patch baseline."
  type        = string
}

variable "amazon_linux_approve_after_days" {
  description = "Number of days after which patches are approved for Amazon Linux."
  type        = number
}

variable "amazon_linux_patch_filters" {
  description = "Patch filters for Amazon Linux."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "amazon_linux_patch_group" {
  description = "Patch group for the Amazon Linux patch baseline."
  type        = string
}

variable "amazon_linux_2_patch_baseline_name" {
  description = "Name of the Amazon Linux 2 patch baseline."
  type        = string
}

variable "amazon_linux_2_patch_baseline_description" {
  description = "Description of the Amazon Linux 2 patch baseline."
  type        = string
}

variable "amazon_linux_2_approve_after_days" {
  description = "Number of days after which patches are approved for Amazon Linux 2."
  type        = number
}

variable "amazon_linux_2_patch_filters" {
  description = "Patch filters for Amazon Linux 2."
  type = list(object({
    key    = string
    values = list(string)
  }))
}

variable "amazon_linux_2_patch_group" {
  description = "Patch group for the Amazon Linux 2 patch baseline."
  type        = string
}

variable "patch_reports_bucket_name" {
  description = "Name of the S3 bucket where patch reports will be stored."
  type        = string
}

variable "patch_report_generation_schedule_monthly" {
  description = "Monthly schedule for patch report generation. AWS CRON expression specifying when the Patching EventBridge Rule will initiate the generation of monthly SSM Patch Manager reports."
  type        = string
}

variable "results_patching_sns_topic_name" {
  description = "Enter the name for the SNS Topic that will be created and used as the endpoint for Failed Patching Notifications"
  type        = string
  default     = "CCS-Patching-instant-report-topic"
}

variable "log_level" {
  description = "Allows various details of lambda events to be logged. Value must be in range:<0- no logging, 1- production, 2- dev, 3 maximum logging"
  type        = number
  default     = 3

  validation {
    condition     = var.log_level >= 0 && var.log_level <= 3
    error_message = "Log level must be between 0 and 3."
  }
}

variable "regions" {
  description = "List of regions where resources will be created."
  type        = list(string)
  
}
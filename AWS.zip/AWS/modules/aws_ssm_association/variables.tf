variable "name" {
  description = "The name of the SSM document to apply."
  type        = string
}

variable "association_name" {
  description = "The descriptive name for the association."
  type        = string

}

variable "schedule_expression" {
  description = "The schedule expression for the association."
  type        = string
  default     = "rate(30 days)"
}

variable "key" {
  description = "Either InstanceIds or tag:Tag Name to specify an EC2 tag."
  type        = string
}

variable "values" {
  description = "User-defined criteria that maps to Key. A list of instance IDs or tag values."
  type        = list(string)
}

variable "parameters" {
  description = "A map of parameters to pass to the SSM document."
  type        = map(string)
  default     = null

}
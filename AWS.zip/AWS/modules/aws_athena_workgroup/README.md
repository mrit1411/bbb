﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_athena_workgroup.athena_workgroup](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/athena_workgroup) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_name"></a> [client\_name](#input\_client\_name) | Enter the name of Client. Used to create the selected resource | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | Description of the workgroup. | `string` | n/a | yes |
| <a name="input_enforce_workgroup_configuration"></a> [enforce\_workgroup\_configuration](#input\_enforce\_workgroup\_configuration) | Boolean whether the settings for the workgroup override client-side settings. | `bool` | n/a | yes |
| <a name="input_output_location"></a> [output\_location](#input\_output\_location) | Location in Amazon S3 where your query results are stored | `string` | n/a | yes |
| <a name="input_publish_cloudwatch_metrics_enabled"></a> [publish\_cloudwatch\_metrics\_enabled](#input\_publish\_cloudwatch\_metrics\_enabled) | Boolean whether Amazon CloudWatch metrics are enabled for the workgroup. | `bool` | n/a | yes |
| <a name="input_state"></a> [state](#input\_state) | Whether to enable of the workgroup. | `bool` | `true` | no |

## Outputs

No outputs.

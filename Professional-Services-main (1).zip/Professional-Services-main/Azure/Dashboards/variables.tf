variable "tags" {
  description = "List of tags to be added to resources."
  type        = map(string)
}

variable "ops_dashboard_workbook_display_name" {
  description = "Specifies the user-defined name (display name) of the Operations workbook."
  type        = string

}

variable "resource_group_name" {
  description = "Name of the resource group where to deploy the resources"
  type        = string

}

variable "location" {
  description = "The location in which the Dashboard will be deployed."
  type        = string
}
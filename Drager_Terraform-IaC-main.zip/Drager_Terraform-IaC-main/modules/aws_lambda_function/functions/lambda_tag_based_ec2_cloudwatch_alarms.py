import boto3
import os
import time
from botocore.exceptions import ClientError

cloudwatch = boto3.client('cloudwatch')
ec2 = boto3.resource('ec2')
ssm = boto3.client('ssm')
sns = boto3.client('sns')
sts = boto3.client('sts')
lmb = boto3.client('lambda')
client = boto3.client('ec2')

region = os.environ.get('AWS_REGION')
sns_topic_arn = os.environ.get('SNOWSNSTopicARN')
ssm_managed_tag_name = os.environ.get('TagsConditionKey')
ssm_managed_tag_value = os.environ.get('TagsConditionValue')
ssm_managed_tag = 'tag:{}'.format(ssm_managed_tag_name)
monitoring_enabled = os.environ.get('MonitoringEnabled') == "true"
logging_enabled = os.environ.get('LoggingEnabled') == "false"
citrix_tag_prefix = os.environ.get('Citrix_Tag_prefix')

print('Lambda environment variables:')
print(" - AWS_REGION: {}".format(region))
print(" - SNOWSNSTopicARN: {}".format(sns_topic_arn))
print(" - TagsConditionKey: {}".format(ssm_managed_tag_name))
print(" - TagsConditionValue: {}".format(ssm_managed_tag_value))

def lambda_handler(event, context):
    print("Received event: " + str(event))
    ec2_arn = event.get('resources')[0]
    instance_id = ec2_arn.split('/')[-1]

    event_detail = event.get('detail', {})
    is_citrix_instance = False
    instance_tags = get_instance_tags(ec2.Instance(instance_id))
    if ("dg-application" in instance_tags.keys() and instance_tags['dg-application'].startswith("citrix cad:".lower())): 
        is_citrix_instance = True

    if (
        "ccs_managed" in event_detail.get("changed-tag-keys", []) and
        "ccs_managed" in event_detail.get("tags", {}) and
        event_detail["tags"]["ccs_managed"] == "yes"
    ):
        print("Configuring monitoring for instance: {}".format(instance_id))
        configure_os_monitoring(instance_id, sns_topic_arn, ssm_managed_tag,is_citrix_instance)

    else:
        print("Condition not met")
        return False
    

    
def configure_os_monitoring(instance_id, sns_topic_arn, ssm_managed_tag,is_citrix_instance=False):
    if (instance_id is None):
        # all_instances = boto3.client('ec2').describe_instances(Filters=[{'Name': 'instance-state-name', 'Values': ['running']},
        #                                                                 {'Name': ssm_managed_tag, 'Values': [ssm_managed_tag_value]}])
        # all_instance_ids = []
        # linux_instance_ids = []
        # windows_instance_ids = []
        # for reservation in all_instances["Reservations"]:
        #     for instance in reservation["Instances"]:
        #         if (instance.get('Platform') is None):
        #             linux_instance_ids.append(instance["InstanceId"])
        #         else:
        #             windows_instance_ids.append(instance["InstanceId"])
        #             all_instance_ids.append(instance["InstanceId"])

        # print("Installing and configuring CloudWatch agent on ec2 instances: {}".format(all_instance_ids))
        # install_and_configure_cwagent(all_instance_ids)
        # print("Sending command to Linux instances: {}".format(linux_instance_ids))
        # send_run_command(linux_instance_ids, "linux")

        # print("Sending command to Windows instances: {}".format(linux_instance_ids))
        # send_run_command(windows_instance_ids, "windows")
        # if monitoring_enabled:
        #     for instance in linux_instance_ids:
        #         print("Creating alarms for Linux ec2 instances {} ...".format(instance.id))
        #         create_alarms_for_linux_instance(instance, instance.id, sns_topic_arn)

        #     for instance in windows_instance_ids:
        #         print("Creating alarms for Windows ec2 instances {} ...".format(instance.id))
        #         create_alarms_for_windows_instance(instance, instance.id, sns_topic_arn)
        print("No Instance Id in request.")

    else:
        instance_id_filter = boto3.client('ec2').describe_instances(
            Filters=[
                {
                    'Name': 'instance-state-name',
                    'Values': ['running']
                },
                {
                    'Name': ssm_managed_tag,
                    'Values': ['yes']
                }
            ],
            InstanceIds=[instance_id])
        try:
            instance_id = instance_id_filter['Reservations'][0]['Instances'][0]['InstanceId']
            print("InstanceID after filter: {}".format(instance_id))
        except Exception as e:
            print(e)
            print("No instances with {} tag found. Aborting...".format(ssm_managed_tag))
            return False

        instance_id_object = ec2.Instance(instance_id)
        if (instance_id):
            print('')
            print("Waiting for ec2 instance {} to reach the state of 'passed'...".format(instance_id))
            ec2_instance_status_check(instance_id)

            print('')
            print("Installing and configuring CloudWatch agent on ec2 instance {} ...".format(instance_id))
            install_and_configure_cwagent(instance_id) #just to create alarm
            if(instance_id_object.platform is None):
                print('')
                print("Sending command to Linux instance {}...".format(instance_id))
                send_run_command(instance_id, "linux") #just to create alarm
                if monitoring_enabled:
                    print('')
                    print("Creating alarms for Linux ec2 instance {} ...".format(instance_id))
                    create_alarms_for_linux_instance(instance_id_object, instance_id, sns_topic_arn)
            else:
                print('')
                print("Sending command to Windows instance {} ...".format(instance_id))
                send_run_command(instance_id, "windows",is_citrix_instance) #just to create alarm
                if monitoring_enabled:
                    print('')
                    print("Creating alarms for Windows ec2 instance {} ...".format(instance_id))
                    create_alarms_for_windows_instance(instance_id_object, instance_id, sns_topic_arn,is_citrix_instance)


def ec2_instance_status_check(instance_id):
    timeout = 60
    while True:
        instanceStatus = client.describe_instance_status(InstanceIds=[instance_id])
        status = instanceStatus['InstanceStatuses'][0]['InstanceStatus']['Details'][0]['Status']
        if (status == 'passed'):
            print(" - actual status: {}. Starting next step on ec2 instance {}...".format(status, instance_id))
            break
        else:
            print(" - actual status: {}. Waiting for ec2 instance {} to reach the state of 'passed'...".format(status, instance_id))
            print("   - timeout after: {} seconds".format(timeout))
            time.sleep(timeout)
            timeout = timeout - 10

        if (timeout == 0):
            print('')
            print("Timeout reached:")
            print(" - ec2 instance {} status: {}".format(instance_id, status))
            return False


def install_and_configure_cwagent(instanceId):
    timeout = 30
    while True:
        ssmagent_update_status = ssm.list_command_invocations(
            InstanceId=instanceId,
            Filters=[
                {
                    'key': 'DocumentName',
                    'value': 'AWS-UpdateSSMAgent'
                },
            ]
        )
        try:
            if ssmagent_update_status['CommandInvocations'][0]['Status'] == 'Success':
                print("SSM Agent finished updating")
                break
        except Exception as e:
            print("Did not find SSM agent update document")
            print(e)
            time.sleep(timeout)
            timeout = timeout - 10
        else:
            print("Waiting for SSM Agent to update")
            time.sleep(timeout)
            timeout = timeout - 10
        if (timeout == 0):
            print("SSM Agent did not perform update, skipping")
            break
    instance_id_object = ec2.Instance(instanceId)
    is_CWAgent_present = False
    if instance_id_object.platform is None:
        command_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName="AWS-RunShellScript",
            Parameters={
                'commands': [
                    'which amazon-cloudwatch-agent-ctl'
                ]
            })
        commandid = command_response['Command']['CommandId']
        time.sleep(5)
        check_command_status = ssm.get_command_invocation(
            InstanceId=instanceId,
            CommandId=commandid
        )
        is_CWAgent_present = check_command_status['Status'] == 'Success'
    else:
        command_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName="AWS-RunPowerShellScript",
            Parameters={
                'commands': [
                    "$ISAGENT = (TEST-PATH 'C:\\Program Files\\Amazon\\AmazonCloudWatchAgent\\amazon-cloudwatch-agent.exe')",
                    "if($ISAGENT -eq $False){THROW}"
                ]
            })
        commandid = command_response['Command']['CommandId']
        time.sleep(5)
        check_command_status = ssm.get_command_invocation(
            InstanceId=instanceId,
            CommandId=commandid
        )
        is_CWAgent_present = check_command_status['Status'] == 'Success'

    if is_CWAgent_present:
        print('CW Agent is already installed, starting uninstall process')
        uninstall_cwagent_response = ssm.send_command(
            InstanceIds=[instanceId],
            DocumentName='AWS-ConfigureAWSPackage',
            Parameters={
                "action": ["Uninstall"],
                "name": ["AmazonCloudWatchAgent"]
            }
        )
        timeout = 60
        uninstall_cwagent_commandid = uninstall_cwagent_response['Command']['CommandId']
        uninstall_cwagent_status = uninstall_cwagent_response['Command']['Status']
        while True:
            if uninstall_cwagent_status == 'Success':
                print("CW Agent uninstalled")
                break
            else:
                print("Waiting for CW Agent uninstallation to complete")
                time.sleep(timeout)
                timeout = timeout - 10
                uninstall_cwagent_response_invocation = ssm.get_command_invocation(
                    CommandId=uninstall_cwagent_commandid,
                    InstanceId=instanceId
                )
                uninstall_cwagent_status = uninstall_cwagent_response_invocation['Status']
            if (timeout == 0):
                print("CW Agent uninstallation did not complete")
                return False
    install_cwagent_response = ssm.send_command(
        InstanceIds=[instanceId],
        DocumentName='AWS-ConfigureAWSPackage',
        Parameters={
            "action": ["Install"],
            "name": ["AmazonCloudWatchAgent"]
        }
    )
    timeout = 60
    install_cwagent_commandid = install_cwagent_response['Command']['CommandId']
    install_cwagent_status = install_cwagent_response['Command']['Status']
    while True:
        if install_cwagent_status == 'Success':
            print("CW Agent installed")
            break
        else:
            print("Waiting for CW Agent installation to complete")
            time.sleep(timeout)
            timeout = timeout - 10
            install_cwagent_response_invocation = ssm.get_command_invocation(
                CommandId=install_cwagent_commandid,
                InstanceId=instanceId
            )
            install_cwagent_status = install_cwagent_response_invocation['Status']
        if (timeout == 0):
            print("CW Agent installation did not complete")
            return False
    print(" - CloudWatch agent installed on ec2 instance {}".format(instanceId))
    return True


def send_run_command(instance_ids, os,is_citrix_instance=False):
    try:
        if(os == "windows"):
            # instance_tags = get_instance_tags(ec2.Instance(instance_ids))
            # is_citrix_instance = False
            # if ("dg-application" in instance_tags.keys() and instance_tags['dg-application'].startswith("citrix cad:".lower())): 
            #     is_citrix_instance = True

            if is_citrix_instance:
                print("citrix CloudWatch Configuration")
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunPowerShellScript',
                    Parameters={
                        'commands': [
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-windows-Citrix-New-ccs", ""
                            # "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                        ],
                        'executionTimeout': ['600']
                    })
            else:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunPowerShellScript',
                    Parameters={
                        'commands': [
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-WindowsLogs-ccs", ""
                            # "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
                            "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                        ],
                        'executionTimeout': ['600']
                    })


            if is_aras_configuration(instance_ids):
                time.sleep(30)
                print("ARAS CloudWatch Configuration")
                ssm.send_command(
                InstanceIds=[instance_ids],
                DocumentName='AWS-RunPowerShellScript',
                Parameters={
                    'commands': [
                        # "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-WindowsLogs-ccs", ""
                        "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-windows-Logs-Aras", ""
                        "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
                    ],
                    'executionTimeout': ['600']
                }) 

                
            # if monitoring_enabled and logging_enabled:
            #     ssm.send_command(
            #         InstanceIds=[instance_ids],
            #         DocumentName='AWS-RunPowerShellScript',
            #         Parameters={
            #             'commands': [
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsmetricsconfiguration", ""
            #                 # "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
            #             ],
            #             'executionTimeout': ['600']
            #         })
            # elif monitoring_enabled and not logging_enabled:
            #     ssm.send_command(
            #         InstanceIds=[instance_ids],
            #         DocumentName='AWS-RunPowerShellScript',
            #         Parameters={
            #             'commands': [
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsmetricsconfiguration", ""
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
            #             ],
            #             'executionTimeout': ['600']
            #         })
            # elif not monitoring_enabled and logging_enabled:
            #     ssm.send_command(
            #         InstanceIds=[instance_ids],
            #         DocumentName='AWS-RunPowerShellScript',
            #         Parameters={
            #             'commands': [
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccswindowsloggingconfiguration", ""
            #                 "cd “C:/Program Files/Amazon/AmazonCloudWatchAgent/”", ".\\amazon-cloudwatch-agent-ctl.ps1 -m ec2 -a start", ""
            #             ],
            #             'executionTimeout': ['600']
            #         })
            print(' - runCommand sent successfully')
            return True

        if(os == 'linux'):
            # if monitoring_enabled and logging_enabled:
                ssm.send_command(
                    InstanceIds=[instance_ids],
                    DocumentName='AWS-RunShellScript',
                    Parameters={
                        'commands': [
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:AmazonCloudWatch-LinuxLogs-ccs',
                            # 'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxloggingconfiguration',
                            'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
                        ],
                        'executionTimeout': ['6000']
                    })
                
                ssm.send_command(InstanceIds=[instance_ids],DocumentName=f'CCS_Linux_Custom_Monitoring_Setup_{region}')


            # elif monitoring_enabled and not logging_enabled:
            #     ssm.send_command(
            #         InstanceIds=[instance_ids],
            #         DocumentName='AWS-RunShellScript',
            #         Parameters={
            #             'commands': [
            #                 'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxmetricsconfiguration',
            #                 'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
            #             ],
            #             'executionTimeout': ['6000']
            #         })
            # elif not monitoring_enabled and logging_enabled:
            #     ssm.send_command(
            #         InstanceIds=[instance_ids],
            #         DocumentName='AWS-RunShellScript',
            #         Parameters={
            #             'commands': [
            #                 'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a append-config -m ec2 -s -c ssm:AmazonCloudWatch-ccslinuxloggingconfiguration',
            #                 'sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a start'
            #             ],
            #             'executionTimeout': ['6000']
            #         })

            # print(' - runCommand sent successfully')
            # return True

    except ClientError as err:
        if 'ThrottlingException' in str(err):
            print("RunCommand throttled, automatically retrying...")
            send_run_command(instance_ids, os)
        else:
            print(" - run Command Failed!\n%s", str(err))
            return False


def get_instance_type(instanceId):
    instance_type = ''
    response = client.describe_instances(InstanceIds=[instanceId, ])
    instance_type = response['Reservations'][0]['Instances'][0]['InstanceType']
    return instance_type


def get_image_id(instanceId):
    image_id = ''
    response = client.describe_instances(InstanceIds=[instanceId, ])
    image_id = response['Reservations'][0]['Instances'][0]['ImageId']
    return image_id

def get_instance_name(instance):
        instance_id = instance.id
        instance_tags = get_instance_tags1(instance)
        if "Name" in instance_tags.keys():
            instance_name = instance_tags["Name"]
        else:
            instance_name = instance_id
        return instance_name

def create_alarms_for_windows_instance(instance, instance_id, sns_topic_arn,is_citrix_instance):
    if is_citrix_instance: # last updated
        instance_name = get_instance_name(instance)
        print(instance_name)
        namespace='Citrix CAD Server new'
        memory_alarm_dimensions = [
            {'Name': 'host', 'Value': instance_name},
            {'Name': 'objectname', 'Value': 'Memory'}
        ]

        uptime_dimension = [
            {'Name': 'host', 'Value': instance_name},
            {'Name': 'objectname', 'Value': 'System'}
        ]

        diskNames = []
        max_retries = 5
        retry_delay = 60  # seconds

        for attempt in range(max_retries):
            metrics = cloudwatch.list_metrics(
                Namespace=namespace,
                MetricName='DiskFree',
                Dimensions=[{'Name': 'host', 'Value': instance_name}]
            )

            for metric in metrics['Metrics']:
                dimensions = metric['Dimensions']
                for dimension in dimensions:
                    if(dimension['Name'] == 'instance'):
                        disk = dimension["Value"]
                        diskNames.append(disk)

            if diskNames:
                print(f"Found disk metrics after {attempt + 1} attempts")
                break
            else:
                print(f"No disk metrics found. Attempt {attempt + 1} of {max_retries}. Waiting {retry_delay} seconds...")
                time.sleep(retry_delay)
    
        if not diskNames:
            print("Warning: No disk metrics available yet. Disk alarms will not be created. Please run this function again after a few minutes.")


        print("Citrix Instance")
        create_cpu_alarm(instance=instance, instance_name=instance_id, threshold=90, duration=15)
        create_memory_alarm(instance_name=instance_id, threshold=95, duration=15, dimensions=memory_alarm_dimensions,metric_name="MemoryInPercent",namespace=namespace)
        # (instance_name, threshold, dimensions, duration=5, periods=5, metric_name='MemoryUsed', namespace='CWAgent')
        for disk in diskNames:
            disk_dimensions = [
                {'Name': 'host', 'Value': instance_name},
                {'Name': 'instance', 'Value': disk},
                {'Name': 'objectname', 'Value': 'LogicalDisk'}
            ]
            # create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=20, duration=5, dimensions=disk_dimensions)
            create_disk_alarm_windows(instance_name=instance_id, disk=disk, threshold=10, duration=15, dimensions=disk_dimensions,namespace=namespace)

        create_system_uptime_alarm(instance, instance_id,dimensions=uptime_dimension,Namespace=namespace)

        print(f"avaliable metrics: {metrics}")
        print(f"avaliable disks alarms : {diskNames}")

        create_status_check_alarm(instance, instance_id)
        print(" - Windows Citrix alarms created")
    else:
        print("non Citrix Instance")
        # instance_name = get_instance_name(instance)
        # print(instance_name)
        namespace='CWAgent'
        memory_alarm_dimensions = [
            {'Name': 'InstanceId', 'Value': instance_id},
            {'Name': 'objectname', 'Value': 'Memory'}
        ]

        uptime_dimension = [
            {'Name': 'InstanceId', 'Value': instance_id},
            {'Name': 'objectname', 'Value': 'System'}
        ]

        diskNames = []
        max_retries = 5
        retry_delay = 60  # seconds

        for attempt in range(max_retries):
            metrics = cloudwatch.list_metrics(
                Namespace=namespace,
                MetricName='LogicalDisk % Free Space',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}]
            )

            for metric in metrics['Metrics']:
                dimensions = metric['Dimensions']
                for dimension in dimensions:
                    if(dimension['Name'] == 'instance'):
                        disk = dimension["Value"]
                        diskNames.append(disk)

            if diskNames:
                print(f"Found disk metrics after {attempt + 1} attempts")
                break
            else:
                print(f"No disk metrics found. Attempt {attempt + 1} of {max_retries}. Waiting {retry_delay} seconds...")
                time.sleep(retry_delay)
    
        if not diskNames:
            print("Warning: No disk metrics available yet. Disk alarms will not be created. Please run this function again after a few minutes.")


        create_cpu_alarm(instance=instance, instance_name=instance_id, threshold=90, duration=15)
        create_memory_alarm(instance_name=instance_id, threshold=95, duration=15, dimensions=memory_alarm_dimensions,metric_name="Memory % Committed Bytes In Use",namespace=namespace)
        # (instance_name, threshold, dimensions, duration=5, periods=5, metric_name='MemoryUsed', namespace='CWAgent')
        for disk in diskNames:
            disk_dimensions = [
                {'Name': 'InstanceId', 'Value': instance_id},
                {'Name': 'instance', 'Value': disk},
                {'Name': 'objectname', 'Value': 'LogicalDisk'}
            ]
            # create_disk_alarm_windows(instance_name=instanceName, disk=disk, threshold=20, duration=5, dimensions=disk_dimensions)
            create_disk_alarm_windows(instance_name=instance_id, disk=disk, threshold=10, duration=15, dimensions=disk_dimensions,metric_name="LogicalDisk % Free Space",namespace=namespace)

        create_system_uptime_alarm(instance, instance_id,dimensions=uptime_dimension,Namespace=namespace)

        print(f"avaliable metrics: {metrics}")
        print(f"avaliable disks alarms : {diskNames}")

        create_status_check_alarm(instance, instance_id)
        print(" - Windows Non-Citrix alarms created")



def create_alarms_for_linux_instance(instance, instance_id, sns_topic_arn):
    # FIXME: remove redundant param
    namespace='CWAgent'
    memory_alarm_dimensions = [
            {'Name': 'InstanceId', 'Value': instance_id}
        ]


    max_retries = 5
    retry_delay = 60
    deviceNames = []

    for attempt in range(max_retries):
        metrics = cloudwatch.list_metrics(
            Namespace=namespace,
            MetricName='disk_used_percent',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}]
        )
        
        # Process metrics to find disk devices
        for metric in metrics['Metrics']:
            data = {}
            dimensions = metric['Dimensions']
            for dimension in dimensions:
                if(dimension['Name'] == 'device'):
                    data["device"] = dimension['Value']
                if(dimension['Name'] == 'path'):
                    data["path"] = dimension['Value']
                if(dimension['Name'] == 'fstype'):
                    data["fstype"] = dimension['Value']
            if "device" in data and data["fstype"] in ["xfs", "ext4"]:
                deviceNames.append(data)

        if deviceNames:
            print(f"Found disk metrics after {attempt + 1} attempts")
            break
        else:
            print(f"No disk metrics found. Attempt {attempt + 1} of {max_retries}. Waiting {retry_delay} seconds...")
            time.sleep(retry_delay)
    
    if not deviceNames:
        print("Warning: No disk metrics available yet. Disk alarms will not be created. Please run this function again after a few minutes.")

        
    create_cpu_alarm(instance=instance, instance_name=instance_id, threshold=95, duration=15)
    create_memory_alarm(instance_name=instance_id, threshold=95, duration=15, dimensions=memory_alarm_dimensions,metric_name="mem_used_percent",namespace=namespace)

    for deviceName in deviceNames:
        disk_dimensions = [
                {'Name': 'path', 'Value': deviceName["path"]},
                {'Name': 'InstanceId', 'Value': instance_id},
                # {'Name': 'ImageId', 'Value': instance.image.id},
                # {'Name': 'InstanceType', 'Value': instance.instance_type},
                {'Name': 'device', 'Value': deviceName["device"]},
                {'Name': 'fstype', 'Value': deviceName["fstype"]}
            ]
        
        create_disk_alarm_linux(instance_name=instance_id, disk=deviceName["path"], threshold=90, duration=15, dimensions=disk_dimensions,metric_name="disk_used_percent",namespace=namespace)

    create_linux_uptime_alarm(instance, instance_id,metric_name="InstanceUptimeSeconds",Namespace="Custom/Uptime")
    create_ssh_service_down_alarm(instance, instance_id,metric_name="ssh_status",Namespace="Custom/SSH")
    

    # Metrics and dimentions can be found here  https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/viewing_metrics_with_cloudwatch.html#list-ec2-metrics-cli
    # SWAP monitoring is supported only by Linux https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/metrics-collected-by-CloudWatch-agent.html
    # I am guessing this one is correct acording to monitoring.json
    # create_swap_alarm(instance_name=instanceName, threshold=85, duration=60, dimensions=memory_alarm_dimensions, metric_name='swap_used_percent', namespace="CWAgent")

    print(f"avaliable metrics: {metrics}")
    print(f"avaliable disks alarms : {deviceNames}")

    create_status_check_alarm(instance, instance_id)
    print(" - Linux alarms created")


def get_instance_platform_name(instance_id):
    response = ssm.describe_instance_information(
        Filters=[
            {
                'Key': 'InstanceIds',
                'Values': [instance_id]
            },
        ]
    )
    return response['InstanceInformationList'][0]['PlatformName'], response['InstanceInformationList'][0]['PlatformVersion']


def get_instance_tags(instance):
    return {tag["Key"].lower(): tag["Value"].lower() for tag in instance.tags}

def get_instance_tags1(instance):
    return {tag["Key"]: tag["Value"] for tag in instance.tags}

def is_sql_server(instance_tags):
    environment_tag = instance_tags.get("ccs_sql")
    return environment_tag in ["yes"]


def create_cpu_alarm(instance, instance_name, threshold, duration=5, periods=5):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% CPU Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        MetricName='CPUUtilization',
        Namespace='AWS/EC2',
        Period=int(periods * 60),
        Statistic='Average',
        Threshold=threshold,
        AlarmDescription='The percentage of allocated EC2 compute units that are currently in use on the instance. This metric identifies the processing power required to run an application upon a selected instance. Depending on the instance type, tools in your operating system can show a lower percentage than CloudWatch when the instance is not allocated a full processor core.',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=[
            {
                'Name': 'InstanceId',
                'Value': instance.id
            }
        ],
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"created cpu metric: {response}")


def create_memory_alarm(instance_name, threshold, dimensions, duration=5, periods=5, metric_name='MemoryUsed', namespace='CWAgent'):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% Memory Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        MetricName=metric_name,
        Namespace=namespace,
        Period=int(periods * 60),
        Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% Memory Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=dimensions,
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"created memory metric: {response}")


def create_swap_alarm(instance_name, threshold, dimensions, duration=5, periods=5, metric_name='SwapUsed', namespace='CWAgent'):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Over {threshold}% SWAP Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        MetricName=metric_name,
        Namespace=namespace,
        Period=int(periods * 60),
        Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% SWAP Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=dimensions,
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create swap metric: {response}")


def create_disk_alarm_windows(instance_name, disk, threshold, dimensions, duration=5, periods=5, metric_name="DiskFree", namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: Drive {disk}: EC2:Over {100-threshold}% Disk Utilization detected over a period of {duration} minutes',
        ComparisonOperator='LessThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        Namespace=namespace,
        MetricName=metric_name,
        Period=int(periods * 60),
        Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {100-threshold}% Disk Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=dimensions,
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create disk metric: {response}")

def create_disk_alarm_linux(instance_name, disk, threshold, dimensions, duration=5, periods=5, metric_name="disk_used_percent", namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: Mount {disk}: EC2:Over {threshold}% Disk Utilization detected over a period of {duration} minutes',
        ComparisonOperator='GreaterThanOrEqualToThreshold',
        EvaluationPeriods=int(int(duration) / int(periods)),
        Namespace=namespace,
        MetricName=metric_name,
        Period=int(periods * 60),
        Statistic='Average',
        Threshold=threshold,
        AlarmDescription=f'Over {threshold}% Disk Utilization detected over a period of {duration} minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=dimensions,
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create disk metric: {response}")


def create_system_uptime_alarm(instance, instance_name,dimensions,Namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:System Uptime is less than 600 seconds',
        ComparisonOperator='LessThanThreshold',
        EvaluationPeriods=1,
        MetricName='System System Up Time',
        Namespace=Namespace,
        Period=300,
        Statistic='Average',
        Threshold=600,
        AlarmDescription='System Uptime for instance is less than 600 seconds',
        AlarmActions=[sns_topic_arn],
        # OKActions=[sns_topic_arn],
        Dimensions=dimensions,
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create system uptime metric: {response}")

def create_linux_uptime_alarm(instance, instance_name,metric_name,Namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:System Uptime is less than 600 seconds',
        ComparisonOperator='LessThanThreshold',
        EvaluationPeriods=1,
        MetricName=metric_name,
        Namespace=Namespace,
        Period=300,
        Statistic='Average',
        Threshold=600,
        AlarmDescription='System Uptime for instance is less than 600 seconds',
        AlarmActions=[sns_topic_arn],
        Dimensions=[
            {
                'Name': 'InstanceId',
                'Value': instance.id
            }
        ],
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create Linux uptime metric: {response}")

def create_ssh_service_down_alarm(instance, instance_name,metric_name,Namespace="CWAgent"):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:SSH service is Down',
        ComparisonOperator='LessThanThreshold',
        EvaluationPeriods=1,
        MetricName=metric_name,
        Namespace=Namespace,
        Period=300,
        Statistic='Average',
        Threshold=1,
        AlarmDescription='SSH service is not running.',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=[
            {
                'Name': 'InstanceId',
                'Value': instance.id
            }
        ],
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create ssh service down alarm: {response}")


def create_status_check_alarm(instance, instance_name):
    response = cloudwatch.put_metric_alarm(
        AlarmName=f'{instance_name}: EC2:Status Check Fail detected',
        ComparisonOperator='GreaterThanThreshold',
        EvaluationPeriods=1,
        MetricName='StatusCheckFailed',
        Namespace='AWS/EC2',
        Period=300,
        Statistic='Sum',
        Threshold=1,
        AlarmDescription='Reports whether the instance has passed both the instance status check and the system status check in the last 5 minutes',
        AlarmActions=[sns_topic_arn],
        OKActions=[sns_topic_arn],
        Dimensions=[
            {
                'Name': 'InstanceId',
                'Value': instance.id
            }
        ],
        Tags=[
            {
                'Key': ssm_managed_tag_name,
                'Value': ssm_managed_tag_value
            },
        ]
    )
    print(f"create status check metric: {response}")

def is_aras_configuration(instance_id):
    ec2_client = boto3.client("ec2")
    response = ec2_client.describe_tags(
        Filters=[
            {"Name": "resource-id", "Values": [instance_id]},
            {"Name": "key", "Values": ["ccs_cloudwatch_config"]},
        ]
    )
    print(response)
    if len(response["Tags"]) > 0 and response["Tags"][0]["Value"] in ["Aras-Cloudwatch"]:
        return True
    else:
        return False

    return False
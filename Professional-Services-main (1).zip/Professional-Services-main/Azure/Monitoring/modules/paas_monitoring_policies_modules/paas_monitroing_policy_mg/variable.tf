variable "name" {
  description = "The name of the policy definition. Changing this forces a new resource to be created."
  type        = string
}

variable "display_name" {
  description = "The display name of the policy definition."
  type        = string
}

variable "policy_type" {
  description = "The policy type. Possible values are BuiltIn, Custom, NotSpecified and Static. Changing this forces a new resource to be created."
  type        = string
  default     = "Custom"
}

variable "mode" {
  description = "The policy resource manager mode that allows you to specify which resource types will be evaluated."
  type        = string
  default     = "Indexed"
}

variable "description" {
  description = "The description of the policy definition."
  type        = string
}

variable "policy_rule_filename" {
  description = "The filename of the policy rule JSON file."
  type        = string
}

variable "policy_parameters_filename" {
  description = "The filename of the policy parameters JSON file."
  type        = string
}

variable "management_group_id" {
  description = "The management group ID where the policy assignment will be created."
  type        = string
}

variable "user_assigned_identity_ids" {
  description = "List of User Assigned Identity IDs to be used for the policy assignment."
  type        = list(string)
}

variable "location" {
  description = "The Azure region where the policy assignment will be created."
  type        = string
}

variable "policy_assignment_parameters" {
  description = "The parameters for the policy assignment."
  type        = string
  default     = ""
}
variable "policy_rule" {
  description = "The policy rule as a JSON object. If provided, this will override the policy_rule_filename."
  type        = string
  default     = ""
}
# variable "subscription_ids" {
#   description = "List of subscription IDs to deploy the policy to"
#   type        = list(string)
# }

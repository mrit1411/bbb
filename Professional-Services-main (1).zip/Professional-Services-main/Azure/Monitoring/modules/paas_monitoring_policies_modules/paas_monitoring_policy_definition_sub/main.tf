resource "azurerm_policy_definition" "policy_definition" {
  name                = lower(var.name)
  display_name        = var.display_name
  policy_type         = var.policy_type
  mode                = var.mode
  description         = var.description
  policy_rule  = var.policy_rule_filename
  parameters  = file("./${path.module}/${var.policy_parameters_filename}")

}
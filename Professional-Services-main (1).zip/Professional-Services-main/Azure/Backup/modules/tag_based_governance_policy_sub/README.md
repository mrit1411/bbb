﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_subscription_policy_assignment.policy_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subscription_policy_assignment) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | Azure region where resources are deployed | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The name of the policy definition. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_policy_assignment_parameters"></a> [policy\_assignment\_parameters](#input\_policy\_assignment\_parameters) | The parameters for the policy assignment. | `string` | `""` | no |
| <a name="input_policy_definition_id"></a> [policy\_definition\_id](#input\_policy\_definition\_id) | The ID of the policy definition to assign. | `string` | n/a | yes |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | Subscription ID where to define and assign the policy | `string` | n/a | yes |
| <a name="input_user_assigned_identity_ids"></a> [user\_assigned\_identity\_ids](#input\_user\_assigned\_identity\_ids) | List of user assigned managed identites for policy assignment | `list(string)` | n/a | yes |

## Outputs

No outputs.

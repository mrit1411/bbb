variable "name" {
  description = "The name of the topic. Topic names must be made up of only uppercase and lowercase ASCII letters, numbers, underscores, and hyphens, and must be between 1 and 256 characters long. For a FIFO (first-in-first-out) topic, the name must end with the .fifo suffix."
  type        = string
}

variable "region" {
  description = "The AWS region where the SNS topic will be created."
  type        = string
  default     = "us-east-1"
}
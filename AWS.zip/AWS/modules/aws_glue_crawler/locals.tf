locals {
  name = "CCS-Glue-Crawler-${var.client_name}"
}
# terraform with s3 backend and s3 state lock
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.3.0"
    }
  }
  backend "s3" {
    bucket       = "ccs-draeger-transition-terraform-state-prod"
    key          = "terraform.tfstate"
    region       = "eu-central-1"
    use_lockfile = true
  }
}

provider "aws" {
  # Configuration options
  region = "eu-central-1"

  default_tags {
    tags = {
      ccs_owned = "yes"
    }
  }
}
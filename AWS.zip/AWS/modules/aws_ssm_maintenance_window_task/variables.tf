variable "window_id" {
  description = "The Id of the maintenance window to register the task with."
  type        = string
}

variable "max_concurrency" {
  description = "The maximum number of targets this task can be run for in parallel."
  type        = string
}

variable "max_errors" {
  description = "The maximum number of errors allowed before this task stops being scheduled."
  type        = string
}

variable "task_type" {
  description = "The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN_COMMAND or STEP_FUNCTIONS."
  type        = string
  default     = "RUN_COMMAND"

  validation {
    condition     = contains(["AUTOMATION", "LAMBDA", "RUN_COMMAND", "STEP_FUNCTIONS"], var.task_type)
    error_message = "task_type must be one of: AUTOMATION, LAMBDA, RUN_COMMAND, STEP_FUNCTIONS."
  }
}

variable "task_arn" {
  description = "The ARN of the task to execute."
  type        = string
}

variable "name" {
  description = "The name of the maintenance window task."
  type        = string
}

variable "description" {
  description = "The description of the maintenance window task."
  type        = string
  default     = ""
}

variable "priority" {
  description = "The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel."
  type        = number
}

variable "task_invocation_service_role_arn" {
  description = "The Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) service role to use to publish Amazon Simple Notification Service (Amazon SNS) notifications for maintenance window Run Command tasks."
  type        = string
}

variable "notification_arn" {
  description = "An Amazon Resource Name (ARN) for a Simple Notification Service (SNS) topic. Run Command pushes notifications about command status changes to this topic."
  type        = string
}

variable "notification_events" {
  description = "The different events for which you can receive notifications. Valid values: All, InProgress, Success, TimedOut, Cancelled, and Failed"
  type        = list(string)

  validation {
    condition     = alltrue([for event in var.notification_events : contains(["All", "InProgress", "Success", "TimedOut", "Cancelled", "Failed"], event)])
    error_message = "notification_events must be one or more of: All, InProgress, Success, TimedOut, Cancelled, Failed."
  }
}

variable "notification_type" {
  description = "When specified with Command, receive notification when the status of a command changes. When specified with Invocation, for commands sent to multiple instances, receive notification on a per-instance basis when the status of a command changes. Valid values: Command and Invocation"
  type        = string

  validation {
    condition     = contains(["Command", "Invocation"], var.notification_type)
    error_message = "notification_type must be one of: Command, Invocation."
  }
}

variable "parameter_name" {
  description = "The name of the parameter for the task."
  type        = string
}

variable "parameter_values" {
  description = "The values of the parameter for the task."
  type        = list(string)
}

variable "target_key" {
  description = "The key for the target."
  type        = string
  default     = "WindowTargetIds"
}

variable "target_values" {
  description = "The values for the target."
  type        = list(string)
}
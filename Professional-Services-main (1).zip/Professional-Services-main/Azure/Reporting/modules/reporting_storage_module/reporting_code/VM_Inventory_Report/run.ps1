param($Timer)
 
Import-Module Az.Accounts
Import-Module Az.Compute
 
$dataResults = "VmName,VmStatus,Location,OsType,Vmsize,Deployed CPU_Core,Deployed RAM(in GB),SubscriptionName,ResourceGroupName,Availability_Zone,ccs_managed,Environment,ServiceName,ServiceOwner,AccountingUnit,LaunchDate,tags"
 
# Get all subscriptions
$subscriptions = Get-AzSubscription
 
foreach ($sub in $subscriptions) {
    $subscriptionName = $subscription.Name
    Set-AzContext -SubscriptionId $sub.Id
 
    $vms = Get-AzVM | Where-Object { if ($_.Tags) { $_.Tags.ContainsKey("ccs_managed")}}
 
    foreach ($vm in $vms) {
         if ($vm.Tags.ContainsKey("ccs_managed") -and $vm.Tags["ccs_managed"] -eq "yes") {
            $vm_name = $vm.Name
            $vm_location = $vm.Location
            $vm_status = (Get-AzVM -Name $vm_name -ResourceGroupName $vm.ResourceGroupName -Status).PowerState
            $vm_os = $vm.StorageProfile.OsDisk.OsType
            $vm_size = $vm.HardwareProfile.VmSize
            $vm_size_info = Get-AzVMSize -Location $vm.Location | Where-Object { $_.Name -eq $vm_size }
            $vm_cpu = $vm_size_info.NumberOfCores
            $vm_mem_GB = $vm_size_info.MemoryInMB / 1024
            $vm_rg = $vm.ResourceGroupName
            $av_zone = if ($vm.Zones -ne $null) { "Zone " + ($vm.Zones -join ',') } else { $null }
 
            $ccs_managed = $vm.Tags["ccs_managed"]
            $Environment = $vm.Tags["Environment"]
            $ServiceName = $vm.Tags["ServiceName"]
            $SystemOwnerName = $vm.Tags["ServiceOwner"]
            $AccountingUnit = $vm.Tags["AccountingUnit"]
            $LaunchDate = $vm.Tags.Keys | Where-Object { $_.ToLower() -match 'launchdate' } | ForEach-Object { $vm.Tags[$_] }
            $tags = ($vm.Tags.GetEnumerator() | ForEach-Object { "$($_.Key) : $($_.Value)" }) -join ','
 
            $dataResults += "`n" + "$vm_name,$vm_status,$vm_location,$vm_os,$vm_size,$vm_cpu,$vm_mem_GB,$subscriptionName,$vm_rg,$av_zone,$ccs_managed,$Environment,$ServiceName,$SystemOwnerName,$AccountingUnit,$LaunchDate,$tags"
        }
    }
}


 
Push-OutputBinding -Name outputBlob -Value ($dataResults -join "`n")
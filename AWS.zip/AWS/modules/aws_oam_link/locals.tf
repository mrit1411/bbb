locals {
  oam_link_label_template = "ccs-${data.aws_caller_identity.current.account_id}-${data.aws_region.current.region}-oam-link"
}
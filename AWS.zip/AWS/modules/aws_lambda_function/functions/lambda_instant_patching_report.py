from __future__ import print_function
import json
import boto3
import os

PatchingInstantReportTopicName = os.environ.get('SNS_TOPIC_ARN')
log_level = int(os.environ.get('log_level'))

def list_compliance_items(instanceid):
    client = boto3.client('ssm')
    response = client.list_compliance_items(
        Filters=[
            {
                'Key': 'Status',
                'Values': [
                    'N',
                ],
                'Type': 'BEGIN_WITH'
            },
        ],
        ResourceIds=[
            instanceid
        ],
        ResourceTypes=[
            'ManagedInstance'
        ],
    )
    return response

def publish_issue(instanceid, accountId, message):
    client = boto3.client('sns')
    region = os.environ['AWS_REGION']
    subject = f"Patching account: {accountId}, region: {region} non compliant instanceId: {instanceid}"
    if log_level > 1:
        print(subject)
    response = client.publish(
        TopicArn=PatchingInstantReportTopicName,
        Message=message,
        Subject=subject
    )
    return response

def lambda_handler(event, context):
    accountId = context.invoked_function_arn.split(":")[4]
    message = event['Records'][0]['Sns']['Message']
    instanceInfo = json.loads(message)
    instanceid = instanceInfo['instanceId']
    if log_level > 0:
        print("Instance Id: " + instanceid)
    resp_list = list_compliance_items(instanceid)

    for key, val in resp_list.items():
        if key == "ComplianceItems":
            if len(val) == 0:
                if log_level > 0:
                    print("instance compliant - do not create ticket")
                # message += "instance compliant"
                # publish_report(instanceid, message)
                return len(val)
            message = "Non compliant instance found: " + instanceid
            message = f"Non compliant items: {len(val)}"
            # message += "; Non compliant patch list:"
            for compl_items in val:
            #    #message += ("\n")
                for key, val in compl_items.items():
            #        if key == "Details" or key == "ExecutionSummary":
            #            message += f"; {key}: {val}"
            #        else:
                    if key=="Title":
                        message += f"; {key}: {val}"
                    elif key=="Severity":
                        message += f"; {key}: {val}"

    if log_level > 2:
        print(message)
    publish_issue(instanceid, accountId, message)

    return message

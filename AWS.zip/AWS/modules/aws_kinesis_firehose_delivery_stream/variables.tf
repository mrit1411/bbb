variable "name" {
  description = " A name to identify the stream. This is unique to the AWS account and region the Stream is created in. When using for WAF logging, name must be prefixed with aws-waf-logs-."
  type        = string
}

variable "destination" {
  description = "This is the destination to where the data is delivered. The only options are extended_s3, redshift, elasticsearch, splunk, http_endpoint, opensearch, opensearchserverless and snowflake."
  type        = string
}

variable "bucket_arn" {
  description = "The ARN of the S3 bucket"
  type        = string
}

variable "prefix" {
  description = "The \"YYYY/MM/DD/HH\" time format prefix is automatically used for delivered S3 files. You can specify an extra prefix to be added in front of the time format prefix. Note that if the prefix ends with a slash, it appears as a folder in the S3 bucket"
  type        = string
}

variable "buffering_interval" {
  description = "Buffer incoming data for the specified period of time, in seconds, before delivering it to the destination."
  type        = number
  default     = 300
}

variable "buffering_size" {
  description = "Buffer incoming data to the specified size, in MBs, before delivering it to the destination. We recommend setting SizeInMBs to a value greater than the amount of data you typically ingest into the delivery stream in 10 seconds. For example, if you typically ingest data at 1 MB/sec set SizeInMBs to be 10 MB or higher."
  type        = number
  default     = 5
}

variable "cloudwatch_logging_enabled" {
  description = "Enables or disables the logging"
  type        = bool
}

variable "log_group_name" {
  description = "The CloudWatch group name for logging."
  type        = string
}

variable "log_stream_name" {
  description = "The CloudWatch log stream name for logging."
  type        = string
}

variable "processing_enabled" {
  description = "Enables or disables data processing."
  type        = bool
}

variable "processor_type" {
  description = "The type of processor. Valid Values: RecordDeAggregation, Lambda, MetadataExtraction, AppendDelimiterToRecord, Decompression, CloudWatchLogProcessing. Validation is done against AWS SDK constants; so values not explicitly listed may also work."
  type        = string
}

variable "processing_parameter_name" {
  description = "Parameter name. Valid Values: LambdaArn, NumberOfRetries, MetadataExtractionQuery, JsonParsingEngine, RoleArn, BufferSizeInMBs, BufferIntervalInSeconds, SubRecordType, Delimiter, CompressionFormat, DataMessageExtraction. Validation is done against AWS SDK constants; so values not explicitly listed may also work."
  type        = string
}

variable "processing_parameter_value" {
  description = "Parameter value. Must be between 1 and 512 length (inclusive). When providing a Lambda ARN, you should specify the resource version as well."
  type        = string
}

variable "compression_format" {
  description = "The compression format. If no value is specified, the default is UNCOMPRESSED. Other supported values are GZIP, ZIP, Snappy, & HADOOP_SNAPPY."
  type        = string
}

variable "role_arn" {
  description = "The ARN of the AWS credentials."
  type        = string
}
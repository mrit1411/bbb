data "azurerm_client_config" "current" {}

# data "azurerm_log_analytics_workspace" "existing_log_analytics_workspace" {
#   count               = var.create_cos_log_analytics_workspace ? 0 : 1
#   name                = var.existing_log_analytics_workspace_name
#   resource_group_name = var.existing_law_resource_group_name
# }


module "cos_azure_data_collection_rule" {
  source                                   = "./modules/data_collection_rule"
  context                                  = var.context
  index                                    = var.index
  environment                              = var.environment
  org                                      = var.org
  resource_group_name                      = var.resource_group_name
  location                                 = var.location
  description                              = "Data Collection Rule for CCS Azure Monitoring"
  destination_log_analytics_workspace_name = "tfm-p-weu-01-org-law"
  workspace_resource_id                    = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/rg-prd-eaf-euw/providers/Microsoft.OperationalInsights/workspaces/tfm-p-weu-01-org-law/"
  #workspace_resource_id                    = "/subscriptions/e3b11d6f-2daa-4dbd-8bf0-484120845219/resourceGroups/RG-PRD-EAF-EUW/providers/Microsoft.OperationalInsights/workspaces/tfm-p-weu-01-org-law/"
  tags                                     = var.tags
}

module "splunk_integration_storage" {
  source                        = "./modules/splunk_integration_storage_module"
  resource_group_name           = var.resource_group_name
  location                      = var.location
  storage_encryption_scope_name = "${module.splunk_integration_storage.account_name}encryptionscope"
  storage_container_name        = "${module.splunk_integration_storage.account_name}-container"
  blob_name                     = "${var.splunk_integration_function_zip_name}.zip"
  file_source                   = var.splunk_integration_function_zip_path
  tags                          = var.tags
  environment                   = var.environment
  context                       = "splunk"
  org                           = var.org
}

module "splunk_integration_function_app" {
  source                             = "./modules/splunk_integration_function_app"
  resource_group_name                = var.resource_group_name
  location                           = var.location
  storage_account_name               = module.splunk_integration_storage.account_name
  storage_account_access_key         = module.splunk_integration_storage.primary_access_key
  key_vault_name                     = module.splunk_integration_key_vault.name
  tags                               = var.tags
  blob_url                           = module.splunk_integration_storage.blob_url
  user_assigned_identity_ids         = var.splunk_integration_user_assigned_identity_ids
  user_assigned_identity_resource_id = var.splunk_integration_package_mi_resource_id
  environment                        = var.environment
  org                                = var.org
  context                            = "splunk"
  depends_on                         = [module.splunk_integration_storage, module.splunk_integration_key_vault]
}

data "azurerm_function_app_host_keys" "splunk_integration_function_app" {
  name                = module.splunk_integration_function_app.name
  resource_group_name = var.resource_group_name
  depends_on          = [module.splunk_integration_function_app]
}

module "splunk_integration_key_vault" {
  source              = "./modules/splunk_integration_key_vault"
  network_acl_bypass  = "AzureServices"
  resource_group_name = var.resource_group_name
  location            = var.location
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = data.azurerm_client_config.current.object_id #var.func_sami_object_id
  vm_mi_object_id                               = var.terraform_vm_mi_object_id
  splunk_integration_prod_client_id_secret_name      = var.splunk_integration_prod_client_id_secret_name
  splunk_integration_prod_client_id_secret_value     = var.splunk_integration_prod_client_id_secret_value
  splunk_integration_prod_client_secret_secret_name  = var.splunk_integration_prod_client_secret_secret_name
  splunk_integration_prod_client_secret_secret_value = var.splunk_integration_prod_client_secret_secret_value
  splunk_integration_test_client_id_secret_name      = var.splunk_integration_test_client_id_secret_name
  splunk_integration_test_client_id_secret_value     = var.splunk_integration_test_client_id_secret_value
  splunk_integration_test_client_secret_secret_name  = var.splunk_integration_test_client_secret_secret_name
  splunk_integration_test_client_secret_secret_value = var.splunk_integration_test_client_secret_secret_value
  tags                                               = var.tags
  environment                                        = var.environment
  org                                                = var.org
  context                                            = "splnkapts"
}



module "cos_iaas_azure_log_analytics_workspace" {
  count  = var.create_cos_log_analytics_workspace ? 1 : 0
  source = "./modules/log_analytics_workspace"
  providers = {
    azurerm = azurerm.security
  }
  project-shortname   = var.project-shortname
  index               = var.index
  environment         = var.environment
  org                 = var.org
  location            = var.location
  resource_group_name = var.iaas_law_rg_name
  sku                 = var.log_analytics_workspace_sku
  retention_in_days   = var.log_analytics_workspace_retention_in_days
  tags                = var.tags
}

module "cos_paas_azure_log_analytics_workspace" {
  count               = var.create_cos_log_analytics_workspace ? 1 : 0
  source              = "./modules/log_analytics_workspace"
  project-shortname   = "paas-tfm"
  index               = var.index
  environment         = var.environment
  org                 = var.org
  location            = var.location
  resource_group_name = var.iaas_law_rg_name
  sku                 = var.log_analytics_workspace_sku
  retention_in_days   = var.log_analytics_workspace_retention_in_days
  tags                = var.tags
}

# module "paas_diagnostic_settings" {
#   source = "./modules/diagnostic_settings"

#   # Path to the CSV file containing diagnostic settings
#   diagnostic_settings_csv_path = "./modules/diagnostic_settings/diagnostic_settings.csv"

#   # Diagnostic settings name
#   diagnostic_settings_Name = "rsv-diagnostic"

#   # Log Analytics Workspace ID
#   log_analytics_workspace_id = local.cos_azure_log_analytics_workspace_id
# }

module "prod_action_group" {
  source = "./modules/splunk_integration_action_group"
  providers = {
    azurerm = azurerm.security
  }
  resource_group_name          = var.iaas_law_rg_name
  short_name                   = var.prod_action_group_short_name
  azure_function_receiver_name = var.azure_prod_function_receiver_name
  function_app_resource_id     = module.splunk_integration_function_app.function_app_id
  function_name                = var.prod_splunk_integration_function_name
  function_default_host_key    = data.azurerm_function_app_host_keys.splunk_integration_function_app.default_function_key
  function_app_name            = module.splunk_integration_function_app.name
  tags                         = var.tags
  org                          = var.org
  context                      = "splunk"
  environment                  = "Prod"
  # depends_on                   = [module.splunk_integration_function_app]
}

module "test_action_group" {
  source = "./modules/splunk_integration_action_group"
  providers = {
    azurerm = azurerm.security
  }
  resource_group_name          = var.iaas_law_rg_name
  short_name                   = "${var.test_action_group_short_name}"
  azure_function_receiver_name = var.azure_test_function_receiver_name
  function_app_resource_id     = module.splunk_integration_function_app.function_app_id
  function_name                = var.test_splunk_integration_function_name
  function_default_host_key    = data.azurerm_function_app_host_keys.splunk_integration_function_app.default_function_key
  function_app_name            = module.splunk_integration_function_app.name
  tags                         = var.tags
  org                          = var.org
  context                      = "splunk"
  environment                  = "Test"
  # depends_on                   = [module.splunk_integration_function_app]
}

# module "event_hub" {
#   source              = "./modules/splunk_integration_eventhub"
#   resource_group_name = var.resource_group_name
#   index               = var.index
#   environment         = var.environment
#   org                 = var.org
#   context             = var.context
#   location            = var.location
#   tags                = var.tags
# }

# module "action_group_event_hub" {
#   source = "./modules/splunk_integration_action_group_eventhub"
#   resource_group_name = var.resource_group_name
#   index               = var.index
#   environment         = var.environment
#   org                 = var.org
#   context             = var.context
#   event_hub_namespace = module.event_hub.eventhub_namespace_name
#   event_hub_name      = module.event_hub.eventhub_name
#   short_name          = var.action_group_short_name
#   event_hub_receiver_name = "acteventhubreceiver"
#   tags                = var.tags
# }

# # ####Alerts for monitoring of MS SQL Database Monitoring

# module "mssql_database_alert_rules" {
#   source = "./modules/alert_rule"
#   for_each = local.mssql_database_alert_rules_map

#   name                    = each.value.name
#   resource_group_name     = var.iaas_law_rg_name
#   location                = var.location
#   scopes                  = [module.cos_iaas_azure_log_analytics_workspace[0].workspace_id]
#   severity                = each.value.severity
#   evaluation_frequency    = each.value.evaluation_frequency
#   window_duration         = each.value.window_duration
#   operator                = each.value.operator
#   dimensions         = each.value.dimensions
#   threshold               = each.value.threshold
#   resource_id_column      = each.value.resource_id_column
#   time_aggregation_method = each.value.time_aggregation_method
#   description             = each.value.description
#   metric_measure_column   = each.value.metric_measure_column
#   query                   = each.value.query
#   action_group_id         = [module.action_group.action_group_id]
#   depends_on = [ module.action_group,module.cos_iaas_azure_log_analytics_workspace ]
# }

#### IAAS Alerts

module "iaas_alert_rule_disk_free_space" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "Org - CCS - All Disks Free space_CRITICAL"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "LessThan"
  dimension_name          = "Disk"
  auto_mitigation_enabled         = true
  threshold               = 10
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Average"
  description             = "All Disks Free space less than 10%"
  metric_measure_column   = "AggregatedValue"
  query                   = <<-QUERY
InsightsMetrics
| where Origin == "vm.azm.ms"
| where Namespace == "LogicalDisk" and Name == "FreeSpacePercentage"
| extend Disk=tostring(todynamic(Tags)["vm.azm.ms/mountId"])
| summarize AggregatedValue = avg(Val) by bin(TimeGenerated, 5m), Computer, _ResourceId, Disk
QUERY
  action_group_id         = [module.action_group.action_group_id]
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]
}

module "iaas_alert_rule_memory_usage" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                         = "Org - CCS - Used Memory in Percentage_CRITICAL (Memory Usage)"
  resource_group_name          = var.iaas_law_rg_name
  location                     = var.location
  
  scopes                       = [local.cos_azure_log_analytics_workspace_id]
  severity                     = 3
  evaluation_frequency         = "PT5M"
  window_duration              = "PT5M"
  operator                     = "GreaterThan"
  dimension_name               = "Computer"
  auto_mitigation_enabled         = true
  threshold                    = 95
  resource_id_column           = "_ResourceId"
  time_aggregation_method      = "Average"
  description                  = "Available Memory in percentage less than 95%"
  metric_measure_column        = "AggregatedValue"
  query                        = <<-QUERY
InsightsMetrics 
| where Origin == "vm.azm.ms" 
| where Namespace == "Memory" and Name == "AvailableMB" 
| extend TotalMemory = toreal(todynamic(Tags)["vm.azm.ms/memorySizeMB"])
| extend AvailableMemoryPercentage = (toreal(Val) / TotalMemory) * 100.0 
| summarize AggregatedValue = avg(AvailableMemoryPercentage) by bin(TimeGenerated, 5m), Computer, _ResourceId 
QUERY
  minimum_failing_periods      = 6
  number_of_evaluation_periods = 6
  action_group_id              = [module.action_group.action_group_id]
  
  depends_on                   = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_cpu_usage" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                         = "Org - CCS - CPU usage in percentage_CRITICAL"
  resource_group_name          = var.iaas_law_rg_name
  location                     = var.location
  
  scopes                       = [local.cos_azure_log_analytics_workspace_id]
  severity                     = 3
  evaluation_frequency         = "PT5M"
  window_duration              = "PT5M"
  operator                     = "GreaterThan"
  dimension_name               = "Computer"
  auto_mitigation_enabled         = true
  threshold                    = 95
  resource_id_column           = "_ResourceId"
  time_aggregation_method      = "Average"
  description                  = "CPU utilization greater than 95%"
  metric_measure_column        = "AggregatedValue"
  query                        = <<-QUERY
InsightsMetrics
| where Origin == "vm.azm.ms" 
| where Namespace == "Processor" and Name == "UtilizationPercentage" 
| summarize AggregatedValue = avg(Val) by bin(TimeGenerated, 15m), Computer, _ResourceId
QUERY
  minimum_failing_periods      = 6
  number_of_evaluation_periods = 6
  action_group_id              = [module.action_group.action_group_id]
  
  depends_on                   = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_heartbeat" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "Org - CCS - Heartbeat"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT10M"
  dimension_name          = "Computer"
  operator                = "GreaterThan"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "VM not responding"
  query                   = <<-QUERY
Heartbeat 
| where TimeGenerated > ago(10m)
| summarize LastCall = max(TimeGenerated) by Computer, _ResourceId
| where LastCall < ago(5m)
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_syslog_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Syslog service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  dimension_name          = "Computer"
  operator                = "GreaterThan"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Syslog service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "Daemons" and SvcName contains "rsyslog" and SvcState == "Running" 
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_ssh_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - SSH service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "GreaterThan"
  dimension_name          = "Computer"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "SSH service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "Daemons" and SvcName contains "ssh" and SvcState != "Running" 
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_dependency_agent_service_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Microsoft Dependency Agent service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "GreaterThan"
  dimension_name          = "Computer"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Microsoft Dependency Agent service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "WindowsServices" and SvcDisplayName == "Microsoft Dependency Agent " and SvcState == "Stopped"
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_remote_service_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Windows Remote Management WS - Management service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "GreaterThan"
  dimension_name          = "Computer"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Windows Remote Management WS-Management service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "WindowsServices" and SvcDisplayName == "Windows Remote Management (WS-Management)" and SvcState == "Stopped"
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_guest_service_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Windows Azure Guest service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "GreaterThan"
  dimension_name          = "Computer"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Windows Azure Guest service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "WindowsServices" and SvcDisplayName == "Windows Azure Guest Agent" and SvcState == "Stopped"
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_ama_heartbeat_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Azure Monitoring Agent Azure VM Extension Heartbeat Service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  dimension_name          = "Computer"
  operator                = "GreaterThan"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Microsoft Monitoring Agent Azure VM Extension Heartbeat Service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "WindowsServices" and SvcDisplayName == "Microsoft Monitoring Agent Azure VM Extension Heartbeat Service" and SvcState == "Stopped"
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_ama_service_stopped" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Azure Monitoring Agent service stopped"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  operator                = "GreaterThan"
  dimension_name          = "Computer"
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Count"
  description             = "Microsoft Monitoring Agent service stopped"
  query                   = <<-QUERY
ConfigurationChange 
| where ConfigChangeType == "WindowsServices" and SvcDisplayName == "Microsoft Monitoring Agent " and SvcState == "Stopped"
QUERY
  action_group_id         = [module.action_group.action_group_id]
  
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]

}

module "iaas_alert_rule_backup_failed" {
  source = "./modules/alert_rule"
  providers = {
    azurerm = azurerm.security
  }
  name                    = "CCS - Recovery Service Vault - Failed Backup"
  resource_group_name     = var.iaas_law_rg_name
  location                = var.location
  scopes                  = [local.cos_azure_log_analytics_workspace_id]
  severity                = 3
  evaluation_frequency    = "PT15M"
  window_duration         = "PT15M"
  operator                = "GreaterThan"
  dimension_name          = "BackupItemUniqueId"  
  threshold               = 0
  resource_id_column      = "_ResourceId"
  time_aggregation_method = "Minimum"
  metric_measure_column   = "AggregatedValue"
  description             = "VM Backup Job Failed"
  query                   = <<-QUERY
AddonAzureBackupJobs
| where JobOperation=="Backup"
| summarize arg_max(TimeGenerated,*) by JobUniqueId
| where JobStatus=="Failed"
| summarize AggregatedValue = count() by BackupItemUniqueId, bin(TimeGenerated, 10m),  JobFailureCode, BackupManagementType, ProtectedContainerUniqueId,_ResourceId
QUERY
  action_group_id         = [module.action_group.action_group_id]
  depends_on              = [module.action_group, module.cos_iaas_azure_log_analytics_workspace]
}

module "paas_alert_rules" {
  source = "./modules/paas_alert_rules"
  providers = {
    azurerm = azurerm.security
  }

  for_each = var.paas_alerts_map

  name                         = each.value.name
  resource_group_name          = var.iaas_law_rg_name
  location                     = var.location
  operator                     = each.value.operator
  threshold                    = each.value.threshold
  time_aggregation_method      = each.value.time_aggregation_method
  metric_measure_column        = "Result"
  resource_id_column           = "_ResourceId"
  query                        = each.value.query
  minimum_failing_periods      = try(each.value.minimum_failing_periods, 1)
  number_of_evaluation_periods = try(each.value.number_of_evaluation_periods, 1)
  scopes                       = [module.cos_paas_azure_log_analytics_workspace[0].workspace_id]
  severity                     = each.value.severity
  evaluation_frequency         = each.value.evaluation_frequency
  window_duration              = each.value.window_duration
  description                  = each.value.description
  action_group_id              = [module.prod_action_group.action_group_id]
  enabled                      = try(each.value.enabled, true)
  auto_mitigation_enabled         = each.value.auto_mitigation_enabled
  # enabled   = true # Set to false for testing purposes, change to true when ready
  namespace = "Microsoft.OperationalInsights/workspaces"
}

# module "ccs_paas_azure_service_bus_namespace_active_messages" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.ServiceBus/namespaces", v.resourceid)) && contains(v.metric_name, "ActiveMessages") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Service Bus Namespace Count of Active Messages_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Service Bus Namespace Average Active Messages is greater than 1000 over 5mins"
#   severity                = 3
#   evaluation_frequency    = "PT5M"
#   window_duration         = "PT5M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.ServiceBus/namespaces"
#   metric_name             = "ActiveMessages"
#   time_aggregation_method = "Average"
#   operator                = "GreaterThan"
#   threshold               = 1000
# }

# module "ccs_paas_azure_service_bus_namespace_deadlettered_messages" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.ServiceBus/namespaces", v.resourceid)) && contains(v.metric_name, "DeadletteredMessages") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Service Bus Namespace Count of Deadlettered Messages_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Service Bus Namespace Average Deadlettered Messages is greater than 100 over 5mins"
#   severity                = 2
#   evaluation_frequency    = "PT5M"
#   window_duration         = "PT5M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.ServiceBus/namespaces"
#   metric_name             = "DeadletteredMessages"
#   time_aggregation_method = "Average"
#   operator                = "GreaterThan"
#   threshold               = 100
# }
# module "ccs_paas_azure_service_bus_namespace_memory_usage" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.ServiceBus/namespaces", v.resourceid)) && contains(v.metric_name, "NamespaceMemoryUsage") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Service Bus Namespace Memory Usage in percentage_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Service Bus Namespace Average Memory Usage is greater than 90 percent over 15mins"
#   severity                = 2
#   evaluation_frequency    = "PT5M"
#   window_duration         = "PT15M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.ServiceBus/namespaces"
#   metric_name             = "NamespaceMemoryUsage"
#   time_aggregation_method = "Average"
#   operator                = "GreaterThan"
#   threshold               = 90
# }

# module "ccs_paas_azure_service_bus_namespace_throttled_requests" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.ServiceBus/namespaces", v.resourceid)) && contains(v.metric_name, "ThrottledRequests") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Service Bus Namespace Count of Throttled Requests_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Service Bus Namespace count of Throttled Requests is greater than 50 over 1min"
#   severity                = 3
#   evaluation_frequency    = "PT1M"
#   window_duration         = "PT1M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.ServiceBus/namespaces"
#   metric_name             = "ThrottledRequests"
#   time_aggregation_method = "Total"
#   operator                = "GreaterThan"
#   threshold               = 50
# }

# module "ccs_paas_azure_event_hub_namespace_cpu_usage" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.EventHub/namespaces", v.resourceid)) && contains(v.metric_name, "NamespaceCpuUsage") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Event Hub Namespace CPU Usage in percentage_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Event Hub Namespace Average CPU Usage is greater than 90% over 15mins"
#   severity                = 2
#   evaluation_frequency    = "PT5M"
#   window_duration         = "PT15M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.EventHub/namespaces"
#   metric_name             = "NamespaceCpuUsage"
#   time_aggregation_method = "Average"
#   operator                = "GreaterThan"
#   threshold               = 90
# }
# module "ccs_paas_azure_event_hub_namespace_memory_usage" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.EventHub/namespaces", v.resourceid)) && contains(v.metric_name, "NamespaceMemoryUsage") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Event Hub Namespace Memory Usage in percentage_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Event Hub Namespace Average Memory Usage is greater than 90% over 15mins"
#   severity                = 2
#   evaluation_frequency    = "PT5M"
#   window_duration         = "PT15M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.EventHub/namespaces"
#   metric_name             = "NamespaceMemoryUsage"
#   time_aggregation_method = "Average"
#   operator                = "GreaterThan"
#   threshold               = 90
# }
# module "ccs_paas_azure_event_hub_namespace_server_errors" {

#   source = "./modules/paas_metric_alerts"
#   providers = {
#     azurerm = azurerm.security
#   }
#   resource_group_name = var.iaas_law_rg_name
#   action_group_id     = module.action_group.action_group_id
#   for_each            = { for k, v in var.paas_metric_alert_target_resources : k => v if can(regex("Microsoft\\.EventHub/namespaces", v.resourceid)) && contains(v.metric_name, "ServerErrors") }

#   scopes                  = [each.value.resourceid]
#   name                    = "CCS - Azure Event Hub Namespace Count of Server Errors_CRITICAL-${element(split("/", each.value.resourceid), length(split("/", each.value.resourceid)) - 1)}"
#   description             = "Alert for Azure Event Hub Namespace Count of Server Errors is greater than 30 over 5mins"
#   severity                = 2
#   evaluation_frequency    = "PT1M"
#   window_duration         = "PT5M"
#   enabled                 = true
#   metric_namespace        = "Microsoft.EventHub/namespaces"
#   metric_name             = "ServerErrors"
#   time_aggregation_method = "Total"
#   operator                = "GreaterThan"
#   threshold               = 30
# }


# module "windows_dependency_agent_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSWinDAPolicy"
#   display_name               = "CCS Dependency agent for Windows virtual machines"
#   description                = "CCS Monitoring Policy to deploy Dependency agent for Windows virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_dependency_agent_policy_rule.json"
#   policy_parameters_filename = "windows_dependency_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "linux_ama_agent_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSLinAMAPolicy"
#   display_name               = "CCS Azure Monitoring Agent for Linux Virtual Machines"
#   description                = "CCS Monitoring Policy to deploy Azure Monitoring agent for Linux virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_ama_agent_policy_rule.json"
#   policy_parameters_filename = "linux_ama_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedManagedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     userAssignedManagedIdentityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "linux_dcr_association_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSLinDCRAPolicy"
#   display_name               = "CCS Linux DCR Association Policy"
#   description                = "CCS Policy to associate Linux VMs having tag ccs_managed with value yes with a Data Collection Rule (DCR)"
#   policy_rule_filename       = "linux_dcr_association_policy_rule.json"
#   policy_parameters_filename = "linux_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = module.cos_azure_data_collection_rule.dcr_resource_id
#     }
#   })
#   depends_on = [module.cos_azure_data_collection_rule]
# }

# module "linux_dependency_agent_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSLinDAPolicy"
#   display_name               = "CCS Dependency agent for Linux virtual machines"
#   description                = "CCS Monitoring Policy to deploy Dependency agent for Linux virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_dependency_agent_policy_rule.json"
#   policy_parameters_filename = "linux_dependency_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "windows_ama_agent_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSWinAMAPolicy"
#   display_name               = "CCS Azure Monitoring Agent for Windows Virtual Machines"
#   description                = "CCS Monitoring Policy to deploy Azure Monitoring agent for Windows virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_ama_agent_policy_rule.json"
#   policy_parameters_filename = "windows_ama_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedManagedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     userAssignedManagedIdentityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "windows_dcr_association_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSWinDCRAPolicy"
#   display_name               = "CCS Windows DCR Association Policy"
#   description                = "Policy to associate Windows VMs having tag ccs_managed with value yes with a Data Collection Rule (DCR)"
#   policy_rule_filename       = "windows_dcr_association_policy_rule.json"
#   policy_parameters_filename = "windows_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = module.cos_azure_data_collection_rule.dcr_resource_id
#     }
#   })
#   depends_on = [module.cos_azure_data_collection_rule]
# }

# module "assign_umi_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSAsgnUMIPolicy"
#   display_name               = "CCS Assign User Managed Identity Policy to VMs"
#   description                = "CCS Policy to assign a user managed identity to resources with ccs_managed tag and value yes"
#   policy_rule_filename       = "assign_umi_policy_rule.json"
#   policy_parameters_filename = "assign_umi_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     identityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "windows_change_tracking_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSWinCTPolicy"
#   display_name               = "CCS Change Tracking Extension for Windows"
#   description                = "CCS Policy to enable Change Tracking Extension for Windows VMs with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_change_tracking_extension_policy_rule.json"
#   policy_parameters_filename = "windows_change_tracking_extension_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "linux_change_tracking_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSLinCTPolicy"
#   display_name               = "CCS Change Tracking Extension for Linux"
#   description                = "CCS Policy to enable Change Tracking Extension for Linux VMs with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_change_tracking_extension_policy_rule.json"
#   policy_parameters_filename = "linux_change_tracking_extension_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "diagnostic_settings_rsv_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   description                = "CCS Policy to enable Diagnostic Settings for ccs_managed tagged Recovery Service Vaults"
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   name                       = "CCSRSVDS"
#   display_name               = "CCS Diagnostic Settings for Recovery Service Vaults"
#   policy_rule_filename       = "deploy_diagnostic_settings_for_rsv_policy_rule.json"
#   policy_parameters_filename = "deploy_diagnostic_settings_for_rsv_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     logAnalytics = {
#       value = module.cos_iaas_azure_log_analytics_workspace[0].workspace_id
#     }
#   })

# }

# module "windows_ct_dcr_association_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSWCTDCRAPolicy"
#   display_name               = "CCS Windows Change Tracking DCR Association Policy"
#   description                = "Policy to associate Windows VMs having tag ccs_managed with value yes with a Change Tracking Data Collection Rule (DCR)"
#   policy_rule_filename       = "windows_change_tracking_dcr_association_policy_rule.json"
#   policy_parameters_filename = "windows_change_tracking_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = var.ct_dcr_id
#     }
#   })
# }

# module "linux_ct_dcr_association_policy" {
#   for_each                   = toset(var.policy_management_group_id)
#   source                     = "./modules/tag_based_governance_policy"
#   name                       = "CCSLCTDCRAPolicy"
#   display_name               = "CCS Linux Change Tracking DCR Association Policy"
#   description                = "CCS Policy to associate Linux VMs having tag ccs_managed with value yes with a Change Tracking Data Collection Rule (DCR)"
#   policy_rule_filename       = "linux_change_tracking_dcr_association_policy_rule.json"
#   policy_parameters_filename = "linux_change_tracking_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   management_group_id        = each.value
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = var.ct_dcr_id
#     }
#   })
# }

# module "windows_dependency_agent_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSWinDAPolicy"
#   display_name               = "CCS Dependency agent for Windows virtual machines"
#   description                = "CCS Monitoring Policy to deploy Dependency agent for Windows virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_dependency_agent_policy_rule.json"
#   policy_parameters_filename = "windows_dependency_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "linux_ama_agent_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSLinAMAPolicy"
#   display_name               = "CCS Azure Monitoring Agent for Linux Virtual Machines"
#   description                = "CCS Monitoring Policy to deploy Azure Monitoring agent for Linux virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_ama_agent_policy_rule.json"
#   policy_parameters_filename = "linux_ama_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedManagedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     userAssignedManagedIdentityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "linux_dcr_association_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSLinDCRAPolicy"
#   display_name               = "CCS Linux DCR Association Policy"
#   description                = "CCS Policy to associate Linux VMs having tag ccs_managed with value yes with a Data Collection Rule (DCR)"
#   policy_rule_filename       = "linux_dcr_association_policy_rule.json"
#   policy_parameters_filename = "linux_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = module.cos_azure_data_collection_rule.dcr_resource_id
#     }
#   })
#   depends_on = [module.cos_azure_data_collection_rule]
# }

# module "linux_dependency_agent_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSLinDAPolicy"
#   display_name               = "CCS Dependency agent for Linux virtual machines"
#   description                = "CCS Monitoring Policy to deploy Dependency agent for Linux virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_dependency_agent_policy_rule.json"
#   policy_parameters_filename = "linux_dependency_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "windows_ama_agent_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSWinAMAPolicy"
#   display_name               = "CCS Azure Monitoring Agent for Windows Virtual Machines"
#   description                = "CCS Monitoring Policy to deploy Azure Monitoring agent for Windows virtual machines with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_ama_agent_policy_rule.json"
#   policy_parameters_filename = "windows_ama_agent_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedManagedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     userAssignedManagedIdentityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "windows_dcr_association_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSWinDCRAPolicy"
#   display_name               = "CCS Windows DCR Association Policy"
#   description                = "Policy to associate Windows VMs having tag ccs_managed with value yes with a Data Collection Rule (DCR)"
#   policy_rule_filename       = "windows_dcr_association_policy_rule.json"
#   policy_parameters_filename = "windows_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = module.cos_azure_data_collection_rule.dcr_resource_id
#     }
#   })
#   depends_on = [module.cos_azure_data_collection_rule]
# }

# module "assign_umi_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSAsgnUMIPolicy"
#   display_name               = "CCS Assign User Managed Identity Policy to VMs"
#   description                = "CCS Policy to assign a user managed identity to resources with ccs_managed tag and value yes"
#   policy_rule_filename       = "assign_umi_policy_rule.json"
#   policy_parameters_filename = "assign_umi_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     bringYourOwnUserAssignedManagedIdentity = {
#       value = true
#     }
#     restrictBringYourOwnUserAssignedIdentityToSubscription = {
#       value = false
#     }
#     userAssignedIdentityName = {
#       value = var.cos_ama_mi_name
#     }
#     identityResourceGroup = {
#       value = var.resource_group_name
#     }
#     userAssignedIdentityResourceId = {
#       value = var.cos_ama_mi_id
#     }
#   })
# }

# module "windows_change_tracking_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSWinCTPolicy"
#   display_name               = "CCS Change Tracking Extension for Windows"
#   description                = "CCS Policy to enable Change Tracking Extension for Windows VMs with ccs_managed tag and value yes"
#   policy_rule_filename       = "windows_change_tracking_extension_policy_rule.json"
#   policy_parameters_filename = "windows_change_tracking_extension_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "linux_change_tracking_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSLinCTPolicy"
#   display_name               = "CCS Change Tracking Extension for Linux"
#   description                = "CCS Policy to enable Change Tracking Extension for Linux VMs with ccs_managed tag and value yes"
#   policy_rule_filename       = "linux_change_tracking_extension_policy_rule.json"
#   policy_parameters_filename = "linux_change_tracking_extension_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#   })
# }

# module "diagnostic_settings_rsv_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   description                = "CCS Policy to enable Diagnostic Settings for ccs_managed tagged Recovery Service Vaults"
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   name                       = "CCSRSVDS"
#   display_name               = "CCS Diagnostic Settings for Recovery Service Vaults"
#   policy_rule_filename       = "deploy_diagnostic_settings_for_rsv_policy_rule.json"
#   policy_parameters_filename = "deploy_diagnostic_settings_for_rsv_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     logAnalytics = {
#       #value = azurerm_log_analytics_workspace.log_analytics_workspace.workspace_id
#       value = azurerm_log_analytics_workspace.log_analytics_workspace.id
#     }
#   })

# }

# module "windows_ct_dcr_association_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSWCTDCRAPolicy"
#   display_name               = "CCS Windows Change Tracking DCR Association Policy"
#   description                = "Policy to associate Windows VMs having tag ccs_managed with value yes with a Change Tracking Data Collection Rule (DCR)"
#   policy_rule_filename       = "windows_change_tracking_dcr_association_policy_rule.json"
#   policy_parameters_filename = "windows_change_tracking_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = var.ct_dcr_id
#     }
#   })
# }

# module "linux_ct_dcr_association_policy_sub" {
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "CCSLCTDCRAPolicy"
#   display_name               = "CCS Linux Change Tracking DCR Association Policy"
#   description                = "CCS Policy to associate Linux VMs having tag ccs_managed with value yes with a Change Tracking Data Collection Rule (DCR)"
#   policy_rule_filename       = "linux_change_tracking_dcr_association_policy_rule.json"
#   policy_parameters_filename = "linux_change_tracking_dcr_association_policy_parameters.json"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = var.policy_subscription_id
#   location                   = var.location
#   policy_assignment_parameters = jsonencode({
#     tagName = {
#       value = var.monitoring_tag_name
#     }
#     tagValue = {
#       value = var.monitoring_tag_value
#     }
#     dcrResourceId = {
#       value = var.ct_dcr_id
#     }
#   })
# }


##################################################################################################################################
#Below code deploys diagnostic settings policy definitions at subscription level and assigns them at subscription level

# module "singlepolicy" {
#   for_each = { for key, value in local.subscription_type_matrix : "${value.subscription_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_sub"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   display_name               = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   policy_rule_filename       = templatefile("./modules/paas_monitoring_policies_modules/paas_monitoring_policy_sub/${each.value.policy_rule_file}", { type = each.value.type })
#   policy_parameters_filename = "PaaS_DS_parameters.json"
#   user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/COS-terraform"]
#   subscription_id            = each.value.subscription_id
#   location                   = "eastus"
#   policy_assignment_parameters = jsonencode({
#     logAnalytics = {
#       value = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourcegroups/paas-diagnostic/providers/microsoft.operationalinsights/workspaces/diagnostictesting"
#     }
#     # targetresourcetypeprovider = {
#     #     value = each.value.type
#     # }
#   })
# }



# Below code deploys diagnostic settings policy definitions at management group level and assigns them at management group level

# module "paas_diagnostic_settings_policy_management_group" {
#   for_each = { for key, value in local.managementgroup_type_matrix : "${value.management_group_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_mg"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   display_name               = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   policy_rule_filename       = templatefile("./modules/paas_monitoring_policies_modules/paas_monitoring_policy_sub/${each.value.policy_rule_file}", { type = each.value.type })
#   policy_parameters_filename = "PaaS_DS_parameters.json"
#   user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/COS-terraform"]
#   management_group_id        = each.value.management_group_id
#   location                   = "eastus"
#   policy_assignment_parameters = jsonencode({
#     logAnalytics = {
#       value = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourcegroups/paas-diagnostic/providers/microsoft.operationalinsights/workspaces/diagnostictesting"
#     }
#     # targetresourcetypeprovider = {
#     #     value = each.value.type
#     # }
#   })
# }



#below code deploys diagnostic settings policy definitions at subscription level and assigns them at subscription level

# module "paas_diagnostic_settings_policy_definition_sub" {
#   for_each = { for key, value in local.subscription_type_matrix : "${value.subscription_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_definition_sub"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   display_name               = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   policy_rule_filename       = templatefile("./modules/paas_monitoring_policies_modules/paas_monitoring_policy_sub/${each.value.policy_rule_file}", { type = each.value.type })
#   policy_parameters_filename = "PaaS_DS_parameters.json"
# }
# module "paas_diagnostic_settings_policy_assignment_sub" {
#   for_each = { for key, value in local.subscription_type_matrix : "${value.subscription_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_assignment_sub"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   subscription_id            = each.value.subscription_id
#   user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/COS-terraform"]
#   location                   = "eastus"
#   policy_definition_id       = module.paas_diagnostic_settings_policy_definition_sub[each.key].id
#   policy_assignment_parameters = jsonencode({
#   logAnalytics = {
#       value = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourcegroups/paas-diagnostic/providers/microsoft.operationalinsights/workspaces/diagnostictesting"
#   }
#     # targetresourcetypeprovider = {
#     #     value = each.value.type
#     # }
#   })
# }

#below code deploys diagnostic settings policy definitions at management group level and assigns them at subscription level
# module "paas_diagnostic_settings_policy_definition_mg" {
#   for_each = { for key, value in local.managementgroup_type_matrix : "${value.management_group_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_definition_mg"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   display_name               = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   policy_rule_filename       = templatefile("./modules/paas_monitoring_policies_modules/paas_monitoring_policy_sub/${each.value.policy_rule_file}", { type = each.value.type })
#   policy_parameters_filename = "PaaS_DS_parameters.json"
#   management_group_id        = each.value.management_group_id
# }

# module "paas_diagnostic_settings_policy_assignment_sub" {
#   for_each = { for key, value in local.subscription_type_matrix : "${value.subscription_id}-${value.type}" => value }
#   source                     = "./modules/paas_monitoring_policies_modules/paas_monitoring_policy_assignment_sub"
#   name                       = "CCSdiagnosticsettings-${each.value.display_name}"
#   description                = "CCS Policy to configure Diagnostic Settings for ${each.value.display_name} to Log Analytics Workspace"
#   subscription_id            = each.value.subscription_id
#   user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/COS-terraform"]
#   location                   = "eastus"
#   # Reference the management group policy definition using the correct key
#   policy_definition_id       = module.paas_diagnostic_settings_policy_definition_mg["${each.value.management_group_id}-${each.value.type}"].id
#   policy_assignment_parameters = jsonencode({
#     logAnalytics = {
#       value = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourcegroups/paas-diagnostic/providers/microsoft.operationalinsights/workspaces/diagnostictesting"
#     }
#     # targetresourcetypeprovider = {
#     #     value = each.value.type
#     # }
#   })
# }
#################################################################################################################
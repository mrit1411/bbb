﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.paas_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_diagnostic_settings_Name"></a> [diagnostic\_settings\_Name](#input\_diagnostic\_settings\_Name) | Diagnostic settings Name | `string` | n/a | yes |
| <a name="input_diagnostic_settings_csv_path"></a> [diagnostic\_settings\_csv\_path](#input\_diagnostic\_settings\_csv\_path) | Path to the diagnostic settings CSV file | `string` | n/a | yes |
| <a name="input_log_analytics_workspace_id"></a> [log\_analytics\_workspace\_id](#input\_log\_analytics\_workspace\_id) | Log Analytics Workspace ID | `string` | n/a | yes |

## Outputs

No outputs.

## How to Add Diagnostic Settings
Step 1:
Go to the file named local.tf located in the folder:
Monitoring/modules/diagnostic_settings

Step 2:
Inside the locals block of the file, look for a variable called diagnostic_settings.
This variable is a map with numbered keys like "0", "1", "2", etc.
Each key represents a diagnostic setting for a PaaS resource, and contains a ResourceID.

Step 3:
To add a new diagnostic setting:

Use the next number in the sequence (e.g., if the last entry is "888", use "889").
Add a new item in the same format.
Set the ResourceID to the full Azure resource ID of the PaaS service.
Example:
"889" = {
  ResourceID = "/subscriptions/{subscription-id}/resourceGroups/{resource-group-name}/providers/Microsoft.Storage/storageAccounts/{storage-account-name}"
}

Step 4: Run the terraform command in the terminal:  terraform apply -target="module.paas_diagnostic_settings"

## How to Remove Diagnostic Settings

Step 1:
Go to the file named local.tf located in the folder:
Monitoring/modules/diagnostic_settings

Step 2:
Inside the locals block of the file, find the variable called diagnostic_settings.
This is a map with numbered keys like "0", "1", "2", etc.
Each key represents a diagnostic setting for a PaaS resource and contains a ResourceID.

Step 3:
To remove a diagnostic setting for a specific PaaS service:
- Find the key that contains the ResourceID of the resource you want to remove.- 
Delete that entire key block from the map.

Step 4: Run the terraform command in the terminal:  terraform apply -target="module.paas_diagnostic_settings"
# Input bindings are passed in via param block.
param($Timer)

Import-Module Az.OperationalInsights
$subscriptions = Get-AzSubscription

$dataResults='Workload, Vault_Name, Status, Status_Code, Start_Time, End_Time, Duration, Size(MB)'


$n = 10
$b = ($subscriptions.count)/$n
$c = [math]::ceiling($b)
Write-Host($b,$c,$subscriptions.count)
$e = @()
$d = @()
foreach ($subscription in $subscriptions) {
    $e += '"'+$subscription+ '"'
}
for (($i=0); $i -lt $c; $i++) {
    $d += $e[($i*$n)..(($i*$n)+$n-1)] -join ","
}


foreach ($s in $d){

$query = @"
arg("").resources
    | where type == "microsoft.compute/virtualmachines" and subscriptionId in ($s)
    | where tags.ccs_managed == "yes"
    | extend Workload = toupper(name)
    | project Workload
    | join (
AddonAzureBackupJobs
| where OperationName == "Job" and BackupManagementType == "IaaSVM"
//| where TimeGenerated >= startofmonth(datetime(now), -1) and TimeGenerated  <= startofmonth(datetime(now))-1s
//| where TimeGenerated >= startofday(datetime(now), -30) and TimeGenerated  <= startofday(datetime(now))-1s
| where TimeGenerated >= startofday(now(), -1) and TimeGenerated < startofday(now())
| where tostring(split(_ResourceId,"/")[2]) in ($s)
| extend Vault_Name = tostring(split(ResourceId,"/")[-1])
| extend Workload = toupper(tostring(split(BackupItemUniqueId,";")[-1]))
| extend Start_Time = format_datetime(todatetime(JobStartDateTime),'dd-MM-yyyy hh:mm:ss tt')
| extend End_Time = format_datetime(todatetime(JobStartDateTime+(round(JobDurationInSecs,0) *1s)),'dd-MM-yyyy hh:mm:ss tt')
| project Workload, Vault_Name, Status = JobStatus, Status_Code=JobFailureCode, Start_Time, End_Time, Duration = round(JobDurationInSecs,0) *1s, Size_MB = DataTransferredInMB
) on Workload
| project-away Workload1
| sort by Workload asc, Start_Time asc
"@


try {
        $queryLAW = Invoke-AzOperationalInsightsQuery -WorkspaceId "c885dbec-434d-4ece-a9d1-e65a03b0e080" -Query $query -ErrorAction Stop
        # $querytoken = $queryLAW.SkipToken
        # Write-Host("Query Token: " + $querytoken)

        $queryResult = $queryLAW.Results | ConvertTo-csv | ConvertFrom-Csv
        foreach($record in $queryResult)
        {
            $record = $record | ConvertTo-csv
            for($i=1;$i -lt $record.Count; $i++)
            {
                $dataResults += "`n" + $record[$i]
            }
        }
    }
    Catch {
        Write-Host "An error occurred:"
        Write-Host $_
    }
}

Push-OutputBinding -Name outputBlob -Value $dataResults
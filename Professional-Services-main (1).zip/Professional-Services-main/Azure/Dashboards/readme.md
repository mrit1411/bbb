

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.22.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.22.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_azure-ops-dashboard"></a> [azure-ops-dashboard](#module\_azure-ops-dashboard) | ./modules/workbooks | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_subscription.sub](https://registry.terraform.io/providers/hashicorp/azurerm/4.22.0/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_ops_dashboard_workbook_display_name"></a> [ops\_dashboard\_workbook\_display\_name](#input\_ops\_dashboard\_workbook\_display\_name) | Specifies the user-defined name (display name) of the Operations workbook. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group where to deploy the resources | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | List of tags to be added to resources. | `map(string)` | n/a | yes |

## Outputs

No outputs.

## Note

We opted for Template Deployment instead of the native Azure Workbook resource in Terraform to bypass the size limitations imposed by Terraform on workbook content. The workbook definition is maintained as a JSON file within the modules directory.
<!-- END_TF_DOCS -->
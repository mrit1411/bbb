using namespace System.NetNewLine
param($Request, $TriggerMetadata)

$alert = $Request.body

Write-Host "Alert payload: " + $alert

$monitoringService = $alert.data.essentials.monitoringService
Write-Output ("Monitoring services : " + $monitoringService)

$payload = @{
    "body"   = @{
        "companyName"            = "Test SA"
        "fullDescription"        = " "  
        "shortDescription"       = " "
        "urgency"                = "3 - Medium"
        "impactedCi"             = " "
        "impact"                 = "3 - Moderate/Limited"
        "externalSystemTicketId" = " "
        "externalSystem"         = " "
        "templateName"           = "TestSA.CGCloudNativeOperations_MEDIUM_DEF"
        "requestedBy"            = "Test"
        "customerShortname"      = "Test SA"
        "ipAddress"              = " "
        "systemPlatform"         = "NoInformation"
        "alertId"                = " "
        "alertType"              = "Submit_Test"
        "correlationFlag"        = " "
        "correlationId"          = " "
        "suppressionFlag"        = " "
        "suppressionId"          = " "
        "deviceType"             = " "
        "modelType"              = " "
        "modelClass"             = " "
        "memoryThreshold"        = " "
        "cpuThreshold"           = " "
        "diskName"               = " "
        "serviceName"            = " "
    }
    "header" = @{
        "topic"         = " " 
        "applicationId" = ""
    }
}


$arrayOfCI = $alert.data.essentials.configurationItems
Foreach ($ci in $arrayOfCI) {
    $ci = $ci.Split("/")
    $separatedCiName = $ci[$ci.Count - 1]
    $payload.body.impactedCi = $separatedCiName


    $payload.body.alertId = $alert.data.essentials.alertId
    Write-Host $alert.data.essentials.monitorCondition 
    if ($alert.data.essentials.monitorCondition -eq "Resolved") {
        $payload.body.alertType = "Okay_Azure"
    }
    else {
        $payload.body.alertType = "Submit_Azure"
    }
    $payload.body.externalSystemTicketId = $alert.data.essentials.originAlertId
    $payload.body.shortDescription = $alert.data.essentials.alertRule
    $payload.body.fullDescription = $alert.data.essentials.description

    switch ($monitoringService) {
        "Log Analytics" {   
            #$payload.body.fullDescription += "`alertID: "+ $payload.body.alertId
            $payload.body.fullDescription += "`n SearchIntervalStartTimeUtc : " + $alert.data.alertContext.SearchIntervalStartTimeUtc   
            $payload.body.fullDescription += "`n SearchIntervalEndtimeUtc : " + $alert.data.alertContext.SearchIntervalEndtimeUtc   
            $payload.body.fullDescription += "`n ResultCount : " + $alert.data.alertContext.ResultCount 
            $payload.body.fullDescription += "`n WorkspaceId : " + $alert.data.alertContext.WorkspaceId 
            Foreach ($dimension in $alert.data.alertContext.Dimensions) {    
                $payload.body.fullDescription += "`n Dimension name: " + $dimension.name    
                $payload.body.fullDescription += "`n Dimension value: " + $dimension.value  
            }   
            break;  
        }   
        "Platform" {    
            $platformAlertMetaData = $alert.data.alertContext.condition.allOf   
            Foreach ($val in $platformAlertMetaData) {       

                $payload.body.fullDescription += "`n alertID: " + $payload.body.alertId
                $payload.body.fullDescription += "`n Data for: " + $affectedCI   
                $payload.body.fullDescription += "`n metric name : " + $val.metricName  
                $payload.body.fullDescription += "`n Metric namespace : " + $val.metricnamespace    
                $payload.body.fullDescription += "`n operator : " + $val.operator   
                $payload.body.fullDescription += "`n Threshold : " + $val.threshold 
                $payload.body.fullDescription += "`n Time Aggregation : " + $val.timeAggregation    
                $payload.body.fullDescription += "`n Metric value : " + $val.metricValue    
            }   
        }
        "Application Insights" {
                    
            $payload.body.ipAddress = $alert.data.alertContext.Dimensions[0].value

            break; 
        }

        "Log Alerts V2" {

            $payload.body.deviceType = $alert.data.alertContext.condition.allOf[0].targetResourceTypes
            $payload.body.fullDescription += "`n SearchIntervalStartTimeUtc : " + $alert.data.alertContext.condition.windowStartTime
            $payload.body.fullDescription += "`n SearchIntervalEndtimeUtc : " + $alert.data.alertContext.condition.windowEndTime
            $payload.body.fullDescription += "`n Metric value : " + $alert.data.alertContext.condition.allOf[0].metricValue
            $payload.body.fullDescription += "`n Disk Name : " + $alert.data.alertContext.condition.allOf[0].dimensions[0].value

            break; 
        }

        default {
            Write-Host "Do nothing"
        }
    }

    $payload.header.topic = "cn/$($payload.body.companyName)/de/Azure_tosplnkeu/ic/$($payload.body.impactedCi)/tn/$($payload.body.templateName)/cs/$($payload.body.customerShortname)/sp/NoInformation/at/$($payload.body.alertType)" 

    $key_vault_name = $env:KEY_VAULT_NAME

    $clientSecret_output = Get-AzKeyVaultSecret -VaultName $key_vault_name -Name 'prodClientSecret' -AsPlainText
    $clientId_output = Get-AzKeyVaultSecret -VaultName $key_vault_name -Name 'prodClientId' -AsPlainText


    $authBody = @{
        "client_id"     = "$clientId_output"
        "client_secret" = "$clientSecret_output"
        "scope"         = "default"
        "grant_type"    = "client_credentials"
    }

    # $uri = "https://ipaastest-apis.eu1.ccp.capgemini.com/token"
    $uri = "https://ipaasprod-apis.eu1.ccp.capgemini.com/token"
    $accessToken = Invoke-WebRequest -Uri $uri -ContentType "application/x-www-form-urlencoded" -Body $authBody -Method Post 
    $accessToken = $accessToken.content | ConvertFrom-Json
    $header = @{
        'Content-Type'  = 'application/json'
        'Accept'        = 'application/json'
        'Authorization' = "Bearer $($accessToken.access_token)"
    }
    $uuid = New-Guid
    $requestHeader = @{
        Authorization = "Bearer $($accessToken.access_token)"
    }
    # $summaryUri = "https://ipaastest-apis.eu1.ccp.capgemini.com/alert-business-service/alerts/event/update?uuid=" + $uuid
    $summaryUri = "https://ipaasprod-apis.eu1.ccp.capgemini.com/alert-business-service/alerts/event/update?uuid=" + $uuid

    $body = $payload | ConvertTo-Json
    Write-Host $body

    try { $summaryResults = Invoke-RestMethod -Method POST -Uri $summaryUri -ContentType application/json -Header $header -Body $body }
    catch {
        Write-Host "An error occurred:"
        Write-Host $_
    }
}
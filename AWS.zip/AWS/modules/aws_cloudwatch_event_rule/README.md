﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_rule.cloudwatch_event_rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.cloudwatch_event_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_context"></a> [context](#input\_context) | The context of the event rule | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | The description of the rule. | `string` | n/a | yes |
| <a name="input_event_pattern"></a> [event\_pattern](#input\_event\_pattern) | The event pattern described as a JSON object. At least one of schedule\_expression or event\_pattern is required. See full documentation of Events and Event Patterns in EventBridge for details. | `string` | `null` | no |
| <a name="input_eventbridge_target_arn"></a> [eventbridge\_target\_arn](#input\_eventbridge\_target\_arn) | The Amazon Resource Name (ARN) of the target. | `string` | n/a | yes |
| <a name="input_eventbridge_target_id"></a> [eventbridge\_target\_id](#input\_eventbridge\_target\_id) | The unique target assignment ID. | `any` | n/a | yes |
| <a name="input_input"></a> [input](#input\_input) | The input to the target. This can be a JSON string or a JSON object. If not provided, the default is an empty string. | `string` | `null` | no |
| <a name="input_schedule"></a> [schedule](#input\_schedule) | The scheduling expression. For example, cron(0 20 * * ? *) or rate(5 minutes). At least one of schedule\_expression or event\_pattern is required. Can only be used on the default event bus. For more information, refer to the AWS documentation Schedule Expressions for Rules. | `string` | `null` | no |
| <a name="input_state"></a> [state](#input\_state) | State of the rule. When state is ENABLED, the rule is enabled for all events except those delivered by CloudTrail. | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_arn"></a> [arn](#output\_arn) | n/a |
| <a name="output_eventbridge_rule_id"></a> [eventbridge\_rule\_id](#output\_eventbridge\_rule\_id) | n/a |

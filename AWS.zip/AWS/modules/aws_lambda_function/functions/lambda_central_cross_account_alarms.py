# -*- coding: utf-8 -*-
"""
Centralized cross-account CloudWatch alarm creator for EC2 instances (Linux & Windows)
-------------------------------------------------------------------------------

This Lambda is deployed in a central *monitoring* account (Account A). It is
triggered by EC2 state-change events (from EventBridge) that may originate from
many *source* accounts. With CloudWatch cross-account observability (OAM sinks
and links) already set up, this function creates all alarms **in Account A**
that evaluate metrics **in the source account** by using CloudWatch's
`PutMetricAlarm` with metric data queries and the `AccountId` field.

Key behaviors
- Builds CloudWatch clients in the event Region (metrics are regional).
- For Linux, creates CPU (AWS/EC2), Memory (CWAgent mem_used_percent), Disk
  (CWAgent disk_used_percent) per mount.
- For Windows, creates CPU (AWS/EC2), Memory (CWAgent Memory % Committed Bytes
  In Use), Disk (% Free Space per logical disk), System Uptime (optional), and
  EC2 Status Check alarms.
- Discovers disk dimensions by calling ListMetrics from the monitoring account
  with IncludeLinkedAccounts=True and OwningAccount=<source_account_id>.

Environment variables
- SNOWSNSTopicARN            : ARN of the SNS topic in Account A to notify
- CREATE_LINUX_ALARMS        : "true" (default) or "false"
- CREATE_WINDOWS_ALARMS      : "true" (default) or "false"
- ALARM_PERIOD_SECONDS       : integer, default 300
- DISK_RETRY_ATTEMPTS        : integer, default 5 (retries to discover disks)
- DISK_RETRY_DELAY_SECONDS   : integer, default 60

Note: This function does *not* assume roles into source accounts. It relies on
CloudWatch cross-account observability (OAM). Ensure your monitoring account has
links to the source accounts and that metrics/logs sharing is enabled in each
Region where your workloads run.
"""
from __future__ import annotations
import os
import time
import random
import logging
from typing import Dict, List, Optional

import boto3

# --- configuration from environment ---
SNS_TOPIC_ARN = os.environ.get("SNOWSNSTopicARN")
CREATE_LINUX = os.environ.get("CREATE_LINUX_ALARMS", "true").lower() == "true"
CREATE_WINDOWS = os.environ.get("CREATE_WINDOWS_ALARMS", "true").lower() == "true"
ALARM_PERIOD = int(os.environ.get("ALARM_PERIOD_SECONDS", "300"))  # seconds
DISK_RETRY_ATTEMPTS = int(os.environ.get("DISK_RETRY_ATTEMPTS", "5"))
DISK_RETRY_DELAY = int(os.environ.get("DISK_RETRY_DELAY_SECONDS", "60"))

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ------------- helpers -------------

def cw_client_for_region(region: str):
    return boto3.client("cloudwatch", region_name=region)


def eval_periods(duration_minutes: int, period_seconds: int = ALARM_PERIOD) -> int:
    return max(1, int((duration_minutes * 60) / period_seconds))


def list_linux_disks_for_instance(
    cw, source_account_id: str, instance_id: str
) -> List[Dict[str, str]]:
    """Return list of {'path','device','fstype'} for a Linux instance.
    Uses OAM visibility from the monitoring account.
    """
    device_names: List[Dict[str, str]] = []
    next_token = None
    while True:
        resp = cw.list_metrics(
            Namespace="CWAgent",
            MetricName="disk_used_percent",
            Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
            IncludeLinkedAccounts=True,
            OwningAccount=source_account_id,
            NextToken=next_token,
        )
        for metric in resp.get("Metrics", []):
            data: Dict[str, str] = {}
            for dim in metric.get("Dimensions", []):
                n, v = dim.get("Name"), dim.get("Value")
                if n == "device":
                    data["device"] = v
                elif n == "path":
                    data["path"] = v
                elif n == "fstype":
                    data["fstype"] = v
            if "device" in data and data.get("fstype") in ("xfs", "ext4"):
                device_names.append(data)
        next_token = resp.get("NextToken")
        if not next_token:
            break
    # de-dup
    uniq = []
    seen = set()
    for d in device_names:
        key = (d.get("path"), d.get("device"), d.get("fstype"))
        if key not in seen:
            seen.add(key)
            uniq.append(d)
    return uniq


def list_windows_disks_for_instance(
    cw, source_account_id: str, instance_id: str
) -> (List[str], Optional[str]):
    """Return (list_of_drive_letters, metric_name_used).

    Tries CWAgent metric names in order to discover LogicalDisk series.
    Returns drive letters like 'C:' and metric name selected (for alarm use).
    """
    metric_candidates = [
        "LogicalDisk % Free Space",  # preferred
        "DiskFree",                   # fallback used in some configs
    ]
    for metric_name in metric_candidates:
        drives: List[str] = []
        next_token = None
        while True:
            resp = cw.list_metrics(
                Namespace="CWAgent",
                MetricName=metric_name,
                Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
                IncludeLinkedAccounts=True,
                OwningAccount=source_account_id,
                NextToken=next_token,
            )
            for metric in resp.get("Metrics", []):
                obj = {d["Name"]: d["Value"] for d in metric.get("Dimensions", [])}
                # Expect objectname=LogicalDisk and a dimension named 'instance' for drive
                if obj.get("objectname") == "LogicalDisk" and "instance" in obj:
                    drives.append(obj["instance"])  # e.g., 'C:'
            next_token = resp.get("NextToken")
            if not next_token:
                break
        if drives:
            return sorted(set(drives)), metric_name
    return [], None


# ------------- alarm creators (all central, cross-account) -------------

def create_cpu_alarm(cw, source_account_id: str, instance_id: str, name: str, threshold: float, duration_min: int = 30):
    cw.put_metric_alarm(
        AlarmName=f"{name}: EC2:Over {threshold}% CPU Utilization detected over a period of {duration_min} minutes",
        ComparisonOperator="GreaterThanOrEqualToThreshold",
        EvaluationPeriods=eval_periods(duration_min),
        Threshold=threshold,
        AlarmDescription=(
            "CPUUtilization across accounts via OAM (centralized alarm)."
        ),
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="notBreaching",
        Metrics=[
            {
                "Id": "cpu_utilization_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/EC2",
                        "MetricName": "CPUUtilization",
                        "Dimensions": [
                            {"Name": "InstanceId", "Value": instance_id}
                        ],
                    },
                    "Period": ALARM_PERIOD,
                    "Stat": "Average",
                },
            }
        ],
    )


def create_status_check_alarm(cw, source_account_id: str, instance_id: str, name: str):
    cw.put_metric_alarm(
        AlarmName=f"{name}: EC2:Status Check Fail detected",
        ComparisonOperator="GreaterThanThreshold",
        EvaluationPeriods=1,
        Threshold=1,
        AlarmDescription=(
            "Reports whether the instance passed both instance and system status checks."
        ),
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="breaching",
        Metrics=[
            {
                "Id": "status_check_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/EC2",
                        "MetricName": "StatusCheckFailed",
                        "Dimensions": [
                            {"Name": "InstanceId", "Value": instance_id}
                        ],
                    },
                    "Period": 300,
                    "Stat": "Sum",
                },
            }
        ],
    )


# -------- Linux alarms --------

def create_linux_memory_alarm(cw, source_account_id: str, instance_id: str, name: str, threshold: float, duration_min: int = 30):
    dims = [{"Name": "InstanceId", "Value": instance_id}]
    cw.put_metric_alarm(
        AlarmName=f"{name}: EC2:Over {threshold}% Memory Utilization detected over a period of {duration_min} minutes",
        ComparisonOperator="GreaterThanOrEqualToThreshold",
        EvaluationPeriods=eval_periods(duration_min),
        Threshold=threshold,
        AlarmDescription=f"Over {threshold}% mem_used_percent (CWAgent)",
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="notBreaching",
        Metrics=[
            {
                "Id": "memory_utilization_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": "mem_used_percent",
                        "Dimensions": dims,
                    },
                    "Period": ALARM_PERIOD,
                    "Stat": "Average",
                },
            }
        ],
    )


def create_linux_disk_alarm(cw, source_account_id: str, instance_id: str, name: str, disk: Dict[str, str], threshold: float, duration_min: int = 5):
    dims = [
        {"Name": "path", "Value": disk["path"]},
        {"Name": "InstanceId", "Value": instance_id},
        {"Name": "device", "Value": disk["device"]},
        {"Name": "fstype", "Value": disk["fstype"]},
    ]
    cw.put_metric_alarm(
        AlarmName=(
            f"{name}: {disk['path']}: EC2:Over {threshold}% Disk Utilization detected "
            f"over a period of {duration_min} minutes"
        ),
        ComparisonOperator="GreaterThanOrEqualToThreshold",
        EvaluationPeriods=eval_periods(duration_min),
        Threshold=threshold,
        AlarmDescription=f"Over {threshold}% disk_used_percent (CWAgent)",
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="notBreaching",
        Metrics=[
            {
                "Id": "linux_disk_utilization_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": "disk_used_percent",
                        "Dimensions": dims,
                    },
                    "Period": ALARM_PERIOD,
                    "Stat": "Average",
                },
            }
        ],
    )


# -------- Windows alarms --------

def create_windows_memory_alarm(cw, source_account_id: str, instance_id: str, name: str, threshold: float, duration_min: int = 30):
    dims = [
        {"Name": "InstanceId", "Value": instance_id},
        {"Name": "objectname", "Value": "Memory"},
    ]
    cw.put_metric_alarm(
        AlarmName=f"{name}: EC2:Over {threshold}% Memory Utilization detected over a period of {duration_min} minutes",
        ComparisonOperator="GreaterThanOrEqualToThreshold",
        EvaluationPeriods=eval_periods(duration_min),
        Threshold=threshold,
        AlarmDescription=f"Over {threshold}% Memory % Committed Bytes In Use (CWAgent)",
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="notBreaching",
        Metrics=[
            {
                "Id": "win_memory_utilization_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": "Memory % Committed Bytes In Use",
                        "Dimensions": dims,
                    },
                    "Period": ALARM_PERIOD,
                    "Stat": "Average",
                },
            }
        ],
    )


def create_windows_disk_alarm(cw, source_account_id: str, instance_id: str, name: str, drive: str, metric_name: str, threshold_free_percent: float, duration_min: int = 5):
    """
    Create a Windows logical disk free-space alarm.
    If metric_name is 'LogicalDisk % Free Space', we alarm when <= threshold.
    If metric_name is 'DiskFree' (fallback), we still use LessThanOrEqualTo.
    """
    dims = [
        {"Name": "InstanceId", "Value": instance_id},
        {"Name": "instance", "Value": drive},
        {"Name": "objectname", "Value": "LogicalDisk"},
    ]
    cw.put_metric_alarm(
        AlarmName=(
            f"{name}: {drive}: EC2:Over {100 - threshold_free_percent}% Disk Utilization "
            f"detected over a period of {duration_min} minutes"
        ),
        ComparisonOperator="LessThanOrEqualToThreshold",
        EvaluationPeriods=eval_periods(duration_min),
        Threshold=threshold_free_percent,
        AlarmDescription=(
            f"LogicalDisk free space <= {threshold_free_percent}% (CWAgent, {metric_name})"
        ),
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="breaching",
        Metrics=[
            {
                "Id": "windows_disk_free_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": metric_name,
                        "Dimensions": dims,
                    },
                    "Period": ALARM_PERIOD,
                    "Stat": "Average",
                },
            }
        ],
    )


def create_windows_system_uptime_alarm(cw, source_account_id: str, instance_id: str, name: str):
    dims = [
        {"Name": "InstanceId", "Value": instance_id},
        {"Name": "objectname", "Value": "System"},
    ]
    cw.put_metric_alarm(
        AlarmName=f"{name}: EC2:System Uptime is less than 20 seconds",
        ComparisonOperator="LessThanThreshold",
        EvaluationPeriods=1,
        Threshold=20,
        AlarmDescription="System Uptime is less than 20 seconds (CWAgent)",
        AlarmActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        OKActions=[SNS_TOPIC_ARN] if SNS_TOPIC_ARN else [],
        TreatMissingData="breaching",
        Metrics=[
            {
                "Id": "system_uptime_timeseries",
                "ReturnData": True,
                "AccountId": source_account_id,
                "MetricStat": {
                    "Metric": {
                        "Namespace": "CWAgent",
                        "MetricName": "System System Up Time",
                        "Dimensions": dims,
                    },
                    "Period": 300,
                    "Stat": "Average",
                },
            }
        ],
    )


# ------------- orchestration per OS -------------

def create_linux_alarms_for_instance(cw, source_account_id: str, instance_id: str, name: str):
    # CPU
    create_cpu_alarm(cw, source_account_id, instance_id, name, threshold=90, duration_min=30)
    # Memory
    for thr in (90, 95):
        create_linux_memory_alarm(cw, source_account_id, instance_id, name, threshold=thr, duration_min=30)
    # Disks: discover with retries
    for attempt in range(1, DISK_RETRY_ATTEMPTS + 1):
        disks = list_linux_disks_for_instance(cw, source_account_id, instance_id)
        if disks:
            break
        delay = DISK_RETRY_DELAY + random.randint(0, 10)
        logger.info(
            "No Linux disk metrics yet (attempt %s/%s). Sleeping %ss...",
            attempt, DISK_RETRY_ATTEMPTS, delay,
        )
        time.sleep(delay)
    if not disks:
        logger.warning("No Linux disk metrics available; skipping disk alarms for %s", instance_id)
    else:
        for d in disks:
            # choose one or two thresholds
            for thr in (80, 90):
                create_linux_disk_alarm(cw, source_account_id, instance_id, name, d, threshold=thr, duration_min=5)
    # Status check is OS-agnostic; create once
    create_status_check_alarm(cw, source_account_id, instance_id, name)


def create_windows_alarms_for_instance(cw, source_account_id: str, instance_id: str, name: str):
    # CPU
    create_cpu_alarm(cw, source_account_id, instance_id, name, threshold=90, duration_min=30)
    # Memory
    for thr in (90, 95):
        create_windows_memory_alarm(cw, source_account_id, instance_id, name, threshold=thr, duration_min=30)
    # Disks: discover drive letters via ListMetrics
    drives, metric_name = [], None
    for attempt in range(1, DISK_RETRY_ATTEMPTS + 1):
        drives, metric_name = list_windows_disks_for_instance(cw, source_account_id, instance_id)
        if drives:
            break
        delay = DISK_RETRY_DELAY + random.randint(0, 10)
        logger.info(
            "No Windows disk metrics yet (attempt %s/%s). Sleeping %ss...",
            attempt, DISK_RETRY_ATTEMPTS, delay,
        )
        time.sleep(delay)
    if not drives:
        logger.warning("No Windows disk metrics available; skipping disk alarms for %s", instance_id)
    else:
        for drive in drives:
            for thr in (20.0, 10.0):  # free space percent thresholds
                create_windows_disk_alarm(
                    cw, source_account_id, instance_id, name,
                    drive=drive, metric_name=metric_name or "LogicalDisk % Free Space",
                    threshold_free_percent=thr, duration_min=5,
                )
    # System uptime
    create_windows_system_uptime_alarm(cw, source_account_id, instance_id, name)
    # Status check is OS-agnostic; create once (safe to call again)
    create_status_check_alarm(cw, source_account_id, instance_id, name)


# ------------- OS detection -------------

def detect_os_via_metrics(cw, source_account_id: str, instance_id: str) -> str:
    """Return 'linux', 'windows', or 'unknown' by probing metric presence via OAM.
    We check a Linux-only metric first, then a Windows-only one.
    """
    try:
        # Linux probe: mem_used_percent
        lm = cw.list_metrics(
            Namespace="CWAgent",
            MetricName="mem_used_percent",
            Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
            IncludeLinkedAccounts=True,
            OwningAccount=source_account_id,
        )
        if lm.get("Metrics"):
            return "linux"
    except Exception as e:
        logger.debug("Linux probe failed: %s", e)
    try:
        # Windows probe: Memory % Committed Bytes In Use
        wm = cw.list_metrics(
            Namespace="CWAgent",
            MetricName="Memory % Committed Bytes In Use",
            Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
            IncludeLinkedAccounts=True,
            OwningAccount=source_account_id,
        )
        if wm.get("Metrics"):
            return "windows"
    except Exception as e:
        logger.debug("Windows probe failed: %s", e)
    return "unknown"


# ------------- Lambda entrypoint -------------

def lambda_handler(event, context):
    logger.info("Event: %s", event)
    detail = event.get("detail", {})
    instance_id = detail.get("instance-id")
    source_account_id = event.get("account")
    region = event.get("region")

    if not instance_id or not source_account_id or not region:
        logger.error("Missing instance_id/account_id/region in the event; aborting")
        return {"ok": False, "reason": "missing_keys"}

    if not SNS_TOPIC_ARN:
        logger.warning("SNOWSNSTopicARN is not set; alarms will have no actions")

    cw = cw_client_for_region(region)

    # Decide OS by probing metrics; if unknown, try both paths conservatively
    os_type = detect_os_via_metrics(cw, source_account_id, instance_id)
    name = instance_id  # Use instance-id as label (no EC2 describes in central pattern)

    logger.info("Creating central alarms in %s for instance %s (src acct %s, OS %s)",
                region, instance_id, source_account_id, os_type)

    created = []
    if os_type in ("linux", "unknown") and CREATE_LINUX:
        try:
            create_linux_alarms_for_instance(cw, source_account_id, instance_id, name)
            created.append("linux")
        except Exception as e:
            logger.exception("Failed to create Linux alarms: %s", e)

    if os_type in ("windows", "unknown") and CREATE_WINDOWS:
        try:
            create_windows_alarms_for_instance(cw, source_account_id, instance_id, name)
            created.append("windows")
        except Exception as e:
            logger.exception("Failed to create Windows alarms: %s", e)

    if not created:
        logger.error("No alarms created (OS %s, toggles L=%s W=%s)", os_type, CREATE_LINUX, CREATE_WINDOWS)
        return {"ok": False, "reason": "no_alarms_created", "os": os_type}

    return {"ok": True, "created_for": created, "instance_id": instance_id, "region": region}

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 6.3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 6.3.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aws_resource_backup_role"></a> [aws\_resource\_backup\_role](#module\_aws\_resource\_backup\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_backup_linux_instance_ssm_automation_document"></a> [backup\_linux\_instance\_ssm\_automation\_document](#module\_backup\_linux\_instance\_ssm\_automation\_document) | ../modules/aws_ssm_document | n/a |
| <a name="module_backup_report_url_iam_user"></a> [backup\_report\_url\_iam\_user](#module\_backup\_report\_url\_iam\_user) | ../modules/aws_iam_user | n/a |
| <a name="module_backup_reports_automation_trigger_daily"></a> [backup\_reports\_automation\_trigger\_daily](#module\_backup\_reports\_automation\_trigger\_daily) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_backup_reports_automation_trigger_monthly"></a> [backup\_reports\_automation\_trigger\_monthly](#module\_backup\_reports\_automation\_trigger\_monthly) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_backup_reports_automation_trigger_weekly"></a> [backup\_reports\_automation\_trigger\_weekly](#module\_backup\_reports\_automation\_trigger\_weekly) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_backup_reports_lambda_function"></a> [backup\_reports\_lambda\_function](#module\_backup\_reports\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_backup_reports_s3_bucket"></a> [backup\_reports\_s3\_bucket](#module\_backup\_reports\_s3\_bucket) | ../modules/aws_s3_bucket | n/a |
| <a name="module_backup_reports_sns_topic"></a> [backup\_reports\_sns\_topic](#module\_backup\_reports\_sns\_topic) | ../modules/aws_sns_topic | n/a |
| <a name="module_backup_reports_sns_topic_subscription"></a> [backup\_reports\_sns\_topic\_subscription](#module\_backup\_reports\_sns\_topic\_subscription) | ../modules/aws_sns_topic_subscription | n/a |
| <a name="module_backup_selection"></a> [backup\_selection](#module\_backup\_selection) | ../modules/aws_backup_selection | n/a |
| <a name="module_backup_url_credentials_stored"></a> [backup\_url\_credentials\_stored](#module\_backup\_url\_credentials\_stored) | ../modules/aws_secretsmanager_secret | n/a |
| <a name="module_backup_url_user_credentials"></a> [backup\_url\_user\_credentials](#module\_backup\_url\_user\_credentials) | ../modules/aws_iam_access_key | n/a |
| <a name="module_backup_vault"></a> [backup\_vault](#module\_backup\_vault) | ../modules/aws_backup_vault | n/a |
| <a name="module_backup_windows_instance_ssm_automation_document"></a> [backup\_windows\_instance\_ssm\_automation\_document](#module\_backup\_windows\_instance\_ssm\_automation\_document) | ../modules/aws_ssm_document | n/a |
| <a name="module_ccs_aws_backup_monitoring"></a> [ccs\_aws\_backup\_monitoring](#module\_ccs\_aws\_backup\_monitoring) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_ccs_backup_plan"></a> [ccs\_backup\_plan](#module\_ccs\_backup\_plan) | ../modules/aws_backup_plan | n/a |
| <a name="module_daily_event_bridge_permission_invoke_reporting_lambda"></a> [daily\_event\_bridge\_permission\_invoke\_reporting\_lambda](#module\_daily\_event\_bridge\_permission\_invoke\_reporting\_lambda) | ../modules/aws_lambda_permission | n/a |
| <a name="module_delete_snapshot_based_on_tag_event_rule"></a> [delete\_snapshot\_based\_on\_tag\_event\_rule](#module\_delete\_snapshot\_based\_on\_tag\_event\_rule) | ../modules/aws_cloudwatch_event_rule | n/a |
| <a name="module_delete_snapshot_based_on_tag_lambda_function"></a> [delete\_snapshot\_based\_on\_tag\_lambda\_function](#module\_delete\_snapshot\_based\_on\_tag\_lambda\_function) | ../modules/aws_lambda_function | n/a |
| <a name="module_delete_snapshot_based_on_tag_permission_invoke_lambda"></a> [delete\_snapshot\_based\_on\_tag\_permission\_invoke\_lambda](#module\_delete\_snapshot\_based\_on\_tag\_permission\_invoke\_lambda) | ../modules/aws_lambda_permission | n/a |
| <a name="module_lambda_backup_reports_iam_role"></a> [lambda\_backup\_reports\_iam\_role](#module\_lambda\_backup\_reports\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_lambda_delete_snapshot_based_on_tag_iam_role"></a> [lambda\_delete\_snapshot\_based\_on\_tag\_iam\_role](#module\_lambda\_delete\_snapshot\_based\_on\_tag\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_monthly_event_bridge_permission_invoke_reporting_lambda"></a> [monthly\_event\_bridge\_permission\_invoke\_reporting\_lambda](#module\_monthly\_event\_bridge\_permission\_invoke\_reporting\_lambda) | ../modules/aws_lambda_permission | n/a |
| <a name="module_ssm_automation_backup_instance_iam_role"></a> [ssm\_automation\_backup\_instance\_iam\_role](#module\_ssm\_automation\_backup\_instance\_iam\_role) | ../modules/aws_iam_role | n/a |
| <a name="module_weekly_event_bridge_permission_invoke_reporting_lambda"></a> [weekly\_event\_bridge\_permission\_invoke\_reporting\_lambda](#module\_weekly\_event\_bridge\_permission\_invoke\_reporting\_lambda) | ../modules/aws_lambda_permission | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/6.3.0/docs/data-sources/region) | data source |
| [terraform_remote_state.infra](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_backup_completion_window"></a> [backup\_completion\_window](#input\_backup\_completion\_window) | The amount of time in minutes AWS Backup attempts a backup before canceling the job and returning an error. | `number` | `1440` | no |
| <a name="input_backup_daily_delete_after_days"></a> [backup\_daily\_delete\_after\_days](#input\_backup\_daily\_delete\_after\_days) | Enter the amount of days that AWS Backup Daily Backups will be retained for. | `number` | `8` | no |
| <a name="input_backup_daily_rule_name"></a> [backup\_daily\_rule\_name](#input\_backup\_daily\_rule\_name) | Enter the name for the AWS Backup Daily Backup Rule that will be deployed | `string` | `"CCSDailyBackupRule"` | no |
| <a name="input_backup_daily_schedule_expression"></a> [backup\_daily\_schedule\_expression](#input\_backup\_daily\_schedule\_expression) | An AWS CRON expression specifying when AWS Backup initiates a Daily backup job. by default (03:04 AM MON-SAT) | `string` | `"cron(4 3 ? * 2,3,4,5,6,7 *)"` | no |
| <a name="input_backup_link_validity"></a> [backup\_link\_validity](#input\_backup\_link\_validity) | Enter how long in seconds the AWS Backup Report notification link will be valid for (86400 - 24h, 604800 - 7 days) | `number` | `604800` | no |
| <a name="input_backup_monthly_delete_after_days"></a> [backup\_monthly\_delete\_after\_days](#input\_backup\_monthly\_delete\_after\_days) | Enter the amount of days that AWS Backup Monthly Backups will be retained for. | `number` | `396` | no |
| <a name="input_backup_monthly_rule_name"></a> [backup\_monthly\_rule\_name](#input\_backup\_monthly\_rule\_name) | Enter the name for the AWS Backup Monthly Backup Rule that will be deployed | `string` | `"CCSMonthlyBackupRule"` | no |
| <a name="input_backup_monthly_schedule_expression"></a> [backup\_monthly\_schedule\_expression](#input\_backup\_monthly\_schedule\_expression) | An AWS CRON expression specifying when AWS Backup initiates a Monthly backup job. by default (01:04 AM 28th of every month) | `string` | `"cron(04 1 28 * ? *)"` | no |
| <a name="input_backup_plan_name"></a> [backup\_plan\_name](#input\_backup\_plan\_name) | Enter name for AWS Backup Plan that will be deployed. | `string` | `"CCSBackupPlan"` | no |
| <a name="input_backup_plan_tags"></a> [backup\_plan\_tags](#input\_backup\_plan\_tags) | A map of tags to assign to the backup plan. | `map(string)` | <pre>{<br/>  "Owner": "CCS"<br/>}</pre> | no |
| <a name="input_backup_report_generation_schedule_daily"></a> [backup\_report\_generation\_schedule\_daily](#input\_backup\_report\_generation\_schedule\_daily) | Enter the schedule for Daily AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of daily AWS Backup reports.by default (01:30 GMT everyday) | `string` | `"cron(30 01 * * ? *)"` | no |
| <a name="input_backup_report_generation_schedule_monthly"></a> [backup\_report\_generation\_schedule\_monthly](#input\_backup\_report\_generation\_schedule\_monthly) | Enter the schedule for Monthly AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of monthly AWS Backup reports. by default (01:30 AM last day of every month) | `string` | `"cron(30 01 L * ? *)"` | no |
| <a name="input_backup_report_generation_schedule_weekly"></a> [backup\_report\_generation\_schedule\_weekly](#input\_backup\_report\_generation\_schedule\_weekly) | Enter the schedule for Weekly AWS Backup report generation. AWS CRON expression specifying when the Backup EventBridge Rule will initiate the generation of weekly AWS Backup reports.by default (01:30 on each monday) | `string` | `"cron(30 01 ? * 2 *)"` | no |
| <a name="input_backup_report_recipient"></a> [backup\_report\_recipient](#input\_backup\_report\_recipient) | Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Backup Reports | `string` | `"akarsh.a.srivastava@capgemini.com"` | no |
| <a name="input_backup_reports_bucket_name"></a> [backup\_reports\_bucket\_name](#input\_backup\_reports\_bucket\_name) | Enter the name of the S3 bucket that will be created and used to store monthly AWS Backup reports | `string` | `"ccs-backup-reports"` | no |
| <a name="input_backup_reports_sns_topic_name"></a> [backup\_reports\_sns\_topic\_name](#input\_backup\_reports\_sns\_topic\_name) | Enter the name for the SNS Topic that will be created and used by the backup report lambda to email monthly AWS Backup reports | `string` | `"ccs-backup-reports"` | no |
| <a name="input_backup_selection_name"></a> [backup\_selection\_name](#input\_backup\_selection\_name) | Enter the name for the AWS Backup resource selection that will be deployed | `string` | `"CCSSelectedResources"` | no |
| <a name="input_backup_start_window"></a> [backup\_start\_window](#input\_backup\_start\_window) | The amount of time in minutes before beginning a backup. | `number` | `120` | no |
| <a name="input_backup_tags_condition_key"></a> [backup\_tags\_condition\_key](#input\_backup\_tags\_condition\_key) | Resources with this Tag Key will be backed up by deployed CCS AWS Backup rules | `string` | `"ccs_backup"` | no |
| <a name="input_backup_tags_condition_value"></a> [backup\_tags\_condition\_value](#input\_backup\_tags\_condition\_value) | Resources with this Tag Value will be backed up by deployed CCS AWS Backup rules | `string` | `"yes"` | no |
| <a name="input_backup_vault_name"></a> [backup\_vault\_name](#input\_backup\_vault\_name) | Enter the name of the AWS Backup Vault that will be created and used to store backups | `string` | `"CCSBackupVault"` | no |
| <a name="input_backup_vault_tags"></a> [backup\_vault\_tags](#input\_backup\_vault\_tags) | Enter the tags that will be applied to the AWS Backup Vault | `map(string)` | <pre>{<br/>  "ccs_backup": "yes"<br/>}</pre> | no |
| <a name="input_backup_weekly_delete_after_days"></a> [backup\_weekly\_delete\_after\_days](#input\_backup\_weekly\_delete\_after\_days) | Enter the amount of days that AWS Backup Weekly Backups will be retained for. | `number` | `35` | no |
| <a name="input_backup_weekly_rule_name"></a> [backup\_weekly\_rule\_name](#input\_backup\_weekly\_rule\_name) | Enter the name for the AWS Backup Weekly Backup Rule that will be deployed | `string` | `"CCSWeeklyBackupRule"` | no |
| <a name="input_backup_weekly_schedule_expression"></a> [backup\_weekly\_schedule\_expression](#input\_backup\_weekly\_schedule\_expression) | An AWS CRON expression specifying when AWS Backup initiates a Weekly backup job. by default  (03:04 AM every Sunday) | `string` | `"cron(4 3 ? * 1 *)"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
resource "random_uuid" "azure_ops_dashboard_name" {
}

resource "azurerm_resource_group_template_deployment" "azure_dashboard" {
  deployment_mode     = "Incremental"
  name                = var.name
  resource_group_name = var.resource_group_name
  parameters_content = jsonencode({
    workbookDisplayName = {
      value = var.dashboard_workbook_display_name
    }
    workbookType = {
      value = "workbook"
    }
    workbookId = {
      value = "${random_uuid.azure_ops_dashboard_name.result}"
    }
    location = {
      value = var.location
    }
  })

  template_content = jsonencode(jsondecode((file("./${path.module}/${var.workbook_name}"))))
}
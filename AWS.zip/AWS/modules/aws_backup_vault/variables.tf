variable "tags" {
  description = "A map of tags to assign to the backup vault."
  type        = map(string)
  default     = {}
}

variable "region" {
  description = "The AWS region where the backup vault will be created."
  type        = string
}

variable "context" {
  description = "The context to be used in naming the backup vault."
  type        = string
}
output "access_key_id" {
  value     = aws_iam_access_key.iam_access_key.id
  sensitive = true
}

output "secret_access_key" {
  value     = aws_iam_access_key.iam_access_key.secret
  sensitive = true

}
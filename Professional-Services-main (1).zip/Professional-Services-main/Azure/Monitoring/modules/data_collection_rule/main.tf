resource "azurerm_monitor_data_collection_rule" "data_collection_rule" {
  name                = local.name
  resource_group_name = var.resource_group_name
  location            = var.location
  description         = var.description

  destinations {
    log_analytics {
      name                  = var.destination_log_analytics_workspace_name
      workspace_resource_id = var.workspace_resource_id
    }
  }

dynamic "data_flow" {
  for_each = [
    for ds in var.data_sources : ds
  ]

  content {
    streams = data_flow.value.streams

    destinations = [
      var.destination_log_analytics_workspace_name
    ]
  }
}

  data_sources {
  dynamic "performance_counter" {
  for_each = [
    for ds in var.data_sources : ds
    if ds.type == "performance_counter"
  ]
  content {
    name                          = performance_counter.value.name
    streams                       = performance_counter.value.streams
    sampling_frequency_in_seconds = performance_counter.value.sampling_frequency_in_seconds
    counter_specifiers            = performance_counter.value.counter_specifiers
  }
  }

  dynamic "windows_event_log" {
  for_each = [
    for ds in var.data_sources : ds
    if ds.type == "windows_event_log"
  ]
  content {
    name                          = windows_event_log.value.name
    streams                       = windows_event_log.value.streams
    x_path_queries                = windows_event_log.value.x_path_queries
  }
  }
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}
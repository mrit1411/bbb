variable "context" {
  description = "The context to be used in naming the backup plan."
  type        = string
}

variable "backup_setting_resource_type" {
  description = "The type of AWS resource to be backed up. For VSS Windows backups, the only supported resource type is Amazon EC2. Valid values: EC2."
  type        = string
  default     = "EC2"
}

variable "backup_setting_windows_vss" {
  description = "Indicates whether to use Windows VSS for backups. Valid values: true, false."
  type        = bool
  default     = false
}

variable "rules" {
  description = <<EOT
    A list of rules for the backup plan. A rule object specifies a scheduled task that is used to back up a selection of resources. Each rule must contain the following attributes:
    - rule_name: The name of the rule.
    - schedule: A CRON expression specifying when AWS Backup initiates a backup job.
    - completion_window: The amount of time in minutes AWS Backup attempts a backup before canceling the job and returning an error.
    - start_window: The amount of time in minutes before beginning a backup.
    - target_vault_name: The name of a logical container where backups are stored.
    - delete_after: Specifies the number of days after creation that a recovery point is deleted.
    - recovery_point_tags: Metadata that you can assign to help organize the resources that you create.
    EOT
  type = list(object({
    rule_name           = string
    schedule            = string
    completion_window   = number
    start_window        = number
    target_vault_name   = string
    delete_after        = number
    recovery_point_tags = map(string)
  }))
}

variable "tags" {
  description = "A map of tags to assign to the backup plan."
  type        = map(string)
}

variable "region" {
  description = "The AWS region where the backup plan will be created."
  type        = string
}
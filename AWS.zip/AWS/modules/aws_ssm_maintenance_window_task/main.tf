resource "aws_ssm_maintenance_window_task" "ssm_maintenance_window_task" {
  window_id       = var.window_id
  max_concurrency = var.max_concurrency
  max_errors      = var.max_errors
  task_type       = var.task_type
  task_arn        = var.task_arn
  name            = var.name
  description     = var.description
  priority        = var.priority

  task_invocation_parameters {
    run_command_parameters {
      service_role_arn = var.task_invocation_service_role_arn

      notification_config {
        notification_arn    = var.notification_arn
        notification_events = var.notification_events
        notification_type   = var.notification_type
      }

      parameter {
        name   = var.parameter_name
        values = var.parameter_values
      }
    }
  }

  targets {
    key    = var.target_key
    values = var.target_values
  }
}
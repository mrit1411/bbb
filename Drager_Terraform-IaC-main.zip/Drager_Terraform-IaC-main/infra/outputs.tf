output "infra_run_command_linux_ssm_automation_document" {
  value = module.run_command_linux_ssm_automation_document
}

output "infra_create_backup_ssm_automation_document" {
  value = module.create_backup_ssm_automation_document
}

output "infra_run_command_windows_ssm_automation_document" {
  value = module.run_command_windows_ssm_automation_document
}

output "infra_snow_sns_topic" {
  value = module.snow_sns_topic
}

output "infra_ec2_instance_profile_name" {
  value = module.ssm_management_ec2_instance_profile

}
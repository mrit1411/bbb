resource "aws_glue_trigger" "glue_trigger" {
  name              = local.name
  type              = var.type
  start_on_creation = var.start_on_creation
  schedule          = var.schedule

  actions {
    crawler_name = var.crawler_name
  }
}
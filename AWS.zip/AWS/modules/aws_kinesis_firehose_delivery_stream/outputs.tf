output "arn" {
  description = "The ARN of the Kinesis Firehose Delivery Stream"
  value       = aws_kinesis_firehose_delivery_stream.kinesis_firehose_delivery_stream.arn
}
locals {
    name = "CCS-${var.context}-BackupPlan-${var.region}"
}
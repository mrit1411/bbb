variable "lambda_function_filename" {
  description = "The name of the Lambda function file without extension"
  type        = string
}

variable "role" {
  description = "ARN of the function's execution role. The role provides the function's identity and access to AWS services and resources."
  type        = string
}

variable "description" {
  description = "Description of what your Lambda Function does."
  type        = string
}

variable "handler" {
  description = "Function entry point in your code"
  type        = string
}

variable "runtime" {
  description = "The runtime environment for the Lambda function"
  type        = string
  default     = "python3.12"
}

variable "timeout" {
  description = "Amount of time your Lambda Function has to run in seconds. Valid between 1 and 900."
  type        = number

  validation {
    condition     = var.timeout >= 1 && var.timeout <= 900
    error_message = "Timeout must be between 1 and 900 seconds."
  }
}

variable "memory_size" {
  description = "Amount of memory available to the function at runtime in MB. Valid between 128 and 10240."
  type        = number

  validation {
    condition     = var.memory_size >= 128 && var.memory_size <= 10240
    error_message = "Memory size must be between 128 and 10240 MB."
  }

}

variable "env_variables" {
  description = "Environment variables to pass to the Lambda function"
  type        = map(string)
  default     = {}
}

variable "layers" {
  description = "List of Lambda Layer Version ARNs (maximum of 5) to attach to your Lambda Function."
  type        = list(string)
  default     = []

  validation {
    condition     = length(var.layers) <= 5
    error_message = "You can attach a maximum of 5 Lambda Layer Versions."
  }
}

variable "tags" {
  description = "A map of tags to assign to the Lambda function."
  type        = map(string)
  default     = {}

}

variable "region" {
  description = "The AWS region where the Lambda function will be deployed."
  type        = string
}
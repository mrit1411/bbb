output "id" {
  value = azurerm_storage_account.storage_account.id
}

output "account_name" {
  value = azurerm_storage_account.storage_account.name
}

output "primary_access_key" {
  value = azurerm_storage_account.storage_account.primary_access_key
}

output "container_name" {
  value = azurerm_storage_container.storage_container.name
}

output "container_id" {
  value = azurerm_storage_container.storage_container.id

}

output "blob_url" {
  value = azurerm_storage_blob.blob.url
}

output "blob_id" {
  value = azurerm_storage_blob.blob.id
}
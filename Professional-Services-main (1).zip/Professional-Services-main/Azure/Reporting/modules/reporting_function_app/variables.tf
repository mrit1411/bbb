variable "resource_group_name" {
  description = "The name of the Resource Group where the Windows Splunk Integration Function App should exist. Changing this forces a new Windows Splunk Integration Function App to be created."
  type        = string
}

variable "location" {
  description = "The Azure Region where the Windows Splunk Integration Function App should exist. Changing this forces a new Windows Splunk Integration Function App to be created."
  type        = string

  validation {
    condition     = contains(["norwayeast", "westeurope", "swedencentral"], var.location)
    error_message = "The supplied value is not in the accepted region list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "storage_account_name" {
  description = "The backend storage account name which will be used by this Splunk Integration Function App."
  type        = string
}

variable "storage_account_access_key" {
  description = "The access key which will be used to access the backend storage account for the Splunk Integration Function App. Conflicts with storage_uses_managed_identity."
  type        = string
}

variable "client_certificate_enabled" {
  description = "Should the Splunk Integration Function App use Client Certificates."
  type        = bool
  default     = false
}

variable "daily_memory_time_quota" {
  description = "The amount of memory in gigabyte-seconds that your application is allowed to consume per day. Setting this value only affects Splunk Integration Function Apps under the consumption plan."
  type        = number
  default     = 0
}

variable "https_only" {
  description = "Can the Splunk Integration Function App only be accessed via HTTPS?."
  type        = bool
  default     = false
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "functions_extension_version" {
  description = "The version of the Azure Functions runtime to use."
  type        = string
  default     = "~4"
}

variable "powershell_core_version" {
  description = "The version of PowerShell Core to use."
  type        = string
  default     = "7.4"
}

variable "blob_url" {
  description = "The URL of the splunk integration function zip blob which should be used for this Windows Splunk Integration Function App."
  type        = string
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}
variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment) # self hosted non production
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "service_plan_os_type" {
  description = "The operating system type of the Splunk Integration App Service Plan. Changing this forces a new Service Plan to be created."
  type        = string
  default     = "Windows"
}

variable "service_plan_sku_name" {
  description = "The SKU name of the Splunk Integration App Service Plan."
  type        = string
  default     = "Y1"
}

variable "maximum_elastic_worker_count" {
  description = "The maximum number of workers that can be allocated to this App Service Plan."
  type        = number
  default     = 1
}

variable "user_assigned_identity_ids" {
  description = "The list of user assigned identity IDs to assign to the Splunk Integration Function App. Changing this forces a new Windows Splunk Integration Function App to be created."
  type        = list(string)
}

variable "user_assigned_identity_resource_id" {
  description = "The resource ID of the user assigned identity to assign to the Splunk Integration Function App."
  type        = string

}

variable "per_site_scaling_enabled" {
  type        = string
  description = "Enabled?"
  default     = "true"
}

variable "client_id" {
  description = "Client ID of the Reporting Function UMI"
  type        = string
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_glue_trigger.glue_trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_trigger) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_name"></a> [client\_name](#input\_client\_name) | Enter the name of Client. Used to create the selected resource | `string` | n/a | yes |
| <a name="input_crawler_name"></a> [crawler\_name](#input\_crawler\_name) | The name of the crawler to be executed. | `string` | n/a | yes |
| <a name="input_schedule"></a> [schedule](#input\_schedule) | A cron expression used to specify the schedule. | `string` | n/a | yes |
| <a name="input_start_on_creation"></a> [start\_on\_creation](#input\_start\_on\_creation) | Set to true to start SCHEDULED and CONDITIONAL triggers when created. True is not supported for ON\_DEMAND triggers. | `bool` | `true` | no |
| <a name="input_type"></a> [type](#input\_type) | The type of trigger. Valid values are CONDITIONAL, EVENT, ON\_DEMAND, and SCHEDULED. | `string` | `"SCHEDULED"` | no |

## Outputs

No outputs.

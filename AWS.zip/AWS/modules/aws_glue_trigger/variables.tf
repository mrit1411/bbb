variable "client_name" {
  description = "Enter the name of Client. Used to create the selected resource"
  type        = string
}

variable "type" {
  description = "The type of trigger. Valid values are CONDITIONAL, EVENT, ON_DEMAND, and SCHEDULED."
  type        = string
  default     = "SCHEDULED"
}

variable "start_on_creation" {
  description = "Set to true to start SCHEDULED and CONDITIONAL triggers when created. True is not supported for ON_DEMAND triggers."
  type        = bool
  default     = true
}

variable "schedule" {
  description = "A cron expression used to specify the schedule."
  type        = string
}

variable "crawler_name" {
  description = "The name of the crawler to be executed."
  type        = string
}
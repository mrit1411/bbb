tags = {
  "ccs_managed" = "yes"
}
resource_group_name                 = "rg-prd-eaf-euw"
ops_dashboard_workbook_display_name = "AzureOpsDashboard2"

location                                  = "West US 2"

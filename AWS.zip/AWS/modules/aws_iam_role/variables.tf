variable "description" {
  description = "Description of the IAM role"
  type        = string
}

variable "assume_role_policy" {
  description = "Policy that grants an entity permission to assume the role."
  type        = string
  default     = ""
}

variable "path" {
  description = "The path for the IAM role."
  type        = string
  default     = "/"
}

variable "managed_policy_arns" {
  description = "List of ARNs of managed policies to attach to the role."
  type        = list(string)
  default     = []
}

# variable "inline_policy_name" {
#   description = "Name of the inline policy to attach to the role."
#   type        = string
# }

# variable "inline_policy" {
#   description = "Inline policy document to attach to the role."
#   type        = string
# }

variable "inline_policies" {
  description = "Map of inline policies to attach to the role."
  type = map(object({
    inline_policy_name = string
    inline_policy      = string
  }))
  default = {}

}

variable "resource_type" {
  description = "Type of the resource, e.g., 'lambda', 'ec2', etc."
  type        = string
}

variable "context" {
  description = "Context for the resource, e.g., 'availability', 'events', etc."
  type        = string
}

variable "location" {
  description = "Azure region for resources"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the existing resource group"
  type        = string
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(string)
}

variable "sub_id" {
  description = "Subscription ID to be amended to Dynamic Scope name"
  type        = string
}

variable "sub_b_id" {
  description = "Subscription ID to be amended to Dynamic Scope name"
  type        = string
}


variable "windows_maintenance_configs" {
  description = "A mapping of variables required for windows maintenance configuration"
  type = map(object({
    name                 = string
    location             = string
    resource_group_name  = string
    reboot               = bool
    start_date_time      = string
    expiration_date_time = string
    kb_numbers_windows   = list(string)
    #classifications_windows   = list(string)
  }))
}




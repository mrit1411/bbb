variable "log_analytics_workspace_sku" {
  description = "The SKU of the Log Analytics Workspace"
  type        = string
}

variable "log_analytics_workspace_retention_in_days" {
  description = "The retention in days of the Log Analytics Workspace"
  type        = number
}

variable "resource_group_name" {
  description = "The name of the resource group in which the Monitoring resources will be created"
  type        = string
}

variable "iaas_law_rg_name" {
  description = "The name of the resource group in which the IaaS LAW will be created"
  type        = string
}

variable "location" {
  description = "The location in which the Monitoring resources will be created"
  type        = string
}

variable "tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
}

variable "data_sources" {
  description = "A list of data sources to be collected by the data collection rule."
  type = list(object({
    name                          = string
    type                          = string
    streams                       = list(string)
    sampling_frequency_in_seconds = optional(number)
    counter_specifiers            = optional(list(string))
    x_path_queries                = optional(list(string))
  }))

  default = []
}

variable "data_flows" {
  description = "A list of data flows to be defined by the data collection rule."
  type = list(object({
    streams       = list(string)
    output_stream = optional(string)
    transform_kql = optional(string)
  }))
  
    default = []
}

variable "splunk_integration_function_zip_name" {
  description = "The name of the Splunk Integration function zip file"
  type        = string
}

variable "splunk_integration_function_zip_path" {
  description = "The path to the Splunk Integration function zip file"
  type        = string
}

# PROD Environment variables for Splunk Integration Key Vault

variable "splunk_integration_prod_client_id_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client ID. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_prod_client_id_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client ID. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "splunk_integration_prod_client_secret_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client secret. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_prod_client_secret_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client secret. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

# TEST Environment variables for Splunk Integration Key Vault

variable "splunk_integration_test_client_id_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client ID. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_test_client_id_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client ID. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "splunk_integration_test_client_secret_secret_name" {
  description = "The name of the Splunk Integration Key Vault secret for the client secret. Changing this forces a new resource to be created."
  type        = string
}

variable "splunk_integration_test_client_secret_secret_value" {
  description = "The value of the Splunk Integration Key Vault secret for the client secret. Changing this will create a new version of the Key Vault Secret."
  type        = string
}

variable "terraform_vm_mi_object_id" {
  description = "The terraform VM Managed Identity object ID"
  type        = string
}

variable "func_sami_object_id" {
  description = "The Splunk Integration SAMI object ID"
  type        = string
}

variable "monitoring_tag_name" {
  description = "The name of the tag used for monitoring"
  type        = string
  default     = "ccs_monitoring"
}

variable "policy_management_group_id" {
  description = "The management group ID for the policy assignment"
  type        = list(string)
}

variable "prod_action_group_short_name" {
  description = "The short name of the action group"
  type        = string
}

variable "test_action_group_short_name" {
  description = "The short name of the action group"
  type        = string
}

variable "azure_prod_function_receiver_name" {
  description = "The name of the Azure Function receiver"
  type        = string
}

variable "azure_test_function_receiver_name" {
  description = "The name of the Azure Function receiver"
  type        = string
}

variable "prod_splunk_integration_function_name" {
  description = "The name of the Splunk Integration function"
  type        = string
}

variable "test_splunk_integration_function_name" {
  description = "The name of the Splunk Integration function"
  type        = string
}

variable "severity" {
  description = "The severity of the alert rule"
  type        = number
  default     = 4
}

variable "evaluation_frequency" {
  description = "The evaluation frequency of the alert rule"
  type        = string
  default     = "PT5M"
}

variable "window_duration" {
  description = "The window duration of the alert rule"
  type        = string
  default     = "PT5M"
}

variable "policy_assignment_user_assigned_identity_ids" {
  description = "The user assigned identity IDs for the Monitoring policy"
  type        = list(string)
}

variable "monitoring_tag_value" {
  description = "The value of the tag used for monitoring"
  type        = string
  default     = "yes"
}

variable "create_cos_log_analytics_workspace" {
  description = "Whether to create a new Log Analytics Workspace?"
  type        = bool
  default     = true
}

variable "existing_log_analytics_workspace_name" {
  description = "The name of the existing Log Analytics Workspace"
  type        = string
  default     = ""

  validation {
    condition     = var.create_cos_log_analytics_workspace || (length(var.existing_log_analytics_workspace_name) > 0)
    error_message = "You must provide an existing Log Analytics Workspace name when not creating a new one."
  }
}

variable "existing_law_resource_group_name" {
  description = "The name of the resource group in which the existing Log Analytics Workspace is located"
  type        = string
  default     = ""

  validation {
    condition     = var.create_cos_log_analytics_workspace || (length(var.existing_law_resource_group_name) > 0)
    error_message = "You must provide an existing Log Analytics Workspace resource group name when not creating a new one."
  }
}

variable "cos_ama_mi_name" {
  description = "The name of the Managed Identity for the COS Azure Monitoring Agent"
  type        = string
}

variable "cos_ama_mi_id" {
  description = "The ID of the Managed Identity for the COS Azure Monitoring Agent"
  type        = string
}

variable "splunk_integration_user_assigned_identity_ids" {
  description = "The user assigned identity IDs for the Splunk Integration Function App"
  type        = list(string)
}

variable "splunk_integration_package_mi_resource_id" {
  description = "The resource ID of the user assigned identity for the Splunk Integration run from package setting"
  type        = string
}

variable "project-shortname" {
  type        = string
  description = "(Required) The project identifier which should be used for this Resource Group. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.project-shortname) >= 1
    error_message = "Project shortname must be defined"
  }
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}

variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment)
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

# variable "security_subscription_id" {
#   type        = string
#   description = "The subscription ID of the security subscription"
# }


# variable "paas_metric_alert_target_resources" {
#   type = map(object({
#     resourceid  = string
#     name        = string
#     metric_name = list(string)
#   }))
#   description = "list of target resource id"
# }

variable "ct_dcr_id" {
  description = "Resource ID of the Change Tracking Resource ID"
  type        = string
}

variable "policy_subscription_id" {
  description = "Subscription ID where to create policy assignment"
  type        = string
}

# Below variables are used for paas monitoring policies
# Define your list of subscriptions
# variable "subscription_ids" {
#   type = list(string)
# }
#
# variable "management_group_ids" {
#   type = list(string)
# }
# # Use a single variable for resource type, display name, and policy rule filename
# variable "resource_types" {
#   type = list(object({
#     type             = string
#     display_name     = string
#     policy_rule_file = string
#   }))
#   description = "A list of objects with resource type, display name, and policy rule filename."
# }

variable "mssql_database_alert_rules" {
  description = "List of MSSQL database alert rules to be created."
  type = list(object({
    name                    = string
    description             = string
    severity                = number
    evaluation_frequency    = string
    window_duration         = string
    operator                = string
    threshold               = number
    time_aggregation_method = string
    metric_measure_column   = string
    resource_id_column      = string

    dimensions = list(object({
      name     = string
      operator = string
      values   = list(string)
    }))

    query = string
  }))

  default = []
}


variable "paas_alerts_map" {
  type = map(object({
    name                         = string
    operator                     = string
    threshold                    = number
    time_aggregation_method      = string
    query                        = string
    minimum_failing_periods      = number
    number_of_evaluation_periods = number
    severity                     = number
    evaluation_frequency         = string
    window_duration              = string
    description                  = string
    enabled                      = bool
    auto_mitigation_enabled      = optional(bool,true)

  }))
  description = "Map of alert configurations"
}

variable "resource_types" {
  type = list(object({
    type             = string
    display_name     = string
    policy_rule_file = string
  }))
  description = "A list of objects with resource type, display name, and policy rule filename."
}
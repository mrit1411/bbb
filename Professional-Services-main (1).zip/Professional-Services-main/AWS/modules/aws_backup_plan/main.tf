resource "aws_backup_plan" "backup_plan" {
  name = local.name
  region = var.region

  advanced_backup_setting {
    resource_type = var.backup_setting_resource_type
    backup_options = {
      WindowsVSS = var.backup_setting_windows_vss ? "enabled" : "disabled"
    }
  }

  dynamic "rule" {
    for_each = var.rules
    content {
      rule_name         = rule.value.rule_name
      schedule          = rule.value.schedule
      completion_window = rule.value.completion_window
      start_window      = rule.value.start_window
      target_vault_name = rule.value.target_vault_name
      lifecycle {
        delete_after = rule.value.delete_after
      }
      recovery_point_tags = rule.value.recovery_point_tags

      # Cross-region copy (optional). One copy_action block per entry in
      # rule.value.copy_actions. Empty list (the default) = no copy_action
      # block at all, i.e. exactly the same plan as before this change.
      dynamic "copy_action" {
        for_each = rule.value.copy_actions
        content {
          destination_vault_arn = copy_action.value.destination_vault_arn

          dynamic "lifecycle" {
            for_each = copy_action.value.delete_after != null ? [1] : []
            content {
              delete_after = copy_action.value.delete_after
            }
          }
        }
      }
    }
  }

  tags = var.tags
}
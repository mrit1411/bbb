variable "resource_group_name" {
  description = "The name of the resource group in which the Monitoring resources will be created"
  type        = string
}

variable "location" {
  description = "The location in which the Monitoring resources will be created"
  type        = string
}

variable "tags" {
  description = "A mapping of tags to assign to the resource"
  type        = map(string)
}

variable "reporting_function_zip_name" {
  description = "The name of the Splunk Integration function zip file"
  type        = string
}

variable "reporting_function_zip_path" {
  description = "The path to the Splunk Integration function zip file"
  type        = string
}

variable "reporting_function_user_assigned_identity_ids" {
  description = "The user assigned identity IDs for the Reporting Function App"
  type        = list(string)
}

variable "client_id_resource_id" {
  description = "The resource ID of the client ID for the UMI"
  type        = string
}

variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment)
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "client_id" {
  description = "Client ID of the Reporting Function UMI"
  type        = string
}
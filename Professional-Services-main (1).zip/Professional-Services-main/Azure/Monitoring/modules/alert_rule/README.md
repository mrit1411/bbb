﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_scheduled_query_rules_alert_v2.alert_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_scheduled_query_rules_alert_v2) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_id"></a> [action\_group\_id](#input\_action\_group\_id) | List of Action Group resource IDs to invoke when the alert fires. | `list(string)` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | Description of the alert rule | `string` | n/a | yes |
| <a name="input_dimension_name"></a> [dimension\_name](#input\_dimension\_name) | Name of the dimension for the alert rule criteria | `string` | `""` | no |
| <a name="input_dimension_operator"></a> [dimension\_operator](#input\_dimension\_operator) | Operator for the dimension in the alert rule criteria | `string` | `"Include"` | no |
| <a name="input_dimension_values"></a> [dimension\_values](#input\_dimension\_values) | Values for the dimension in the alert rule criteria | `list(string)` | <pre>[<br/>  "*"<br/>]</pre> | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Whether the alert rule is enabled | `bool` | `true` | no |
| <a name="input_evaluation_frequency"></a> [evaluation\_frequency](#input\_evaluation\_frequency) | How often the scheduled query rule is evaluated, represented in ISO 8601 duration format. Possible values are PT1M, PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, PT6H, P1D. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure location where the Monitor Scheduled Query Rule should exist. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_metric_measure_column"></a> [metric\_measure\_column](#input\_metric\_measure\_column) | Metric measure column for the alert rule criteria | `string` | `""` | no |
| <a name="input_minimum_failing_periods"></a> [minimum\_failing\_periods](#input\_minimum\_failing\_periods) | Minimum number of failing periods to trigger the alert | `number` | `1` | no |
| <a name="input_name"></a> [name](#input\_name) | Specifies the name which should be used for this Monitor Scheduled Query Rule. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_number_of_evaluation_periods"></a> [number\_of\_evaluation\_periods](#input\_number\_of\_evaluation\_periods) | Number of evaluation periods to consider for the alert | `number` | `1` | no |
| <a name="input_operator"></a> [operator](#input\_operator) | Operator for the alert rule criteria (e.g. GreaterThan, LessThan) | `string` | n/a | yes |
| <a name="input_query"></a> [query](#input\_query) | Kusto query for the alert rule criteria | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the Monitor Scheduled Query Rule. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_resource_id_column"></a> [resource\_id\_column](#input\_resource\_id\_column) | Resource ID column for the alert rule criteria | `string` | n/a | yes |
| <a name="input_scopes"></a> [scopes](#input\_scopes) | Specifies the list of resource IDs that this scheduled query rule is scoped to. Changing this forces a new resource to be created. Currently, the API supports exactly 1 resource ID in the scopes list. | `list(string)` | n/a | yes |
| <a name="input_severity"></a> [severity](#input\_severity) | Severity of the alert. Should be an integer between 0 and 4. Value of 0 is severest. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | <pre>{<br/>  "ccs_managed": "yes"<br/>}</pre> | no |
| <a name="input_threshold"></a> [threshold](#input\_threshold) | Threshold value for the alert rule criteria | `number` | n/a | yes |
| <a name="input_time_aggregation_method"></a> [time\_aggregation\_method](#input\_time\_aggregation\_method) | Time aggregation method for the alert rule criteria (e.g. Total, Average) | `string` | n/a | yes |
| <a name="input_window_duration"></a> [window\_duration](#input\_window\_duration) | Specifies the period of time in ISO 8601 duration format on which the Scheduled Query Rule will be executed (bin size). If evaluation\_frequency is PT1M, possible values are PT1M, PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, and PT6H. Otherwise, possible values are PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, PT6H, P1D, and P2D. | `string` | n/a | yes |

## Outputs

No outputs.

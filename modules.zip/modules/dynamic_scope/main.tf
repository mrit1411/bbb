terraform {
 required_providers {
   azurerm = {
     source                = "hashicorp/azurerm"
     configuration_aliases = [azurerm.sub1]
   }
 }
}
resource "azurerm_maintenance_assignment_dynamic_scope" "dynamic_scope" {
  name                         = var.name
  maintenance_configuration_id = var.maintenance_configuration_id

  filter {
    resource_types = ["Microsoft.Compute/virtualMachines"]
    tag_filter     = "All"

    dynamic "tags" {
      for_each = var.tag_filters
      content {
        tag    = tags.value.tag
        values = tags.value.values
      }
    }
  }
}
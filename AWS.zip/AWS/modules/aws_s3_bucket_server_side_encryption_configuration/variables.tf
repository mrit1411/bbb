variable "bucket" {
  description = "ID (name) of the bucket"
  type        = string
}

variable "sse_algorithm" {
  description = "Server-side encryption algorithm to use. Valid values are AES256, aws:kms, and aws:kms:dsse"
  type        = string
  default     = "AES256"
}

variable "region" {
  description = "The AWS region where the S3 bucket is located"
  type        = string
}
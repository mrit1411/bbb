locals {
  # Cross-region backup copy (see backup_vault_dr / ccs_backup_plan in main.tf).
  # Regions whose backups are copied to the DR vault. Empty when
  # enable_cross_region_backup_copy = false. A region equal to var.dr_region is
  # skipped (copy into the same region is not a cross-region copy).
  cross_region_copy_source_regions = var.enable_cross_region_backup_copy ? [
    for r in var.regions : r if r != var.dr_region
  ] : []

  # true only when at least one region actually needs copying.
  cross_region_copy_active = length(local.cross_region_copy_source_regions) > 0
}

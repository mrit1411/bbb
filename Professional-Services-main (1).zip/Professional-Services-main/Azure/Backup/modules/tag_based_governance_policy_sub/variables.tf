variable "subscription_id" {
  description = "Subscription ID where to define and assign the policy"
  type        = string
}

variable "name" {
  description = "The name of the policy definition. Changing this forces a new resource to be created."
  type        = string
  default     = "org - CCS Backup For VM"
}

variable "user_assigned_identity_ids" {
  description = "List of user assigned managed identites for policy assignment"
  type        = list(string)
}

variable "location" {
  description = "Azure region where resources are deployed"
  type        = string
}

variable "policy_assignment_parameters" {
  description = "The parameters for the policy assignment."
  type        = string
  default     = ""
}

variable "policy_definition_id" {
  description = "The ID of the policy definition to assign."
  type        = string
}

resource "azurerm_recovery_services_vault" "vault" {
  for_each = var.resource_group_name_map

  name                = "${var.recovery_vault_name_prefix}${lower(each.key)}"
  location            = each.key
  resource_group_name = each.value
  sku                 = var.vault_sku
  # soft_delete_enabled = var.soft_delete_enabled
  storage_mode_type = var.storage_mode_type

  # identity {
  #   type = "SystemAssigned"
  # }
  tags = var.tags
}

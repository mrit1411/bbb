variable "client_name" {
  description = "Enter the name of Client. Used to create the selected resource"
  type        = string
}

variable "description" {
  description = "Description of the workgroup."
  type        = string
}

variable "state" {
  description = "Whether to enable of the workgroup."
  type        = bool
  default     = true
}

variable "enforce_workgroup_configuration" {
  description = "Boolean whether the settings for the workgroup override client-side settings."
  type        = bool
}

variable "publish_cloudwatch_metrics_enabled" {
  description = "Boolean whether Amazon CloudWatch metrics are enabled for the workgroup."
  type        = bool
}

variable "output_location" {
  description = "Location in Amazon S3 where your query results are stored"
  type        = string
}
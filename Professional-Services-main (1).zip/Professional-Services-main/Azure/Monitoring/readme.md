

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.22.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.22.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_action_group"></a> [action\_group](#module\_action\_group) | ./modules/splunk_integration_action_group | n/a |
| <a name="module_action_group_test"></a> [action\_group\_test](#module\_action\_group\_test) | ./modules/splunk_integration_action_group | n/a |
| <a name="module_assign_umi_policy"></a> [assign\_umi\_policy](#module\_assign\_umi\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_assign_umi_policy_sub"></a> [assign\_umi\_policy\_sub](#module\_assign\_umi\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_ccs_paas_azure_event_hub_namespace_cpu_usage"></a> [ccs\_paas\_azure\_event\_hub\_namespace\_cpu\_usage](#module\_ccs\_paas\_azure\_event\_hub\_namespace\_cpu\_usage) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_event_hub_namespace_memory_usage"></a> [ccs\_paas\_azure\_event\_hub\_namespace\_memory\_usage](#module\_ccs\_paas\_azure\_event\_hub\_namespace\_memory\_usage) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_event_hub_namespace_server_errors"></a> [ccs\_paas\_azure\_event\_hub\_namespace\_server\_errors](#module\_ccs\_paas\_azure\_event\_hub\_namespace\_server\_errors) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_service_bus_namespace_active_messages"></a> [ccs\_paas\_azure\_service\_bus\_namespace\_active\_messages](#module\_ccs\_paas\_azure\_service\_bus\_namespace\_active\_messages) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_service_bus_namespace_deadlettered_messages"></a> [ccs\_paas\_azure\_service\_bus\_namespace\_deadlettered\_messages](#module\_ccs\_paas\_azure\_service\_bus\_namespace\_deadlettered\_messages) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_service_bus_namespace_memory_usage"></a> [ccs\_paas\_azure\_service\_bus\_namespace\_memory\_usage](#module\_ccs\_paas\_azure\_service\_bus\_namespace\_memory\_usage) | ./modules/paas_metric_alerts | n/a |
| <a name="module_ccs_paas_azure_service_bus_namespace_throttled_requests"></a> [ccs\_paas\_azure\_service\_bus\_namespace\_throttled\_requests](#module\_ccs\_paas\_azure\_service\_bus\_namespace\_throttled\_requests) | ./modules/paas_metric_alerts | n/a |
| <a name="module_cos_azure_data_collection_rule"></a> [cos\_azure\_data\_collection\_rule](#module\_cos\_azure\_data\_collection\_rule) | ./modules/data_collection_rule | n/a |
| <a name="module_cos_iaas_azure_log_analytics_workspace"></a> [cos\_iaas\_azure\_log\_analytics\_workspace](#module\_cos\_iaas\_azure\_log\_analytics\_workspace) | ./modules/log_analytics_workspace | n/a |
| <a name="module_cos_paas_azure_log_analytics_workspace"></a> [cos\_paas\_azure\_log\_analytics\_workspace](#module\_cos\_paas\_azure\_log\_analytics\_workspace) | ./modules/log_analytics_workspace | n/a |
| <a name="module_diagnostic_settings_rsv_policy"></a> [diagnostic\_settings\_rsv\_policy](#module\_diagnostic\_settings\_rsv\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_diagnostic_settings_rsv_policy_sub"></a> [diagnostic\_settings\_rsv\_policy\_sub](#module\_diagnostic\_settings\_rsv\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_iaas_alert_rule_ama_heartbeat_stopped"></a> [iaas\_alert\_rule\_ama\_heartbeat\_stopped](#module\_iaas\_alert\_rule\_ama\_heartbeat\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_ama_service_stopped"></a> [iaas\_alert\_rule\_ama\_service\_stopped](#module\_iaas\_alert\_rule\_ama\_service\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_backup_failed"></a> [iaas\_alert\_rule\_backup\_failed](#module\_iaas\_alert\_rule\_backup\_failed) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_cpu_usage"></a> [iaas\_alert\_rule\_cpu\_usage](#module\_iaas\_alert\_rule\_cpu\_usage) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_dependency_agent_service_stopped"></a> [iaas\_alert\_rule\_dependency\_agent\_service\_stopped](#module\_iaas\_alert\_rule\_dependency\_agent\_service\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_disk_free_space"></a> [iaas\_alert\_rule\_disk\_free\_space](#module\_iaas\_alert\_rule\_disk\_free\_space) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_disk_free_space_test"></a> [iaas\_alert\_rule\_disk\_free\_space\_test](#module\_iaas\_alert\_rule\_disk\_free\_space\_test) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_guest_service_stopped"></a> [iaas\_alert\_rule\_guest\_service\_stopped](#module\_iaas\_alert\_rule\_guest\_service\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_heartbeat"></a> [iaas\_alert\_rule\_heartbeat](#module\_iaas\_alert\_rule\_heartbeat) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_heartbeat_test"></a> [iaas\_alert\_rule\_heartbeat\_test](#module\_iaas\_alert\_rule\_heartbeat\_test) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_memory_usage"></a> [iaas\_alert\_rule\_memory\_usage](#module\_iaas\_alert\_rule\_memory\_usage) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_remote_service_stopped"></a> [iaas\_alert\_rule\_remote\_service\_stopped](#module\_iaas\_alert\_rule\_remote\_service\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_ssh_stopped"></a> [iaas\_alert\_rule\_ssh\_stopped](#module\_iaas\_alert\_rule\_ssh\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_iaas_alert_rule_syslog_stopped"></a> [iaas\_alert\_rule\_syslog\_stopped](#module\_iaas\_alert\_rule\_syslog\_stopped) | ./modules/alert_rule | n/a |
| <a name="module_linux_ama_agent_policy"></a> [linux\_ama\_agent\_policy](#module\_linux\_ama\_agent\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_linux_ama_agent_policy_sub"></a> [linux\_ama\_agent\_policy\_sub](#module\_linux\_ama\_agent\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_linux_change_tracking_policy"></a> [linux\_change\_tracking\_policy](#module\_linux\_change\_tracking\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_linux_change_tracking_policy_sub"></a> [linux\_change\_tracking\_policy\_sub](#module\_linux\_change\_tracking\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_linux_ct_dcr_association_policy"></a> [linux\_ct\_dcr\_association\_policy](#module\_linux\_ct\_dcr\_association\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_linux_ct_dcr_association_policy_sub"></a> [linux\_ct\_dcr\_association\_policy\_sub](#module\_linux\_ct\_dcr\_association\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_linux_dcr_association_policy"></a> [linux\_dcr\_association\_policy](#module\_linux\_dcr\_association\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_linux_dcr_association_policy_sub"></a> [linux\_dcr\_association\_policy\_sub](#module\_linux\_dcr\_association\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_linux_dependency_agent_policy"></a> [linux\_dependency\_agent\_policy](#module\_linux\_dependency\_agent\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_linux_dependency_agent_policy_sub"></a> [linux\_dependency\_agent\_policy\_sub](#module\_linux\_dependency\_agent\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_paas_alert_rules"></a> [paas\_alert\_rules](#module\_paas\_alert\_rules) | ./modules/paas_alert_rules | n/a |
| <a name="module_paas_alert_rules_test"></a> [paas\_alert\_rules\_test](#module\_paas\_alert\_rules\_test) | ./modules/paas_alert_rules | n/a |
| <a name="module_paas_diagnostic_settings"></a> [paas\_diagnostic\_settings](#module\_paas\_diagnostic\_settings) | ./modules/diagnostic_settings | n/a |
| <a name="module_splunk_integration_function_app"></a> [splunk\_integration\_function\_app](#module\_splunk\_integration\_function\_app) | ./modules/splunk_integration_function_app | n/a |
| <a name="module_splunk_integration_key_vault"></a> [splunk\_integration\_key\_vault](#module\_splunk\_integration\_key\_vault) | ./modules/splunk_integration_key_vault | n/a |
| <a name="module_splunk_integration_storage"></a> [splunk\_integration\_storage](#module\_splunk\_integration\_storage) | ./modules/splunk_integration_storage_module | n/a |
| <a name="module_tag_non_prod_dependency_policy"></a> [tag\_non\_prod\_dependency\_policy](#module\_tag\_non\_prod\_dependency\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_tag_non_prod_dependency_policy_sub"></a> [tag\_non\_prod\_dependency\_policy\_sub](#module\_tag\_non\_prod\_dependency\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_tag_non_prod_non_dependency_policy"></a> [tag\_non\_prod\_non\_dependency\_policy](#module\_tag\_non\_prod\_non\_dependency\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_tag_non_prod_non_dependency_policy_sub"></a> [tag\_non\_prod\_non\_dependency\_policy\_sub](#module\_tag\_non\_prod\_non\_dependency\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_tag_prod_dependency_policy"></a> [tag\_prod\_dependency\_policy](#module\_tag\_prod\_dependency\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_tag_prod_dependency_policy_sub"></a> [tag\_prod\_dependency\_policy\_sub](#module\_tag\_prod\_dependency\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_tag_prod_non_dependency_policy"></a> [tag\_prod\_non\_dependency\_policy](#module\_tag\_prod\_non\_dependency\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_tag_prod_non_dependency_policy_sub"></a> [tag\_prod\_non\_dependency\_policy\_sub](#module\_tag\_prod\_non\_dependency\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_windows_ama_agent_policy"></a> [windows\_ama\_agent\_policy](#module\_windows\_ama\_agent\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_windows_ama_agent_policy_sub"></a> [windows\_ama\_agent\_policy\_sub](#module\_windows\_ama\_agent\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_windows_change_tracking_policy"></a> [windows\_change\_tracking\_policy](#module\_windows\_change\_tracking\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_windows_change_tracking_policy_sub"></a> [windows\_change\_tracking\_policy\_sub](#module\_windows\_change\_tracking\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_windows_ct_dcr_association_policy"></a> [windows\_ct\_dcr\_association\_policy](#module\_windows\_ct\_dcr\_association\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_windows_ct_dcr_association_policy_sub"></a> [windows\_ct\_dcr\_association\_policy\_sub](#module\_windows\_ct\_dcr\_association\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_windows_dcr_association_policy"></a> [windows\_dcr\_association\_policy](#module\_windows\_dcr\_association\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_windows_dcr_association_policy_sub"></a> [windows\_dcr\_association\_policy\_sub](#module\_windows\_dcr\_association\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |
| <a name="module_windows_dependency_agent_policy"></a> [windows\_dependency\_agent\_policy](#module\_windows\_dependency\_agent\_policy) | ./modules/tag_based_governance_policy | n/a |
| <a name="module_windows_dependency_agent_policy_sub"></a> [windows\_dependency\_agent\_policy\_sub](#module\_windows\_dependency\_agent\_policy\_sub) | ./modules/tag_based_governance_policy_sub | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.22.0/docs/data-sources/client_config) | data source |
| [azurerm_function_app_host_keys.splunk_integration_function_app](https://registry.terraform.io/providers/hashicorp/azurerm/4.22.0/docs/data-sources/function_app_host_keys) | data source |
| [azurerm_log_analytics_workspace.existing_log_analytics_workspace](https://registry.terraform.io/providers/hashicorp/azurerm/4.22.0/docs/data-sources/log_analytics_workspace) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_short_name"></a> [action\_group\_short\_name](#input\_action\_group\_short\_name) | The short name of the action group | `string` | n/a | yes |
| <a name="input_azure_function_receiver_name"></a> [azure\_function\_receiver\_name](#input\_azure\_function\_receiver\_name) | The name of the Azure Function receiver | `string` | n/a | yes |
| <a name="input_context"></a> [context](#input\_context) | (Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cos_ama_mi_id"></a> [cos\_ama\_mi\_id](#input\_cos\_ama\_mi\_id) | The ID of the Managed Identity for the COS Azure Monitoring Agent | `string` | n/a | yes |
| <a name="input_cos_ama_mi_name"></a> [cos\_ama\_mi\_name](#input\_cos\_ama\_mi\_name) | The name of the Managed Identity for the COS Azure Monitoring Agent | `string` | n/a | yes |
| <a name="input_create_cos_log_analytics_workspace"></a> [create\_cos\_log\_analytics\_workspace](#input\_create\_cos\_log\_analytics\_workspace) | Whether to create a new Log Analytics Workspace? | `bool` | `true` | no |
| <a name="input_ct_dcr_id"></a> [ct\_dcr\_id](#input\_ct\_dcr\_id) | Resource ID of the Change Tracking Resource ID | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_evaluation_frequency"></a> [evaluation\_frequency](#input\_evaluation\_frequency) | The evaluation frequency of the alert rule | `string` | `"PT5M"` | no |
| <a name="input_existing_law_resource_group_name"></a> [existing\_law\_resource\_group\_name](#input\_existing\_law\_resource\_group\_name) | The name of the resource group in which the existing Log Analytics Workspace is located | `string` | `""` | no |
| <a name="input_existing_log_analytics_workspace_name"></a> [existing\_log\_analytics\_workspace\_name](#input\_existing\_log\_analytics\_workspace\_name) | The name of the existing Log Analytics Workspace | `string` | `""` | no |
| <a name="input_func_sami_object_id"></a> [func\_sami\_object\_id](#input\_func\_sami\_object\_id) | The Splunk Integration SAMI object ID | `string` | n/a | yes |
| <a name="input_iaas_law_rg_name"></a> [iaas\_law\_rg\_name](#input\_iaas\_law\_rg\_name) | The name of the resource group in which the IaaS LAW will be created | `string` | n/a | yes |
| <a name="input_index"></a> [index](#input\_index) | (Required) The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | The location in which the Monitoring resources will be created | `string` | n/a | yes |
| <a name="input_log_analytics_workspace_retention_in_days"></a> [log\_analytics\_workspace\_retention\_in\_days](#input\_log\_analytics\_workspace\_retention\_in\_days) | The retention in days of the Log Analytics Workspace | `number` | n/a | yes |
| <a name="input_log_analytics_workspace_sku"></a> [log\_analytics\_workspace\_sku](#input\_log\_analytics\_workspace\_sku) | The SKU of the Log Analytics Workspace | `string` | n/a | yes |
| <a name="input_monitoring_tag_name"></a> [monitoring\_tag\_name](#input\_monitoring\_tag\_name) | The name of the tag used for monitoring | `string` | `"ccs_managed"` | no |
| <a name="input_monitoring_tag_value"></a> [monitoring\_tag\_value](#input\_monitoring\_tag\_value) | The value of the tag used for monitoring | `string` | `"yes"` | no |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_paas_alerts_map"></a> [paas\_alerts\_map](#input\_paas\_alerts\_map) | Map of alert configurations | <pre>map(object({<br/>    name                         = string<br/>    operator                     = string<br/>    threshold                    = number<br/>    time_aggregation_method      = string<br/>    query                        = string<br/>    minimum_failing_periods      = number<br/>    number_of_evaluation_periods = number<br/>    severity                     = number<br/>    evaluation_frequency         = string<br/>    window_duration              = string<br/>    description                  = string<br/>    enabled                      = bool<br/><br/><br/>  }))</pre> | n/a | yes |
| <a name="input_paas_alerts_map_test"></a> [paas\_alerts\_map\_test](#input\_paas\_alerts\_map\_test) | Map of alert configurations | <pre>map(object({<br/>    name                         = string<br/>    operator                     = string<br/>    threshold                    = number<br/>    time_aggregation_method      = string<br/>    query                        = string<br/>    minimum_failing_periods      = number<br/>    number_of_evaluation_periods = number<br/>    severity                     = number<br/>    evaluation_frequency         = string<br/>    window_duration              = string<br/>    description                  = string<br/>    enabled                      = bool<br/><br/><br/>  }))</pre> | n/a | yes |
| <a name="input_paas_metric_alert_target_resources"></a> [paas\_metric\_alert\_target\_resources](#input\_paas\_metric\_alert\_target\_resources) | list of target resource id | <pre>map(object({<br/>    resourceid  = string<br/>    name        = string<br/>    metric_name = list(string)<br/>  }))</pre> | n/a | yes |
| <a name="input_policy_assignment_user_assigned_identity_ids"></a> [policy\_assignment\_user\_assigned\_identity\_ids](#input\_policy\_assignment\_user\_assigned\_identity\_ids) | The user assigned identity IDs for the Monitoring policy | `list(string)` | n/a | yes |
| <a name="input_policy_management_group_id"></a> [policy\_management\_group\_id](#input\_policy\_management\_group\_id) | The management group ID for the policy assignment | `list(string)` | n/a | yes |
| <a name="input_policy_subscription_id"></a> [policy\_subscription\_id](#input\_policy\_subscription\_id) | Subscription ID where to create policy assignment | `string` | n/a | yes |
| <a name="input_project-shortname"></a> [project-shortname](#input\_project-shortname) | (Required) The project identifier which should be used for this Resource Group. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which the Monitoring resources will be created | `string` | n/a | yes |
| <a name="input_security_subscription_id"></a> [security\_subscription\_id](#input\_security\_subscription\_id) | The subscription ID of the security subscription | `string` | n/a | yes |
| <a name="input_severity"></a> [severity](#input\_severity) | The severity of the alert rule | `number` | `4` | no |
| <a name="input_splunk_integration_client_id_secret_name"></a> [splunk\_integration\_client\_id\_secret\_name](#input\_splunk\_integration\_client\_id\_secret\_name) | The name of the secret in the Key Vault that will contain the Splunk Integration client ID | `string` | n/a | yes |
| <a name="input_splunk_integration_client_id_secret_value"></a> [splunk\_integration\_client\_id\_secret\_value](#input\_splunk\_integration\_client\_id\_secret\_value) | The value of the Splunk Integration client ID | `string` | n/a | yes |
| <a name="input_splunk_integration_client_secret_secret_name"></a> [splunk\_integration\_client\_secret\_secret\_name](#input\_splunk\_integration\_client\_secret\_secret\_name) | The name of the secret in the Key Vault that contains the Splunk Integration client secret | `string` | n/a | yes |
| <a name="input_splunk_integration_client_secret_secret_value"></a> [splunk\_integration\_client\_secret\_secret\_value](#input\_splunk\_integration\_client\_secret\_secret\_value) | The value of the Splunk Integration client secret | `string` | n/a | yes |
| <a name="input_splunk_integration_function_name"></a> [splunk\_integration\_function\_name](#input\_splunk\_integration\_function\_name) | The name of the Splunk Integration function | `string` | n/a | yes |
| <a name="input_splunk_integration_function_zip_name"></a> [splunk\_integration\_function\_zip\_name](#input\_splunk\_integration\_function\_zip\_name) | The name of the Splunk Integration function zip file | `string` | n/a | yes |
| <a name="input_splunk_integration_function_zip_path"></a> [splunk\_integration\_function\_zip\_path](#input\_splunk\_integration\_function\_zip\_path) | The path to the Splunk Integration function zip file | `string` | n/a | yes |
| <a name="input_splunk_integration_package_mi_resource_id"></a> [splunk\_integration\_package\_mi\_resource\_id](#input\_splunk\_integration\_package\_mi\_resource\_id) | The resource ID of the user assigned identity for the Splunk Integration run from package setting | `string` | n/a | yes |
| <a name="input_splunk_integration_user_assigned_identity_ids"></a> [splunk\_integration\_user\_assigned\_identity\_ids](#input\_splunk\_integration\_user\_assigned\_identity\_ids) | The user assigned identity IDs for the Splunk Integration Function App | `list(string)` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource | `map(string)` | n/a | yes |
| <a name="input_terraform_vm_mi_object_id"></a> [terraform\_vm\_mi\_object\_id](#input\_terraform\_vm\_mi\_object\_id) | The terraform VM Managed Identity object ID | `string` | n/a | yes |
| <a name="input_window_duration"></a> [window\_duration](#input\_window\_duration) | The window duration of the alert rule | `string` | `"PT5M"` | no |

## Outputs

No outputs.

## Usage

Scenario 1: New VM in pre-existing CCS Management Group (Common apps, Identity, Controlled-sandbox, Security)

The Azure Policies are defined and assigned at the management group scope, so any new VMs created in subscriptions under these management groups will automatically be onboarded to the monitoring solution provided the VMs are created with the ccs_managed=yes tag.

Scenario 2: New VM in new Management Group

You will have to define and assign the Azure Policies in the new Management Group. Add the new management group's ID to the "policy_management_group_id" variable. Apply all the policy modules using the -target flag.

Note: When adding new Management Groups, the role assignment scopes of the "az-umi-org-no-ps-policyassignment-p-01", "az-umi-org-no-ps-ama-p-01" and "az-umi-org-no-ps-terraform-p-01" managed identities will also have to be updated.
<!-- END_TF_DOCS -->
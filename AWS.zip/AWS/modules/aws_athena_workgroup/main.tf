resource "aws_athena_workgroup" "athena_workgroup" {
  name        = local.name
  description = var.description
  state       = var.state ? "ENABLED" : "DISABLED"

  configuration {
    enforce_workgroup_configuration    = var.enforce_workgroup_configuration
    publish_cloudwatch_metrics_enabled = var.publish_cloudwatch_metrics_enabled

    result_configuration {
      output_location = var.output_location
    }
  }
}
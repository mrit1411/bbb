#The below data block will create the zip file as per the below path 
data "archive_file" "archive" {
  type        = "zip"
  source_dir  = "${path.module}/splunk_integration_code"
  output_path = "${path.module}/splunk_package/splunk_azure_integration_func.zip"

}

resource "azurerm_storage_account" "storage_account" {
  name                            = local.name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  account_tier                    = var.account_tier
  account_replication_type        = var.account_replication_type
  account_kind                    = var.account_kind
  https_traffic_only_enabled      = var.https_traffic_only_enabled
  is_hns_enabled                  = var.is_hns_enabled
  allow_nested_items_to_be_public = var.allow_nested_items_to_be_public
  #shared_access_key_enabled        = var.shared_access_key_enabled
  cross_tenant_replication_enabled = var.cross_tenant_replication_enabled

  network_rules {
    bypass                     = ["AzureServices"]
    default_action             = "Allow"
    ip_rules                   = []
    virtual_network_subnet_ids = []
  }

  blob_properties {
    versioning_enabled  = var.versioning_enabled
    change_feed_enabled = var.versioning_enabled
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [tags, network_rules]
  }
}

resource "azurerm_storage_account_network_rules" "deny" {
  for_each                   = var.deny_rules
  default_action             = var.default_action
  storage_account_id         = azurerm_storage_account.storage_account.id
  virtual_network_subnet_ids = each.value.subnets
  bypass                     = each.value.bypass
  ip_rules                   = each.value.ip_rules

  dynamic "private_link_access" {
    for_each = each.value.private_link_access_ids
    content {
      endpoint_resource_id = private_link_access.value
    }
  }
}

resource "azurerm_storage_encryption_scope" "storage_encryption_scope" {
  name               = var.storage_encryption_scope_name
  source             = "Microsoft.Storage"
  storage_account_id = azurerm_storage_account.storage_account.id
}

resource "azurerm_storage_container" "storage_container" {
  name                  = var.storage_container_name
  storage_account_id    = azurerm_storage_account.storage_account.id
  container_access_type = var.container_access_type
}

resource "azurerm_storage_blob" "blob" {
  name                   = var.blob_name
  storage_account_name   = azurerm_storage_account.storage_account.name
  storage_container_name = azurerm_storage_container.storage_container.name
  type                   = var.type
  source                 = data.archive_file.archive.output_path
  content_md5            = data.archive_file.archive.output_md5

  lifecycle {
    ignore_changes = [content_type]
  }
}
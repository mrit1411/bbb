module "enable_ssm_association" {
  source           = "../modules/aws_ssm_association"
  name             = "AWS-GatherSoftwareInventory"
  association_name = "Inventory-Association-Enable"
  key              = "tag:${var.tags_condition_key}"
  values           = ["${var.tags_condition_value}"]
}

module "ssm_management_ec2_instance_profile" {
  source = "../modules/aws_iam_instance_profile"
  name   = var.ssm_management_ec2_instance_profile_name
  role   = module.ssm_management_ec2_iam_role.role_name
}

module "ssm_automation_run_command_iam_role" {
  source              = "../modules/aws_iam_role"
  resource_type       = "SSM"
  context             = "automation-run-command"
  description         = "Role created by CCS Core Infra Solution Deployment. Created for the SSMAutomationDocumentRunCommandWindows and SSMAutomationDocumentRunCommandLinux SSM Automation documents to assume. Grants SSM automation role permissions"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonSSMAutomationRole"]

}

module "ssm_automation_create_backup_iam_role" {
  source              = "../modules/aws_iam_role"
  resource_type       = "SSM"
  context             = "automation-create-backup"
  description         = "Role created by CCS Core Infra Solution Deployment. Created for the SSMAutomationCreateBackup SSM Automation document to assume. grants SSM automation role permissions"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonSSMAutomationRole"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "CreateBackup"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/create_backup.json")
    }
  }
}

module "ssm_automation_backup_iam_role" {
  source              = "../modules/aws_iam_role"
  resource_type       = "Backup"
  context             = "automation-backup"
  description         = "Role created by CCS Core Infra Solution Deployment. Created for the SSMAutomationCreateBackup SSM Automation document to assume. Role grants permissions to carry out AWS Backup backups"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup", "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForRestores"]

}

module "ssm_management_ec2_iam_role" {
  source              = "../modules/aws_iam_role"
  resource_type       = "EC2"
  context             = "ssm-management"
  description         = "Role created by CCS Monitoring Solution Deployment. Grants all permissions necessary for CCS create cloudwatch alarms Lambda and SSM to setup, configure and manage EC2 instances (that are tagged with management key and value)"
  managed_policy_arns = ["arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy", "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"]

}

module "ccs_snow_api_listner_iam_role" {
  source        = "../modules/aws_iam_role"
  resource_type = "SNOW"
  context       = "api-listner"
  description   = "Role created by CCS Core Infra Solution Deployment. Created for the CCS SNOW Listener API Lambda function to assume. Grants permissions to retrieve API password from Secrets Manager and to query ec2 tags for instance name."
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = ["lambda.amazonaws.com", "events.amazonaws.com"]
        }
        Action = "sts:AssumeRole"
      }
    ]
  })
  inline_policies = {
    policy0 = {
      inline_policy_name = "CCSSNOWAWSLambdaBasicExecutionRole"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/ccs_snow_lambda_basic_execution_role.json")
    }
    policy1 = {
      inline_policy_name = "CCSSNOWSecretsManagerAccess"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/ccs_snow_secrets_manager_access.tpl.json", {
        ccs_snow_secrets_manager_arn = flatten([for r in var.regions : [
          module.ccs_snow_secret[r].secret_id
        ]
        ])
      })
    }
    policy2 = {
      inline_policy_name = "CCSSNOWDescribeEc2Tags"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/ccs_snow_describe_ec2_tags.json")
    }
  }

}

module "ccs_snow_secret" {
  for_each    = toset(var.regions)
  source      = "../modules/aws_secretsmanager_secret"
  region = each.key
  context = "snow-listener"
  description = "API credentials stored for CCS-SNOW-Listener lambda function to utilise for API connection with iPaaS API endpoint"
  secret_string_wo = jsonencode({
    clientid     = var.snow_client_id
    clientsecret = var.snow_client_secret
  })
  secret_string_wo_version = 1 //Increment this value when an update to secret_string_wo is required.
}

# module "snow_sns_topic" {
#   source = "../modules/aws_sns_topic"
#   name   = var.snow_sns_topic_name
# }

# module "snow_sns_topic_policy" {
#   source        = "../modules/aws_sns_topic_policy"
#   sns_topic_arn = module.snow_sns_topic.sns_topic_arn
#   policy_json = templatefile("../modules/aws_sns_topic_policy/policies/snow_sns_topic_policy.tpl.json", {
#     aws_account_id = data.aws_caller_identity.current.account_id,
#     sns_topic_arn  = module.snow_sns_topic.sns_topic_arn
#   })
# }

# module "ccs_snow_listner_lambda_sns_subscription" {
#   source    = "../modules/aws_sns_topic_subscription"
#   topic_arn = module.snow_sns_topic.sns_topic_arn
#   endpoint  = module.ccs_snow_listner_lambda_function.arn
#   protocol  = "lambda"
# }

# module "ccs_snow_listner_lambda_function" {
#   source                   = "../modules/aws_lambda_function"
#   lambda_function_filename = "snow_listener"
#   role                     = module.ccs_snow_api_listner_iam_role.role_arn
#   description              = "CCS Lambda function that will connect to iPaaS API endpoint via secret manager API key and pass alert payloads to CCS MSP ServiceNow"
#   handler                  = "snow_listener.lambda_handler"
#   timeout                  = 300
#   memory_size              = 128
#   env_variables = {
#     company_name = var.api_company_name
#     snow_secret  = module.ccs_snow_secret.secret_id
#     log_level    = var.log_level
#   }
#   tags = {
#     company_name = var.api_company_name
#   }
# }

# module "ccs_snow_listner_lambda_permission" {
#   source        = "../modules/aws_lambda_permission"
#   function_name = module.ccs_snow_listner_lambda_function.arn
#   principal     = "sns.amazonaws.com"
#   source_arn    = module.snow_sns_topic.sns_topic_arn
# }

module "run_command_linux_ssm_automation_document" {
  source = "../modules/aws_ssm_document"
  name   = "SSMAutomationDocumentRunCommandLinux"
  content = templatefile("../modules/aws_ssm_document/ssm_documents/run_command_linux.tpl.json", {
    ssm_automation_run_command_iam_role_arn = module.ssm_automation_run_command_iam_role.role_arn
  })
}

module "run_command_windows_ssm_automation_document" {
  source = "../modules/aws_ssm_document"
  name   = "SSMAutomationDocumentRunCommandWindows"
  content = templatefile("../modules/aws_ssm_document/ssm_documents/run_command_windows.tpl.json", {
    ssm_automation_run_command_iam_role_arn = module.ssm_automation_run_command_iam_role.role_arn
  })
}

module "create_backup_ssm_automation_document" {
  source = "../modules/aws_ssm_document"
  name   = "SSMAutomationCreateBackup"
  content = templatefile("../modules/aws_ssm_document/ssm_documents/create_backup.tpl.json", {
    ssm_automation_create_backup_iam_role_arn = module.ssm_automation_create_backup_iam_role.role_arn,
    ssm_automation_backup_iam_role_arn        = module.ssm_automation_backup_iam_role.role_arn
  })

}

module "splunk_forwarder_sns_topic" {
  for_each = toset(var.regions)

  source = "../modules/aws_sns_topic"
  name   = var.splunk_forwarder_sns_topic_name
  region = each.value

}

module "splunk_forwarder_sns_topic_policy" {
  for_each = toset(var.regions)

  source        = "../modules/aws_sns_topic_policy"
  sns_topic_arn = module.splunk_forwarder_sns_topic[each.value].sns_topic_arn
  region        = each.value
  policy_json = templatefile("../modules/aws_sns_topic_policy/policies/splunk_forwarder_sns_topic_policy.tftpl", {
    aws_account_id         = data.aws_caller_identity.current.account_id,
    sns_topic_arn          = module.splunk_forwarder_sns_topic[each.value].sns_topic_arn,
    aws_source_account_ids = jsonencode(var.aws_source_account_ids),
    aws_region             = each.value
  })

}

module "splunk_forwarder_sqs_queue" {
  source = "../modules/aws_sqs_queue"

  name = "Splunk-Forwarder-Queue"
}

module "splunk_forwarder_sns_topic_sqs_subscription" {
  for_each = toset(var.regions)

  source = "../modules/aws_sns_topic_subscription"

  topic_arn = module.splunk_forwarder_sns_topic[each.value].sns_topic_arn
  protocol  = "sqs"
  endpoint  = module.splunk_forwarder_sqs_queue.arn
  region    = each.value
}

module "splunk_forwarder_sqs_queue_policy" {
  source = "../modules/aws_sqs_queue_policy"

  sqs_queue_url = module.splunk_forwarder_sqs_queue.url
  policy_json = templatefile("../modules/aws_sqs_queue_policy/policies/splunk_forwarder_sqs_queue_policy.tftpl", {
    aws_account_id                  = data.aws_caller_identity.current.account_id,
    splunk_forwarder_sns_topic_arns = jsonencode([for r in var.regions : module.splunk_forwarder_sns_topic[r].sns_topic_arn]),
    sqs_queue_arn                   = module.splunk_forwarder_sqs_queue.arn
  })

}

# module "oam_sink" {
#   source = "../modules/aws_oam_sink"
#   providers = {
#     aws = aws.monitoring_account
#   }
#   region             = var.oam_sink_region
#   source_account_ids = var.oam_source_account_ids

# }

# module "oam_link" {
#   source       = "../modules/aws_oam_link"
#   oam_sink_arn = module.oam_sink.arn
#   region       = var.oam_link_region
# }
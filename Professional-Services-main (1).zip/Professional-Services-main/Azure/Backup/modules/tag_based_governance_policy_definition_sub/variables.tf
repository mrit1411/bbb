variable "name" {
  description = "The name of the policy definition. Changing this forces a new resource to be created."
  type        = string
}

variable "display_name" {
  description = "The display name of the policy definition."
  type        = string
}

# variable "subscription_id" {
#   description = "Management Group ID where to define and assign the policy"
#   type        = string
# }

variable "policy_type" {
  description = "The policy type. Possible values are BuiltIn, Custom, NotSpecified and Static. Changing this forces a new resource to be created."
  type        = string
  default     = "Custom"
}

variable "mode" {
  description = "The policy resource manager mode that allows you to specify which resource types will be evaluated."
  type        = string
  default     = "Indexed"
}

variable "description" {
  description = "The description of the policy definition."
  type        = string
}

variable "policy_rule_filename" {
  description = "The filename of the policy rule JSON file."
  type        = string
}

variable "policy_parameters_filename" {
  description = "The filename of the policy parameters JSON file."
  type        = string
}


import csv
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from azure.identity import DefaultAzureCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.resource.resources.models import TagsPatchResource

# Authenticate once
credential = DefaultAzureCredential()
log_file = open('patching_tagging_log.txt', 'w')

# Function to add tags using scope-based update
def add_tags_to_resource(row):
    if len(row) != 4:
        warning = f" Skipping invalid row: {row}"
        return ("INVALID_ROW", "FAILURE", warning)

    resource_id, tag_name, tag_value, subscription_id = map(str.strip, row)
    try:
        resource_client = ResourceManagementClient(credential, subscription_id)
        tags = {tag_name: tag_value}
        tag_patch_resource = TagsPatchResource(operation="Merge", properties={"tags": tags})
        resource_client.tags.begin_update_at_scope(resource_id, tag_patch_resource)
        return (resource_id, "SUCCESS", f"Tags applied to: {resource_id}")
    except Exception as e:
        return (resource_id, "FAILURE", f"Failed to tag resource: {resource_id} - Reason: {e}")

# Read CSV and apply tags concurrently
with open('org_tag_input.csv', 'r') as file:
    reader = list(csv.reader(file))
    rows = reader[1:]  # Skip header

    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(add_tags_to_resource, row) for row in rows]
        for future in tqdm(as_completed(futures), total=len(futures), desc="Tagging Resources", ncols=100):
            resource_id, status, message = future.result()
            print(message)
            log_file.write(f"{resource_id}, {status}, {message}\n")

log_file.close()
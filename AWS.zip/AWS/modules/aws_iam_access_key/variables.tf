variable "user" {
  description = "IAM user to associate with this access key."
  type        = string
}

variable "status" {
  description = "Access key status to apply. If true, the key will be active; if false, it will be inactive."
  type        = bool
  default     = true
}
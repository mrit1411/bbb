snow_client_id     = "test"
snow_client_secret = "test"
api_company_name   = "testcompany"
regions = ["eu-west-1", "us-east-1", "ap-south-1", "us-east-2", "ap-southeast-1", "eu-central-1"]
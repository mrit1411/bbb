﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_lambda_permission.lambda_permission](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action"></a> [action](#input\_action) | Lambda action to allow in this statement | `string` | `"lambda:InvokeFunction"` | no |
| <a name="input_function_name"></a> [function\_name](#input\_function\_name) | The name of the Lambda function to which the permission will be added. | `string` | n/a | yes |
| <a name="input_principal"></a> [principal](#input\_principal) | AWS service or account that invokes the function | `string` | `"events.amazonaws.com"` | no |
| <a name="input_source_arn"></a> [source\_arn](#input\_source\_arn) | ARN of the source resource granting permission to invoke the Lambda function | `string` | n/a | yes |

## Outputs

No outputs.

import boto3
import time
import csv
import os
import json
from datetime import datetime, timedelta
from botocore.config import Config
from botocore.exceptions import ClientError
from dateutil.relativedelta import *


cloudwatch_client = boto3.client("cloudwatch")
ec2_client = boto3.client("ec2")
sns_client = boto3.client('sns')

s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic_arn = os.environ.get('SNS_TOPIC_ARN')

def lambda_handler(event, context):
    secret_response = json.loads(get_secret())
    s3_client = boto3.client("s3", config=Config(signature_version='s3v4'),
                         region_name=os.environ.get("AWS_REGION"),
                         aws_access_key_id=secret_response["ACCESS_KEY"],
                         aws_secret_access_key=secret_response["SECRET_KEY"])    
    alarm_data=[": EC2:Over 80% CPU Utilization detected over a period of 30 minutes",": EC2:Over 90% CPU Utilization detected over a period of 30 minutes",": EC2:System Uptime is less than 20 seconds",": EC2:Over 90% Memory Utilization detected over a period of 15 minutes",": EC2:Over 90% Disk Utilization detected over a period of 15 minutes",": EC2:Status Check Fail detected"]             
    # start_date =datetime(2021, 1, 1).replace(month=datetime.today().month, year=datetime.today().year) + relativedelta(months=-1)
    # end_date = start_date + relativedelta(months=1,seconds=-1)
    start_date = datetime(2025, 7, 1)
    end_date = datetime(2025, 7, 31, 23, 59, 59)
    fieldnames = ["Start Time","End Time","Region Name","Server Name","Problem","DateTime"]
    filename = "Events-report-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime("%d-%m-%Y_%H:%M.%f") + ".csv"
    try:
      with open("/tmp/" + filename, 'w+') as temp_file:
        csvdata = csv.DictWriter(temp_file, delimiter=';', fieldnames=fieldnames, extrasaction='ignore')
        csvdata.writeheader()
        alarm_history_details = {}
        for region in boto3.client('ec2').describe_regions()['Regions']:
            ec2_client = boto3.client('ec2', region_name=region['RegionName'])
            cloudtrail_client = boto3.client('cloudtrail', region_name=region['RegionName'])
            cloudwatch_client = boto3.client('cloudwatch', region_name=region['RegionName'])
            instance_dict = get_instance_ids(start_date,end_date,ec2_client,cloudtrail_client,region["RegionName"])
            for instance_id in instance_dict:
                alarm_history_details['Start Time'] = start_date
                alarm_history_details['End Time'] = end_date
                alarm_history_details['Region Name'] = region['RegionName']
                alarm_history_details['Server Name'] = get_server_name(instance_id, ec2_client)
                for alarm in alarm_data:
                    for metric in get_metric_history(cloudwatch_client,instance_id,start_date,end_date,alarm):
                        alarm_history_details["Problem"] =metric["AlarmName"]
                        alarm_history_details["DateTime"] =metric["TimeStamp"]
                        csvdata.writerow(alarm_history_details)

        temp_file.close()
    except Exception as e:
        print("Error opening csv file: %s" % e)
        exit(1)
    try:
        print("Upload report to S3 bucket: " + s3_destination_bucket)
        s3_client.upload_file("/tmp/" + filename, s3_destination_bucket, filename)

        print("Generate URL link to events reports")
        presigned_url = s3_client.generate_presigned_url('get_object',  Params={'Bucket': s3_destination_bucket, 'Key': filename}, ExpiresIn=s3_presigned_link_expiration)
        print("Send message")
        sns_client.publish(TargetArn=s3_sns_topic_arn, Message="Link to availability reports (link is valid for " + str(int(int(s3_presigned_link_expiration)/3600)) + " hours): " + presigned_url, MessageStructure='string' )
    except ClientError as e:
        print("Unexpected error: %s" % e)

    return 0


def get_metric_history(cloudwatch_client,instance_id,start_date,end_date,alarm):
    response = cloudwatch_client.describe_alarm_history(
    AlarmName= instance_id + alarm, 
    HistoryItemType='StateUpdate',
    StartDate=start_date,
    EndDate=end_date
    )
    information = []
    short_information={}
    for alarms in range(len(response["AlarmHistoryItems"])):
        if (response["AlarmHistoryItems"][alarms]["HistorySummary"]) == "Alarm updated from OK to ALARM":
            short_information["AlarmName"] = response["AlarmHistoryItems"][alarms]["AlarmName"]
            short_information["TimeStamp"] = response["AlarmHistoryItems"][alarms]["Timestamp"].strftime('%d-%m-%Y %H:%M')
            short_information["HistorySummary"] = response["AlarmHistoryItems"][alarms]["HistorySummary"]
            information.append(short_information)
            short_information={}
    return information

def get_server_name(instance_id, ec2):
    server_name = 'undefined'
    try:
            response = ec2.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [instance_id]
                    }
                ]
            )
            for Tag in response['Tags']:
                if Tag['Key'] == 'Name':
                    server_name = Tag['Value']
    except Exception as e:
        print("Error while reading instance tags: %s" % e)
    return server_name
    
def get_instance_ids(start_date,end_date,ec2,cloudtrail,region):
    instance_list = []
    try:
        #instances that were terminated in the last 30 days
        response_terimnated = cloudtrail.lookup_events(
            LookupAttributes=[
                {
                    'AttributeKey': 'EventName',
                    'AttributeValue': 'TerminateInstances'
                },
            ],
            StartTime=start_date,
            EndTime=end_date
            )
        for event in response_terimnated['Events']:
          for resource in event['Resources']:
                instance_list.append(resource["ResourceName"])     
        # instances that are running or stopped
        response_current = ec2.describe_instances()
        for reservation in response_current['Reservations']:
            for instance in reservation['Instances']:
                instance_list.append(instance['InstanceId'])           
    except Exception as e:
        print(f"Fetching instances for region: {region} failed")
    return instance_list
    

def get_secret():
    region_name = os.environ.get("AWS_REGION")
    secret_name = f"ccs-events-user-{region_name}"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        return get_secret_value_response['SecretString']
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
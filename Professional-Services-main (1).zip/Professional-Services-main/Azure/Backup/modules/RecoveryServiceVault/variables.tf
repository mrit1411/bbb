
# variable "regions" {
#   description = "Regions to create RSVs in (e.g., [\"eastus\", \"westeurope\", \"canadacentral\"])"
#   type        = list(string)
# }

variable "resource_group_name_map" {
  description = "Map of region => resource group name where the RSV will be created"
  type        = map(string)

  # Ensure every region has a corresponding RG
  # validation {
  #   condition     = alltrue([for r in var.regions : contains(keys(var.resource_group_name_map), r)])
  #   error_message = "resource_group_name_map must include every region listed in var.regions."
  # }
}

variable "recovery_vault_name_prefix" {
  description = "Prefix for naming (e.g., CCS)"
  type        = string
  default     = "CCS-RSV-"
}
# variable "prefix" {
#   description = "Prefix for naming (e.g., CCS)"
#   type        = string
#   default     = "CCS"
# }

# variable "vault_base_name" {
#   description = "Base name component for RSV (kept simple)"
#   type        = string
#   default     = "RSV"
# }

# variable "sep" {
#   description = "Separator used in names"
#   type        = string
#   default     = "-"
# }

variable "vault_sku" {
  description = "RSV SKU"
  type        = string
  default     = "Standard"
}

variable "soft_delete_enabled" {
  description = "Whether soft delete is enabled on the RSV"
  type        = bool
  default     = true
}

variable "storage_mode_type" {
  description = "Backup storage redundancy"
  type        = string
  default     = "LocallyRedundant" # Other valid options: GeoRedundant, ZoneRedundant (check provider version)
}

variable "tags" {
  description = "Tags applied to RSVs"
  type        = map(string)
  default     = { ccs_managed = "yes", ccs_monitoring = "yes" }
}

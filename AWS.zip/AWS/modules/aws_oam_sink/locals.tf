locals {
  oam_sink_name = "ccs-${data.aws_caller_identity.current.account_id}-${data.aws_region.current.region}-oam-sink"
}
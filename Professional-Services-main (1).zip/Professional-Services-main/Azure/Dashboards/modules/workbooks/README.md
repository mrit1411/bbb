﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group_template_deployment.azure_dashboard](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [random_uuid.azure_ops_dashboard_name](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/uuid) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_dashboard_workbook_display_name"></a> [dashboard\_workbook\_display\_name](#input\_dashboard\_workbook\_display\_name) | Specifies the user-defined name (display name) of the workbook. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | Name of the deployment | `string` | `"azure_dashboard"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group | `string` | n/a | yes |
| <a name="input_workbook_name"></a> [workbook\_name](#input\_workbook\_name) | Name of the workbook JSON file | `string` | n/a | yes |

## Outputs

No outputs.

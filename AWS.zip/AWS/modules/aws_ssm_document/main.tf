resource "aws_ssm_document" "ssm_document" {
  name          = var.name
  content       = var.content
  document_type = var.document_type
  target_type   = var.target_type
}
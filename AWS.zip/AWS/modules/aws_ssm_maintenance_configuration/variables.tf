variable "window_name" {
  description = "The name of the maintenance window."
  type        = string
}

variable "window_schedule" {
  description = "The schedule of the Maintenance Window in the form of a cron or rate expression."
  type        = string
}

variable "window_cutoff" {
  description = "The number of hours before the end of the Maintenance Window that Systems Manager stops scheduling new tasks for execution."
  type        = number
  default     = 1
}

variable "window_duration" {
  description = "The duration of the Maintenance Window in hours."
  type        = number
  default     = 4
}

variable "window_description" {
  description = "A description of the Maintenance Window. Should be between 3 and 128 characters."
  type        = string

  validation {
    condition     = length(var.window_description) >= 3 && length(var.window_description) <= 128
    error_message = "window_description must be between 3 and 128 characters."
  }
}

variable "allow_unassociated_targets" {
  description = "Whether targets must be registered with the Maintenance Window before tasks can be defined for those targets."
  type        = bool
  default     = false
}

variable "window_end_date" {
  description = "Timestamp in ISO-8601 extended format when to no longer run the maintenance window."
  type        = string
}

variable "window_start_date" {
  description = "Timestamp in ISO-8601 extended format when to begin the maintenance window."
  type        = string
}

variable "window_schedule_timezone" {
  description = "Timezone for schedule in Internet Assigned Numbers Authority (IANA) Time Zone Database format. For example: America/Los_Angeles, etc/UTC, or Asia/Seoul."
  type        = string
  default     = "UTC"
}

variable "window_target_name" {
  description = "The name of the target for the maintenance window target."
  type        = string
}

variable "window_target_description" {
  description = "A description of the target for the maintenance window target."
  type        = string
}

variable "window_target_resource_type" {
  description = "The type of target being registered with the Maintenance Window. Possible values are INSTANCE and RESOURCE_GROUP."
  type        = string
  default     = "INSTANCE"

  validation {
    condition     = contains(["INSTANCE", "RESOURCE_GROUP"], var.window_target_resource_type)
    error_message = "target_resource_type must be either 'INSTANCE' or 'RESOURCE_GROUP'."
  }
}

variable "window_targets" {
  description = "A map of target definitions for the maintenance window target."
  type = list(object({
    key    = string
    values = list(string)
  }))
  default = []
}

variable "owner_information" {
  description = "User-provided value to be included in any Amazon CloudWatch Events events raised while running tasks for these targets in this Maintenance Window."
  type        = string
  default     = "CCS AWS IaaS "
}

variable "patching_task_max_concurrency" {
  description = "The maximum number of targets this task can be run for in parallel."
  type        = number
  default     = 10
}

variable "patching_task_max_errors" {
  description = "The maximum number of errors allowed before this task stops being scheduled."
  type        = number
  default     = 1
}

variable "patching_task_type" {
  description = "The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN_COMMAND or STEP_FUNCTIONS."
  type        = string
  default     = "RUN_COMMAND"

  validation {
    condition     = contains(["AUTOMATION", "LAMBDA", "RUN_COMMAND", "STEP_FUNCTIONS"], var.patching_task_type)
    error_message = "task_type must be one of: AUTOMATION, LAMBDA, RUN_COMMAND, STEP_FUNCTIONS."
  }
}

variable "patching_task_arn" {
  description = "The ARN of the task to execute."
  type        = string
  default     = "AWS-RunPatchBaseline"
}

variable "patching_task_name" {
  description = "The name of the maintenance window task."
  type        = string
  default     = "Patch-EC2-Instances"
}

variable "patching_task_description" {
  description = "The description of the maintenance window task."
  type        = string
  default     = "Task that applies patches to EC2 instances."
}

variable "patching_task_priority" {
  description = "The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel."
  type        = number
  default     = 20
}

variable "patching_task_invocation_service_role_arn" {
  description = "The Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) service role to use to publish Amazon Simple Notification Service (Amazon SNS) notifications for maintenance window Run Command tasks."
  type        = string
}

variable "patching_task_notification_arn" {
  description = "An Amazon Resource Name (ARN) for a Simple Notification Service (SNS) topic. Run Command pushes notifications about command status changes to this topic."
  type        = string
}

variable "patching_task_notification_events" {
  description = "The different events for which you can receive notifications. Valid values: All, InProgress, Success, TimedOut, Cancelled, and Failed"
  type        = list(string)
  default     = ["Failed", "TimedOut"]

  validation {
    condition     = alltrue([for event in var.patching_task_notification_events : contains(["All", "InProgress", "Success", "TimedOut", "Cancelled", "Failed"], event)])
    error_message = "notification_events must be one or more of: All, InProgress, Success, TimedOut, Cancelled, Failed."
  }
}

variable "patching_task_notification_type" {
  description = "When specified with Command, receive notification when the status of a command changes. When specified with Invocation, for commands sent to multiple instances, receive notification on a per-instance basis when the status of a command changes. Valid values: Command and Invocation"
  type        = string
  default     = "Invocation"

  validation {
    condition     = contains(["Command", "Invocation"], var.patching_task_notification_type)
    error_message = "notification_type must be one of: Command, Invocation."
  }
}

variable "patching_task_parameter_name" {
  description = "The name of the parameter for the task."
  type        = string
  default     = "Operation"
}

variable "patching_task_reboot_parameter_name" {
  description = "The name of the reboot parameter for the task."
  type        = string
  default     = "RebootOption"
}

variable "patching_task_parameter_values" {
  description = "The values of the parameter for the task."
  type        = list(string)
  default     = ["Install"]
}

variable "require_reboot" {
  description = "Whether to reboot the instance if needed after the patching operation. true to reboot if needed, false to not reboot."
  type        = bool
  default     = true
  
}

variable "patching_task_target_key" {
  description = "The key for the target."
  type        = string
  default     = "WindowTargetIds"
}

variable "disable_alarms_task_description" {
  description = "Description of the task that disables EC2 CloudWatch alarms."
  type        = string
  default     = "Task will trigger the AWS-ConfigureCloudWatchOnEC2Instance SSM Automation doc. Disabling EC2 CloudWatch Alarms"

}

variable "disable_alarms_task_name" {
  description = "Name of the task that disables EC2 CloudWatch alarms."
  type        = string
  default     = "Disable-Cloudwatch-Alarms"

}

variable "disable_alarms_task_arn" {
  description = "ARN of the task that disables EC2 CloudWatch alarms."
  type        = string
  default     = "AWS-ConfigureCloudWatchOnEC2Instance"

}

variable "disable_alarms_task_max_concurrency" {
  description = "The maximum number of targets this task can be run for in parallel."
  type        = number
  default     = 1

}

variable "disable_alarms_task_max_errors" {
  description = "The maximum number of errors allowed before this task stops being scheduled."
  type        = number
  default     = 1

}

variable "disable_alarms_task_priority" {
  description = "The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel."
  type        = number
  default     = 10

}

variable "disable_alarms_task_type" {
  description = "The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN_COMMAND or STEP_FUNCTIONS."
  type        = string
  default     = "AUTOMATION"

  validation {
    condition     = contains(["AUTOMATION", "LAMBDA", "RUN_COMMAND", "STEP_FUNCTIONS"], var.disable_alarms_task_type)
    error_message = "task_type must be one of: AUTOMATION, LAMBDA, RUN_COMMAND, STEP_FUNCTIONS."
  }

}

variable "disable_alarms_task_target_key" {
  description = "The key for the target."
  type        = string
  default     = "WindowTargetIds"
}

variable "modify_alarms_task_assume_role_arn" {
  description = "The ARN of the IAM role that allows the Automation to perform actions on your behalf."
  type        = string
}

variable "enable_alarms_task_description" {
  description = "Description of the task that enables EC2 CloudWatch alarms."
  type        = string
  default     = "Task will trigger the AWS-ConfigureCloudWatchOnEC2Instance SSM Automation doc. Enabling EC2 CloudWatch Alarms"

}

variable "enable_alarms_task_name" {
  description = "Name of the task that enables EC2 CloudWatch alarms."
  type        = string
  default     = "Enable-Cloudwatch-Alarms"

}

variable "enable_alarms_task_arn" {
  description = "ARN of the task that enables EC2 CloudWatch alarms."
  type        = string
  default     = "AWS-ConfigureCloudWatchOnEC2Instance"

}

variable "enable_alarms_task_max_concurrency" {
  description = "The maximum number of targets this task can be run for in parallel."
  type        = number
  default     = 1

}

variable "enable_alarms_task_max_errors" {
  description = "The maximum number of errors allowed before this task stops being scheduled."
  type        = number
  default     = 1

}

variable "enable_alarms_task_priority" {
  description = "The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel."
  type        = number
  default     = 90

}

variable "enable_alarms_task_type" {
  description = "The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN_COMMAND or STEP_FUNCTIONS."
  type        = string
  default     = "AUTOMATION"

  validation {
    condition     = contains(["AUTOMATION", "LAMBDA", "RUN_COMMAND", "STEP_FUNCTIONS"], var.enable_alarms_task_type)
    error_message = "task_type must be one of: AUTOMATION, LAMBDA, RUN_COMMAND, STEP_FUNCTIONS."
  }

}

variable "enable_alarms_task_target_key" {
  description = "The key for the target."
  type        = string
  default     = "WindowTargetIds"
}
variable "name" {
  description = "Specifies the name which should be used for this Monitor Scheduled Query Rule. Changing this forces a new resource to be created."
  type        = string
}

variable "resource_group_name" {
  description = "The name of the resource group in which to create the Monitor Scheduled Query Rule. Changing this forces a new resource to be created."
  type        = string
}

variable "location" {
  description = "The Azure location where the Monitor Scheduled Query Rule should exist. Changing this forces a new resource to be created."
  type        = string
}

variable "scopes" {
  description = "Specifies the list of resource IDs that this scheduled query rule is scoped to. Changing this forces a new resource to be created. Currently, the API supports exactly 1 resource ID in the scopes list."
  type        = list(string)
}

variable "severity" {
  description = "Severity of the alert. Should be an integer between 0 and 4. Value of 0 is severest."
  type        = string
}

variable "evaluation_frequency" {
  description = "How often the scheduled query rule is evaluated, represented in ISO 8601 duration format. Possible values are PT1M, PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, PT6H, P1D."
  type        = string
}

variable "window_duration" {
  description = "Specifies the period of time in ISO 8601 duration format on which the Scheduled Query Rule will be executed (bin size). If evaluation_frequency is PT1M, possible values are PT1M, PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, and PT6H. Otherwise, possible values are PT5M, PT10M, PT15M, PT30M, PT45M, PT1H, PT2H, PT3H, PT4H, PT5H, PT6H, P1D, and P2D."
  type        = string
}

variable "action_group_id" {
  description = "List of Action Group resource IDs to invoke when the alert fires."
  type        = list(string)
}

variable "threshold" {
  description = "Threshold value for the alert rule criteria"
  type        = number
}

variable "time_aggregation_method" {
  description = "Time aggregation method for the alert rule criteria (e.g. Total, Average)"
  type        = string
}

variable "metric_measure_column" {
  description = "Metric measure column for the alert rule criteria"
  type        = string
  default     = ""
}

variable "resource_id_column" {
  description = "Resource ID column for the alert rule criteria"
  type        = string
}

variable "query" {
  description = "Kusto query for the alert rule criteria"
  type        = string
}

variable "description" {
  description = "Description of the alert rule"
  type        = string
}

variable "enabled" {
  description = "Whether the alert rule is enabled"
  type        = bool
  default     = true
}

variable "operator" {
  description = "Operator for the alert rule criteria (e.g. GreaterThan, LessThan)"
  type        = string
}

variable "minimum_failing_periods" {
  description = "Minimum number of failing periods to trigger the alert"
  type        = number
  default     = 1
}
variable "number_of_evaluation_periods" {
  description = "Number of evaluation periods to consider for the alert"
  type        = number
  default     = 1
}
variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(string)
  default     = { "ccs_managed" = "yes" }
}

variable "dimension_name" {
  description = "Name of the dimension for the alert rule criteria"
  type        = string
  default     = ""
}

variable "dimension_operator" {
  description = "Operator for the dimension in the alert rule criteria"
  type        = string
  default     = "Include"
}

variable "dimension_values" {
  description = "Values for the dimension in the alert rule criteria"
  type        = list(string)
  default     = ["*"]
}

variable "dimensions" {
  description = "List of dimensions for alert criteria"
  type = list(object({
    name     = string
    operator = string
    values   = list(string)
  }))
  default = []
}

variable "identity" {
  description = "Optional managed identity configuration"
  type = object({
    type         = string
    identity_ids = list(string)
  })
  default = null
}

variable "auto_mitigation_enabled" {
  description = "Whether auto-mitigation is enabled for the alert rule"
  type        = bool
  default     = false
}
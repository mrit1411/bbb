<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.22.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.22.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_reporting_function_app"></a> [reporting\_function\_app](#module\_reporting\_function\_app) | ./modules/reporting_function_app | n/a |
| <a name="module_reporting_function_storage"></a> [reporting\_function\_storage](#module\_reporting\_function\_storage) | ./modules/reporting_storage_module | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.22.0/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_id"></a> [client\_id](#input\_client\_id) | Client ID of the Reporting Function UMI | `string` | n/a | yes |
| <a name="input_client_id_resource_id"></a> [client\_id\_resource\_id](#input\_client\_id\_resource\_id) | The resource ID of the client ID for the UMI | `string` | n/a | yes |
| <a name="input_context"></a> [context](#input\_context) | (Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The location in which the Monitoring resources will be created | `string` | n/a | yes |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_reporting_function_user_assigned_identity_ids"></a> [reporting\_function\_user\_assigned\_identity\_ids](#input\_reporting\_function\_user\_assigned\_identity\_ids) | The user assigned identity IDs for the Reporting Function App | `list(string)` | n/a | yes |
| <a name="input_reporting_function_zip_name"></a> [reporting\_function\_zip\_name](#input\_reporting\_function\_zip\_name) | The name of the Splunk Integration function zip file | `string` | n/a | yes |
| <a name="input_reporting_function_zip_path"></a> [reporting\_function\_zip\_path](#input\_reporting\_function\_zip\_path) | The path to the Splunk Integration function zip file | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which the Monitoring resources will be created | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource | `map(string)` | n/a | yes |

## Outputs

No outputs.

Note: When adding new Management Groups, the role assignment scopes of the "az-umi-org-no-ps-reportingfa-p-01" managed identity will also have to be updated.
<!-- END_TF_DOCS -->
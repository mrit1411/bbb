
import boto3
import sys
import os
import csv
import json
from botocore.config import Config
from datetime import datetime
from dateutil.relativedelta import *
from botocore.exceptions import ClientError

config = Config(retries=dict(max_attempts=6))
client = boto3.client('cloudwatch', config=config)  # will be overridden per region
ssm_client = boto3.client('ssm')                    # will be overridden per region
ec2 = boto3.client('ec2')                           # will be overridden per region

instances_list = []
s3_destination_bucket = os.environ.get('S3_BUCKET')
tags_condition_key = os.environ.get('TAGS_CONDITION_KEY')
tags_condition_value = os.environ.get('TAGS_CONDITION_VALUE')
current_region = os.environ.get('AWS_REGION')  # preserved but not used for multi-region

CPUStatistics = ['Average', 'Maximum']
MemoryStatistics = ['Average', 'Maximum', 'Minimum']

def check_ccs_tags(instance):
    if instance.tags:
        for item in instance.tags:
            if item['Key'] == tags_condition_key:
                if item['Value'] == tags_condition_value:
                    return True
    return False

def get_platform_type(instance):
    try:
        return ssm_client.describe_instance_information(
            InstanceInformationFilterList=[{'key': 'InstanceIds','valueSet': [instance.id]}]
        )['InstanceInformationList'][0]['PlatformType']
    except IndexError:
        if instance.platform:
            return instance.platform.capitalize()
        else:
            return "Linux (Inferred)"

def get_hostgroup_name(instance_id,account_id,ec2):
    env_type = 'undefined'
    account_name = os.environ.get('ACCOUNT_NAME')
    try:
        response = ec2.describe_tags(
            Filters=[
                {
                    'Name': 'resource-id',
                    'Values': [instance_id]
                }
            ]
        )
        for Tag in response['Tags']:
            if Tag['Key'] == 'environment':
                env_type = Tag['Value']
    except Exception as e:
        print("Error while reading instance tags: %s" % e)
    return f'{account_name}/aws/{account_id}/{env_type}'

def get_statistics(StartTime, EndTime, instanceId, nameSpace, metricName, CPUDimentions, statistics, client):
    try:
        response = client.get_metric_statistics(
            Namespace=nameSpace,
            MetricName=metricName,
            Dimensions=CPUDimentions,
            StartTime=StartTime,
            EndTime=EndTime,
            Period=2678400,
            Statistics=statistics,
            Unit='Percent'
        )
        print(response)
        return response
    except Exception as e:
        print("Error getting instance statistics for instance: {} error: {}".format(instanceId, e))
        exit(1)

def get_data(EndTime, instanceId, nameSpace, metricName, Dimentions, statistics, client):
    try:
        response = client.get_metric_data(
            MetricDataQueries=[
                {
                    'Id': 'ccsperformancereport',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': nameSpace,
                            'MetricName': metricName,
                            'Dimensions': Dimentions
                        },
                        'Stat': statistics,
                        'Period': 86400
                    },
                    'ReturnData': True,
                },
            ],
            StartTime=EndTime + relativedelta(days=-1),
            EndTime=EndTime,
            ScanBy='TimestampDescending',
            MaxDatapoints=1,
        )
        return response
    except Exception as e:
        print("Error getting instance statistics for instance: {} error: {}".format(instanceId, e))
        exit(False)

def extract_tag_value(instance, TagKey):
    for item in instance.tags:
        if item['Key'] == TagKey:
            return item['Value']
    return "Missing" + TagKey + "Tag"

def get_cpu(StartTime,EndTime,instanceId, nameSpace, client):
    CPUDimentions=[
        {
            'Name': 'InstanceId',
            'Value': instanceId
        }]
    cpuAve = ''
    cpuMax = ''
    statsCPU = get_statistics(StartTime,EndTime,instanceId, 'AWS/EC2', 'CPUUtilization', CPUDimentions, CPUStatistics, client)
    for cpu in statsCPU['Datapoints']:
        if(cpu):
            if 'Average' in cpu:
                cpuAve = round(cpu['Average'],2)
            if 'Maximum' in cpu:
                cpuMax = round(cpu['Maximum'],2)
    print(cpuAve, cpuMax)
    return cpuAve, cpuMax;

def get_mem(StartTime,EndTime,instanceId, OS, client):
    MemoryDimentionsLinux = [
        {
            'Name': 'InstanceId',
            'Value': instanceId
        }
    ]
    MemoryDimentionsWindows = [
        {
            'Name': 'InstanceId',
            'Value': instanceId
        },
        {
            'Name': 'objectname',
            'Value': 'Memory'
        }
    ]
    freeMemAve, freeMemMax, freeMemMin = '', '', ''
    if OS == 'Linux':
        statsMem = get_statistics(StartTime,EndTime,instanceId, 'CWAgent', 'mem_used_percent', MemoryDimentionsLinux, MemoryStatistics, client)
    else:
        statsMem = get_statistics(StartTime,EndTime,instanceId, 'CWAgent', 'MemoryUsed', MemoryDimentionsWindows, MemoryStatistics, client)
    for mem in statsMem['Datapoints']:
        if(mem):
            if 'Average' in mem:
                freeMemAve = round(100-mem['Average'],2)
            if 'Maximum' in mem:
                freeMemMax = round(100-mem['Minimum'],2)
            if 'Minimum' in mem:
                freeMemMin = round(100-mem['Maximum'],2)
    return freeMemAve, freeMemMax, freeMemMin;

def get_disk_windows(StartTime, EndTime, instanceId, client):
    try:
        response = client.list_metrics(
            Namespace='CWAgent',
            MetricName='DiskFree', # Match the renamed metric from config
            Dimensions=[{
                'Name': 'InstanceId',
                'Value': instanceId
            }]
        )
        stats = []
        for res in response['Metrics']:
            try:
                diskLetter = ''
                for dim in res['Dimensions']:
                    if dim['Name'] == 'instance':
                        diskLetter = dim['Value']
                print(f"Processing disk: {diskLetter}")
                # Get disk dimensions
                disk_dims = [
                    {'Name': 'InstanceId', 'Value': instanceId},
                    {'Name': 'instance', 'Value': diskLetter},
                    {'Name': 'objectname', 'Value': 'LogicalDisk'}
                ]
                # Get free space in MB
                statsDisk = get_data(EndTime, instanceId, 'CWAgent', 'DiskFreeMb', disk_dims, 'Average', client)
                if statsDisk and statsDisk['MetricDataResults'][0]['Values']:
                    diskFree = statsDisk['MetricDataResults'][0]['Values'][0] / 1024 # Convert MB to GB
                else:
                    continue
                # Get free space percentage
                statsDisk = get_data(EndTime, instanceId, 'CWAgent', 'DiskFree', disk_dims, 'Average', client)
                if statsDisk and statsDisk['MetricDataResults'][0]['Values']:
                    diskFreePct = statsDisk['MetricDataResults'][0]['Values'][0]
                else:
                    continue
                # Calculate total and used space
                diskTotal = (diskFree * 100) / diskFreePct
                diskUsed = diskTotal - diskFree
                # Get minimum free space for max utilized
                statsDisk = get_data(EndTime, instanceId, 'CWAgent', 'DiskFreeMb', disk_dims, 'Minimum', client)
                if statsDisk and statsDisk['MetricDataResults'][0]['Values']:
                    minDiskFree = statsDisk['MetricDataResults'][0]['Values'][0] / 1024
                    maxDiskUsed = diskTotal - minDiskFree
                else:
                    maxDiskUsed = diskUsed
                stats.append({
                    'letter': diskLetter,
                    'total': round(diskTotal, 2),
                    'free': round(diskFree, 2),
                    'utilized': round(diskUsed, 2),
                    'freePct': round(diskFreePct, 2),
                    'Max_diskUtilized': round(maxDiskUsed, 2)
                })
            except Exception as f:
                print(f"Error in metric for windows instance: {instanceId}\n{res}\n{f}")
                continue
        return stats
    except Exception as e:
        print(f"Error in Windows Disk metric for {instanceId}\nerror: {e}")
        return []

def get_windows_drives(StartTime, EndTime, instanceId, client):
    try:
        response = client.list_metrics(
            #Namespace='Windows System',
            Namespace='CWAgent',
            MetricName='DiskFree',
            Dimensions=[{
                'Name': 'InstanceId',
                'Value': instanceId
            }]
        )
        disk_Path=[]
        for res in response['Metrics']:
            try:
                for dim in res['Dimensions']:
                    if dim['Name']=='instance':
                        disk_Path.append(dim['Value'])
            except Exception as f:
                print('path exceptions',f)
    except Exception as e:
        print("get drive exceptions",e)
    return disk_Path

def get_linux_drives(StartTime, EndTime, instanceId, client):
    try:
        response = client.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[{
                'Name': 'InstanceId',
                'Value': instanceId
            }]
        )
        disk_Path=[]
        for res in response['Metrics']:
            try:
                for dim in res['Dimensions']:
                    if dim['Name']=='path':
                        disk_Path.append(dim['Value'])
            except Exception as f:
                print('path exceptions',f)
    except Exception as e:
        print("get drive exceptions",e)
    return disk_Path

def get_disk_linux(StartTime, EndTime, instanceId, client):
    try:
        response = client.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[{
                'Name': 'InstanceId',
                'Value': instanceId
            }]
        )
        print("response")
        print(response)
        print(type(response))
        stats = []
        i=0
        n=len(response['Metrics'])
        for res in response['Metrics']:
            try:
                for dim in res['Dimensions']:
                    if dim['Name']=='path' and "/snapd/" not in dim['Value'] :
                        print("None")
                        diskUsed=diskTotal=diskFree=diskUsedPct=None
                        diskPath = dim['Value']
                        print("disk path: {}".format(diskPath))
                        # intendenting
                        statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_used', res['Dimensions'], 'Maximum', client)
                        print("statsDisk1")
                        print(statsDisk)
                        if[statsDisk]:
                            for val in statsDisk['MetricDataResults']:
                                if(val['Values']):
                                    # diskUsed=val['Values'][0]/1000000000
                                    Max_diskUsed=val['Values'][0]/1073741824
                        statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_used', res['Dimensions'], 'Average', client)
                        print("statsDisk1")
                        print(statsDisk)
                        if[statsDisk]:
                            for val in statsDisk['MetricDataResults']:
                                if(val['Values']):
                                    # diskUsed=val['Values'][0]/1000000000
                                    diskUsed=val['Values'][0]/1073741824
                        print("Disk Used :",diskUsed)
                        statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_total', res['Dimensions'], 'Average', client)
                        print("statsDisk2")
                        print(statsDisk)
                        if[statsDisk]:
                            for val in statsDisk['MetricDataResults']:
                                if(val['Values']):
                                    # diskTotal=(val['Values'][0])/1000000000
                                    diskTotal=(val['Values'][0])/1073741824
                        statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_free', res['Dimensions'], 'Average', client)
                        print("statsDisk3")
                        print(statsDisk)
                        if[statsDisk]:
                            for val in statsDisk['MetricDataResults']:
                                if(val['Values']):
                                    # diskFree=val['Values'][0]/1000000000
                                    diskFree=val['Values'][0]/1073741824
                        statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_used_percent', res['Dimensions'], 'Average', client)
                        print("statsDisk4")
                        print(statsDisk)
                        for val in statsDisk['MetricDataResults']:
                            if(val['Values']):
                                diskUsedPct=val['Values'][0]
                        stats.append({'letter': diskPath, 'total': round(diskTotal,2), 'free': round(diskFree,2), 'utilized': round(diskUsed,2), 'freePct': round(diskUsedPct,2),'Max_utilized': round(Max_diskUsed,2)},)
            except Exception as f:
                print("error in metric for instance : ",instanceId,"\n",res,"\n",f)
                stats.append({'letter': diskPath, 'total': '', 'free': '', 'utilized': '', 'freePct': '','Max_utilized':''}, )
        return stats
    except Exception as e:
        stats = []
        print("error in Disk metric for ",instanceId,"\nerror:",e)
        return stats

def lambda_handler(event, context):
    filename = "performance-report-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime("%Y%m%d_%H%M") + ".csv"
    fieldnames = ["Start Time","End Time","Cloud","Hostgroup Name","AWS Region","Instance Id","Platform","Server Name","Instance_State","Average CPU Utilisation(%)",
                  "Maximum CPU Utilisation(%)","Average free Memory(%)","Maximum free Memory(%)","Minimum free Memory(%)","Drive Name","Total Disk Space(GB)",
                  "Free Disk Space(GB)","Utilised Disk Space(GB)","Free Disk Space (%)","Max Utilised Disk Space (GB)"]
    account_id = context.invoked_function_arn.split(":")[4]
    StartTime=datetime(2021, 1, 1).replace(month=datetime.today().month, year=datetime.today().year) + relativedelta(months=-1)
    EndTime=StartTime + relativedelta(months=1,seconds=-1)

    print('Start Time of report: {0}'.format(StartTime))
    print('End Time of report: {0}'.format(EndTime))
    print("report name: " + filename)

    try:
        with open("/tmp/" + filename, 'w+') as temp_file:
            csvdata = csv.DictWriter(temp_file, delimiter=',', fieldnames=fieldnames, extrasaction='ignore')
            csvdata.writeheader()

            # === Multi-region processing (minimal change) ===
            for region in boto3.client('ec2').describe_regions()['Regions']:
                region_name = region['RegionName']
                print("processing region: {}".format(region_name))

                # Region-scoped clients/resources
                cw_client    = boto3.client('cloudwatch', region_name=region_name, config=config)
                ec2_client   = boto3.client('ec2',        region_name=region_name)
                ec2_resource = boto3.resource('ec2',      region_name=region_name)
                ssm_regional = boto3.client('ssm',        region_name=region_name)

                # Override globals so existing functions keep working as-is
                global client
                client = cw_client
                global ec2
                ec2 = ec2_client
                global ssm_client
                ssm_client = ssm_regional

                try:
                    for instance in ec2_resource.instances.all():
                        print("processing instance: {}".format(instance))
                        if check_ccs_tags(instance):
                            instance_details = {}
                            instance_details['Start Time'] = StartTime
                            instance_details['End Time'] = EndTime
                            instance_details['Cloud'] = "AWS"
                            instance_details['Hostgroup Name'] = get_hostgroup_name(instance.id,account_id,ec2_client)
                            instance_details['AWS Region'] = region_name
                            instance_details['Instance Id'] = instance.id
                            instance_details['Platform'] = get_platform_type(instance)
                            instance_details['Server Name'] = extract_tag_value(instance, "Name")
                            instance_details['Instance_State'] = ec2.describe_instances(InstanceIds=[instance.id])['Reservations'][0]['Instances'][0]['State']['Name']
                            print(instance_details['Platform'])

                            if(instance_details['Platform']!='Windows'):
                                (instance_details['Average CPU Utilisation(%)'], instance_details['Maximum CPU Utilisation(%)']) = get_cpu(StartTime,EndTime,instance.id, 'Linux', client)
                                (instance_details['Average free Memory(%)'], instance_details['Maximum free Memory(%)'], instance_details['Minimum free Memory(%)']) = get_mem(StartTime,EndTime,instance.id, 'Linux', client)

                                disk_stats = get_disk_linux(StartTime,EndTime,instance.id,client)
                                if disk_stats:
                                    for stat in disk_stats:
                                        row = dict(instance_details)
                                        row['Drive Name']=stat['letter']
                                        row['Total Disk Space(GB)']=stat['total']
                                        row['Free Disk Space(GB)']=stat['free']
                                        row['Utilised Disk Space(GB)']=stat['utilized']
                                        row['Max Utilised Disk Space (GB)']=stat['Max_utilized']
                                        row['Free Disk Space (%)']=stat['freePct']
                                        print(row)
                                        csvdata.writerow(row)
                                else:
                                    # Fallback: ensure instance appears even if no disk metrics are present
                                    row = dict(instance_details)
                                    row['Drive Name']=row['Total Disk Space(GB)']=row['Free Disk Space(GB)']=''
                                    row['Utilised Disk Space(GB)']=row['Free Disk Space (%)']=row['Max Utilised Disk Space (GB)']=''
                                    print(row)
                                    csvdata.writerow(row)
                            else:
                                (instance_details['Average CPU Utilisation(%)'], instance_details['Maximum CPU Utilisation(%)']) = get_cpu(StartTime,EndTime,instance.id, 'Windows', client)
                                (instance_details['Average free Memory(%)'], instance_details['Maximum free Memory(%)'], instance_details['Minimum free Memory(%)']) = get_mem(StartTime,EndTime,instance.id, 'Windows', client)

                                disk_stats = get_disk_windows(StartTime,EndTime,instance.id,client)
                                if disk_stats:
                                    for stat in disk_stats:
                                        row = dict(instance_details)
                                        row['Drive Name']=stat['letter']
                                        row['Total Disk Space(GB)']=stat['total']
                                        row['Free Disk Space(GB)']=stat['free']
                                        row['Utilised Disk Space(GB)']=stat['utilized']
                                        row['Max Utilised Disk Space (GB)']=stat['Max_diskUtilized']
                                        row['Free Disk Space (%)']=stat['freePct']
                                        print(row)
                                        csvdata.writerow(row)
                                else:
                                    # Fallback: ensure instance appears even if no disk metrics are present
                                    row = dict(instance_details)
                                    row['Drive Name']=row['Total Disk Space(GB)']=row['Free Disk Space(GB)']=''
                                    row['Utilised Disk Space(GB)']=row['Free Disk Space (%)']=row['Max Utilised Disk Space (GB)']=''
                                    print(row)
                                    csvdata.writerow(row)

                except Exception as e:
                    if isinstance(e, ClientError) and e.response['Error']['Code'] == 'UnauthorizedOperation':
                        print("Error processing region: {} Check if region is supported. Error: {}".format(region_name, e))
                    else:
                        raise e

            temp_file.close()
    except Exception as e:
        print("Error opening csv file: %s" % e)
        exit(1)

    try:
        s3_client = boto3.client("s3")
        print("upload report: "+filename)
        s3_client.upload_file("/tmp/" + filename, s3_destination_bucket, filename)
    except ClientError as e:
        print("Unexpected error: %s" % e)

variable "allow_nested_items_to_be_public" {
  type        = bool
  default     = false
  description = "allow_blob_public_access - defaults to false"
}
variable "cross_tenant_replication_enabled" {
  type    = bool
  default = false
}
variable "shared_access_key_enabled" {
  type    = bool
  default = false
}

variable "resource_group_name" {
  description = "The name of the resource group in which to create the storage account. Changing this forces a new resource to be created."
  type        = string
}

variable "location" {
  description = " Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created."
  type        = string

  validation {
    condition     = contains(["norwayeast", "westeurope", "swedencentral"], var.location)
    error_message = "The supplied value is not in the accepted region list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "versioning_enabled" {
  type        = bool
  description = "Should versinoning be enabled on the storage account? Defaults to false."
  default     = false
}

variable "account_tier" {
  description = "Defines the Tier to use for this storage account. Changing this forces a new resource to be created."
  type        = string
  default     = "Standard"
}

variable "account_replication_type" {
  description = "Defines the type of replication to use for this storage account. Changing this forces a new resource to be created when types LRS, GRS and RAGRS are changed to ZRS, GZRS or RAGZRS and vice versa."
  type        = string
  default     = "GRS"
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "deny_rules" {
  type = map(object({
    subnets                 = list(string)
    bypass                  = optional(list(string), [])
    ip_rules                = list(string)
    private_link_access_ids = optional(set(string), [])
  }))
  default = {}
}
variable "default_action" {
  type    = string
  default = "Deny"
}
variable "is_hns_enabled" {
  type        = string
  default     = false
  description = "(Optional) Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2 (see here for more information). Changing this forces a new resource to be created."
}
variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}
variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment) # self hosted non production
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "account_kind" {
  description = "Defines the Kind of account. Valid options are Storage, StorageV2, BlobStorage, FileStorage. Changing the account_kind value from Storage to StorageV2 will not trigger a force new on the storage account, it will only upgrade the existing storage account from Storage to StorageV2 keeping the existing storage account in place.Changing this forces a new resource to be created."
  type        = string
  default     = "StorageV2"
}

variable "https_traffic_only_enabled" {
  description = "Allows https traffic only to storage service if set to true."
  type        = bool
  default     = true
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(any)
}

variable "storage_encryption_scope_name" {
  description = "Specifies the name of the Splunk Integration storage account encryption scope. Changing this forces a new encryption scope to be created."
  type        = string
}

variable "storage_container_name" {
  description = "The name of the Splunk Integration Function Container which should be created within the Storage Account. Changing this forces a new resource to be created."
  type        = string
}

variable "container_access_type" {
  description = "The access level to use for this container. Possible values are 'private', 'blob', 'container'."
  type        = string
  default     = "private"
}

variable "blob_name" {
  description = "The name of the splunk integration function zip storage blob. Must be unique within the storage container the blob is located. Changing this forces a new resource to be created."
  type        = string
}

variable "type" {
  description = "The type of the storage blob to be created. Possible values are Append, Block or Page. Changing this forces a new resource to be created."
  type        = string
  default     = "Block"
}

variable "file_source" {
  description = "An absolute path to splunk integration function zip on the local system. This field cannot be specified for Append blobs and cannot be specified if source_content or source_uri is specified. Changing this forces a new resource to be created."
  type        = string
}
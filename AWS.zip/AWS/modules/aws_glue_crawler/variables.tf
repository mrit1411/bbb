variable "client_name" {
  description = "Enter the name of Client. Used to create the selected resource"
  type        = string
}

variable "configuration" {
  description = "JSON string of configuration information."
  type        = string
}

variable "s3_target_path" {
  description = "The path to the Amazon S3 target."
  type        = string
}

variable "exclusions" {
  description = "A list of glob patterns used to exclude from the crawl."
  type        = list(string)
}

variable "role" {
  description = "The IAM role friendly name (including path without leading slash), or ARN of an IAM role, used by the crawler to access other resources."
  type        = string
}

variable "database_name" {
  description = "Glue database where results are written."
  type        = string
}
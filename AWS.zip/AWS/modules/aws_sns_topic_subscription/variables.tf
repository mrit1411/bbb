variable "topic_arn" {
  description = "ARN of the SNS topic to subscribe to."
  type        = string
}

variable "endpoint" {
  description = "Endpoint to send data to."
  type        = string
}

variable "protocol" {
  description = "Protocol to use. Valid values are: sqs, sms, lambda, firehose, and application. Protocols email, email-json, http and https are also valid but partially supported."
  type        = string
  default     = "email"
}

variable "region" {
  description = "The AWS region where the SNS topic is located."
  type        = string
  default     = "us-east-1"
  
}
output "aws_ssm_association" {
  value = aws_ssm_association.ssm_association

}
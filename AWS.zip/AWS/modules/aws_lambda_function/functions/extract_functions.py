import ast
import csv
import sys

def extract_function_info(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        source = f.read()

    tree = ast.parse(source)
    lines = source.splitlines()
    functions = []

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            name = node.name
            args = [arg.arg for arg in node.args.args]
            start_line = node.lineno - 1
            end_line = max(getattr(n, 'lineno', start_line) for n in ast.walk(node)) - 1
            code_lines = lines[start_line:end_line + 1]
            loc = sum(1 for line in code_lines if line.strip() and not line.strip().startswith("#"))
            functions.append((name, ", ".join(args), loc))

    return functions

def write_to_csv(functions, output_csv):
    with open(output_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["functionName", "parameters", "linesOfCode"])
        writer.writerows(functions)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_functions.py <input_python_file.py> <output.csv>")
    else:
        input_file = sys.argv[1]
        output_csv = sys.argv[2]
        function_data = extract_function_info(input_file)
        write_to_csv(function_data, output_csv)
        print(f"Extracted {len(function_data)} functions to {output_csv}")

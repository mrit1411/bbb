﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_patch_baseline.ssm_patch_baseline](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_patch_baseline) | resource |
| [aws_ssm_patch_group.sm_patch_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_patch_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_approve_after_days"></a> [approve\_after\_days](#input\_approve\_after\_days) | Number of days after the release date of each patch matched by the rule the patch is marked as approved in the patch baseline. Valid Range: 0 to 360. | `number` | n/a | yes |
| <a name="input_approved_patches_compliance_level"></a> [approved\_patches\_compliance\_level](#input\_approved\_patches\_compliance\_level) | Compliance level for approved patches. This means that if an approved patch is reported as missing, this is the severity of the compliance violation. Valid values are CRITICAL, HIGH, MEDIUM, LOW, INFORMATIONAL, UNSPECIFIED. | `string` | `"MEDIUM"` | no |
| <a name="input_compliance_level"></a> [compliance\_level](#input\_compliance\_level) | Compliance level for patches approved by this rule. Valid values are CRITICAL, HIGH, MEDIUM, LOW, INFORMATIONAL, and UNSPECIFIED. | `string` | `"MEDIUM"` | no |
| <a name="input_description"></a> [description](#input\_description) | The description of the patch baseline. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The name of the patch baseline. | `string` | n/a | yes |
| <a name="input_operating_system"></a> [operating\_system](#input\_operating\_system) | Operating system the patch baseline applies to. Valid values are ALMA\_LINUX, AMAZON\_LINUX, AMAZON\_LINUX\_2, AMAZON\_LINUX\_2022, AMAZON\_LINUX\_2023, CENTOS, DEBIAN, MACOS, ORACLE\_LINUX, RASPBIAN, REDHAT\_ENTERPRISE\_LINUX, ROCKY\_LINUX, SUSE, UBUNTU, and WINDOWS. | `string` | n/a | yes |
| <a name="input_patch_filters"></a> [patch\_filters](#input\_patch\_filters) | Patch filter group that defines the criteria for the rule. Up to 5 patch filters can be specified per approval rule using Key/Value pairs. Valid combinations of these Keys and the operating\_system value can be found in the SSM DescribePatchProperties API Reference. Valid Values are exact values for the patch property given as the key, or a wildcard *, which matches all values. PATCH\_SET defaults to OS if unspecified | <pre>list(object({<br/>    key    = string<br/>    values = list(string)<br/>  }))</pre> | n/a | yes |
| <a name="input_patch_group"></a> [patch\_group](#input\_patch\_group) | The name of the patch group that should be registered with the patch baseline. | `string` | n/a | yes |

## Outputs

No outputs.

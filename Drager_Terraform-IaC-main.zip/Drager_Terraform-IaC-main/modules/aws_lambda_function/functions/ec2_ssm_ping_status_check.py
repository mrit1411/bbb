import boto3
import os
import json
from datetime import datetime,timedelta,timezone



SNS_TOPIC_ARN = os.environ.get("SNOWSNSTopicARN")
SSM_MANAGED_TAG_NAME = os.environ.get("TagsConditionKey")
SSM_MANAGED_TAG_VALUE = os.environ.get("TagsConditionValue")

ssm_client = boto3.client("ssm")
ec2_resource = boto3.resource('ec2')
ec2_client = boto3.client('ec2')
sns_client = boto3.client("sns")

ssm_issue =[]

ssm_instances = []

ec2_running_instances = []

connection_lost_instance = []

def lambda_handler(event, context):
    print(event)
    print(SSM_MANAGED_TAG_NAME,SSM_MANAGED_TAG_VALUE)
    
    filters = [{'Name': f'tag:{SSM_MANAGED_TAG_NAME}','Values': [SSM_MANAGED_TAG_VALUE]},
               {'Name':'instance-state-name','Values':['running']}]
    
    for instance in ec2_resource.instances.filter(Filters=filters):
        ec2_running_instances.append(instance.id)

    print("ec2_running_instances",ec2_running_instances)


    paginator = ssm_client.get_paginator('describe_instance_information')
    response_iterator =  paginator.paginate()

    # get list of instances which is not online in Fleet Manager
    for page in response_iterator:
        for item in page['InstanceInformationList']:
            if item["InstanceId"] in ec2_running_instances:
                ssm_instances.append(item["InstanceId"])
                if item["PingStatus"] != "Online":
                    ssm_issue.append(item)

    # print("ssm_issue",ssm_issue)
    # print("ssm_instances",ssm_instances)

    difference_set = set(ec2_running_instances) - set(ssm_instances)

    items_not_in_ssm_instances = list(difference_set)
    
    for instance in items_not_in_ssm_instances:
        print(instance)
        subject = "Instance SSM Agent is not reporting to Fleet Manager"
        message = {
            "AlarmName": f"{instance}: EC2:Instance is not reporting to Fleet Manager",
            "AlarmDescription": f"Alarm generated when EC2 Instance is tagged with {SSM_MANAGED_TAG_NAME} = {SSM_MANAGED_TAG_VALUE} and not reporting to SSM Fleet Manager.",
            "InstanceID": instance,
            "CheckTime": datetime.now(timezone.utc).strftime("%m/%d/%Y, %H:%M:%S"),
        }
        print(subject, message)
        # if instance == "i-056d5d1f9f059b1c7":
        res = ec2_client.describe_instances(InstanceIds=[instance])
        if datetime.now(timezone.utc) - timedelta(minutes=5) > res["Reservations"][0]["Instances"][0]["LaunchTime"]:
            print("send sns msg")
            print(send_sns_msg(subject, message))

    # print("items_not_in_ssm_instances")
    # print(items_not_in_ssm_instances)

    off_set = (datetime.now(timezone.utc)-timedelta(minutes=30))

    if len(ssm_issue)>0:
        for instance in ssm_issue:
            print("Connection Lost",instance)
            # if "LastPingDateTime" in instance.keys():
            #     if (instance["LastPingDateTime"]).astimezone(timezone.utc) > off_set:
            subject = "SSM Agent is not online"
            message = {
                "AlarmName": f"{instance["InstanceId"]}: EC2:SSM Agent ping status is not online.",
                "AlarmDescription": f"Alarm generated when EC2 Instance is tagged with {SSM_MANAGED_TAG_NAME} = {SSM_MANAGED_TAG_VALUE} and the SSM agent ping status is not online in SSM Fleet Manager.",
                "InstanceID": instance["InstanceId"],
                "CheckTime": datetime.now(timezone.utc).strftime("%m/%d/%Y, %H:%M:%S")
            }
            # if instance["InstanceId"] == "i-076736516fa33c929":
            res = ec2_client.describe_instances(InstanceIds=[instance["InstanceId"]])
            if datetime.now(timezone.utc) - timedelta(minutes=5) > res["Reservations"][0]["Instances"][0]["LaunchTime"]:
                print(subject, message)
                send_sns_msg(subject, message)

def send_sns_msg(subject: str, message: dict) -> dict:
    """Function to publish a message on a SNS Topic.

    Args:
        subject (str): Subject of a message.
        message (str): Message body.

    Returns:
        dict: SNS response
    """
    response = sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message= json.dumps({"default": json.dumps(message,default=json_serial)}),#json.dumps({"default": "message"}),#json.dumps({"default": json.dumps(message)}),
        Subject=subject,
        MessageStructure="json"
    )
    return response

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")
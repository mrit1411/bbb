data "azurerm_subscription" "sub" {
}

module "azure-ops-dashboard" {
  source                          = "./modules/workbooks"
  dashboard_workbook_display_name = var.ops_dashboard_workbook_display_name
  workbook_name                   = "ARMTemplate.json"
  resource_group_name             = var.resource_group_name
  location = var.location
}
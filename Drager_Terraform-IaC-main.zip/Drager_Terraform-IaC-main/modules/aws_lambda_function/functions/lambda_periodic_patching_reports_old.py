from __future__ import print_function
import boto3
import csv
import json
import os
import pandas as pd
from datetime import datetime
from botocore.exceptions import ClientError
from botocore.config import Config

ssm_client = boto3.client('ssm')
ec2_client = boto3.client('ec2')
sns_client = boto3.client('sns')

s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic = os.environ.get('SNS_TOPIC_ARN')
tag_condition_key = os.environ.get('TAGS_CONDITION_KEY')
tag_condition_value = os.environ.get('TAGS_CONDITION_VALUE')
reports = {'compliant': "C", 'noncompliant': "N"}


def lambda_handler(event, context):
    s3_client = boto3.client("s3", config=Config(signature_version='s3v4'),region_name=os.environ.get("AWS_REGION"))
    fieldnames = ["ComplianceType", "ResourceType", "ResourceId", "ResourceName", "Id", "Title", "Status", "Severity",
                  "ExecutionSummary", "Details"]
    filename = "periodic-patching-report-" + context.invoked_function_arn.split(":")[3] + "-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime(
        "%Y%m%d_%H%M") + ".xlsx"

    print("report name: " + filename)
    try:
        for report_name, report_type in reports.items():
            with open("/tmp/" + report_name + ".csv", 'w+') as temp_file:
                print("/tmp/" + report_name + ".csv")
                csvdata = csv.DictWriter(temp_file, delimiter=';', fieldnames=fieldnames, extrasaction='ignore')
                csvdata.writeheader()
                for i in get_instance_list():
                    print("instance: " + i)
                    instance_name = i#get_instance_name(i)
                    resp_list = list_compliant_items(i, report_type)
                    for key, val in resp_list.items():
                        if key == "ComplianceItems":
                            for compl_items in val:
                                compl_items['ResourceName'] = instance_name
                                csvdata.writerow(compl_items)
            temp_file.close()
    except Exception as e:
        print("Error preparing csv report: %s" % e)
        exit(1)

    try:
        print("convert csv's to excel")
        writer = pd.ExcelWriter('/tmp/file.xlsx')#, engine='xlsxwriter')
        for report_name, report_type in reports.items():
            df = pd.read_csv("/tmp/" + report_name + ".csv", sep=';')#, error_bad_lines=False)
            df.to_excel(writer, sheet_name=report_name)
        writer.close()
    except Exception as e:
        print("Error converting report to excel file: %s" % e)
        exit(1)

    try:
        print("upload report")
        s3_client.upload_file("/tmp/file.xlsx", s3_destination_bucket, filename)
        presigned_url = s3_client.generate_presigned_url('get_object',
                                                         Params={'Bucket': s3_destination_bucket, 'Key': filename},
                                                         ExpiresIn=s3_presigned_link_expiration)
        sns_client.publish(TargetArn=s3_sns_topic, Message="Link to patching report (link is valid for " + str(
            int(int(s3_presigned_link_expiration) / 3600)) + " hours): " + presigned_url, MessageStructure='string')
    except ClientError as e:
        print("Unexpected error: %s" % e)

    return 0


def get_instance_list():
    instances = []
    resp_instances = describe_instances()
    for key, val in resp_instances.items():
        if key == "Reservations":
            for reservation in val:
                for res_key, res_val in reservation.items():
                    if res_key == "Instances":
                        for inst in res_val:
                            for inst_key, inst_val in inst.items():
                                if inst_key == "InstanceId":
                                    instances.append(inst_val)
    return instances


def describe_instances():
    try:
        response = ec2_client.describe_instances(
            Filters=[
                {
                    'Name': 'tag:' + tag_condition_key,
                    'Values': [
                        tag_condition_value,
                    ]
                },
            ]
        )
    except Exception as e:
        print(e)
        exit(1)
    return response


def list_compliant_items(instanceid, compliant_status):
    try:
        response = ssm_client.list_compliance_items(
            # turn on filter to limit report to non-compliant
            Filters=[
                {
                    'Key': 'Status',
                    'Values': [
                        compliant_status,
                    ],
                    'Type': 'BEGIN_WITH'
                },
            ],
            ResourceIds=[
                instanceid
            ],
            ResourceTypes=[
                'ManagedInstance'
            ],
        )
    except Exception as e:
        print(e)
        exit(1)
    return response


def get_instance_name(instanceid):
    resource_name = 'resource not named'
    try:
        response = ec2_client.describe_tags(
            Filters=[
                {
                    'Name': 'resource-id',
                    'Values': [instanceid]
                },
                {
                    'Name': 'key',
                    'Values': ["Name"]
                }
            ]
        )
        for Tag in response['Tags']:

            if Tag['Key'] == 'Name':
                resource_name = Tag['Value']
                break
    except Exception as e:
        print(e)
    finally:
        print(resource_name)
        return resource_name
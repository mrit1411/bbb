# # ======================================================
# # MANAGEMENT GROUP DEPLOYMENT
# # Uncomment when deploying at MG scope
# # ======================================================

# module "add_vm_to_rsv_policy_definition_mg" {
#   source                     = "./modules/tag_based_governance_policy_definition"
#   name                       = var.azure_policy_Backup_definition_name
#   display_name               = var.azure_policy_Backup_definition_name
#   description                = "CCS Policy to add VMs with tags ccs_backup to Recovery Service Vault"
#   policy_rule_filename       = "add_vm_to_rsv_policy_rule_aptiv.json"
#   policy_parameters_filename = "add_vm_to_rsv_polict_parameters_aptiv.json"
#   management_group_id        = var.policy_management_group_id
# }


# ################### New Assignments for standard and enhanced #################

# module "add_vm_to_rsv_policy_assignment_standard_mg" {
#   for_each                   = local.flattened_standard_backup_map
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "${var.azure_policy_Backup_assignment_name}-standard"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = each.value.sub_id
#   location                   = each.value.region
#   policy_definition_id       = module.add_vm_to_rsv_policy_definition_mg.id
#   policy_assignment_parameters = jsonencode({
#     BackupTagValue = {
#       value = var.backup_tag_value
#     }
#     BackupTagName = {
#       value = var.backup_tag_name_standard
#     }
#     BackupPolicyId = {
#       value = each.value.bp_id
#     }
#     vaultLocation = {
#       value = each.value.region
#     }
#   })
# }

# module "add_vm_to_rsv_policy_assignment_enhanced_mg" {
#   for_each                   = local.flattened_enhanced_backup_map
#   source                     = "./modules/tag_based_governance_policy_sub"
#   name                       = "${var.azure_policy_Backup_assignment_name}-enhanced"
#   user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
#   subscription_id            = each.value.sub_id
#   location                   = each.value.region
#   policy_definition_id       = module.add_vm_to_rsv_policy_definition_mg.id
#   policy_assignment_parameters = jsonencode({
#     BackupTagValue = {
#       value = var.backup_tag_value
#     }
#     BackupTagName = {
#       value = var.backup_tag_name_enhanced
#     }
#     BackupPolicyId = {
#       value = each.value.bp_id
#     }
#     vaultLocation = {
#       value = each.value.region
#     }
#   })
# }


#########################################################
# Subscription Scoped Policy Definition
# Uncomment for Subscription-based deployments scope
#########################################################

module "add_vm_to_rsv_policy_definition_sub" {
  source                     = "./modules/tag_based_governance_policy_definition_sub"
  name                       = var.azure_policy_Backup_definition_name
  display_name               = var.azure_policy_Backup_definition_name
  description                = "CCS Policy to add VMs with tags ccs_backup to Recovery Service Vault"
  policy_rule_filename       = "add_vm_to_rsv_policy_rule_aptiv.json"
  policy_parameters_filename = "add_vm_to_rsv_policy_parameters_aptiv.json"
}

module "add_vm_to_rsv_policy_assignment_standard_sub" {
  for_each                   = local.flattened_standard_backup_map
  source                     = "./modules/tag_based_governance_policy_sub"
  name                       = "${var.azure_policy_Backup_assignment_name}-standard"
  user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
  subscription_id            = each.value.sub_id
  location                   = each.value.region

  policy_definition_id = module.add_vm_to_rsv_policy_definition_sub.id

  policy_assignment_parameters = jsonencode({
    BackupTagValue = {
      value = var.backup_tag_value
    }
    BackupTagName = {
      value = var.backup_tag_name_standard
    }
    BackupPolicyId = {
      value = each.value.bp_id
    }
    vaultLocation = {
      value = each.value.region
    }
  })
}

module "add_vm_to_rsv_policy_assignment_enhanced_sub" {
  for_each                   = local.flattened_enhanced_backup_map
  source                     = "./modules/tag_based_governance_policy_sub"
  name                       = "${var.azure_policy_Backup_assignment_name}-enhanced"
  user_assigned_identity_ids = var.policy_assignment_user_assigned_identity_ids
  subscription_id            = each.value.sub_id
  location                   = each.value.region

  policy_definition_id = module.add_vm_to_rsv_policy_definition_sub.id

  policy_assignment_parameters = jsonencode({
    BackupTagValue = {
      value = var.backup_tag_value
    }
    BackupTagName = {
      value = var.backup_tag_name_enhanced
    }
    BackupPolicyId = {
      value = each.value.bp_id
    }
    vaultLocation = {
      value = each.value.region
    }
  })
}



module "recovery_vault_sub1" {
  source                  = "./modules/RecoveryServiceVault"
  providers               = { azurerm = azurerm.sub1 }
  resource_group_name_map = var.subscriptions["sub1"].resource_group_name_map
}



module "backup_policy_sub1" {

  #for_each = var.subscriptions["sub1"].backup_policies
  source                  = "./modules/BackupPolicy"
  providers               = { azurerm = azurerm.sub1 }
  resource_group_name_map = var.subscriptions["sub1"].resource_group_name_map
  standard_policy_name    = var.subscriptions["sub1"].standard_policy_name
  enhanced_policy_name    = var.subscriptions["sub1"].enhanced_policy_name
  standard_policy         = var.subscriptions["sub1"].standard_policy
  enhanced_policy         = var.subscriptions["sub1"].enhanced_policy
  # recovery_vault_name      = var.subscriptions["sub1"].recovery_vault_name

  create_standard_policy = true
  create_enhanced_policy = true
  depends_on             = [module.recovery_vault_sub1]

}


locals {
  regions = {
    norwayeast    = "noe"
    westeurope    = "weu"
    swedencentral = "swec"
  }
}

locals {
  environments = {
    Dev  = "n"
    Test = "t"
    UAT  = "uat"
    Prod = "p"
    SHN  = "shn"
  }
}

locals {
  name = "${var.context}-${local.environments[var.environment]}-${local.regions[var.location]}-${format("%02d", var.index)}-${var.org}-dcr"
}
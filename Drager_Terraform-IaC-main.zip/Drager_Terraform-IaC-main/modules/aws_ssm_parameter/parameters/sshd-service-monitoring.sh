#!/bin/bash

# # Detect OS Name in lowercase
# os_name=$(grep '^NAME=' /etc/os-release | cut -d'=' -f2 | tr -d '"' | tr '[:upper:]' '[:lower:]')

# # Default service
# service=""

# case "$os_name" in
#     *"ubuntu"*)
#         service="ssh"
#         ;;
#     *"red hat"*|*"rhel"*)
#         service="sshd"
#         ;;
#     *"amazon linux"*)
#         service="sshd"
#         ;;
#     *"suse"*|*"sles"*)
#         service="sshd"
#         ;;
#     *)
#         echo "Unsupported OS: $os_name"
#         exit 1
#         ;;
# esac

# # Check SSH service status
# if systemctl is-active --quiet "$service"; then
#     STATUS=1
# else
#     STATUS=0
# fi

# if systemctl is-active --quiet $service; then
#     STATUS=1
# else
#     STATUS=0
# fi


if systemctl is-active --quiet ssh || systemctl is-active --quiet sshd; then
    STATUS=1
else
    STATUS=0
fi


TOKEN=$(curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
instanceid=$(curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)
region=$(curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone | sed -e 's/.$//')
 

aws cloudwatch put-metric-data  --namespace "Custom/SSH"  --region ${region} --metric-data "MetricName=ssh_status,Value=$STATUS,Dimensions=[{Name=InstanceId,Value=$instanceid}]"
resource "azurerm_maintenance_configuration" "maintenance_configuration" {
  name                     = var.name
  location                 = var.location
  resource_group_name      = var.resource_group_name
  scope                    = "InGuestPatch"
  in_guest_user_patch_mode = "User"

  install_patches {
    reboot = var.reboot ? "Always" : "Never"
    windows {
      classifications_to_include = var.classifications_windows
      kb_numbers_to_include      = var.kb_numbers_windows
    }
    linux {
      classifications_to_include = var.classifications_linux
    }
  }

  window {
    start_date_time      = var.start_date_time
    expiration_date_time = var.expiration_date_time
    recur_every          = var.recur_every
    time_zone            = var.time_zone
    duration             = var.duration
  }
  tags = merge(var.tags, {
    patch_reference = tostring(var.is_reference)
  })

  lifecycle {
    ignore_changes = [tags,install_patches[0].reboot]
  }
}
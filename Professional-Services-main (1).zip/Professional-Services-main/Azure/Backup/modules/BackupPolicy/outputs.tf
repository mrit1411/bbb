# output "policy_ids" {
#   value = { for k, v in azurerm_backup_policy_vm.policy : k => v.id }
# }

# output "policy_ids_list" {
#   description = "List of all backup policy IDs"
#   value       = [for p in values(azurerm_backup_policy_vm.policy) : p.id]
# }


output "standard_policy_ids" {
  description = "Standard backup policy IDs by region"
  value = {
    for k, v in azurerm_backup_policy_vm.standard_backup_policy :
    k => v.id
  }
}

output "enhanced_policy_ids" {
  description = "Enhanced backup policy IDs by region"
  value = {
    for k, v in azurerm_backup_policy_vm.enhanced_backup_policy :
    k => v.id
  }
}
variable "name" {
  description = "Name of the IAM Instance Profile. Can be a string of characters consisting of upper and lowercase alphanumeric characters and these special characters: _, +, =, ,, ., @, -. Spaces are not allowed. The name must be unique, regardless of the path or role. In other words, if there are different role or path values but the same name as an existing instance profile, it will still cause an EntityAlreadyExists error."
  type        = string
}

variable "role" {
  description = "The IAM role to associate with the instance profile."
  type        = string

}
data "aws_region" "current" {}

locals {
  name = "ccs-${var.context}-user-${var.region}"
}
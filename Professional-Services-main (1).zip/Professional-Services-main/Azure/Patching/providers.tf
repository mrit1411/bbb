terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.22.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~>3.0"
    }
  }
}

provider "azurerm" {
  features {}

  use_msi = true
  #resource_provider_registrations = "none"
  subscription_id = var.sub_id
}

provider "azurerm" {
  alias = "sub_b"
  features {}

  use_msi = true
  #resource_provider_registrations = "none"
  subscription_id = var.sub_b_id
}





output "function_app_principal_id" {
  description = "The principal ID for the Azure service principal"
  value       = azurerm_windows_function_app.splunk_integration_function_app.identity[0].principal_id
}

output "function_app_id" {
  description = "The ID of the Azure Function App"
  value       = azurerm_windows_function_app.splunk_integration_function_app.id
}

output "service_plan_id" {
  description = "The ID of the App Service Plan."
  value       = azurerm_service_plan.app_service_plan.id
}

output "name" {
  value = azurerm_windows_function_app.splunk_integration_function_app.name
}
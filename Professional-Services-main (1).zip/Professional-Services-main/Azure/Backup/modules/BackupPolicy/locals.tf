
# locals {
#   backup_by_region = {
#     for region in var.regions : region => {
#       name = "${var.recovery_vault_name_prefix}${lower(region)}"
#       rg   = var.resource_group_name_map[region]
#       region = region
#     }
#   }
# }


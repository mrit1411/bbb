locals {
  name = "CCS-Logging-${var.client_name}-Workgroup"
}
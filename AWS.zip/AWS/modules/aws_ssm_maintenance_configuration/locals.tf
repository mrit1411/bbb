locals {
  enable_alarms_task_parameters = [
    {
      name   = "InstanceId"
      values = ["{{RESOURCE_ID}}"]
    },
    {
      name   = "status"
      values = ["Enabled"]
    },
    {
      name   = "AutomationAssumeRole"
      values = [var.modify_alarms_task_assume_role_arn]
    }
  ]

  disable_alarms_task_parameters = [
    {
      name   = "InstanceId"
      values = ["{{RESOURCE_ID}}"]
    },
    {
      name   = "status"
      values = ["Disabled"]
    },
    {
      name   = "AutomationAssumeRole"
      values = [var.modify_alarms_task_assume_role_arn]
    }
  ]
}
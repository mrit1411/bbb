resource "azurerm_subscription_policy_assignment" "policy_assignment" {
  name                 = "${lower(var.name)}-asgmnt"
  policy_definition_id = var.policy_definition_id
  subscription_id      = var.subscription_id
  description          = var.description
  identity {
    type         = "UserAssigned"
    identity_ids = var.user_assigned_identity_ids
  }

  location = var.location

  parameters = var.policy_assignment_parameters != null ? var.policy_assignment_parameters : ""
}

import boto3
import sys
import os
import csv
import json
from botocore.config import Config
from datetime import datetime
from dateutil.relativedelta import *
from botocore.exceptions import ClientError

config = Config(retries=dict(max_attempts=6))
client = boto3.client('cloudwatch', config=config)
sns_client = boto3.client('sns')
ssm_client = boto3.client('ssm')
ec2 = boto3.client('ec2')

instances_list = []
s3_destination_bucket = os.environ.get('S3_BUCKET')
tags_condition_key = os.environ.get('TAGS_CONDITION_KEY')
tags_condition_value = os.environ.get('TAGS_CONDITION_VALUE')

s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic_arn = os.environ.get('SNS_TOPIC_ARN')
current_region = os.environ.get('AWS_REGION') #newly added

CPUStatistics = ['Average', 'Maximum']
MemoryStatistics = ['Average', 'Maximum', 'Minimum']

def check_ccs_tags(instance):
    if instance.tags:
        for item in instance.tags:
            if item['Key'] == tags_condition_key:
                if item['Value'] == tags_condition_value:
                    return True
    return False
    
def get_platform_type(instance):
    try:
        return ssm_client.describe_instance_information(
            InstanceInformationFilterList=[{'key': 'InstanceIds','valueSet': [instance.id]}]
        )['InstanceInformationList'][0]['PlatformType']
    except IndexError:
        if instance.platform:
            return instance.platform.capitalize()
        else:
            return "Linux (Inferred)"
            
def get_secret():
    region_name = os.environ.get("AWS_REGION")
    secret_name = f"ccs-performance-user-{region_name}"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        return get_secret_value_response['SecretString']
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
            
def get_hostgroup_name(instance_id,account_id,ec2):
    env_type = 'undefined'
    account_name = os.environ.get('ACCOUNT_NAME')
    try:
            response = ec2.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [instance_id]
                    }
                ]
            )
            for Tag in response['Tags']:
                if Tag['Key'] == 'environment':
                    env_type = Tag['Value']
    except Exception as e:
            print("Error while reading instance tags: %s" % e)

    return f'{account_name}/aws/{account_id}/{env_type}'
    
            
def get_statistics(StartTime, EndTime, instanceId, nameSpace, metricName, CPUDimentions, statistics, client):
    try:
        response = client.get_metric_statistics(
            Namespace=nameSpace,
            MetricName=metricName,
            Dimensions=CPUDimentions,
            StartTime=StartTime, 
            EndTime=EndTime,
            Period=2678400,
            Statistics=statistics,
            Unit='Percent'
        )
        return response
    except Exception as e:
        print("Error getting instance statistics for instance: {} error: {}".format(instance, e))
        exit(1)
    # get_data(EndTime,instanceId, 'CWAgent', 'disk_used', res['Dimensions'], 'Average', client)
def get_data(EndTime, instanceId, nameSpace, metricName, Dimentions, statistics, client):
    # print('EndTime',EndTime)
    # print('instanceId',instanceId)
    # print('nameSpace',nameSpace)
    # print('metricName',metricName)
    # print('Dimentions',Dimentions)
    # print('statistics',statistics)
    # print('client',client)
    try:
        response = client.get_metric_data(
            MetricDataQueries=[
                {
                'Id': 'ccsperformancereport',
                'MetricStat': {
                    'Metric': {
                        'Namespace': nameSpace,
                        'MetricName':  metricName,
                        'Dimensions': Dimentions
                    },
                    'Stat': statistics,
                    # 'Unit': 'Megabytes',
                    'Period': 86400
                },
                'ReturnData': True,
                },
            ],
            StartTime=EndTime + relativedelta(days=-1),
            EndTime=EndTime,
            ScanBy='TimestampDescending',
            MaxDatapoints=1,
        )
        return response
        
    except Exception as e:
        print("Error getting instance statistics for instance: {} error: {}".format(instance, e))
        exit(false)
        
    
def extract_tag_value(instance, TagKey):
    for item in instance.tags:
        if item['Key'] == TagKey:
            return item['Value']
    return "Missing" + TagKey + "Tag"
    
def get_cpu(StartTime,EndTime,instanceId, nameSpace, client):
  CPUDimentions=[                
    {
    'Name': 'InstanceId',
    'Value': instanceId
    }]
  cpuAve = ''
  cpuMax = ''
  statsCPU = get_statistics(StartTime,EndTime,instanceId, 'AWS/EC2', 'CPUUtilization', CPUDimentions, CPUStatistics, client)
  for cpu in statsCPU['Datapoints']:
    if(cpu):
      if 'Average' in cpu:
        cpuAve = round(cpu['Average'],2)
      if 'Maximum' in cpu:
        cpuMax = round(cpu['Maximum'],2)
  return cpuAve, cpuMax;
  
def get_mem(StartTime,EndTime,instanceId, OS, client):
  MemoryDimentionsLinux = [
      {
      'Name': 'InstanceId',
      'Value': instanceId
      }
  ]
  MemoryDimentionsWindows = [
    {
    'Name': 'InstanceId',
    'Value': instanceId
    },
    {
    'Name': 'objectname',
    'Value': 'Memory'
    }
  ]
  freeMemAve, freeMemMax, freeMemMin = '', '', ''
  if OS == 'Linux':
    statsMem = get_statistics(StartTime,EndTime,instanceId, 'CWAgent', 'mem_used_percent', MemoryDimentionsLinux, MemoryStatistics, client)
  else:
    statsMem = get_statistics(StartTime,EndTime,instanceId, 'Windows System', 'MemoryUsed', MemoryDimentionsWindows, MemoryStatistics, client)
  for mem in statsMem['Datapoints']:
    if(mem):
      if 'Average' in mem:
        freeMemAve = round(100-mem['Average'],2)
      if 'Maximum' in mem:
        freeMemMax = round(100-mem['Minimum'],2)
      if 'Minimum' in mem:
        freeMemMin = round(100-mem['Maximum'],2)
  return freeMemAve, freeMemMax, freeMemMin;
  
def get_disk_windows(StartTime, EndTime, instanceId, client):
  EndTime=datetime.today().replace(hour=1,minute=0,second=0)
  try:
    response = client.list_metrics(
      Namespace='Windows System',
      MetricName='DiskFree',
      Dimensions=[{
        'Name': 'InstanceId',
        'Value': instanceId
        }]
      )
    print(response)
    stats = []
    i=0
    n=len(response['Metrics'])
    for res in response['Metrics']:
      try:
        for dim in res['Dimensions']:
          if dim['Name']=='instance':
            diskLetter = dim['Value']
            print (diskLetter)
        statsDisk = get_data(EndTime,instanceId, 'Windows System', 'DiskUsedMb', res['Dimensions'], 'Average', client)
        print("statsDisk1")
        print(statsDisk)
        if[statsDisk]:
          for val in statsDisk['MetricDataResults']:
            if(val['Values']):
              # diskUtilized=(val['Values'][0])/1024
              diskFree=(val['Values'][0])/1024 #  In Parameter store the Free MB metric is renamed to DiskUsedMb
              print(diskFree)
            # else: 
            #   return {}
        statsDisk = get_data(EndTime,instanceId, 'Windows System', 'DiskFree', res['Dimensions'], 'Average', client)
        print("statsDisk2")
        print(statsDisk)
        for val in statsDisk['MetricDataResults']:
          if(val['Values']):
            # diskUsed=val['Values'][0]
            diskFree_pct=val['Values'][0]
            print(diskFree_pct)
          # else:
          #   return {}
        # if(diskUsed):
        if(diskFree_pct):
          diskTotal=diskFree*100/diskFree_pct
          diskUsed=diskTotal-diskFree
          diskUsed_pct=100-diskFree_pct
          print('diskTotal',diskTotal)
          print('diskUsed',diskUsed)
          print('diskUsed_pct',diskUsed_pct)
        stats.append({'letter': diskLetter, 'total': round(diskTotal,2), 'free': round(diskFree,2), 'utilized': round(diskUsed,2), 'freePct': round(diskFree_pct,2)}, )
      except Exception as f:
        print("error in metric for windows instance : ",instanceId,"\n",res,"\n",f)
        stats.append({'letter': diskLetter, 'total': '', 'free': '', 'utilized': '', 'freePct': ''}, )
    return stats
  except Exception as e:
    stats = []
    print("error in Windows Disk metric for ",instanceId)
    return stats

# newly added
def get_windows_drives(StartTime, EndTime, instanceId, client):
    try:
      response = client.list_metrics(
        Namespace='Windows System',
        MetricName='DiskFree',
        Dimensions=[{
          'Name': 'InstanceId',
          'Value': instanceId
          }]
        )
      disk_Path=[]
      for res in response['Metrics']:
        try:
          for dim in res['Dimensions']:
            if dim['Name']=='instance':
              disk_Path.append(dim['Value'])
        except Exception as f:
          print('path exceptions',f)
    except Exception as e:
      print("get drive exceptions",e)
    return disk_Path
  
# newly added
def get_linux_drives(StartTime, EndTime, instanceId, client):
    try:
      response = client.list_metrics(
        Namespace='CWAgent',
        MetricName='disk_used_percent',
        Dimensions=[{
          'Name': 'InstanceId',
          'Value': instanceId
          }]
        )
      disk_Path=[]
      for res in response['Metrics']:
        try:
          for dim in res['Dimensions']:
            if dim['Name']=='path':
              disk_Path.append(dim['Value'])
        except Exception as f:
          print('path exceptions',f)
    except Exception as e:
      print("get drive exceptions",e)
    return disk_Path
        
    

def get_disk_linux(StartTime, EndTime, instanceId, client):
  EndTime=datetime.today().replace(hour=1,minute=0,second=0)
  try:
    response = client.list_metrics(
      Namespace='CWAgent',
      MetricName='disk_used_percent',
      Dimensions=[{
        'Name': 'InstanceId',
        'Value': instanceId
        }]
      )
    print("response")
    print(response)
    print(type(response))
    stats = []
    i=0
    n=len(response['Metrics'])
    for res in response['Metrics']:
      try:
        for dim in res['Dimensions']:
          
          if dim['Name']=='path' and "/snapd/" not in dim['Value'] :
            print("None")
            diskUsed=diskTotal=diskFree=diskUsedPct=None
            diskPath = dim['Value']
            print("disk path: {}".format(diskPath))
          # if dim['Name']=='fstype' and dim['Value'] in ['xfs']:
        # print("Test get_data")
        # intendenting
            statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_used', res['Dimensions'], 'Average', client)
            print("statsDisk1")
            print(statsDisk)
            if[statsDisk]:
              for val in statsDisk['MetricDataResults']:
                if(val['Values']):
                  # diskUsed=val['Values'][0]/1000000000
                  diskUsed=val['Values'][0]/1073741824
                # else: 
                  # return {} # comment it next
            print("Disk Used :",diskUsed)
            statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_total', res['Dimensions'], 'Average', client)
            print("statsDisk2")
            print(statsDisk)
            if[statsDisk]:
              for val in statsDisk['MetricDataResults']:
                if(val['Values']):
                  # diskTotal=(val['Values'][0])/1000000000
                  diskTotal=(val['Values'][0])/1073741824
                # else: 
                  # return {}
            statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_free', res['Dimensions'], 'Average', client)
            print("statsDisk3")
            print(statsDisk)
            if[statsDisk]:
              for val in statsDisk['MetricDataResults']:
                if(val['Values']):
                  # diskFree=val['Values'][0]/1000000000
                  diskFree=val['Values'][0]/1073741824
                # else: 
                #   return {}
            statsDisk = get_data(EndTime,instanceId, 'CWAgent', 'disk_used_percent', res['Dimensions'], 'Average', client)
            print("statsDisk4")
            print(statsDisk)
            for val in statsDisk['MetricDataResults']:
              if(val['Values']):
                diskUsedPct=val['Values'][0]
              # else:
              #   return {}
                
            stats.append({'letter': diskPath, 'total': round(diskTotal,2), 'free': round(diskFree,2), 'utilized': round(diskUsed,2), 'freePct': round(diskUsedPct,2)}, )
        #unintendednt
      except Exception as f:
        print("error in metric for instance : ",instanceId,"\n",res,"\n",f)
        stats.append({'letter': diskPath, 'total': '', 'free': '', 'utilized': '', 'freePct': ''}, )
    return stats
  except Exception as e:
    stats = []
    print("error in Disk metric for ",instanceId,"\nerror:",e)
    return stats
    
def lambda_handler(event, context):
    filename = "performance-report-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime("%Y%m%d_%H%M") + ".csv"
    fieldnames = ["Start Time","End Time","Cloud","Hostgroup Name","AWS Region","Instance Id","Platform","Server Name","Instance_State","Average CPU Utilisation",
    "Maximum CPU Utilisation","Average free Memory","Maximum free Memory","Minimum free Memory","Drive Name","Total Disk Space",
    "Free Disk Space","Utilised Disk Space","Free Disk Space %"]
    account_id = context.invoked_function_arn.split(":")[4]
    StartTime=datetime(2021, 1, 1).replace(month=datetime.today().month, year=datetime.today().year) + relativedelta(months=-1)   #debug: datetime(2021, 8, 24)#
    EndTime=StartTime + relativedelta(months=1,seconds=-1)    #debug datetime(2021, 9, 24)#
    print('Start Time of report: {0}'.format(StartTime))
    print('End Time of report: {0}'.format(EndTime))
    print("report name: " + filename)
    try:
      with open("/tmp/" + filename, 'w+') as temp_file:
        csvdata = csv.DictWriter(temp_file, delimiter=',', fieldnames=fieldnames, extrasaction='ignore')
        csvdata.writeheader()
        #secret_response = json.loads(get_secret())
        # for region in boto3.client('ec2').describe_regions()['Regions']: #altered
        #debug if(region['RegionName']=='ca-central-1'):
        try:  
         client = boto3.client('cloudwatch',
                  # region_name=region['RegionName'], # altered
                  region_name=current_region)#,newly added aws_access_key_id=secret_response["ACCESS_KEY"],aws_secret_access_key=secret_response["SECRET_KEY"],config=config)
        except Exception as e:
          print("Error getting client: {}".format(e))
          exit(1)
        try:            
          # print("processing region: {}".format(region['RegionName'])) # altered
          # ec2_client = boto3.client('ec2', region_name=region['RegionName']) # altered
          # ec2_resource = boto3.resource('ec2', region_name=region['RegionName']) # altered
          print("processing region: {}".format(current_region)) # newly added
          ec2_client = boto3.client('ec2', region_name=current_region) # newly added
          ec2_resource = boto3.resource('ec2', region_name=current_region) # newly added
          # instances_1=[ec2_resource.Instance('i-06447786b31ef7013'),ec2_resource.Instance('i-032d2d8ce32298bee')]
          for instance in ec2_resource.instances.all():
          # for instance in instances_1:
            # debug: if(instance.id in ('i-010ee58cc7a23470c')):#'i-0872af04101c75a39')):
              print("processing instance: {}".format(instance))
              if check_ccs_tags(instance):
                instance_details = {}
                instance_details['Start Time'] = StartTime
                instance_details['End Time'] = EndTime
                instance_details['Cloud'] = "AWS"
                instance_details['Hostgroup Name'] = get_hostgroup_name(instance.id,account_id,ec2_client)
                # instance_details['AWS Region'] = region['RegionName'] # altered
                instance_details['AWS Region'] = current_region # newly added
                instance_details['Instance Id'] = instance.id
                instance_details['Platform'] = get_platform_type(instance)
                instance_details['Server Name'] = extract_tag_value(instance, "Name")
                instance_details['Instance_State'] = ec2.describe_instances(InstanceIds=[instance.id])['Reservations'][0]['Instances'][0]['State']['Name']
                print(instance_details['Platform'])
                if(instance_details['Platform']!='Windows'):
                    # instance_details['Drive Name']=get_linux_drives(StartTime,EndTime,instance.id,client) # newly added  ---1
                    # csvdata.writerow(instance_details) # newly added  ---1
                    (instance_details['Average CPU Utilisation'], instance_details['Maximum CPU Utilisation']) = get_cpu(StartTime,EndTime,instance.id, 'Linux', client)      
                    (instance_details['Average free Memory'], instance_details['Maximum free Memory'], instance_details['Minimum free Memory']) = get_mem(StartTime,EndTime,instance.id, 'Linux', client)
                    for stat in get_disk_linux(StartTime,EndTime,instance.id,client):
                      instance_details['Drive Name']=stat['letter']
                      instance_details['Total Disk Space']=stat['total']
                      instance_details['Free Disk Space']=stat['free']
                      instance_details['Utilised Disk Space']=stat['utilized']
                      instance_details['Free Disk Space %']=stat['freePct']
                      print(instance_details)
                      csvdata.writerow(instance_details)
                    # print(instance_details)
                    # csvdata.writerow(instance_details)
                else:
                    (instance_details['Average CPU Utilisation'], instance_details['Maximum CPU Utilisation']) = get_cpu(StartTime,EndTime,instance.id, 'Windows', client)  
                    (instance_details['Average free Memory'], instance_details['Maximum free Memory'], instance_details['Minimum free Memory']) = get_mem(StartTime,EndTime,instance.id, 'Windows', client)
                    # instance_details['Drive Name']=get_windows_drives(StartTime,EndTime,instance.id,client) # newly added  ---1
                    # csvdata.writerow(instance_details) # newly added ---1
                    for stat in get_disk_windows(StartTime,EndTime,instance.id,client):
                      instance_details['Drive Name']=stat['letter']
                      instance_details['Total Disk Space']=stat['total']
                      instance_details['Free Disk Space']=stat['free']
                      instance_details['Utilised Disk Space']=stat['utilized']
                      instance_details['Free Disk Space %']=stat['freePct']
                      print(instance_details)
                      csvdata.writerow(instance_details)
                    # print(instance_details)
                    # csvdata.writerow(instance_details)
                # print(instance_details)
        except Exception as e:
          if e.response['Error']['Code'] == 'UnauthorizedOperation':
            # print("Error processing region: {} Check if region is supported. Error: {}".format(region['RegionName'], e)) # altered
            print("Error processing region: {} Check if region is supported. Error: {}".format(current_region, e)) # newly added
          else:
            raise e
            
      temp_file.close()
    except Exception as e:
      print("Error opening csv file: %s" % e)
      exit(1)
        
    try:
      #secret_response = json.loads(get_secret())
      s3_client = boto3.client("s3", config=Config(signature_version='s3v4'),
                           region_name=os.environ.get("AWS_REGION"))#,aws_access_key_id=secret_response["ACCESS_KEY"],aws_secret_access_key=secret_response["SECRET_KEY"])
      print("upload report: "+filename)
      s3_client.upload_file("/tmp/" + filename, s3_destination_bucket, filename)
      print("Generate URL link to performance reports")
      presigned_url = s3_client.generate_presigned_url('get_object',  Params={'Bucket': s3_destination_bucket, 'Key': filename}, ExpiresIn=s3_presigned_link_expiration)
      print("Send message")
      sns_client.publish(TargetArn=s3_sns_topic_arn, Message="Link to performance reports (link is valid for " + str(int(int(s3_presigned_link_expiration)/3600)) + " hours): " + presigned_url, MessageStructure='string' )
    except ClientError as e:
      print("Unexpected error: %s" % e)
module "lambda_create_cloudwatch_paas_alarms_iam_role" {
  
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Monitoring Solution Deployment. Used by CCS-Lambda-lambda_cloudwatch_paas_alarms"
  context       = "CloudWatch_Alarms_for_PaaS_Instances"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "Lambda_Create_CloudWatch_PaaS_Alarms_Policy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_create_cloudwatch_paas_alarms_policy.json")
    }
  }
}


module "create_cloud_watch_alarms_for_paas_services_lambda_function" {
  for_each    = toset(var.regions)
  region      = each.key
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_cloudwatch_paas_alarms"
  role                     = module.lambda_create_cloudwatch_paas_alarms_iam_role.role_arn
  description              = "CCS Lambda Function. Creates CloudWatch Alarms for PaaS Instances"
  handler                  = "lambda_cloudwatch_paas_alarms.lambda_handler"
  timeout                  = 870
  memory_size              = 1024
  env_variables = {
    SNOWSNSTopicARN    = data.terraform_remote_state.infra.outputs.infra_snow_sns_topic
    #SNOWSNSTopicARN    = module.paas_alarm_sns_topic[each.key].sns_topic_arn
    TagsConditionKey   = var.tags_condition_key
    TagsConditionValue = var.tags_condition_value
  }
}



module "create_paas_alarms_event_rule" {
  for_each    = toset(var.regions)
  region      = each.key
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "CreatePaaSAlarms"
  description = "CCS EventRule that will trigger the CCS CreatePaaSAlarms lambda function whenever a paas service is created."
  event_pattern = jsonencode(
{
  "source": ["aws.tag"],
  "detail-type": ["Tag Change on Resource"],
  "detail": {
    "service": ["rds", "lambda", "elasticloadbalancing"],
    "resource-type": ["db", "function", "loadbalancer"],
    "changed-tag-keys": ["${var.tags_condition_key}"],
    "tags": {
      "${var.tags_condition_key}": [ { "exists": true  } ]
    }

  }
}
)
  eventbridge_target_arn = module.create_cloud_watch_alarms_for_paas_services_lambda_function[each.key].arn
  eventbridge_target_id  = "CreatePaaSCloudWatchAlarmsForInstances-${each.key}"
}

module "Create_paas_alarms_lambda_permission" {
  for_each    = toset(var.regions)
  region      = each.key
  source        = "../modules/aws_lambda_permission"
  function_name = module.create_cloud_watch_alarms_for_paas_services_lambda_function[each.key].arn
  source_arn    = module.create_paas_alarms_event_rule[each.key].arn
}

# module "paas_alarm_sns_topic" {
#   for_each    = toset(var.regions)
#   region      = each.key
#   source = "../modules/aws_sns_topic"
#   name   = "paas_alarm_sns_topic"
# }
# module "paas_alarm_sns_topic_subscription" {
#   for_each    = toset(var.regions)
#   region      = each.key
#   source      = "../modules/aws_sns_topic_subscription"
#   topic_arn   = module.paas_alarm_sns_topic[each.key].sns_topic_arn
#   endpoint    = "akash.k.s@capgemini.com"
# }


module "lambda_delete_cloudwatch_paas_alarms_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Monitoring Solution Deployment. Used by CCS-Lambda-lambda_terminate_paas_alarms"
  context       = "terminate_CloudWatch_Alarms_for_PaaS"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "Lambda_Delete_CloudWatch_PaaS_Alarms_Policy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_delete_cloudwatch_paas_alarms_policy.json")
    }
  }
}


module "delete_cloud_watch_alarms_for_paas_services_lambda_function" {
  for_each    = toset(var.regions)
  region      = each.key
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_terminate_paas_alarms"
  role                     = module.lambda_delete_cloudwatch_paas_alarms_iam_role.role_arn
  description              = "CCS Lambda Function. Deletes CloudWatch Alarms for PaaS Instances"
  handler                  = "lambda_terminate_paas_alarms.lambda_handler"
  timeout                  = 870
  memory_size              = 1024
  env_variables = {
    TagsConditionKey   = var.tags_condition_key
    TagsConditionValue = var.tags_condition_value
  }
}



module "delete_paas_alarms_event_rule" {
  for_each    = toset(var.regions)
  region      = each.key
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "DeletePaaSAlarms"
  description = "CCS EventRule that will trigger the CCS DeletePaaSAlarms lambda function whenever a paas service is deleted."
  event_pattern = jsonencode(
{
  "source": ["aws.tag"],
  "detail-type": ["Tag Change on Resource"],
  "detail": {
    "service": ["rds", "lambda", "elasticloadbalancing"],
    "resource-type": ["db", "function", "loadbalancer"],
    "changed-tag-keys": ["${var.tags_condition_key}"],
    "tags": {
      "${var.tags_condition_key}": [ { "exists": false  } ]
    }

  }
}
)
  eventbridge_target_arn = module.delete_cloud_watch_alarms_for_paas_services_lambda_function[each.key].arn
  eventbridge_target_id  = "DeletePaaSCloudWatchAlarmsForInstances"
}

module "terminate_paas_alarms_lambda_permission" {
  for_each    = toset(var.regions)
  region      = each.key
  source        = "../modules/aws_lambda_permission"
  function_name = module.delete_cloud_watch_alarms_for_paas_services_lambda_function[each.key].arn
  source_arn    = module.delete_paas_alarms_event_rule[each.key].arn
}
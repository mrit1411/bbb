regions = ["eu-central-1", "us-east-1", "ap-east-1", "eu-west-2"]
# regions         = ["eu-central-1"]
logging_enabled = false
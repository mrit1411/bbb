output "definition_id" {
  value = azurerm_policy_definition.policy_definition.id
}

output "assignment_id" {
  value = azurerm_management_group_policy_assignment.policy_assignment.id
}

output "assignment_name" {
  value = azurerm_management_group_policy_assignment.policy_assignment.name
}
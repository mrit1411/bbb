variable "patching_event_identity" {
  type = list(string)
}

variable "patching_automation_account_name" {
  description = "value for the runbook automation account name"
  type = string
}


variable "location" {
  description = "Location of the runbook automation account"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
}


variable "tags" {
  description = "Tags for the resources"
  type        = map(string)
}


﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_glue_crawler.glue_crawler](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_crawler) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_name"></a> [client\_name](#input\_client\_name) | Enter the name of Client. Used to create the selected resource | `string` | n/a | yes |
| <a name="input_configuration"></a> [configuration](#input\_configuration) | JSON string of configuration information. | `string` | n/a | yes |
| <a name="input_database_name"></a> [database\_name](#input\_database\_name) | Glue database where results are written. | `string` | n/a | yes |
| <a name="input_exclusions"></a> [exclusions](#input\_exclusions) | A list of glob patterns used to exclude from the crawl. | `list(string)` | n/a | yes |
| <a name="input_role"></a> [role](#input\_role) | The IAM role friendly name (including path without leading slash), or ARN of an IAM role, used by the crawler to access other resources. | `string` | n/a | yes |
| <a name="input_s3_target_path"></a> [s3\_target\_path](#input\_s3\_target\_path) | The path to the Amazon S3 target. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | Crawler name |

locals {
  cos_azure_log_analytics_workspace_id = var.create_cos_log_analytics_workspace ? module.cos_iaas_azure_log_analytics_workspace[0].workspace_id : data.azurerm_log_analytics_workspace.existing_log_analytics_workspace[0].id
}

locals {
  mssql_database_alert_rules_map = {
    for alert in var.mssql_database_alert_rules :
    alert.name => alert
  }
}


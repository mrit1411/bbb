resource "azurerm_service_plan" "app_service_plan" {
  name                         = local.aspname
  location                     = var.location
  os_type                      = var.service_plan_os_type
  resource_group_name          = var.resource_group_name
  sku_name                     = var.service_plan_sku_name
  maximum_elastic_worker_count = var.maximum_elastic_worker_count
  per_site_scaling_enabled     = var.per_site_scaling_enabled
  tags                         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_windows_function_app" "splunk_integration_function_app" {
  name                = local.faname
  resource_group_name = var.resource_group_name
  location            = var.location
  service_plan_id     = azurerm_service_plan.app_service_plan.id

  identity {
    type         = "SystemAssigned, UserAssigned"
    identity_ids = var.user_assigned_identity_ids
  }

  functions_extension_version   = var.functions_extension_version
  public_network_access_enabled = true
  storage_account_name          = var.storage_account_name
  storage_account_access_key    = var.storage_account_access_key
  client_certificate_enabled    = var.client_certificate_enabled
  daily_memory_time_quota       = var.daily_memory_time_quota
  https_only                    = var.https_only

  site_config {
    application_stack {
      powershell_core_version = var.powershell_core_version
    }
  }

  app_settings = {
    "WEBSITE_RUN_FROM_PACKAGE"                     = "${var.blob_url}"
    "WEBSITE_CONTENTSHARE"                         = "${lower(local.faname)}b74a"
    "KEY_VAULT_NAME"                               = var.key_vault_name
    "WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID" = var.user_assigned_identity_resource_id
  }

  lifecycle {
    ignore_changes = [tags, identity, app_settings, site_config, sticky_settings]
  }

  tags = var.tags
}
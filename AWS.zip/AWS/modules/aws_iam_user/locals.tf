data "aws_region" "current" {}

locals {
  policy_name = "${var.policy_base_name}UserS3Policy"
}
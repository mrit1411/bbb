variable "kinesis_athena_bucket_name" {
  description = "Enter S3 Bucket name that will be created and used to store converted CloudWatch Logs and Athena query results"
  type        = string
  default     = "ccs-logging"
}

variable "log_group_name" {
  description = "Name of the log group to be created"
  type        = string
  default     = "CCS-EC2-Instance-CloudWatch-Logs"
}

variable "client_name" {
  description = "Enter the name of Client. Used to create the selected resource"
  type        = string
  default     = "test_client"
}

variable "log_retention_in_days" {
  description = "Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the log group are always retained and never expire."
  type        = number
  default     = 3
}

variable "firehose_log_group_name" {
  description = "Name of the Firehose log group to be created"
  type        = string
  default     = "/aws/firehose/CCS-KinesisFirehose-Delivery-Stream"
}

variable "firehose_log_stream_name" {
  description = "Name of the firehose log stream name."
  type        = string
  default     = "CCS-Firehose-Log-Stream"
}

variable "firehose_subscription_filter_name" {
  description = "Name of the Firehose Subscription Filter"
  type        = string
  default     = "CCS-Firehose-Subscription-Filter"
}

variable "kinesis_firehose_delivery_stream_name" {
  description = "The name of the Kinesis Firehose Delivery Stream"
  type        = string
  default     = "CCS-KinesisFirehose-Delivery-Stream"
}

variable "kinesis_firehose_delivery_stream_prefix" {
  description = "The \"YYYY/MM/DD/HH\" time format prefix is automatically used for delivered S3 files. You can specify an extra prefix to be added in front of the time format prefix. Note that if the prefix ends with a slash, it appears as a folder in the S3 bucket"
  type        = string
  default     = "kinesis-"
}
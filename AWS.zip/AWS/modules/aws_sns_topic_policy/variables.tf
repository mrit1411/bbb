variable "sns_topic_arn" {
  description = "The ARN of the SNS topic to which the policy will be applied."
  type        = string
}

variable "policy_json" {
  description = "The JSON policy to apply to the SNS topic."
  type        = string

}

variable "region" {
  description = "The AWS region where the SNS topic is located."
  type        = string
  default     = "us-east-1"
}
output "id" {
  value = azurerm_maintenance_configuration.maintenance_configuration.id
}

output "name" {
  description = "Name of the maintenance configuration."
  value       = azurerm_maintenance_configuration.maintenance_configuration.name
}

output "location" {
  description = "Location/region of the maintenance configuration."
  value       = azurerm_maintenance_configuration.maintenance_configuration.location
}

output "resource_group_name" {
  description = "Resource group containing the maintenance configuration."
  value       = azurerm_maintenance_configuration.maintenance_configuration.resource_group_name
}
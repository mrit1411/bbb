resource "aws_cloudwatch_event_rule" "cloudwatch_event_rule" {
  name                = local.name
  region = var.region
  description         = var.description
  event_pattern       = var.event_pattern
  schedule_expression = var.schedule
  state               = var.state ? "ENABLED" : "DISABLED"
}

resource "aws_cloudwatch_event_target" "cloudwatch_event_target" {
  arn       = var.eventbridge_target_arn
  region = aws_cloudwatch_event_rule.cloudwatch_event_rule.region
  rule      = aws_cloudwatch_event_rule.cloudwatch_event_rule.id
  role_arn  = var.eventbridge_target_role_arn
  target_id = var.eventbridge_target_id
  input     = var.input
}
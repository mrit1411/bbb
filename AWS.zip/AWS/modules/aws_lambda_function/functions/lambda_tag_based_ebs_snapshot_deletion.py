import boto3
import datetime

ec2 = boto3.client('ec2')

def lambda_handler(event, context):

    delete_on = datetime.date.today().strftime('%Y-%m-%d')
    filters = [
        {'Name': 'tag-key', 'Values': ['DeleteOn']},
        {'Name': 'tag-value', 'Values': [delete_on]},
    ]

    snapshot_response = ec2.describe_snapshots(Filters=filters)
    
    if snapshot_response['Snapshots']:
        for snap in snapshot_response['Snapshots']:
            print("Deleting snapshot %s" % snap['SnapshotId'])
            try:
                ec2.delete_snapshot(SnapshotId=snap['SnapshotId'])
            except Exception as e:
                print(f"Error occured while deleting the snapshot: {e}. Skipping...")
                pass
    else:
        print(f'No snapshots tagged with "DeleteOn: {delete_on}"')

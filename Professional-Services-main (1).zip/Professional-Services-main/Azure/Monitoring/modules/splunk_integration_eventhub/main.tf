resource "azurerm_eventhub_namespace" "splunk_integration_eventhub_namespace" {
    name                = local.name
    location            = var.location
    resource_group_name = var.resource_group_name
    sku                 = "Standard"
    capacity            = 1
    tags                = var.tags
}
resource "azurerm_eventhub" "splunk_integration_eventhub" {
  name              = local.eventhub_name
  namespace_id      = azurerm_eventhub_namespace.splunk_integration_eventhub_namespace.id
  partition_count   = 1
  message_retention = 1
}
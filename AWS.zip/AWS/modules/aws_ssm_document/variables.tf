variable "name" {
  description = "The name of the SSM document."
  type        = string
}

variable "content" {
  description = "The content of the SSM document in JSON or YAML format."
  type        = string
}

variable "document_type" {
  description = "The type of the SSM document. Valid values are Command | Policy | Automation | Session | Package | ApplicationConfiguration | ApplicationConfigurationSchema | DeploymentStrategy | ChangeCalendar | Automation.ChangeTemplate | ProblemAnalysis | ProblemAnalysisTemplate | CloudFormation | ConformancePackTemplate | QuickSetup | ManualApprovalPolicy | AutoApprovalPolicy."
  type        = string
  default     = "Automation"

  validation {
    condition     = contains(["Command", "Policy", "Automation", "Session", "Package", "ApplicationConfiguration", "ApplicationConfigurationSchema", "DeploymentStrategy", "ChangeCalendar", "Automation.ChangeTemplate", "ProblemAnalysis", "ProblemAnalysisTemplate", "CloudFormation", "ConformancePackTemplate", "QuickSetup", "ManualApprovalPolicy", "AutoApprovalPolicy"], var.document_type)
    error_message = "Invalid document type. Must be one of: Command, Policy, Automation, Session, Package, ApplicationConfiguration, ApplicationConfigurationSchema, DeploymentStrategy, ChangeCalendar, Automation.ChangeTemplate, ProblemAnalysis, ProblemAnalysisTemplate, CloudFormation, ConformancePackTemplate, QuickSetup, ManualApprovalPolicy, AutoApprovalPolicy."
  }
}

variable "target_type" {
  description = "The target type which defines the kinds of resources the document can run on. For example, /AWS::EC2::Instance"
  type        = string
  default     = null
}
output "secret_id" {
  value = aws_secretsmanager_secret.secretsmanager_secret.id
}
resource "aws_sqs_queue" "sqs_queue" {
  region = var.region
  name   = local.name
}
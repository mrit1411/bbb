﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_scheduled_query_rules_alert_v2.paas_alert_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_scheduled_query_rules_alert_v2) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_id"></a> [action\_group\_id](#input\_action\_group\_id) | List of Action Group resource IDs to trigger when the alert fires | `list(string)` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | Description of the alert rule | `string` | n/a | yes |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Whether the alert rule is enabled | `bool` | `true` | no |
| <a name="input_evaluation_frequency"></a> [evaluation\_frequency](#input\_evaluation\_frequency) | How often the alert rule is evaluated (e.g. PT5M) | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Location for the PaaS Log V2 Alert | `string` | n/a | yes |
| <a name="input_metric_measure_column"></a> [metric\_measure\_column](#input\_metric\_measure\_column) | Metric measure column for the alert rule criteria | `string` | `""` | no |
| <a name="input_minimum_failing_periods"></a> [minimum\_failing\_periods](#input\_minimum\_failing\_periods) | Minimum number of failing periods to trigger the alert | `number` | `1` | no |
| <a name="input_name"></a> [name](#input\_name) | Name of the alert rule | `string` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | provider namespace for the PaaS Log V2 Alert, e.g. Microsoft.OperationalInsights/workspaces | `string` | n/a | yes |
| <a name="input_number_of_evaluation_periods"></a> [number\_of\_evaluation\_periods](#input\_number\_of\_evaluation\_periods) | Number of evaluation periods to consider for the alert | `number` | `1` | no |
| <a name="input_operator"></a> [operator](#input\_operator) | Operator for the alert rule criteria (e.g. GreaterThan, LessThan) | `string` | n/a | yes |
| <a name="input_query"></a> [query](#input\_query) | Kusto query for the alert rule criteria | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resource group for the PaaS Log V2 Alert | `string` | n/a | yes |
| <a name="input_resource_id_column"></a> [resource\_id\_column](#input\_resource\_id\_column) | Resource ID column for the alert rule criteria | `string` | n/a | yes |
| <a name="input_scopes"></a> [scopes](#input\_scopes) | List of resource IDs to scope the alert rule to | `list(string)` | n/a | yes |
| <a name="input_severity"></a> [severity](#input\_severity) | Severity of the alert rule (0 is highest, 4 is lowest) | `number` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | <pre>{<br/>  "ccs_managed": "yes"<br/>}</pre> | no |
| <a name="input_threshold"></a> [threshold](#input\_threshold) | Threshold value for the alert rule criteria | `number` | n/a | yes |
| <a name="input_time_aggregation_method"></a> [time\_aggregation\_method](#input\_time\_aggregation\_method) | Time aggregation method for the alert rule criteria (e.g. Total, Average) | `string` | n/a | yes |
| <a name="input_window_duration"></a> [window\_duration](#input\_window\_duration) | The time window over which data is analyzed (e.g. PT5M) | `string` | n/a | yes |

## Outputs

No outputs.


## Usage

**How to Create a New Log Search Alert for a PaaS Service**

Step 1:
Go to the file named terraform.tfvars located under the folder Monitoring, you will find a map variable named "paas_alerts_map".

Step 2:
Inside the map, each key (like SQLdb_cpu_1, app_service_plan_cpu_2, etc.) represents a log search alert configuration for a PaaS resource.

Step 3:
To add a new log search alert:
- Use a unique key name following the existing naming pattern.
- Add a new block with the required alert details such as:
  - name
  - operator
  - threshold
  - time_aggregation_method
  - query
  - severity
  - evaluation_frequency
  - window_duration
  - description
  - enabled
  - minimum_failing_periods
  - number_of_evaluation_periods

Example:
new_alert_key = {
  name                         = "Your Alert Name"
  operator                     = "GreaterThan"
  threshold                    = 85
  time_aggregation_method      = "Average"
  query                        = <<-QUERY
AzureMetrics
| where MetricName == "your_metric_name" and ResourceId contains "your_resource_type"
| summarize Result=aggregationtype(aggregationtypecolumn) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
  severity                     = 2
  evaluation_frequency         = "PT5M"
  window_duration              = "PT15M"
  description                  = "Your alert description"
  enabled                      = true
  minimum_failing_periods      = 1
  number_of_evaluation_periods = 1
}

Step 4: Run the terraform command in the terminal:
```bash
terraform apply -target="module.paas_alert_rules"
```

**How to Delete an Alert for a PaaS Service**

Step 1:
Go to the file named terraform.tfvars located under the folder Monitoring, you will find a map variable named "paas_alerts_map".

Step 2:
Inside the map, each key (like SQLdb_cpu_1, app_service_plan_cpu_2, etc.) represents an alert configuration for a PaaS Service. Find the key that corresponds to the log search alert you want to remove.

Step 3:
Delete the entire block for that key from the map.

Example:  When you find the key corresponding to log search alert, remove the whole key block

new_alert_key = {
  name                         = "Your Alert Name"
  operator                     = "GreaterThan"
  threshold                    = 85
  time_aggregation_method      = "Average"
  query                        = <<-QUERY
AzureMetrics
| where MetricName == "your_metric_name" and ResourceId contains "your_resource_type"
| summarize Result=aggregationtype(aggregationtypecolumn) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
  severity                     = 2
  evaluation_frequency         = "PT5M"
  window_duration              = "PT15M"
  description                  = "Your alert description"
  enabled                      = true
  minimum_failing_periods      = 1
  number_of_evaluation_periods = 1
}

Step 4: Run the terraform command in the terminal:
```bash
terraform apply -target="module.paas_alert_rules"
```


**How to Modify a Log Search Alert for a PaaS Service**

Step 1:
Go to the file named "terraform.tfvars" located under the folder "Monitoring".  
You will find a map variable named "paas_alerts_map".

Step 2:
Inside the map, each key (like "SQLdb_cpu_1", "app_service_plan_cpu_2", etc.) represents an alert configuration for a PaaS service.  
Find the key that corresponds to the log search alert you want to modify.

Step 3: 
Change the parameter value in the key block of the log search alert.  
You can update values like "threshold", "query", "severity", etc.

Example:

new_alert_key = {
  name                         = "Your Alert Name"
  operator                     = "GreaterThan"
  threshold                    = 85
  time_aggregation_method      = "Average"
  query                        = <<-QUERY
AzureMetrics
| where MetricName == "your_metric_name" and ResourceId contains "your_resource_type"
| summarize Result=aggregationtype(aggregationtypecolumn) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
  severity                     = 2
  evaluation_frequency         = "PT5M"
  window_duration              = "PT15M"
  description                  = "Your alert description"
  enabled                      = true
  minimum_failing_periods      = 1
  number_of_evaluation_periods = 1
}


Step 4:
Run the following Terraform command in the terminal to apply the changes:
```bash
terraform apply -target="module.paas_alert_rules"
```
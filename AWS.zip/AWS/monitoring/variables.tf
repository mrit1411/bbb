variable "availability_reports_bucket_name" {
  description = "Enter the name of the S3 bucket that will be created and used to store monthly AWS Availability reports"
  type        = string
  default     = "ccs-availability-reports-bucket"
}

variable "events_reports_bucket_name" {
  description = "Enter the name of the S3 bucket that will be created and used to store monthly AWS Events reports"
  type        = string
  default     = "ccs-events-reports-bucket"
}

variable "performance_reports_bucket_name" {
  description = "Enter the name of the S3 bucket that will be created and used to store monthly AWS Performance reports"
  type        = string
  default     = "ccs-performance-reports-bucket"
}

variable "availability_report_generation_schedule_monthly" {
  description = "Enter the schedule for Monthly AWS Availability report generation. AWS CRON expression specifying when the Availability EventBridge Rule will initiate the generation of monthly AWS Availability reports. by default (01:30 AM first day of every month)"
  type        = string
  default     = "cron(30 1 1 * ? *)"
}

variable "events_report_generation_schedule_monthly" {
  description = "Enter the schedule for Monthly AWS Events report generation. AWS CRON expression specifying when the Events EventBridge Rule will initiate the generation of monthly AWS Events reports. by default (01:30 AM first day of every month)"
  type        = string
  default     = "cron(30 1 1 * ? *)"
}

variable "performace_report_generation_schedule_monthly" {
  description = "Enter the schedule for Monthly AWS Performance report generation. AWS CRON expression specifying when the Performance EventBridge Rule will initiate the generation of monthly AWS Performance reports. by default (01:30 AM first day of every month)"
  type        = string
  default     = "cron(30 1 1 * ? *)"
}

variable "availability_report_sns_topic_name" {
  description = "Enter the name for the SNS Topic that will be created and used by the Availability report lambda to email monthly AWS Availability reports"
  type        = string
  default     = "Availability-Reports"
}

variable "events_report_sns_topic_name" {
  description = "Enter the name for the SNS Topic that will be created and used by the Events report lambda to email monthly AWS Events reports"
  type        = string
  default     = "Events-Reports"
}

variable "performance_report_sns_topic_name" {
  description = "Enter the name for the SNS Topic that will be created and used by the Performance report lambda to email monthly AWS Performance reports"
  type        = string
  default     = "Performance-Reports"
}

variable "availability_report_recipient" {
  description = "Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Availability Reports"
  type        = string
  default     = "akarsh.a.srivastava@capgemini.com"
}

variable "events_report_recipient" {
  description = "Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Events Reports"
  type        = string
  default     = "akarsh.a.srivastava@capgemini.com"
}

variable "performance_report_recipient" {
  description = "Enter the recipient email address that will receive scheduled emails containing a link to Monthly AWS Performance Reports"
  type        = string
  default     = "akarsh.a.srivastava@capgemini.com"
}

variable "availability_link_validity" {
  description = "Enter how long in seconds the AWS Availability Report notification link will be valid for (86400 - 24h, 604800 - 7 days)"
  type        = number
  default     = 604800
}

variable "tags_condition_key" {
  description = "Resources with this Tag Key will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "ccs_managed"
}

variable "tags_condition_value" {
  description = "Resources with this Tag Value will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "yes"
}

variable "account_name" {
  description = "Enter the name of Client."
  type        = string
  default     = "TestClient"
}

variable "monitoring_enabled" {
  description = "Specifies if the CCS Incident Manager module and resources will be deployed."
  type        = bool
  default     = true
}

variable "logging_enabled" {
  description = "Set to true if Incident Manager is already enabled"
  type        = bool
  default     = true
}
variable "availability_url_user_credentials" {

  description = "iam user for AvailabilityURLUserCredentials"
  type        = string
  default     = "AvailabilityURLUserCredentials"

}
variable "events_url_user_credentials" {

  description = "iam user for EventsURLUserCredentials"
  type        = string
  default     = "EventsURLUserCredentials"

}
variable "performance_url_user_credentials" {

  description = "iam user for PerformanceURLUserCredentials"
  type        = string
  default     = "PerformanceURLUserCredentials"

}

variable "availability_report_url_user" {
  description = "IAM user for AvailabilityReportURLUser"
  type        = string
  default     = "AvailabilityReportURLUser"
}

variable "event_report_url_user" {
  description = "IAM user for EventsReportURLUser"
  type        = string
  default     = "EventsReportURLUser"
}

variable "performance_report_url_user" {
  description = "IAM user for PerformanceReportURLUser"
  type        = string
  default     = "PerformanceReportURLUser"
}

variable "regions" {
  description = "Enter the AWS regions where the AWS resources will be deployed."
  type        = list(string)
}
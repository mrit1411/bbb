resource "azurerm_log_analytics_workspace" "log_analytics_workspace" {
  name                       = local.name
  location                   = var.location
  resource_group_name        = var.resource_group_name
  sku                        = var.sku
  retention_in_days          = var.retention_in_days
  cmk_for_query_forced       = var.cmk_for_query_forced
  internet_ingestion_enabled = var.internet_ingestion_enabled
  internet_query_enabled     = var.internet_query_enabled
  tags                       = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_maintenance_configuration.maintenance_configuration](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/maintenance_configuration) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_classifications_linux"></a> [classifications\_linux](#input\_classifications\_linux) | Linux classifications to include | `list(string)` | `[]` | no |
| <a name="input_classifications_windows"></a> [classifications\_windows](#input\_classifications\_windows) | Windows classifications to include | `list(string)` | <pre>[<br/>  "Security"<br/>]</pre> | no |
| <a name="input_duration"></a> [duration](#input\_duration) | The duration of the maintenance window in HH:mm format. | `string` | `"03:55"` | no |
| <a name="input_expiration_date_time"></a> [expiration\_date\_time](#input\_expiration\_date\_time) | Effective expiration date of the maintenance window in YYYY-MM-DD hh:mm format. | `string` | `"2099-01-06 19:15"` | no |
| <a name="input_kb_numbers_windows"></a> [kb\_numbers\_windows](#input\_kb\_numbers\_windows) | KB numbers to include for Windows | `list(string)` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | Location of the maintenance configuration | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | Name of the maintenance configuration | `string` | n/a | yes |
| <a name="input_reboot"></a> [reboot](#input\_reboot) | Reboot option for the maintenance configuration | `bool` | `false` | no |
| <a name="input_recur_every"></a> [recur\_every](#input\_recur\_every) | The rate at which a maintenance window is expected to recur. The rate can be expressed as daily, weekly, or monthly schedules. | `string` | `"Day"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group | `string` | n/a | yes |
| <a name="input_start_date_time"></a> [start\_date\_time](#input\_start\_date\_time) | Effective start date of the maintenance window in YYYY-MM-DD hh:mm format. | `string` | `"2026-01-08 18:15"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the maintenance configuration | `map(string)` | n/a | yes |
| <a name="input_time_zone"></a> [time\_zone](#input\_time\_zone) | Time zone for the maintenance configuration | `string` | `"Eastern Standard Time"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_location"></a> [location](#output\_location) | Location/region of the maintenance configuration. |
| <a name="output_name"></a> [name](#output\_name) | Name of the maintenance configuration. |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | Resource group containing the maintenance configuration. |

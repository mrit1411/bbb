resource "aws_sns_topic_subscription" "ns_topic_subscription" {
  topic_arn = var.topic_arn
  endpoint  = var.endpoint
  protocol  = var.protocol
  region = var.region
}
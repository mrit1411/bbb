locals {
  name = "CCS-${var.context}-EventRule-${var.region}"
}
import os
import boto3
from datetime import datetime

ssm_client = boto3.client('ssm-incidents')
ec2_client = boto3.client('ec2')

response_plan_arn = os.environ.get('ResponsePlanArn')
ssm_managed_tag_name  = os.environ.get('TagsConditionKey')
ssm_managed_tag_value = os.environ.get('TagsConditionValue')

def lambda_handler(event, context):
    # date
    alarm_event_date = datetime.strptime(event['detail']['state']['timestamp'], "%Y-%m-%dT%H:%M:%S.%f%z")
    alarm_datetime = alarm_event_date.strftime("%Y, %m, %d")
    
    # alarm details
    event_id = event['id']
    event_source = event['source']
    instance_id = event['detail']['configuration']['metrics'][0]['metricStat']['metric']['dimensions']['InstanceId']
    resource_arn =  event['resources'][0]

    # create incident
    if check_if_tags_exist(ec2_client, instance_id, ssm_managed_tag_name, ssm_managed_tag_value):
        print('Creating the incident...')
        create_incident(ssm_client, resource_arn, alarm_datetime, response_plan_arn, event_id, event_source)
    else:
        print(f'EC2 instance with ID: {instance_id} doesn\'t have the required tags. Incident cannot be created.')
    

def check_if_tags_exist(ec2_client, instance_id, ssm_managed_tag_name, ssm_managed_tag_value):
    instance_tags = ec2_client.describe_tags(Filters =[{ 'Name': 'resource-id', 'Values': [ instance_id ]}])
    print(instance_tags["Tags"])
    for tag in instance_tags["Tags"]:
        if tag['Key'] == ssm_managed_tag_name:
            if (tag['Value'] == ssm_managed_tag_value):
                return True
            else:
                return False

def create_incident(ssm_client, resource_arn, alarm_datetime, response_plan_arn, event_id, event_source):
    try:
        response = ssm_client.start_incident(
            clientToken=event_id,
            impact=3,
            relatedItems=[
                {
                    'identifier': {
                        'type': 'OTHER',
                        'value': {
                            'arn': resource_arn
                        }
                    },
                    'title': 'CloudWatchAlarm'
                },
            ],
            responsePlanArn=response_plan_arn,
            triggerDetails={
                'source': event_source,
                'timestamp': alarm_datetime,
                'triggerArn': resource_arn
            }
        )

        print(response['incidentRecordArn'])
        
    except Exception as e:
        print("Unexpected error: %s" % e)

    return response['incidentRecordArn']
resource "aws_ssm_maintenance_window" "ssm_maintenance_window" {
  name                       = var.window_name
  schedule                   = var.window_schedule
  cutoff                     = var.window_cutoff
  duration                   = var.window_duration
  description                = var.window_description
  allow_unassociated_targets = var.allow_unassociated_targets
  end_date                   = var.window_end_date
  start_date                 = var.window_start_date
  schedule_timezone          = var.window_schedule_timezone
}

resource "aws_ssm_maintenance_window_target" "ssm_maintenance_window_target" {
  window_id         = aws_ssm_maintenance_window.ssm_maintenance_window.id
  name              = var.window_target_name
  description       = var.window_target_description
  resource_type     = var.window_target_resource_type
  owner_information = var.owner_information

  dynamic "targets" {
    for_each = var.window_targets
    content {
      key    = "tag:${targets.value.key}"
      values = targets.value.values
    }
  }
}

resource "aws_ssm_maintenance_window_task" "patching_task" {
  window_id       = aws_ssm_maintenance_window.ssm_maintenance_window.id
  max_concurrency = var.patching_task_max_concurrency
  max_errors      = var.patching_task_max_errors
  task_type       = var.patching_task_type
  task_arn        = var.patching_task_arn
  name            = var.patching_task_name
  description     = var.patching_task_description
  priority        = var.patching_task_priority

  task_invocation_parameters {
    run_command_parameters {
      service_role_arn = var.patching_task_invocation_service_role_arn

      notification_config {
        notification_arn    = var.patching_task_notification_arn
        notification_events = var.patching_task_notification_events
        notification_type   = var.patching_task_notification_type
      }

      parameter {
        name   = var.patching_task_parameter_name
        values = var.patching_task_parameter_values
      }

      parameter {
        name = var.patching_task_reboot_parameter_name
        values = var.require_reboot ? ["RebootIfNeeded"] : ["NoReboot"]
      }
    }
  }

  targets {
    key    = var.patching_task_target_key
    values = [aws_ssm_maintenance_window_target.ssm_maintenance_window_target.id]
  }
}

resource "aws_ssm_maintenance_window_task" "disable_alarms_task" {
  window_id       = aws_ssm_maintenance_window.ssm_maintenance_window.id
  max_concurrency = var.disable_alarms_task_max_concurrency
  max_errors      = var.disable_alarms_task_max_errors
  task_type       = var.disable_alarms_task_type
  task_arn        = var.disable_alarms_task_arn
  name            = var.disable_alarms_task_name
  description     = var.disable_alarms_task_description
  priority        = var.disable_alarms_task_priority

  task_invocation_parameters {
    automation_parameters {

      dynamic "parameter" {
        for_each = local.disable_alarms_task_parameters
        content {
          name   = parameter.value.name
          values = parameter.value.values
        }

      }
    }
  }

  service_role_arn = var.modify_alarms_task_assume_role_arn

  targets {
    key    = var.disable_alarms_task_target_key
    values = [aws_ssm_maintenance_window_target.ssm_maintenance_window_target.id]
  }
}

resource "aws_ssm_maintenance_window_task" "enable_alarms_task" {
  window_id       = aws_ssm_maintenance_window.ssm_maintenance_window.id
  max_concurrency = var.enable_alarms_task_max_concurrency
  max_errors      = var.enable_alarms_task_max_errors
  task_type       = var.enable_alarms_task_type
  task_arn        = var.enable_alarms_task_arn
  name            = var.enable_alarms_task_name
  description     = var.enable_alarms_task_description
  priority        = var.enable_alarms_task_priority

  task_invocation_parameters {
    automation_parameters {

      dynamic "parameter" {
        for_each = local.enable_alarms_task_parameters
        content {
          name   = parameter.value.name
          values = parameter.value.values
        }

      }
    }
  }

  service_role_arn = var.modify_alarms_task_assume_role_arn

  targets {
    key    = var.enable_alarms_task_target_key
    values = [aws_ssm_maintenance_window_target.ssm_maintenance_window_target.id]
  }
}
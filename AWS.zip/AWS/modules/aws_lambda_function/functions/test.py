import boto3


session = boto3.Session(profile_name='monitoring_account')

cloudwatch = session.client('cloudwatch')

response_monitoring_account = cloudwatch.put_metric_alarm(
    AlarmName="oam_alarm_monitoring_account",
    MetricName="Errors",
    Namespace="AWS/Lambda",
    Statistic="Sum",
    Period=300,
    EvaluationPeriods=1,
    Threshold=1,
    ComparisonOperator="GreaterThanOrEqualToThreshold",
    AlarmDescription="Alarm when the Lambda function has errors",
    Dimensions=[
        {
            "Name":"FunctionName",
            "Value":"CCS-Lambda-lambda_performance_reports"
        },
        {
            "Name":"AccountId",
            "Value":"869935067455"
        }
    ],
    AlarmActions=[],
    OKActions=[]
)

print(f"monitoring account response = {response_monitoring_account}")

response_source_account = cloudwatch.put_metric_alarm(
    AlarmName="oam_alarm_source_account",
    MetricName="Errors",
    Namespace="AWS/Lambda",
    Statistic="Sum",
    Period=300,
    EvaluationPeriods=1,
    Threshold=1,
    ComparisonOperator="GreaterThanOrEqualToThreshold",
    AlarmDescription="Alarm when the Lambda function has errors",
    Dimensions=[
        {
            "Name":"FunctionName",
            "Value":"CCS-Lambda-lambda_performance_reports"
        },
        {
            "Name":"AccountId",
            "Value":"471112573064"
        }
    ],
    AlarmActions=[],
    OKActions=[]
)

print(f"source account response = {response_source_account}")

# code for random string generation
import random
import string
def random_string(length=8):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

cloudwatch.put_metric_alarm(
    AlarmName="oam_alarm_source_account_metrics_array",
    AlarmDescription="Alarm created in monitoring account for metric in source account using boto3 metrics array.",
    ActionsEnabled=True,
    OKActions=[],
    AlarmActions=[],
    InsufficientDataActions=[],
    EvaluationPeriods=1,
    DatapointsToAlarm=1,
    Threshold=1,
    ComparisonOperator="GreaterThanThreshold",
    TreatMissingData="missing",
    Metrics=[
        {
            "Id": random_string(5),
            "ReturnData": True,
            "AccountId": "471112573064",
            "MetricStat": {
                "Metric": {
                    "Namespace": "AWS/Lambda",
                    "MetricName": "Errors",
                    "Dimensions": [
                        {
                            "Name": "FunctionName",
                            "Value": "CCS-Lambda-lambda_performance_reports"
                        }
                    ]
                },
                "Period": 60,
                "Stat": "Sum"
            }
        }
    ],
    Tags=[
        {
            "Key": "ccs_managed",
            "Value": "yes"
        }
    ]
)
locals {
  patch_baselines = [
    {
      name               = "CCS-windows-server-patch-baseline"
      description        = "Windows patch baseline installing critical and security updates. Deployed as part of CCS Patching Solution."
      os                 = "WINDOWS"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["CriticalUpdates", "SecurityUpdates"]
        },
        {
          key    = "MSRC_SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-suse-linux-patch-baseline"
      description        = "SUSE patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "SUSE"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Recommended"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-rhel-patch-baseline"
      description        = "RHEL patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "REDHAT_ENTERPRISE_LINUX"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Bugfix"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-ubuntu-patch-baseline"
      description        = "Ubuntu patch baseline installing important and required updates. Deployed as part of CCS Patching Solution."
      os                 = "UBUNTU"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "PRIORITY"
          values = ["Important", "Required"]
        }
      ]
    },
    {
      name               = "CCS-centos-patch-baseline"
      description        = "CentOS patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "CENTOS"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Bugfix"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-debian-linux-patch-baseline"
      description        = "Debian patch baseline installing security updates. Deployed as part of CCS Patching Solution."
      os                 = "DEBIAN"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "PRIORITY"
          values = ["Important", "Required"]
        }
      ]
    },
    {
      name               = "CCS-oracle-linux-patch-baseline"
      description        = "Oracle Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "ORACLE_LINUX"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Bugfix"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-amazon-linux-patch-baseline"
      description        = "Amazon Linux patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "AMAZON_LINUX"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Bugfix"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    },
    {
      name               = "CCS-amazon-linux-2-patch-baseline"
      description        = "Amazon Linux 2 patch baseline installing critical and important updates. Deployed as part of CCS Patching Solution."
      os                 = "AMAZON_LINUX_2"
      approve_after_days = 1
      patch_filters = [
        {
          key    = "CLASSIFICATION"
          values = ["Security", "Bugfix"]
        },
        {
          key    = "SEVERITY"
          values = ["Critical", "Important"]
        }
      ]
    }
  ]
}

location                                  = "westeurope"
log_analytics_workspace_sku               = "PerGB2018"
log_analytics_workspace_retention_in_days = 30
resource_group_name                       = "RG-PRD-EAF-EUW"
iaas_law_rg_name                          = "RG-PRD-EAF-EUW"
tags = {
  "ccs_managed" = "yes"
  "Environment" = "Prod"
}
splunk_integration_function_zip_name = "splunk_azure_integration_func"
splunk_integration_function_zip_path = "./modules/splunk_integration_storage_module/function.zip"
prod_action_group_short_name                       = "splunkpag"
test_action_group_short_name                       = "splunktag"
azure_prod_function_receiver_name                  = "splunk_integration"
azure_test_function_receiver_name                  = "splunk_integration_test"
prod_splunk_integration_function_name              = "splunk_integration"
test_splunk_integration_function_name              = "splunk_integration_test"
org                                                = "org"
environment                                        = "Prod"
project-shortname                                  = "tfm"
context                                            = "tfm"
policy_management_group_id                         = [""] #resource id of the management group where policy will be applied 
cos_ama_mi_name                                    = "tftest-main" #name of MI which will be attached to the VMs for monitoring module 
cos_ama_mi_id                                      = "/subscriptions/********/resourceGroups/*********/providers/Microsoft.ManagedIdentity/userAssignedIdentities/tftest-main" #resource id  of MI which will be attached to the VMs for monitoring module
ct_dcr_id                                          = "/subscriptions/***********/resourceGroups/******/providers/Microsoft.Insights/dataCollectionRules/********" ##resource id of Change tracking DCR 
policy_subscription_id                             = "/subscriptions/*******" #resource id of the subscription on which policy will be assigned 
policy_assignment_user_assigned_identity_ids       = ["/subscriptions/*********/resourceGroups/*********/providers/Microsoft.ManagedIdentity/userAssignedIdentities/*****"]
func_sami_object_id                                = "" #this needs to be changed later as this is SAMI of function app. This will be added after function app has been created 
splunk_integration_prod_client_id_secret_name      = "prodClientId" #name of the secret which contains client id. should not be changed 
splunk_integration_prod_client_id_secret_value     = ""
splunk_integration_prod_client_secret_secret_name  = "prodClientSecret" #name of the secret which contains client secret. should not be changed 
splunk_integration_prod_client_secret_secret_value = ""
splunk_integration_test_client_id_secret_name      = "testClientId" #name of the secret which contains client id. should not be changed 
splunk_integration_test_client_id_secret_value     = ""
splunk_integration_test_client_secret_secret_name  = "testClientSecret" #name of the secret which contains client secret. should not be changed 
splunk_integration_test_client_secret_secret_value = ""
splunk_integration_package_mi_resource_id = ""
splunk_integration_user_assigned_identity_ids = [""] 
terraform_vm_mi_object_id = ""

### Below variables will be used in deployment of mssql database alert rules. These are optional and can be removed if not required.

data_sources = [
  {
    name                          = "perfCounterDataSource60"
    type                          = "performance_counter"
    streams                       = ["Microsoft-Perf"]
    sampling_frequency_in_seconds = 60
    counter_specifiers = [
      "\\SQLServer:Buffer Manager\\Buffer cache hit ratio",
      "\\SQLServer:Buffer Manager\\Page life expectancy",
      "\\SQLServer:General Statistics\\Processes blocked",
      "\\SQLServer:SQL Statistics\\Batch Requests/sec",
      "\\SQLServer:General Statistics\\User Connections",
      "\\SQLServer:Transactions\\Free Space in tempdb (KB)",
      "\\SQLServer:Transactions\\Longest Transaction Running Time",
      "\\MSSQL$A105050:Buffer Manager\\Buffer cache hit ratio",
      "\\MSSQL$A105050:Buffer Manager\\Page life expectancy",
      "\\MSSQL$A105050:General Statistics\\Processes blocked",
      "\\MSSQL$A105050:SQL Statistics\\Batch Requests/sec",
      "\\MSSQL$A105050:General Statistics\\User Connections",
      "\\MSSQL$A105050:Transactions\\Free Space in tempdb (KB)",
      "\\MSSQL$A105050:Transactions\\Longest Transaction Running Time",
      "\\MSSQL$B105050:Buffer Manager\\Buffer cache hit ratio",
      "\\MSSQL$B105050:Buffer Manager\\Page life expectancy",
      "\\MSSQL$B105050:General Statistics\\Processes blocked",
      "\\MSSQL$B105050:SQL Statistics\\Batch Requests/sec",
      "\\MSSQL$B105050:General Statistics\\User Connections",
      "\\MSSQL$B105050:Transactions\\Free Space in tempdb (KB)",
      "\\MSSQL$B105050:Transactions\\Longest Transaction Running Time",
      "\\MSSQL$C105050:Buffer Manager\\Buffer cache hit ratio",
      "\\MSSQL$C105050:Buffer Manager\\Page life expectancy",
      "\\MSSQL$C105050:General Statistics\\Processes blocked",
      "\\MSSQL$C105050:SQL Statistics\\Batch Requests/sec",
      "\\MSSQL$C105050:General Statistics\\User Connections",
      "\\MSSQL$C105050:Transactions\\Free Space in tempdb (KB)",
      "\\MSSQL$C105050:Transactions\\Longest Transaction Running Time"
    ]
    x_path_queries = null
  },

  {
    name                          = "eventLogsDataSource"
    type                          = "windows_event_log"
    streams                       = ["Microsoft-Event"]
    sampling_frequency_in_seconds = null
    counter_specifiers            = null
    x_path_queries = [
        "System!*[System[(EventID=1135 or EventID=26014 or EventID=7036 or EventID=7000 or EventID=7009 or EventID=7011 or EventID=1205)]]",
         "Application!*[System[(EventID=17069 or EventID=3449 or EventID=26067)]]",
          "Application!*[System[(EventID=17131 or EventID=885 or EventID=17148 or EventID=3624 or EventID=14420 or EventID=42008 or EventID=26014 or EventID=18401 or EventID=60712 or EventID=17065)]]",
           "Application!*[System[(EventID=17207 or EventID=833 or EventID=20084 or EventID=701 or EventID=17883 or EventID=802 or EventID=2004 or EventID=17803 or EventID=832)]]",
            "Application!*[System[(EventID=32042 or EventID=1205 or EventID=50000 or EventID=9002 or EventID=1105 or EventID=1101)]]",
             "Application!*[System[(EventID=102 or EventID=318 or EventID=1416 or EventID=1479 or EventID=35264 or EventID=1480 or EventID=35267 or EventID=605 or EventID=18204)]]",
              "System!*[System[(EventID=1069 or EventID=1135 or EventID=1146 or EventID=1205)]]",
              "Application!*[System[(EventID=1480 or EventID=1479 or EventID=35201 or EventID=35206 or EventID=35250 or EventID=35264 or EventID=35265 or EventID=35267 or EventID=34047)]]",
               "Application!*[System[(EventID=34048 or EventID=41047 or EventID=41048 or EventID=41049 or EventID=41091 or EventID=41131 or EventID=41144 or EventID=41406 or EventID=19406)]]",
                "System!*[System[(EventID=7000 or EventID=7034)]]",
                "Application!*[System[(EventID=17061 or EventID=17062 or EventID=17063)]]", 
                "Application!*[System[(EventID=17113 or EventID=17120 or EventID=3415 or EventID=823 or EventID=824 or EventID=825 or EventID=3456 or EventID=3417 or EventID=3414 or EventID=5084 )]]",
                 "Application!*[System[(EventID=3041 or EventID=3041)]]"
    ]
  }
]

data_flows = [
  {
    streams       = ["Microsoft-Perf"]
    output_stream = "Microsoft-Perf"
    transform_kql = "source"
  },
  {
    streams       = ["Microsoft-Event"]
    output_stream = "Microsoft-Event"
    transform_kql = "source"
  }
]

mssql_database_alert_rules = [

  {
    name                    = "ORG-CCS-MSSQL-Check_UserConnections"
    description             = "ORG-CCS-MSSQL-Check_UserConnections"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "Equal"
    threshold               = 0
    time_aggregation_method = "Maximum"
    metric_measure_column   = "CounterValue"
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "CounterPath", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Perf
| where CounterName == 'User Connections'
| where TimeGenerated > ago(5m)
| summarize arg_max(TimeGenerated, CounterValue) by Computer, CounterPath, _ResourceId
| project TimeGenerated, Computer, CounterPath, CounterValue, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_TempdbFull"
    description             = "ORG-CCS-MSSQL-Check_TempdbFull"
    severity                = 2
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "LessThan"
    threshold               = 10240
    time_aggregation_method = "Maximum"
    metric_measure_column   = "CounterValue"
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "CounterPath", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Perf
| where CounterName == 'Free Space in tempdb (KB)'
| where TimeGenerated > ago(5m)
| summarize arg_max(TimeGenerated, CounterValue) by Computer, CounterPath, _ResourceId
| project TimeGenerated, Computer, CounterPath, CounterValue, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_SQLServicesStatus"
    description             = "ORG-CCS-MSSQL-Check_SQLServicesStatus"
    severity                = 2
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID == 7036
| where TimeGenerated > ago(15m)
| where RenderedDescription has_any (
    "SQL Server (",
    "SQL Server Agent",
    "SQL Server Integration",
    "SQL Server Analysis",
    "SQL Server Reporting"
)
| where RenderedDescription has "stopped"
| summarize LatestTime = max(TimeGenerated) by Computer, EventID, RenderedDescription, _ResourceId
| project TimeGenerated = LatestTime, Computer, EventID, RenderedDescription, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_PageLifeExpectancy"
    description             = "ORG-CCS-MSSQL-Check_PageLifeExpectancy"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "LessThan"
    threshold               = 300
    time_aggregation_method = "Average"
    metric_measure_column   = "ple"
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "CounterPath", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Perf
| where CounterName == "Page life expectancy"
| where TimeGenerated > ago(5m)
| summarize ple = avg(CounterValue), LatestTime = max(TimeGenerated) by Computer, CounterPath, _ResourceId
| project TimeGenerated = LatestTime, Computer, CounterPath, ple, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_MemoryIssues"
    description             = "ORG-CCS-MSSQL-Check_MemoryIssues"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID in (701, 17883, 802, 2004, 17803, 832, 17131, 885)
| where Source has_any ("MSSQL", "SQLSERVER")
| where RenderedDescription !contains "Unable to open the Server service performance object."
| where TimeGenerated > ago(15m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project TimeGenerated = LatestTime, Computer, Source, EventID, RenderedDescription, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_IOErrors"
    description             = "ORG-CCS-MSSQL-Check_IOErrors"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT30M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID in (823, 833)
| where TimeGenerated > ago(30m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project TimeGenerated = LatestTime, Computer, Source, EventID, RenderedDescription, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_DatabaseState"
    description             = "ORG-CCS-MSSQL-Check_DatabaseState"
    severity                = 2
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where TimeGenerated > ago(15m)
| where EventID in (
    3414, 3415, 3417, 3456, 3041, 5084, 17113,
    824, 825
)
| extend Description = tostring(RenderedDescription)
| where Description has_any (
    "Setting database option OFFLINE to ON for",
    "database recovery failed",
    "Recovery of database failed",
    "SQL Server service failed to start",
    "system database",
    "Database shutdown",
    "Database is marked RESTORING",
    "Database is marked SUSPECT",
    "Database cannot be opened",
    "Error during recovery",
    "I/O error",
    "Transaction log full",
    "Could not open database",
    "Database not accessible"
)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project
    TimeGenerated = LatestTime,
    Computer,
    Source,
    EventID,
    RenderedDescription,
    _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_DatabaseRsvBackup"
    description             = "ORG-CCS-MSSQL-Check_DatabaseRsvBackup"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "ResourceId"

    dimensions = [
      { name = "JobFailureCode", operator = "Include", values = ["*"] },
      { name = "BackupItemUniqueId", operator = "Include", values = ["*"] },
      { name = "ProtectedContainerUniqueId", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
AddonAzureBackupJobs
| where TimeGenerated > ago(72h)
| where BackupManagementType == "AzureWorkload"
| where BackupItemUniqueId contains "mssqlserver"
| where JobFailureCode != "Success"
| where JobOperationSubType == "Full"
| extend Computer = split(BackupItemUniqueId, ";")[4]
| project Computer, ResourceId, JobFailureCode, BackupItemUniqueId, TimeGenerated, ProtectedContainerUniqueId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_DatabaseFileIssues"
    description             = "ORG-CCS-MSSQL-Check_DatabaseFileIssues"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID in (17113, 17204, 9002, 1105, 1101, 17207)
| where TimeGenerated > ago(15m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project
    TimeGenerated = LatestTime,
    Computer,
    Source,
    EventID,
    RenderedDescription,
    _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_DatabaseFileFull"
    description             = "ORG-CCS-MSSQL-Check_DatabaseFileFull"
    severity                = 2
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID in (9002, 1105)
| where TimeGenerated > ago(15m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project
    TimeGenerated = LatestTime,
    Computer,
    Source,
    EventID,
    RenderedDescription,
    _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_BufferCacheHitRatio"
    description             = "ORG-CCS-MSSQL-Check_BufferCacheHitRatio"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "LessThan"
    threshold               = 100
    time_aggregation_method = "Average"
    metric_measure_column   = "AvgHitRatio"
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "CounterPath", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Perf
| where CounterName == "Buffer cache hit ratio"
| where TimeGenerated > ago(5m)
| summarize AvgHitRatio = avg(CounterValue), LatestTime = max(TimeGenerated) by Computer, CounterPath, _ResourceId
| project TimeGenerated = LatestTime, Computer, CounterPath, AvgHitRatio, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_Blockings"
    description             = "ORG-CCS-MSSQL-Check_Blockings"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Maximum"
    metric_measure_column   = "blocker_counter"
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "CounterPath", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Perf
| where CounterName == "Processes blocked"
| where TimeGenerated > ago(5m)
| summarize blocker_counter = avg(CounterValue), LatestTime = max(TimeGenerated) by Computer, CounterPath, _ResourceId
| project TimeGenerated = LatestTime, Computer, CounterPath, blocker_counter, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_AlwaysON"
    description             = "ORG-CCS-MSSQL-Check_AlwaysON"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID in (
    1069, 1135, 1146, 1205, 1480, 1479,
    35201, 35206, 35250, 35264, 35265, 35267,
    34047, 34048,
    41047, 41048, 41049, 41091, 41131, 41144, 41406,
    19406
)
| where TimeGenerated > ago(15m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project TimeGenerated = LatestTime, Computer, Source, EventID, RenderedDescription, _ResourceId
QUERY
  },

  {
    name                    = "ORG-CCS-MSSQL-Check_AlwaysONFailover"
    description             = "ORG-CCS-MSSQL-Check_AlwaysONFailover"
    severity                = 3
    evaluation_frequency    = "PT5M"
    window_duration         = "PT5M"
    operator                = "GreaterThan"
    threshold               = 0
    time_aggregation_method = "Count"
    metric_measure_column   = ""
    resource_id_column      = "_ResourceId"

    dimensions = [
      { name = "Computer", operator = "Include", values = ["*"] },
      { name = "RenderedDescription", operator = "Include", values = ["*"] }
    ]

query = <<QUERY
Event
| where EventID == 1480
| where RenderedDescription contains "changing roles from \"PRIMARY\""
| where TimeGenerated > ago(5m)
| summarize LatestTime = max(TimeGenerated) by Computer, Source, EventID, RenderedDescription, _ResourceId
| project LatestTime, Computer, Source, EventID, RenderedDescription, _ResourceId
QUERY
  }
]

# below  variables values are used in the for paas monitoring policies deployment

# subscription_ids = [
#   "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51"
# ]


# management_group_ids = [
#   "/providers/Microsoft.Management/managementGroups/CCS-Root-MG"
# ]

# resource_types = [
#   {
#     type             = "Microsoft.KeyVault/vaults"
#     display_name     = "KeyVault"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Storage/storageAccounts"
#     display_name     = "StorageAccount"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Web/sites"
#     display_name     = "AppService"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Web/serverfarms"
#     display_name     = "App Service Plan"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.ApiManagement/service"
#     display_name     = "APImanagement Service"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Network/applicationGateways"
#     display_name     = "Application Gateway"
#    policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Insights/components"
#     display_name     = "Application Insights"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.ContainerRegistry/registries"
#     display_name     = "Container registry"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.DataFactory/factories"
#     display_name     = "Datafactory"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.EventHub/namespaces"
#     display_name     = "Eventhubs Namespace"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Logic/workflows"
#     display_name     = "Logic Workflow"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.ServiceBus/namespaces"
#     display_name     = "Servicebus Namespaces"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Sql/servers/databases"
#     display_name     = "SQL Database"
#     policy_rule_file = "PaaS_DS_rule_SQL_Database.json"
#   },
#   {
#     type             = "Microsoft.Sql/servers/elasticpools"
#     display_name     = "SQL Elastic Pool"
#     policy_rule_file = "PaaS_DS_rule_SQL_Elastic_Pool.json"
#   },
#   {
#     type             = "Microsoft.Sql/managedInstances"
#     display_name     = "SQL Managed Instance"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.DBforMySQL/flexibleServers"
#     display_name     = "MySQL Flexible Server"
#     policy_rule_file = "PaaS_DS_rule.json"
#   },
#   {
#     type             = "Microsoft.Kusto/clusters"
#     display_name     = "Data Explorer Cluster"
#     policy_rule_file = "PaaS_DS_rule.json"
#   }
# ]

paas_alerts_map = {


  app_service_plan_cpu_1 = {
    name                         = "CCS - App service plan CPU usage in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'CpuPercentage' and ResourceId contains 'MICROSOFT.WEB/SERVERFARMS' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for app service plan Average CPU usage is greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }


  app_service_plan_memory_2 = {
    name                         = "CCS - App service plan Memory usage in Percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics 
| where MetricName == 'MemoryPercentage' and ResourceId contains 'MICROSOFT.WEB/SERVERFARMS' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for app service plan Average memory usage is greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }


  app_service_Http5XX_3 = {
    name                         = "CCS - App service Http Server Errors in count_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 50
    time_aggregation_method      = "Total"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'Http5xx' and ResourceId contains 'MICROSOFT.WEB/SITES' 
| summarize Result=sum(Total) by Resource, _ResourceId, bin(TimeGenerated, 5m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT1M"
    window_duration              = "PT5M"
    description                  = "Alert for app service Http server error count greater than 50 over 5mins for 6 consecutive evalutions."
    enabled                      = true
    minimum_failing_periods      = 6
    number_of_evaluation_periods = 6
    auto_mitigation_enabled      = false
  }

  app_service_HealthCheckStatus_4 = {
    name                         = "CCS - App service Health check status in count_CRITICAL"
    operator                     = "LessThan"
    threshold                    = 100
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'HealthCheckStatus' and ResourceId contains 'MICROSOFT.WEB/SITES' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 5m)
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT1M"
    window_duration              = "PT5M"
    description                  = "Alert for app service health check status is Less than 100% over 5mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
    auto_mitigation_enabled      = false
  }
    SQLdb_cpu_5 = {
    name                         = "CCS - Azure SQL Database CPU usage in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == "cpu_percent" and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId !contains "/ELASTICPOOLS/"
| summarize Result= avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for SQL Database Average CPU usage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  SQLdb_dtu_consumption_percent_6 = {
    name                         = "CCS - Azure SQLDatabase DTU consumption in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == "dtu_consumption_percent" and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId !contains "/ELASTICPOOLS/"
| summarize Result= avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for SQL Database DTU consumption is greater than 90% over 15mins."
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  SQLDatabase_Data_space_used_percent_7 = {

    query                        = <<-QUERY
AzureMetrics
| where MetricName == "storage_percent" and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId !contains "/ELASTICPOOLS/"
| summarize Result = max(Maximum) by Resource, _ResourceId, bin(TimeGenerated, 15m)
QUERY
    name                         = "CCS - Azure SQLDatabase Data space used in percentage_CRITICAL"
    time_aggregation_method      = "Maximum"
    operator                     = "GreaterThan"
    threshold                    = 90
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    severity                     = 1
    description                  = "Alert for SQL Database data space used is greater than 90% over 5mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  APIManagement_capacity_8 = {
    name                         = "CCS - APIManagement capacity in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == "Capacity" and ResourceId contains "MICROSOFT.APIMANAGEMENT/SERVICE"
| summarize Result = avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for APIManagement capacity is greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  ApplicationGateway_UnhealthyHostCount_9 = {
    name                         = "CCS - ApplicationGateway Unhealthy Host Count_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 0
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == "UnhealthyHostCount" and ResourceId contains "MICROSOFT.NETWORK/APPLICATIONGATEWAYS"
| summarize Result = avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for ApplicationGateway Unhealthy Host Count is greater than 0 over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
    auto_mitigation_enabled      = false
  }

    SQL_Elastic_Pool_CPU_10 = {
    name                         = "CCS - Azure SQL Database Elastic Pool CPU usage in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'cpu_percent' and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId contains "/ELASTICPOOLS/"
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Database Elastic Pool - Average CPU usage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  SQL_Elastic_Pool_DTU_11 = {
    name                         = "CCS - Azure SQL Database Elastic Pool DTU consumption in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'dtu_consumption_percent' and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId contains "/ELASTICPOOLS/"
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Database Elastic Pool - Average DTU consumption greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  SQL_Elastic_Pool_DTU_IO_12 = {
    name                         = "CCS - Azure SQL Database Elastic Pool Data IO percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'physical_data_read_percent' and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId contains "/ELASTICPOOLS/"
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Database Elastic Pool - Average Data IO percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  SQL_Elastic_Pool_Storage_13 = {
    name                         = "CCS - Azure SQL Database Elastic Pool Storage percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'storage_percent' and ResourceId contains "MICROSOFT.SQL/SERVERS" and ResourceId contains "/ELASTICPOOLS/"
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Database Elastic Pool - Average Storage percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }
  MySQL_flexible_server_CPU_14 = {
    name                         = "CCS - Azure Database for MySQL flexible server Host CPU percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'cpu_percent' and ResourceId contains 'Microsoft.DBforMySQL/flexibleServers' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure Database for MySQL flexible server - Average Host CPU percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }
  MySQL_flexible_server_IO_Consumption_15 = {
    name                         = "CCS - Azure Database for MySQL flexible server Storage IO Consumption percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'io_consumption_percent' and ResourceId contains 'Microsoft.DBforMySQL/flexibleServers' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure Database for MySQL flexible server - Average Storage IO Consumption percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  MySQL_flexible_server_Memory_16 = {
    name                         = "CCS - Azure Database for MySQL flexible server Memory percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'memory_percent' and ResourceId contains 'Microsoft.DBforMySQL/flexibleServers' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure Database for MySQL flexible server - Average Memory percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  MySQL_flexible_server_Storage_17 = {
    name                         = "CCS - Azure Database for MySQL flexible server Storage percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'storage_percent' and ResourceId contains 'Microsoft.DBforMySQL/flexibleServers' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure Database for MySQL flexible server - Average storage percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }



  Data_Explorer_Cluster_CPU_18 = {
    name                         = "CCS - Azure Data Explorer Cluster CPU utilization level in percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'CPU' and ResourceId contains 'Microsoft.Kusto/Clusters' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure Data Explorer Cluster - Average CPU utilization greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }


  SQL_Managed_Instance_CPU_19 = {
    name                         = "CCS - Azure SQL Managed Instance CPU percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName == 'avg_cpu_percent' and ResourceId contains 'Microsoft.Sql/managedInstances' 
| summarize Result=avg(Average) by Resource, _ResourceId, bin(TimeGenerated, 15m)
  QUERY
    severity                     = 2
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Managed Instance - Average CPU percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  }

  
  SQL_Managed_Instance_Storage_20 = {
    name                         = "CCS - Azure Azure SQL Managed Instance Storage percentage_CRITICAL"
    operator                     = "GreaterThan"
    threshold                    = 90
    time_aggregation_method      = "Average"
    query                        = <<-QUERY
AzureMetrics
| where MetricName in ("storage_space_used_mb", "reserved_storage_mb")
    and ResourceId contains "Microsoft.Sql/managedInstances"
| summarize storage_space_used_mb = avgif(Average, MetricName == "storage_space_used_mb"), reserved_storage_mb   = avgif(Average, MetricName == "reserved_storage_mb")
    by Resource, _ResourceId, bin(TimeGenerated, 5m)
| extend StoragePercent = iff(reserved_storage_mb > 0, (storage_space_used_mb * 100.0) / reserved_storage_mb, 0.0)
| project TimeGenerated, Resource, _ResourceId, storage_space_used_mb, reserved_storage_mb, Result = round(StoragePercent, 2)
| order by TimeGenerated desc
  QUERY
    severity                     = 1
    evaluation_frequency         = "PT5M"
    window_duration              = "PT15M"
    description                  = "Alert for Azure SQL Managed Instance - Average Storage percentage greater than 90% over 15mins"
    enabled                      = true
    minimum_failing_periods      = 1
    number_of_evaluation_periods = 1
  
  }
}


resource_types = [
  {
    type         = "Microsoft.Web/sites"
    display_name = "AppSvc"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.Web/serverfarms"
    display_name = "AppSvPlan"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.ApiManagement/service"
    display_name = "APIMgmt"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.Network/applicationGateways"
    display_name = "AppGW"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.Sql/servers/databases"
    display_name = "SQLDB"
    policy_rule_file = "PaaS_DS_rule_SQL_Database.json"
  },
  {
    type         = "Microsoft.Sql/servers/elasticpools"
    display_name = "SQLEPool"
    policy_rule_file = "PaaS_DS_rule_SQL_Elastic_Pool.json"
  },
  {
    type         = "Microsoft.Sql/managedInstances"
    display_name = "SQLMI"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.DBforMySQL/flexibleServers"
    display_name = "MySQLFlex"
    policy_rule_file = "PaaS_DS_rule.json"
  },
  {
    type         = "Microsoft.Kusto/clusters"
    display_name = "ADEclustr"
    policy_rule_file = "PaaS_DS_rule.json"
  }
]
variable "region" {
  type        = string
  description = "Region where the resource need to deployed."
}

variable "patch_baseline" {
  # type = list(map())
}
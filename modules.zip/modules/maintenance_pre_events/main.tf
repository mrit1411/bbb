resource "azurerm_eventgrid_system_topic" "maintenance_pre_event_topic" {
  for_each            = var.maintenance_configs
  name                = "${each.value.name}-Event-Topic"
  location            = each.value.location
  resource_group_name = each.value.resource_group_name
  source_arm_resource_id  = each.value.id
  topic_type          = "Microsoft.Maintenance.MaintenanceConfigurations"
  tags                 = var.tags

  lifecycle {
    ignore_changes = [ tags ]
  }
}



resource "azurerm_eventgrid_system_topic_event_subscription" "maintenance_pre_event_subscription" {
  for_each = var.maintenance_configs

  name                = "${each.value.name}-PreEvent-Subscription"
  system_topic        = azurerm_eventgrid_system_topic.maintenance_pre_event_topic[each.key].name
  resource_group_name = each.value.resource_group_name

  webhook_endpoint {
    url = var.webhook_uri
    max_events_per_batch = 1
    preferred_batch_size_in_kilobytes = 64
  }

}
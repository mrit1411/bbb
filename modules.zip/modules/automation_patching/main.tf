resource "azurerm_automation_account" "patching_automation_account" {
  name                = var.patching_automation_account_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                 = var.tags
  sku_name = "Basic"

  identity {
    type         = "UserAssigned"
    identity_ids = var.patching_event_identity
  }

  lifecycle {
    ignore_changes = [ tags ]
    }
}

resource "azapi_resource" "powershell_74_runtime" {
  type      = "Microsoft.Automation/automationAccounts/runtimeEnvironments@2024-10-23"
  name      = "powershell_74_runtime"
  parent_id = azurerm_automation_account.patching_automation_account.id
  location  = var.location

  body = {
    properties = {
      description = "pathing runbook runtime"
      runtime = {
        language = "PowerShell"
        version  = "7.4"
      }
      defaultPackages = {
        "Az"        = "12.3.0"
        "Azure CLI" = "2.64.0"
      }
    }
  }
}


data "local_file" "patching_exclude_current_month_script" {
  filename = "${path.module}/scripts/Exclude-CurrentMonthPatches.ps1"
}

resource "azurerm_automation_runbook" "patching_exclude_current_month_runbook" {
  name                    = "Exclude-CurrentMonthPatches"
  location                = var.location
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.patching_automation_account.name
  log_verbose             = "true"
  log_progress            = "true"
  runbook_type            = "PowerShell"

  content = data.local_file.patching_exclude_current_month_script.content
    lifecycle {
    ignore_changes = [ tags ]
    }
}

resource "azapi_update_resource" "patching_exclude_current_month_runbook" {
  type      = "Microsoft.Automation/automationAccounts/runbooks@2024-10-23"
  name      = azurerm_automation_runbook.patching_exclude_current_month_runbook.name
  parent_id = azurerm_automation_account.patching_automation_account.id
  body = {
    properties = {
      runtimeEnvironment = azapi_resource.powershell_74_runtime.name
    }
  }
}

resource "azapi_resource_action" "undoedit_patching_exclude_current_month_runbook" { # updating the runtime causes the runbook to be in edit status, reverting to last published version to avoid confusion
  depends_on  = [azapi_update_resource.patching_exclude_current_month_runbook]
  type        = "Microsoft.Automation/automationAccounts/runbooks@2024-10-23"
  resource_id = azurerm_automation_runbook.patching_exclude_current_month_runbook.id
  action      = "draft/undoEdit"
}

resource "azurerm_automation_webhook" "patching_exclude_current_month_runbook_webhook" {
  name                    = "patching_exclude_current_month_runbook_webhook"
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.patching_automation_account.name
  expiry_time             = "2026-12-31T23:59:59Z"
  enabled                 = true
  runbook_name            = azurerm_automation_runbook.patching_exclude_current_month_runbook.name
  parameters = {
    input = "WebhookData"
  }
  depends_on = [ azurerm_automation_runbook.patching_exclude_current_month_runbook ]
}

resource "azurerm_automation_variable_string" "approved_patch_kb_ids" {
 name                    = "ApprovedPatchKBIDs"
 resource_group_name     = var.resource_group_name
 automation_account_name = azurerm_automation_account.patching_automation_account.name
 value                   = "[]"
 encrypted               = false
 lifecycle {
   ignore_changes = [value]
 }
}

resource "azurerm_automation_schedule" "monthly_kb_refresh_schedule" {
  name                    = "MonthlyKBRefresh-1st-0005-IST"
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.patching_automation_account.name
  frequency               = "Month"
  interval                = 1
  timezone                = "Asia/Kolkata"
  start_time              = "2026-07-28T19:40:00+05:30"
  description             = "Runs on the 1st of every month at 00:05 IST to refresh ApprovedPatchKBIDs"
}

resource "azurerm_automation_job_schedule" "monthly_kb_refresh_job" {
  resource_group_name     = var.resource_group_name
  automation_account_name = azurerm_automation_account.patching_automation_account.name
  schedule_name           = azurerm_automation_schedule.monthly_kb_refresh_schedule.name
  runbook_name            = azurerm_automation_runbook.patching_exclude_current_month_runbook.name

  depends_on = [azapi_resource_action.undoedit_patching_exclude_current_month_runbook]
}
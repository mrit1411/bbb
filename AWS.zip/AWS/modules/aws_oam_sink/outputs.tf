output "arn" {
  description = "The ARN of the OAM sink."
  value       = aws_oam_sink.oam_sink.arn
}
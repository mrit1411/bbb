output "dcr_resource_id" {
  value = azurerm_monitor_data_collection_rule.data_collection_rule.id

}
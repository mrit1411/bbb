# output "vault_names" {
#   description = "Names of created Recovery Services Vaults by region"
#   value       = { for r, v in local.rsv_by_region : r => v.name }
# }

output "vault_ids" {
  description = "IDs of the created RSVs by region"
  value       = { for r, res in azurerm_recovery_services_vault.vault : r => res.id }
}
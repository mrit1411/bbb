resource "aws_ssm_association" "ssm_association" {
  name                = var.name
  association_name    = var.association_name
  schedule_expression = var.schedule_expression
  targets {
    key    = var.key
    values = var.values
  }

  parameters = var.parameters != null ? var.parameters : {}
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_s3_bucket.s3_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_lifecycle_configuration.s3_bucket_lifecycle_configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_lifecycle_configuration) | resource |
| [aws_s3_bucket_public_access_block.s3_bucket_public_access_block](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_block_public_acls"></a> [block\_public\_acls](#input\_block\_public\_acls) | Whether Amazon S3 should block public ACLs for this bucket. Enabling this setting does not affect existing policies or ACLs. When set to true causes the following behavior:<br/>PUT Bucket acl and PUT Object acl calls will fail if the specified ACL allows public access.<br/>PUT Object calls will fail if the request includes an object ACL. | `bool` | `true` | no |
| <a name="input_block_public_policy"></a> [block\_public\_policy](#input\_block\_public\_policy) | Whether Amazon S3 should block public bucket policies for this bucket. Enabling this setting does not affect the existing bucket policy. When set to true causes Amazon S3 to:<br/>Reject calls to PUT Bucket policy if the specified bucket policy allows public access. | `bool` | `true` | no |
| <a name="input_bucket_base_name"></a> [bucket\_base\_name](#input\_bucket\_base\_name) | Name of the bucket. If omitted, Terraform will assign a random, unique name. Must be lowercase and less than or equal to 63 characters in length. The name must not be in the format [bucket\_name]--[azid]--x-s3. Forces new resource. | `string` | n/a | yes |
| <a name="input_enable_transition"></a> [enable\_transition](#input\_enable\_transition) | Whether to enable transition | `bool` | `false` | no |
| <a name="input_expiration_days"></a> [expiration\_days](#input\_expiration\_days) | Lifetime, in days, of the objects that are subject to the rule. The value must be a non-zero positive integer. | `number` | `365` | no |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy) | Boolean that indicates all objects (including any locked objects) should be deleted from the bucket when the bucket is destroyed so that the bucket can be destroyed without error. These objects are not recoverable. This only deletes objects when the bucket is destroyed, not when setting this parameter to true. Once this parameter is set to true, there must be a successful terraform apply run before a destroy is required to update this value in the resource state. Without a successful terraform apply after this parameter is set, this flag will have no effect. If setting this field in the same operation that would require replacing the bucket or destroying the bucket, this flag will not work. Additionally when importing a bucket, a successful terraform apply is required to set this value in state before it will take effect on a destroy operation. | `bool` | `false` | no |
| <a name="input_ignore_public_acls"></a> [ignore\_public\_acls](#input\_ignore\_public\_acls) | Whether Amazon S3 should ignore public ACLs for this bucket. Enabling this setting does not affect the persistence of any existing ACLs and doesn't prevent new public ACLs from being set. When set to true causes Amazon S3 to:<br/>Ignore public ACLs on this bucket and any objects that it contains. | `bool` | `true` | no |
| <a name="input_restrict_public_buckets"></a> [restrict\_public\_buckets](#input\_restrict\_public\_buckets) | Whether Amazon S3 should restrict public bucket policies for this bucket. Enabling this setting does not affect the previously stored bucket policy, except that public and cross-account access within the public bucket policy, including non-public delegation to specific accounts, is blocked. When set to true:<br/>Only the bucket owner and AWS Services can access this buckets if it has a public policy. | `bool` | `true` | no |
| <a name="input_rule_id"></a> [rule\_id](#input\_rule\_id) | Unique identifier for the rule. The value cannot be longer than 255 characters. | `string` | `"removeafterdays"` | no |
| <a name="input_rule_status"></a> [rule\_status](#input\_rule\_status) | Whether the rule is currently being applied. | `bool` | `true` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the resoruce | `map(string)` | <pre>{<br/>  "ccs_managed": "yes"<br/>}</pre> | no |
| <a name="input_transition_in_days"></a> [transition\_in\_days](#input\_transition\_in\_days) | Number of days after creation when objects are transitioned to the specified storage class. The value must be a positive integer. | `number` | `60` | no |
| <a name="input_transition_storage_class"></a> [transition\_storage\_class](#input\_transition\_storage\_class) | Class of storage used to store the object. Valid Values: GLACIER, STANDARD\_IA, ONEZONE\_IA, INTELLIGENT\_TIERING, DEEP\_ARCHIVE, GLACIER\_IR. | `string` | `"STANDARD_IA"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bucket_arn"></a> [bucket\_arn](#output\_bucket\_arn) | ARN of the S3 bucket |
| <a name="output_bucket_id"></a> [bucket\_id](#output\_bucket\_id) | n/a |

﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_association.ssm_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_association_name"></a> [association\_name](#input\_association\_name) | The descriptive name for the association. | `string` | n/a | yes |
| <a name="input_key"></a> [key](#input\_key) | Either InstanceIds or tag:Tag Name to specify an EC2 tag. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The name of the SSM document to apply. | `string` | n/a | yes |
| <a name="input_parameters"></a> [parameters](#input\_parameters) | A map of parameters to pass to the SSM document. | `map(string)` | `null` | no |
| <a name="input_schedule_expression"></a> [schedule\_expression](#input\_schedule\_expression) | The schedule expression for the association. | `string` | `"rate(30 days)"` | no |
| <a name="input_values"></a> [values](#input\_values) | User-defined criteria that maps to Key. A list of instance IDs or tag values. | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_ssm_association"></a> [aws\_ssm\_association](#output\_aws\_ssm\_association) | n/a |

module "s3_bucket_availability_reports" {
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.availability_reports_bucket_name
}

module "s3_bucket_availability_reports_encryption_configuration" {
  source = "../modules/aws_s3_bucket_server_side_encryption_configuration"

  bucket = module.s3_bucket_availability_reports.bucket_id
}

module "s3_bucket_availability_reports_policy" {
  source = "../modules/aws_s3_bucket_policy"

  bucket = module.s3_bucket_availability_reports.bucket_id
}

module "s3_bucket_events_reports" {
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.events_reports_bucket_name
}

module "s3_bucket_events_reports_encryption_configuration" {
  source = "../modules/aws_s3_bucket_server_side_encryption_configuration"

  bucket = module.s3_bucket_events_reports.bucket_id
}

module "s3_bucket_events_reports_policy" {
  source = "../modules/aws_s3_bucket_policy"

  bucket = module.s3_bucket_events_reports.bucket_id
}

module "s3_bucket_performance_reports" {
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.performance_reports_bucket_name
}

module "s3_bucket_performance_reports_encryption_configuration" {
  source = "../modules/aws_s3_bucket_server_side_encryption_configuration"

  bucket = module.s3_bucket_performance_reports.bucket_id
}

module "s3_bucket_performance_reports_policy" {
  source = "../modules/aws_s3_bucket_policy"

  bucket = module.s3_bucket_performance_reports.bucket_id
}

module "availability_url_credentials_stored" {
  source      = "../modules/aws_secretsmanager_secret"
  context     = "availability"
  description = "Deployed by CCS Availability solution. Secret contains the API key for AvailabilityReportURLUser. Credentials are used by Availability report SSM automation doc when generating signed URL."
  secret_string_wo = jsonencode({
    ACCESS_KEY = module.availability_url_user_credentials.access_key_id
    SECRET_KEY = module.availability_url_user_credentials.secret_access_key
  })

  secret_string_wo_version = 1
}

module "events_url_credentials_stored" {
  source      = "../modules/aws_secretsmanager_secret"
  context     = "events"
  description = "Deployed by CCS Events solution. Secret contains the API key for EventsReportURLUser. Credentials are used by Events report SSM automation doc when generating signed URL."
  secret_string_wo = jsonencode({
    ACCESS_KEY = module.events_url_user_credentials.access_key_id
    SECRET_KEY = module.events_url_user_credentials.secret_access_key
  })
  secret_string_wo_version = 1
}

module "performance_url_credentials_stored" {
  source      = "../modules/aws_secretsmanager_secret"
  context     = "performance"
  description = "Deployed by CCS Performance solution. Secret contains the API key for PerformanceReportURLUser. Credentials are used by Performance report SSM automation doc when generating signed URL."
  secret_string_wo = jsonencode({
    ACCESS_KEY = module.performance_url_user_credentials.access_key_id
    SECRET_KEY = module.performance_url_user_credentials.secret_access_key
  })
  secret_string_wo_version = 1
}

module "availability_reports_automation_trigger_monthly" {
  source                 = "../modules/aws_cloudwatch_event_rule"
  context                = "AvailabilityReports"
  description            = "EventRule for triggering CCS Availability Report Lambda Function to generate monthly Availability reports."
  schedule               = var.availability_report_generation_schedule_monthly
  eventbridge_target_arn = module.availability_reports_lambda_function.arn
  eventbridge_target_id  = "AvailabilityReports"
}

module "events_reports_automation_trigger_monthly" {
  source                 = "../modules/aws_cloudwatch_event_rule"
  context                = "EventsReports"
  description            = "EventRule for triggering CCS Events Report Lambda Function to generate monthly Events reports."
  schedule               = var.events_report_generation_schedule_monthly
  eventbridge_target_arn = module.events_reports_lambda_function.arn
  eventbridge_target_id  = "EventsReports"
}

module "performance_report_automation_trigger_monthly" {
  source                 = "../modules/aws_cloudwatch_event_rule"
  context                = "PerformanceReport"
  description            = "EventRule for triggering CCS Performance Report Lambda Function to generate monthly Performance reports."
  schedule               = var.performace_report_generation_schedule_monthly
  eventbridge_target_arn = module.performance_reports_lambda_function.arn
  eventbridge_target_id  = "PerformanceReports"
}

module "create_alarms_event_rule" {
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "CreateAlarms"
  description = "CCS EventRule that will trigger the CCS CreateCloudWatchAlarmForInstances lambda function whenever an EC2 instance is in the running state."
  event_pattern = jsonencode({
    source = [
      "aws.ec2"
    ]
    detail-type = [
      "EC2 Instance State-change Notification"
    ]
    detail = {
      state = [
        "running"
      ]
    }
  })
  eventbridge_target_arn = module.create_cloud_watch_alarms_for_instances_lambda_function.arn
  eventbridge_target_id  = "CreateCloudWatchAlarmForInstances"
}

module "tag_based_create_alarms_event_rule" {
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "TagBasedCreateAlarms"
  description = "CCS EventRule that will trigger the CCS TagBasedCreateCloudWatchAlarmForInstances lambda function whenever ccs_managed tag is added to an EC2 instance."
  event_pattern = jsonencode({
    source = [
      "aws.tag"
    ]
    detail-type = [
      "Tag Change on Resource"
    ]
    detail = {
      changed-tag-keys = [
        "${var.tags_condition_key}"
      ]
      tags = {
        "${var.tags_condition_key}" = [{ exists = true }]
      }
    }
  })
  eventbridge_target_arn = module.tag_based_create_cloud_watch_alarms_for_instances_lambda_function.arn
  eventbridge_target_id  = "TagBasedCreateCloudWatchAlarmForInstances"
}

# module "tag_based_terminate_alarms_event_rule" {
#   source      = "../modules/aws_cloudwatch_event_rule"
#   context     = "TagBasedTerminateAlarms"
#   description = "CCS EventRule that will trigger the CCS TagBasedTerminateCloudWatchAlarmForInstances lambda function whenever ccs_managed tag is removed from an EC2 instance."
#   event_pattern = jsonencode({
#     source = [
#       "aws.tag"
#     ]
#     detail-type = [
#       "Tag Change on Resource"
#     ]
#     detail = {
#       changed-tag-keys = [
#         "${var.tags_condition_key}"
#       ]
#       tags = {
#         "${var.tags_condition_key}" = [{ exists = false }]
#       }
#     }
#   })
#   eventbridge_target_arn = module.tag_based_terminate_cloud_watch_alarms_for_instances_lambda_function.arn
#   eventbridge_target_id  = "TagBasedTerminateCloudWatchAlarmForInstances"
# }

module "terminate_alarms_event_rule" {
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "TerminateAlarms"
  description = "CCS EventRule that will trigger the CCS TerminateCloudWatchAlarmsForInstances lambda function whenever an EC2 instance is in the terminated state."
  event_pattern = jsonencode({
    source = [
      "aws.ec2"
    ]
    detail-type = [
      "EC2 Instance State-change Notification"
    ]
    detail = {
      state = [
        "terminated"
      ]
    }
  })
  eventbridge_target_arn = module.terminate_cloud_watch_alarms_for_instances_lambda_function.arn
  eventbridge_target_id  = "TerminateCloudWatchAlarmsForInstances"
}

module "availability_report_sns_topic" {
  source = "../modules/aws_sns_topic"
  name   = var.availability_report_sns_topic_name
}

module "events_report_sns_topic" {
  source = "../modules/aws_sns_topic"
  name   = var.events_report_sns_topic_name
}

module "performance_report_sns_topic" {
  source = "../modules/aws_sns_topic"
  name   = var.performance_report_sns_topic_name
}

module "availability_report_sns_topic_subscription" {
  source    = "../modules/aws_sns_topic_subscription"
  topic_arn = module.availability_report_sns_topic.sns_topic_arn
  endpoint  = var.availability_report_recipient
}

module "events_report_sns_topic_subscription" {
  source    = "../modules/aws_sns_topic_subscription"
  topic_arn = module.events_report_sns_topic.sns_topic_arn
  endpoint  = var.events_report_recipient
}

module "performance_report_sns_topic_subscription" {
  source    = "../modules/aws_sns_topic_subscription"
  topic_arn = module.performance_report_sns_topic.sns_topic_arn
  endpoint  = var.performance_report_recipient
}

module "availability_reports_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_availability_reports"
  role                     = module.lambda_availability_reports_iam_role.role_arn
  description              = "CCS Developed Lambda Function. Will generate an Availability report when triggered, place into an S3 bucket and send a presigned URL to the topic ARN. Triggered automatically through monthly EventBridge rules."
  handler                  = "lambda_availability_reports.lambda_handler"
  timeout                  = 600
  memory_size              = 128
  env_variables = {
    SNS_TOPIC_ARN                = module.availability_report_sns_topic.sns_topic_arn
    S3_LINK_EXPIRATION           = var.availability_link_validity
    S3_BUCKET                    = module.s3_bucket_availability_reports.bucket_id
    AVAILABILITY_REPORTING_KEY   = var.tags_condition_key
    AVAILABILITY_REPORTING_VALUE = var.tags_condition_value
    ACCOUNT_NAME                 = var.account_name
  }
}

module "events_reports_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_events_reports"
  role                     = module.lambda_events_reports_iam_role.role_arn
  description              = "CCS Developed Lambda Function. Will generate an Events report when triggered, place into an S3 bucket and send a presigned URL to the topic ARN. Triggered automatically through monthly EventBridge rules."
  handler                  = "lambda_events_reports.lambda_handler"
  timeout                  = 600
  memory_size              = 128
  env_variables = {
    SNS_TOPIC_ARN          = module.events_report_sns_topic.sns_topic_arn
    S3_LINK_EXPIRATION     = var.availability_link_validity
    S3_BUCKET              = module.s3_bucket_events_reports.bucket_id
    Events_REPORTING_KEY   = var.tags_condition_key
    Events_REPORTING_VALUE = var.tags_condition_value
  }
}

module "performance_reports_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_performance_reports"
  role                     = module.lambda_performance_reports_iam_role.role_arn
  description              = "CCS Developed Lambda Function. Will generate a Performance report when triggered, place into an S3 bucket and send a presigned URL to the topic ARN. Triggered automatically through monthly EventBridge rules."
  handler                  = "lambda_performance_reports.lambda_handler"
  timeout                  = 600
  memory_size              = 128
  env_variables = {
    SNS_TOPIC_ARN        = module.performance_report_sns_topic.sns_topic_arn
    S3_LINK_EXPIRATION   = var.availability_link_validity
    S3_BUCKET            = module.s3_bucket_performance_reports.bucket_id
    TAGS_CONDITION_KEY   = var.tags_condition_key
    TAGS_CONDITION_VALUE = var.tags_condition_value
    ACCOUNT_NAME         = var.account_name
  }
}

module "create_cloud_watch_alarms_for_instances_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_central_cloudwatch_alarms"
  role                     = module.lambda_create_cloudwatch_alarms_iam_role.role_arn
  description              = "CCS Lambda Function. Triggered by CreateAlarmsEventRule EventBridge rule on EC2 running state. Configure only EC2's containing tag key and value variables, setup cloudwatch agent and create cloudwatch alarms to output to the snstopic variable value"
  handler                  = "lambda_central_cloudwatch_alarms.lambda_handler"
  timeout                  = 870
  memory_size              = 1024
  env_variables = {
    SNOWSNSTopicARN    = data.terraform_remote_state.infra.outputs.infra_snow_sns_topic
    TagsConditionKey   = var.tags_condition_key
    TagsConditionValue = var.tags_condition_value
    MonitoringEnabled  = var.monitoring_enabled
    LoggingEnabled     = var.logging_enabled
  }
}

module "tag_based_create_cloud_watch_alarms_for_instances_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_tag_based_ec2_cloudwatch_alarms"
  role                     = module.lambda_create_cloudwatch_alarms_iam_role.role_arn
  description              = "CCS Lambda Function. Triggered by TagBasedCreateAlarmsEventRule EventBridge rule on EC2 running state. Configure only EC2's containing tag key and value variables, setup cloudwatch agent and create cloudwatch alarms to output to the snstopic variable value"
  handler                  = "lambda_tag_based_ec2_cloudwatch_alarms.lambda_handler"
  timeout                  = 870
  memory_size              = 1024
  env_variables = {
    SNOWSNSTopicARN    = data.terraform_remote_state.infra.outputs.infra_snow_sns_topic
    TagsConditionKey   = var.tags_condition_key
    TagsConditionValue = var.tags_condition_value
    MonitoringEnabled  = var.monitoring_enabled
    LoggingEnabled     = var.logging_enabled
  }
}

module "terminate_cloud_watch_alarms_for_instances_lambda_function" {
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "terminate_cloudwatch_alarms"
  role                     = module.lambda_terminate_cloudwatch_alarms_iam_role.role_arn
  description              = "CCS Lambda Function that will be triggered by TerminateAlarmsEventRule eventbridge rule on EC2 termination. It will remove any cloudwatch alarms linked to terminated instances"
  handler                  = "terminate_cloudwatch_alarms.lambda_handler"
  timeout                  = 600
  memory_size              = 1024
}

# module "tag_based_terminate_cloud_watch_alarms_for_instances_lambda_function" {
#   source                   = "../modules/aws_lambda_function"
#   lambda_function_filename = "tag_based_terminate_cloudwatch_alarms"
#   role                     = module.lambda_terminate_cloudwatch_alarms_iam_role.role_arn
#   description              = "CCS Lambda Function that will be triggered by TagBasedTerminateAlarmsEventRule eventbridge rule on EC2 termination. It will remove any cloudwatch alarms linked to instances on which management tag has been removed"
#   handler                  = "tag_based_terminate_cloudwatch_alarms.lambda_handler"
#   timeout                  = 600
#   memory_size              = 1024
# }

module "create_cloud_watch_alarms_for_instances_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.create_cloud_watch_alarms_for_instances_lambda_function.arn
  source_arn    = module.create_alarms_event_rule.arn
}

module "tag_based_create_cloud_watch_alarms_for_instances_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.tag_based_create_cloud_watch_alarms_for_instances_lambda_function.arn
  source_arn    = module.tag_based_create_alarms_event_rule.arn
}

# module "tag_based_terminate_cloud_watch_alarms_for_instances_lambda_permission" {
#   source        = "../modules/aws_lambda_permission"
#   function_name = module.tag_based_terminate_cloud_watch_alarms_for_instances_lambda_function.arn
#   source_arn    = module.tag_based_terminate_alarms_event_rule.arn
# }

module "terminate_cloud_watch_alarms_for_instances_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.terminate_cloud_watch_alarms_for_instances_lambda_function.arn
  source_arn    = module.terminate_alarms_event_rule.arn
}

module "performance_reports_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.performance_reports_lambda_function.arn
  source_arn    = module.performance_report_automation_trigger_monthly.arn
}

module "events_reports_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.events_reports_lambda_function.arn
  source_arn    = module.events_reports_automation_trigger_monthly.arn
}

module "availability_reports_lambda_permission" {
  source        = "../modules/aws_lambda_permission"
  function_name = module.availability_reports_lambda_function.arn
  source_arn    = module.availability_reports_automation_trigger_monthly.arn
}

module "availability_url_user_credentials" {
  source = "../modules/aws_iam_access_key"
  user   = module.availability_report_url_user.name
}

module "events_url_user_credentials" {
  source = "../modules/aws_iam_access_key"
  user   = module.event_report_url_user.name
}

module "performance_url_user_credentials" {
  source = "../modules/aws_iam_access_key"
  user   = module.performance_report_url_user.name
}

module "lambda_create_cloudwatch_alarms_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Monitoring Solution Deployment. Used by Create CloudWatch Alarms for Instances lambda function to create cloudwatch alarms, set alert output to sns topic and  trigger SSM run commands"
  context       = "Create-CloudWatch-Alarms"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "Lambda_Create_CloudWatch_Alarms_Policy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_create_cloudwatch_alarms_policy.json")
    }
  }
}

module "lambda_terminate_cloudwatch_alarms_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Monitoring Solution Deployment. Used by Terminate CloudWatch Alarms for Instances lambda function to assume, query deleted ec2s and remove associated alarms"
  context       = "Terminate-CloudWatch-Alarms"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "Lambda_Terminate_CloudWatch_Alarms_Policy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_terminate_cloudwatch_alarms_policy.json")
    }
  }
}

module "lambda_availability_reports_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Availability Solution Deployment. Used by the Availability Reports Lambda Function to generate Availability reports, store in S3 and publish URL to SNS"
  context       = "Availability-Reports"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaAvailabilityReportsInstantPolicy"
      inline_policy      = templatefile("../modules/aws_iam_role/inline_policies/lambda_availability_reports_instant_policy.tpl.json", { availability_reports_sns_topic_arn = module.availability_report_sns_topic.sns_topic_arn, s3_bucket_availability_reports_bucket_id = module.s3_bucket_availability_reports.bucket_id })
    }
    policy1 = {
      inline_policy_name = "AvailabilityReportURLUserSecretKeyAccess-${data.aws_region.current.region}"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/availability_report_url_user_secret_key_access.tpl.json", {
        availability_report_url_user_secret_arn = module.availability_url_credentials_stored.secret_id
      })
    }
  }
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/ResourceGroupsandTagEditorReadOnlyAccess"]
}

module "lambda_events_reports_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Events Solution Deployment. Used by the Events Reports Lambda Function to generate Events reports, store in S3 and publish URL to SNS"
  context       = "Events-Reports"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaEventsReportsInstantPolicy"
      inline_policy      = templatefile("../modules/aws_iam_role/inline_policies/lambda_events_reports_instant_policy.tpl.json", { events_reports_sns_topic_arn = module.events_report_sns_topic.sns_topic_arn, s3_bucket_events_reports_bucket_id = module.s3_bucket_events_reports.bucket_id })
    }
    policy1 = {
      inline_policy_name = "EventsReportURLUserSecretKeyAccess-${data.aws_region.current.region}"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/events_report_url_user_secret_key_access.tpl.json", {
        events_report_url_user_secret_arn = module.events_url_credentials_stored.secret_id
      })
    }
  }
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/ResourceGroupsandTagEditorReadOnlyAccess"]

}

module "lambda_performance_reports_iam_role" {
  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Performance Solution Deployment. Used by the Performance Reports Lambda Function to generate Performance reports,store in S3 and publish URL to SNS"
  context       = "Performance-Reports"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaPerformanceReportsInstantPolicy"
      inline_policy      = templatefile("../modules/aws_iam_role/inline_policies/lambda_performance_reports_instant_policy.tpl.json", { performance_reports_sns_topic_arn = module.performance_report_sns_topic.sns_topic_arn, s3_bucket_performance_reports_bucket_id = module.s3_bucket_performance_reports.bucket_id })
    }
    policy1 = {
      inline_policy_name = "PerformanceReportURLUserSecretKeyAccess-${data.aws_region.current.region}"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/performance_report_url_user_secret_key_access.tpl.json", {
        performance_report_url_user_secret_arn = module.performance_url_credentials_stored.secret_id
      })
      path                = "/service-role/"
      managed_policy_arns = ["arn:aws:iam::aws:policy/ResourceGroupsandTagEditorReadOnlyAccess"]
    }
  }
}

module "availability_report_url_user" {
  source           = "../modules/aws_iam_user"
  user_name        = var.availability_report_url_user
  policy_base_name = "Availability"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AvailabilityS3Access"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObjectAcl",
          "s3:GetObject",
          "s3:AbortMultipartUpload",
          "s3:PutObjectAcl"
        ]
        Resource = [
          "arn:aws:s3:::${module.s3_bucket_availability_reports.bucket_id}/*"
        ]
      }
    ]
  })
}

module "event_report_url_user" {
  source           = "../modules/aws_iam_user"
  user_name        = var.event_report_url_user
  policy_base_name = "Events"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "EventS3Access"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObjectAcl",
          "s3:GetObject",
          "s3:AbortMultipartUpload",
          "s3:PutObjectAcl"
        ]
        Resource = [
          "arn:aws:s3:::${module.s3_bucket_events_reports.bucket_id}/*"
        ]
      }
    ]
  })
}

module "performance_report_url_user" {
  source           = "../modules/aws_iam_user"
  user_name        = var.performance_report_url_user
  policy_base_name = "Performance"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "PerformanceS3Access"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObjectAcl",
          "s3:GetObject",
          "s3:AbortMultipartUpload",
          "s3:PutObjectAcl"
        ]
        Resource = [
          "arn:aws:s3:::${module.s3_bucket_performance_reports.bucket_id}/*"
        ]
      },
      {
        Sid    = "CloudWatchAccess"
        Effect = "Allow"
        Action = [
          "cloudwatch:GetMetricStatistics",
          "cloudwatch:GetMetricData",
          "cloudwatch:ListMetrics",
          "ssm:DescribeInstanceInformation"
        ]
        Resource = "*"
      }
    ]
  })
}

module "cw_agent_update_ssm_association" {
  source           = "../modules/aws_ssm_association"
  name             = "AWS-ConfigureAWSPackage"
  association_name = "CWAgent-Update-Association"
  key              = "tag:${var.tags_condition_key}"
  values           = ["${var.tags_condition_value}"]
  parameters = {
    action = "Install"
    name   = "AmazonCloudWatchAgent"
  }
}

module "linux_ssm_parameter" {
  source      = "../modules/aws_ssm_parameter"
  name        = "AmazonCloudWatch-ccslinuxmetricsconfiguration"
  tier        = "Advanced"
  description = "CCS Default cloudwatch configuration for EC2 linux instances. Used by CCS Create CloudWatch Alarms for Instances lambda function to stream these metrics to cloudwatch and configure cloudwatch alarms based on them"
  parameter_file = templatefile("../modules/aws_ssm_parameter/parameters/linux_ssm_parameters.tpl.json", {
    log_group_name = data.terraform_remote_state.logging.outputs.logging_ec2_instance_cloudwatch_log_group
  })
}

module "collectd_config_ssm_parameter" {
  source         = "../modules/aws_ssm_parameter"
  name           = "AmazonCloudWatch-ccslinuxcollectdconfiguration"
  tier           = "Standard"
  description    = "CCS collectd cloudwatch configuration for EC2 linux instances. Used by CCS Create CloudWatch Alarms for Instances lambda function to stream these metrics to cloudwatch and configure cloudwatch alarms based on them"
  parameter_file = file("../modules/aws_ssm_parameter/parameters/collectd_config_ssm_parameters.conf")
}

module "windows_ssm_parameter" {
  source      = "../modules/aws_ssm_parameter"
  name        = "AmazonCloudWatch-ccswindowsmetricsconfiguration"
  tier        = "Advanced"
  description = "CCS Default cloudwatch configuration for EC2 Windows instances. Used by CCS ${module.tag_based_create_cloud_watch_alarms_for_instances_lambda_function.arn} lambda function to stream these metrics to cloudwatch and configure cloudwatch alarms based on them"
  parameter_file = templatefile("../modules/aws_ssm_parameter/parameters/windows_ssm_parameters.tpl.json", {
    log_group_name = data.terraform_remote_state.logging.outputs.logging_ec2_instance_cloudwatch_log_group
  })

}

resource "aws_instance" "ubuntu_ec2" {
  ami           = "ami-0360c520857e3138f" # Replace with the Ubuntu AMI ID for your region
  instance_type = "t3.micro"             # Replace with your desired instance type
  key_name      = "ccs_linux_test_key_pair"   # Replace with the name of your pre-existing key pair
  iam_instance_profile = data.terraform_remote_state.infra.outputs.infra_ec2_instance_profile_name
  associate_public_ip_address = false

  tags = {
    Name = "ccs-linux-test"
    ccs_backup = "yes"
    ccs_dependency_type = "dependency"
    "Patch Group" = "linux_default"    
    ccs_managed = "yes"
  }

  lifecycle {
    ignore_changes = [ associate_public_ip_address ]
  }
}

resource "aws_instance" "windows_ec2" {
  ami           = "ami-0e3c2921641a4a215" # Replace with the Ubuntu AMI ID for your region
  instance_type = "t3.micro"             # Replace with your desired instance type
  key_name      = "ccs_windows_test_key_pair"   # Replace with the name of your pre-existing key pair
  iam_instance_profile = data.terraform_remote_state.infra.outputs.infra_ec2_instance_profile_name
  associate_public_ip_address = false

  tags = {
    Name = "ccs-windows-test"
    ccs_backup = "yes"
    ccs_dependency_type = "dependency"
    "Patch Group" = "windows_default"
    ccs_managed = "yes"
  }
  
  lifecycle {
    ignore_changes = [ associate_public_ip_address ]
  }
}


module "create_central_cloud_watch_alarms_for_instances_lambda_function" {
  providers = {
    aws = aws.monitoring_account
  }

  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_central_cross_account_alarms"
  role                     = module.lambda_create_central_cloudwatch_alarms_iam_role.role_arn
  description              = "CCS Lambda Function. Triggered by CreateAlarmsEventRule EventBridge rule on EC2 running state. Configure only EC2's containing tag key and value variables, setup cloudwatch agent and create cloudwatch alarms to output to the snstopic variable value"
  handler                  = "lambda_central_cross_account_alarms.lambda_handler"
  timeout                  = 870
  memory_size              = 1024
  env_variables = {
    SNOWSNSTopicARN    = data.terraform_remote_state.infra.outputs.infra_snow_sns_topic
    TagsConditionKey   = var.tags_condition_key
    TagsConditionValue = var.tags_condition_value
    MonitoringEnabled  = var.monitoring_enabled
    LoggingEnabled     = var.logging_enabled
  }
}

module "lambda_create_central_cloudwatch_alarms_iam_role" {
  providers = {
    aws = aws.monitoring_account
  }

  source        = "../modules/aws_iam_role"
  description   = "Role created by CCS Monitoring Solution Deployment. Used by Create CloudWatch Alarms for Instances lambda function to create cloudwatch alarms, set alert output to sns topic and  trigger SSM run commands"
  context       = "Create-CloudWatch-Alarms"
  resource_type = "Lambda"
  inline_policies = {
    policy0 = {
      inline_policy_name = "Lambda_Create_CloudWatch_Alarms_Policy"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/lambda_create_cloudwatch_alarms_policy.json")
    }
  }
}

module "create_central_alarms_event_rule" {
  source      = "../modules/aws_cloudwatch_event_rule"
  context     = "CreateCentralAlarms"
  description = "CCS EventRule that will trigger the CCS CreateCloudWatchAlarmForInstances lambda function whenever an EC2 instance is in the running state."
  event_pattern = jsonencode({
    source = [
      "aws.ec2"
    ]
    detail-type = [
      "EC2 Instance State-change Notification"
    ]
    detail = {
      state = [
        "running"
      ]
    }
  })
  eventbridge_target_arn = module.create_central_cloud_watch_alarms_for_instances_lambda_function.arn
  eventbridge_target_role_arn = module.events_invoke_cross_account_lambda_role.role_arn
  eventbridge_target_id  = "CreateCentralCloudWatchAlarmForInstances"
}

module "create_central_cloud_watch_alarms_for_instances_lambda_permission" {
  providers = {
    aws = aws.monitoring_account
  }

  source        = "../modules/aws_lambda_permission"
  function_name = module.create_central_cloud_watch_alarms_for_instances_lambda_function.arn
  source_arn    = module.create_central_alarms_event_rule.arn
}

module "events_invoke_cross_account_lambda_role" {
  source = "../modules/aws_iam_role"

  resource_type = "events"
  context = "central-invoke-cross-account-lambda"
  description = "Role created by CCS Monitoring Solution Deployment. Used by EventBridge in the monitoring account to assume and invoke the CreateCloudWatchAlarmsForInstances Lambda function in the monitored account."
  inline_policies = {
    policy0 = {
      inline_policy_name = "Events_Invoke_Cross_Account_Lambda_Policy"
      inline_policy      = templatefile("../modules/aws_iam_role/inline_policies/events_invoke_cross_account_lambda_policy.tpl.json", {
        central_monitoring_lambda_arn = module.create_central_cloud_watch_alarms_for_instances_lambda_function.arn
      })
    }
  }
}
# CCS Deployment

Capgemini Cloud Services (CCS) is Cloud Native solution

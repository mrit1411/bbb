data "archive_file" "lambda_package" {
  type        = "zip"
  source_file = "${path.module}/functions/${var.lambda_function_filename}.py"
  output_path = "${path.module}/lambda_packages/${var.lambda_function_filename}.zip"
}

resource "aws_lambda_function" "lambda_function" {
  function_name    = local.name
  filename         = data.archive_file.lambda_package.output_path
  source_code_hash = data.archive_file.lambda_package.output_base64sha256
  role             = var.role
  region = var.region
  description      = var.description
  handler          = var.handler
  runtime          = var.runtime
  timeout          = var.timeout
  memory_size      = var.memory_size
  layers           = var.layers
  environment {
    variables = var.env_variables
  }
  tags = var.tags

}
module "windows_maintenance_configuration_test" {
  source               = "./modules/maintenance_configuration"
  tags                 = var.tags
  for_each             = var.windows_maintenance_configs
  location             = each.value.location
  resource_group_name  = each.value.resource_group_name
  name                 = each.value.name
  reboot               = each.value.reboot
  start_date_time      = each.value.start_date_time
  expiration_date_time = each.value.expiration_date_time
  #tags = each.value.tags
  kb_numbers_windows = each.value.kb_numbers_windows
}


module "test_dynamic_scope_testing" {
  for_each                     = var.windows_maintenance_configs
  source                       = "./modules/dynamic_scope"
  name                         = "test_${each.value.name}_${var.sub_id}"
  location                     = var.location
  resource_group_name          = var.resource_group_name
  maintenance_configuration_id = module.windows_maintenance_configuration_test[each.key].id
  tag_filters = [
    {
      tag    = "ccs_patchgroup"
      values = ["${each.value.name}"]
    }
    # {
    #   tag    = "ccs_dependency_type"
    #   values = ["dependency"]
    # }

  ]
}


module "dynamic_scope_sub_b" {
  providers = {
    azurerm = azurerm.sub_b
  }
  for_each                     = var.windows_maintenance_configs
  source                       = "./modules/dynamic_scope"
  name                         = "test_${each.value.name}_${var.sub_b_id}"
  location                     = var.location # subscription-level assignment should have empty location
  resource_group_name          = var.resource_group_name
  maintenance_configuration_id = module.windows_maintenance_configuration_test[each.key].id
  tag_filters = [
    { tag = "ccs_patchgroup", values = [each.value.name] }
  ]
}



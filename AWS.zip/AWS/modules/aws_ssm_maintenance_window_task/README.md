﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_maintenance_window_task.ssm_maintenance_window_task](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_maintenance_window_task) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | The description of the maintenance window task. | `string` | `""` | no |
| <a name="input_max_concurrency"></a> [max\_concurrency](#input\_max\_concurrency) | The maximum number of targets this task can be run for in parallel. | `string` | n/a | yes |
| <a name="input_max_errors"></a> [max\_errors](#input\_max\_errors) | The maximum number of errors allowed before this task stops being scheduled. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | The name of the maintenance window task. | `string` | n/a | yes |
| <a name="input_notification_arn"></a> [notification\_arn](#input\_notification\_arn) | An Amazon Resource Name (ARN) for a Simple Notification Service (SNS) topic. Run Command pushes notifications about command status changes to this topic. | `string` | n/a | yes |
| <a name="input_notification_events"></a> [notification\_events](#input\_notification\_events) | The different events for which you can receive notifications. Valid values: All, InProgress, Success, TimedOut, Cancelled, and Failed | `list(string)` | n/a | yes |
| <a name="input_notification_type"></a> [notification\_type](#input\_notification\_type) | When specified with Command, receive notification when the status of a command changes. When specified with Invocation, for commands sent to multiple instances, receive notification on a per-instance basis when the status of a command changes. Valid values: Command and Invocation | `string` | n/a | yes |
| <a name="input_parameter_name"></a> [parameter\_name](#input\_parameter\_name) | The name of the parameter for the task. | `string` | n/a | yes |
| <a name="input_parameter_values"></a> [parameter\_values](#input\_parameter\_values) | The values of the parameter for the task. | `list(string)` | n/a | yes |
| <a name="input_priority"></a> [priority](#input\_priority) | The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel. | `number` | n/a | yes |
| <a name="input_target_key"></a> [target\_key](#input\_target\_key) | The key for the target. | `string` | `"WindowTargetIds"` | no |
| <a name="input_target_values"></a> [target\_values](#input\_target\_values) | The values for the target. | `list(string)` | n/a | yes |
| <a name="input_task_arn"></a> [task\_arn](#input\_task\_arn) | The ARN of the task to execute. | `string` | n/a | yes |
| <a name="input_task_invocation_service_role_arn"></a> [task\_invocation\_service\_role\_arn](#input\_task\_invocation\_service\_role\_arn) | The Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) service role to use to publish Amazon Simple Notification Service (Amazon SNS) notifications for maintenance window Run Command tasks. | `string` | n/a | yes |
| <a name="input_task_type"></a> [task\_type](#input\_task\_type) | The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN\_COMMAND or STEP\_FUNCTIONS. | `string` | `"RUN_COMMAND"` | no |
| <a name="input_window_id"></a> [window\_id](#input\_window\_id) | The Id of the maintenance window to register the task with. | `string` | n/a | yes |

## Outputs

No outputs.

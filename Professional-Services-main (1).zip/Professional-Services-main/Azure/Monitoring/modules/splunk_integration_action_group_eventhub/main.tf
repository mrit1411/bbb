resource "azurerm_monitor_action_group" "action_group" {
  name                = local.name
  resource_group_name = var.resource_group_name
  short_name          = var.short_name

    event_hub_receiver {
    name                    = var.event_hub_receiver_name
    event_hub_namespace     = var.event_hub_namespace
    event_hub_name          = var.event_hub_name
    #subscription_id         = "00000000-0000-0000-0000-000000000000" # Optional subscription ID of the Event Hub Namespace. Defaults to the Action Group's subscription.
    use_common_alert_schema = var.use_common_alert_schema
  }

  lifecycle {
    ignore_changes = [tags]

  }

  tags = var.tags
}
from __future__ import print_function
import boto3
import os
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from botocore.exceptions import ClientError

sns_client = boto3.client('sns')
s3_client = boto3.client('s3')

# Environment variables
s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic = os.environ.get('SNS_TOPIC_ARN')
tag_condition_key = os.environ.get('TAGS_CONDITION_KEY', "ccs_managed")
tag_condition_value = os.environ.get('TAGS_CONDITION_VALUE', "yes")
current_region = os.environ.get('AWS_REGION')

# Report types
reports = {
    'compliant': "C",
    'noncompliant': "N"
}


# ===================================================================
# Lambda Handler
# ===================================================================
def lambda_handler(event, context):
    c_fieldnames = [
        "ComplianceType", "ResourceType", "ResourceId", "ResourceName",
        "Region", "Id", "Title", "Status", "Severity",
        "ExecutionSummary", "Details"
    ]

    fieldnames = { 

    "compliant" : [
        "ComplianceType", "ResourceType", "ResourceId", "ResourceName",
        "Region", "Id", "Title", "Status", "Severity","Installation_Date",
        "ExecutionSummary", "Details"
    ],

    "noncompliant" : [
        "ComplianceType", "ResourceType", "ResourceId", "ResourceName",
        "Region", "Id", "Title", "Status", "Severity",
        "ExecutionSummary", "Details"
    ]
    }

    filename = "periodic-patching-report-" + context.invoked_function_arn.split(":")[3] + "-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime(
        "%Y%m%d_%H%M") + ".xlsx"
    print("Report name:", filename)

    try:
        # regions = list_enabled_regions()
        regions = [current_region]
        # print("Enabled regions:", regions)

        # Aggregated output for all regions
        report_data = {name: [] for name in reports}

        # -------------------------------------------------------------
        # ✅ Sequential region processing (per your requirement)
        # -------------------------------------------------------------
        for region in regions:
            print("\n====== Processing REGION:", region, "======")

            region_output = process_region(region)

            # merge into global result
            for r in reports:
                report_data[r].extend(region_output[r])

        # -------------------------------------------------------------
        # Write output Excel
        # -------------------------------------------------------------
        writer = pd.ExcelWriter('/tmp/file.xlsx', engine='xlsxwriter')

        for report_name, rows in report_data.items():
            df = pd.DataFrame(rows, columns=fieldnames[report_name])
            df.to_excel(writer, sheet_name=report_name, index=False)

        writer.close()

        # -------------------------------------------------------------
        # upload report to S3
        # -------------------------------------------------------------
        print("upload report")
        s3_client.upload_file("/tmp/file.xlsx", s3_destination_bucket, filename)

        # -------------------------------------------------------------
        # send Email Notification
        # -------------------------------------------------------------
        presigned_url = s3_client.generate_presigned_url('get_object',
                                                         Params={'Bucket': s3_destination_bucket, 'Key': filename},
                                                         ExpiresIn=s3_presigned_link_expiration)
        sns_client.publish(TargetArn=s3_sns_topic, Message="Link to patching report (link is valid for " + str(
            int(int(s3_presigned_link_expiration) / 3600)) + " hours): " + presigned_url, MessageStructure='string')
    
    except Exception as e:
        print("Error generating report:", e)
        raise

    print("Report generated successfully.")
    return 0


# ===================================================================
# REGION WORKER — INSTANCE‑LEVEL MULTITHREADING
# ===================================================================
def process_region(region):
    ec2_client = get_ec2_client(region)
    ssm_client = get_ssm_client(region)

    instances = get_instance_list(ec2_client)
    print(f"Found {len(instances)} instances in region {region}")

    # per-region data store
    region_data = {name: [] for name in reports}

    # -------------------------------------------------------------
    # ✅ MULTITHREADING per instance
    # -------------------------------------------------------------
    def process_instance(instance):
        instance_id, instance_name = instance

        instance_results = {name: [] for name in reports}

        for report_name, report_type in reports.items():
            items = list_compliant_items(ssm_client, instance_id, report_type)

            for row in items:
                row['ResourceName'] = instance_name
                row['Region'] = region
                if "InstalledTime" in row["Details"].keys():
                    row["Installation_Date"] = row["Details"]["InstalledTime"]
                instance_results[report_name].append(row)

        return instance_results

    # Thread pool for instances
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(process_instance, inst): inst for inst in instances}

        for future in as_completed(futures):
            inst = futures[future]
            try:
                inst_result = future.result()
                # merge instance result into region result
                for r in reports:
                    region_data[r].extend(inst_result[r])
            except Exception as e:
                print(f"[ERROR] Instance {inst[0]} failed:", e)

    return region_data


# ===================================================================
# AWS Helper Functions
# ===================================================================
def get_ec2_client(region):
    return boto3.client('ec2', region_name=region)


def get_ssm_client(region):
    return boto3.client('ssm', region_name=region)


def get_instance_list(ec2_client):
    instances = []

    try:
        response = ec2_client.describe_instances()

        for reservation in response.get("Reservations", []):
            for inst in reservation.get("Instances", []):
                instance_id = inst.get("InstanceId")

                name = "resource not named"
                for t in inst.get("Tags", []):
                    if t["Key"] == "Name":
                        name = t["Value"]
                        break

                instances.append((instance_id, name))

    except Exception as e:
        print("Error in get_instance_list:", e)

    return instances


def list_compliant_items(ssm_client, instanceid, compliant_status):
    try:
        items = []
        paginator = ssm_client.get_paginator('list_compliance_items')

        for page in paginator.paginate(
            Filters=[{
                'Key': 'Status',
                'Values': [compliant_status],
                'Type': 'BEGIN_WITH'
            },
            {
                'Key': 'ComplianceType',
                'Values': ["Patch"],
                'Type': 'EQUAL'
            }],
            ResourceIds=[instanceid],
            ResourceTypes=['ManagedInstance']
        ):
            items.extend(page.get("ComplianceItems", []))

        return items

    except Exception as e:
        print("Error listing compliance items:", e)
        return []


def list_enabled_regions():
    ec2 = boto3.client("ec2")
    resp = ec2.describe_regions(AllRegions=True)

    regions = [
        r["RegionName"]
        for r in resp.get("Regions", [])
        if r.get("OptInStatus") in ("opt-in-not-required", "opted-in")
    ]
    regions.sort()
    return regions


# ===================================================================
# Local Test Mode
# ===================================================================
if __name__ == "__main__":
    print(datetime.now())
    lambda_handler("", "")
    print(datetime.now())
variable "context" {
  description = "The context to be used in naming the backup selection."
  type        = string
  
}

variable "plan_id" {
  description = "The backup plan ID to be associated with the selection of resources."
  type        = string
}

variable "iam_role_arn" {
  description = "The ARN of the IAM role that AWS Backup uses to authenticate when restoring and backing up the target resource."
  type        = string
}

variable "selection_tags" {
  description = <<EOT
  Tag-based conditions used to specify a set of resources to assign to a backup plan. The selection_tag configuration block supports the following attributes:
  - type: An operation, such as STRINGEQUALS, that is applied to the key-value pair used to filter resources in a selection.
  - key: Key for the filter.
  - value: Value for the filter.
  EOT
  type = list(object({
    type  = string
    key   = string
    value = string
  }))

}

variable "region" {
  description = "The AWS region where the backup selection will be created."
  type        = string
}
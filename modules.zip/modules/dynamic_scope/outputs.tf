output "id" {
  value = azurerm_maintenance_assignment_dynamic_scope.dynamic_scope.id
}

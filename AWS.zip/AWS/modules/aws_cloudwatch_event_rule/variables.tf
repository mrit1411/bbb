variable "event_pattern" {
  description = "The event pattern described as a JSON object. At least one of schedule_expression or event_pattern is required. See full documentation of Events and Event Patterns in EventBridge for details."
  type        = string
  default     = null
}

variable "description" {
  description = "The description of the rule."
  type        = string
}

variable "schedule" {
  description = "The scheduling expression. For example, cron(0 20 * * ? *) or rate(5 minutes). At least one of schedule_expression or event_pattern is required. Can only be used on the default event bus. For more information, refer to the AWS documentation Schedule Expressions for Rules."
  type        = string
  default     = null
}

variable "state" {
  description = "State of the rule. When state is ENABLED, the rule is enabled for all events except those delivered by CloudTrail."
  type        = bool
  default     = true
}

variable "eventbridge_target_arn" {
  description = "The Amazon Resource Name (ARN) of the target."
  type        = string
}

variable "eventbridge_target_role_arn" {
  description = "The Amazon Resource Name (ARN) of the IAM role to be used for this target when the rule is triggered. Required if ecs_target is used or target in arn is EC2 instance, Kinesis data stream, Step Functions state machine, or Event Bus in different account or region."
  type        = string
  default     = null
}

variable "eventbridge_target_id" {
  description = "The unique target assignment ID."
}

variable "context" {
  description = "The context of the event rule"
  type        = string
}

variable "input" {
  description = "The input to the target. This can be a JSON string or a JSON object. If not provided, the default is an empty string."
  type        = string
  default     = null

}

variable "region" {
  description = "The AWS region where the CloudWatch Event Rule will be created."
  type        = string
}
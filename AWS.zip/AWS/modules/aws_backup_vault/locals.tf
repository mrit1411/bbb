locals {
  name = "CCS-${var.context}-BackupVault-${var.region}"
}
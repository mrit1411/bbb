resource "azurerm_key_vault" "key_vault" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = var.sku_name
  tenant_id           = var.tenant_id

  access_policy {
    tenant_id = var.tenant_id
    object_id = var.object_id

    secret_permissions = [
      "Get",
      "List",
      "Set",
      "Delete",
      "Backup",
      "Restore",
      "Purge",
      "Recover"
    ]
  }

  access_policy {
    tenant_id = var.tenant_id
    object_id = var.vm_mi_object_id

    secret_permissions = [
      "Get",
      "List",
      "Set",
      "Delete",
      "Backup",
      "Restore",
      "Purge",
      "Recover"
    ]
  }

  enabled_for_deployment          = var.enabled_for_deployment
  enabled_for_disk_encryption     = var.enabled_for_disk_encryption
  enabled_for_template_deployment = var.enabled_for_template_deployment

  tags = var.tags

  # enable_rbac_authorization       = var.enable_rbac_authorization
  # public_network_access_enabled   = var.public_network_access_enabled
  # soft_delete_retention_days      = var.soft_delete_retention_days
  # purge_protection_enabled        = var.purge_protection_enabled

  # network_acls {
  #   default_action             = var.network_acl_default_action
  #   bypass                     = var.network_acl_bypass
  #   ip_rules                   = var.network_acl_ip_rules
  #   virtual_network_subnet_ids = var.network_acl_virtual_network_subnet_ids
  # }

  lifecycle {
    ignore_changes = [tags]
  }

}

resource "azurerm_key_vault_secret" "prod_client_id" {
  name         = var.splunk_integration_prod_client_id_secret_name
  value        = var.splunk_integration_prod_client_id_secret_value
  key_vault_id = azurerm_key_vault.key_vault.id
  tags         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_key_vault_secret" "prod_client_secret" {
  name         = var.splunk_integration_prod_client_secret_secret_name
  value        = var.splunk_integration_prod_client_secret_secret_value
  key_vault_id = azurerm_key_vault.key_vault.id
  tags         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_key_vault_secret" "test_client_id" {
  name         = var.splunk_integration_test_client_id_secret_name
  value        = var.splunk_integration_test_client_id_secret_value
  key_vault_id = azurerm_key_vault.key_vault.id
  tags         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_key_vault_secret" "test_client_secret" {
  name         = var.splunk_integration_test_client_secret_secret_name
  value        = var.splunk_integration_test_client_secret_secret_value
  key_vault_id = azurerm_key_vault.key_vault.id
  tags         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}
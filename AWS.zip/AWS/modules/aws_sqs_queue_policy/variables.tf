variable "region" {
  description = "The AWS region where the SQS queue is located."
  type        = string
  default = "us-east-1"
}

variable "sqs_queue_url" {
  description = "The URL of the SQS queue to which the policy will be applied."
  type        = string
  
}

variable "policy_json" {
  description = "The JSON policy document to apply to the SQS queue. Ensure that Version = \"2012-10-17\" is set in the policy or AWS may hang in creating the queue."
  type        = string
  
}
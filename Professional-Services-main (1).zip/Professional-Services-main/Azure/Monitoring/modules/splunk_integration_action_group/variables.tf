variable "index" {
  type        = number
  description = "(Required) The index which should be used for this resource. Changing this forces a new resource to be created."
  default     = 1
}

variable "environment" {
  type        = string
  description = "The environment in which to deploy."

  validation {
    condition     = contains(["Prod", "UAT", "Test", "Dev", "SHN"], var.environment)
    error_message = "The supplied value is not in the accepted environment list"
  }
}

variable "org" {
  type        = string
  description = "The owning org."

  validation {
    condition     = contains(["org"], var.org)
    error_message = "The supplied value is not in the accepted org list"
  }
}

variable "context" {
  type        = string
  description = "(Required) The contextual identifier which should be used for this resource. Changing this forces a new resource to be created."

  validation {
    condition     = length(var.context) >= 1
    error_message = "Context must be defined"
  }

  validation {
    condition     = length(var.context) <= 9
    error_message = "Context must be less than or equal to 9 characters"
  }
}

variable "resource_group_name" {
  description = "The name of the resource group in which the Splunk Integration Action Group should be created."
  type        = string
}

variable "short_name" {
  description = "The short name of the Splunk Integration Action Group. This will be used in SMS messages."
  type        = string
}

variable "azure_function_receiver_name" {
  description = "The name of the Azure Function receiver."
  type        = string
}

variable "function_app_resource_id" {
  description = "The Resource ID of the Splunk Integration Azure Function App."
  type        = string
}

variable "function_name" {
  description = "The name of the Splunk Integration Azure Function."
  type        = string
}

variable "function_default_host_key" {
  description = "The default host key of the Splunk Integration Azure Function."
  type        = string
}

variable "use_common_alert_schema" {
  description = "Whether to use the common alert schema for the Azure Function receiver."
  type        = bool
  default     = true
}

variable "function_app_name" {
  description = "The name of the Splunk Integration Azure Function App."
  type        = string
}

variable "tags" {
  description = "A mapping of tags to assign to the resource."
  type        = map(any)
}
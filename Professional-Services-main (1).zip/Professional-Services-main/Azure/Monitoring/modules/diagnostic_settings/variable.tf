# variable "diagnostic_settings_csv_path" {
#   description = "Path to the diagnostic settings CSV file"
#   type        = string
# }
variable "diagnostic_settings_Name" {
  description = "Diagnostic settings Name"
  type        = string
}
variable "log_analytics_workspace_id" {
  description = "Log Analytics Workspace ID"
  type        = string
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_policy_definition.policy_definition](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/policy_definition) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | The description of the policy definition. | `string` | n/a | yes |
| <a name="input_display_name"></a> [display\_name](#input\_display\_name) | The display name of the policy definition. | `string` | n/a | yes |
| <a name="input_management_group_id"></a> [management\_group\_id](#input\_management\_group\_id) | Management Group ID where to define and assign the policy | `string` | n/a | yes |
| <a name="input_mode"></a> [mode](#input\_mode) | The policy resource manager mode that allows you to specify which resource types will be evaluated. | `string` | `"Indexed"` | no |
| <a name="input_name"></a> [name](#input\_name) | The name of the policy definition. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_policy_parameters_filename"></a> [policy\_parameters\_filename](#input\_policy\_parameters\_filename) | The filename of the policy parameters JSON file. | `string` | n/a | yes |
| <a name="input_policy_rule_filename"></a> [policy\_rule\_filename](#input\_policy\_rule\_filename) | The filename of the policy rule JSON file. | `string` | n/a | yes |
| <a name="input_policy_type"></a> [policy\_type](#input\_policy\_type) | The policy type. Possible values are BuiltIn, Custom, NotSpecified and Static. Changing this forces a new resource to be created. | `string` | `"Custom"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |

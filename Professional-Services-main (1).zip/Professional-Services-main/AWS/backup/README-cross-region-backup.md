# Cross-Region Backup Copy (optional feature)

The backup deployment in this folder supports two modes, switched by **one variable**.

| Mode | Setting in `terraform.tfvars` | What gets deployed |
|------|-------------------------------|--------------------|
| **Normal backup** (default) | nothing, or `enable_cross_region_backup_copy = false` | Exactly what existed before this feature: one vault + one plan (daily/weekly/monthly/yearly) + one selection per region in `regions`. `terraform plan` shows **no changes**. |
| **Cross-region backup** | `enable_cross_region_backup_copy = true` | Everything above **plus** one DR vault in `dr_region`, and every recovery point from the other regions is automatically copied into it after each backup job completes. |

## How to turn it on

Add to `AWS/backup/terraform.tfvars`:

```hcl
enable_cross_region_backup_copy = true
dr_region                       = "us-east-1"   # where the copies should land

# optional – retention for the copies in days.
# Omit/null = same retention as the source rule (daily 8, weekly 35, monthly 396, yearly 3650)
# cross_region_copy_delete_after_days = 30
```

Then run `terraform plan` from `AWS/backup` and review it before `apply`.

## What `terraform plan` will show when you switch it ON

| Resource | Change |
|----------|--------|
| `module.backup_vault_dr[0].aws_backup_vault.backup_vault` | **create** – vault `CCS-CCSBackupVault-DR-BackupVault-<dr_region>` |
| `module.ccs_backup_plan["<region>"].aws_backup_plan.backup_plan` | **update in-place** – a `copy_action` is added to each of the 4 rules (every region except `dr_region`) |
| `module.aws_resource_backup_role.aws_iam_role_policy.iam_role_policy["policy1"]` | **create** – inline policy `BackupCrossRegionCopyPolicy` |

Nothing is destroyed or replaced. Existing recovery points are not touched; copies start with the next scheduled backup.

## How to turn it OFF again

Set `enable_cross_region_backup_copy = false` (or remove the line) and apply. The copy actions and the extra IAM policy are removed, and the DR vault is destroyed. **Note:** AWS will not delete a vault that still contains recovery points, so either let the copies expire first or delete them manually before applying.

## Notes

* A region listed in `regions` that is the same as `dr_region` is **not** copied (a copy into the same region is not cross-region). Its normal regional backup continues as usual.
* Copies are stored in the same account. Resources encrypted with a **customer-managed KMS key** need a key usable in the destination region; AWS-managed keys (`aws/ebs`) work without extra setup.
* Copy job failures are covered by the existing `ccs_aws_backup_monitoring` EventBridge rule (state `FAILED`).
* Cross-region data transfer and storage in the DR vault are billed.

## Files changed by this feature

* `AWS/backup/main.tf` – DR vault, `copy_actions` on the 4 rules, conditional IAM policy
* `AWS/backup/locals.tf` – helper locals `cross_region_copy_source_regions` and `cross_region_copy_active`
* `AWS/backup/variables.tf` – `enable_cross_region_backup_copy`, `dr_region`, `cross_region_copy_delete_after_days`
* `AWS/modules/aws_backup_plan/*` – optional `copy_actions` per rule (defaults to `[]`)
* `AWS/modules/aws_backup_vault/outputs.tf` – new `arn` output
* `AWS/modules/aws_iam_role/inline_policies/backup_cross_region_copy_policy.json` – new policy file

resource "aws_kinesis_firehose_delivery_stream" "kinesis_firehose_delivery_stream" {
  name = var.name

  destination = var.destination

  extended_s3_configuration {
    bucket_arn         = var.bucket_arn
    prefix             = var.prefix
    buffering_interval = var.buffering_interval
    buffering_size     = var.buffering_size

    cloudwatch_logging_options {
      enabled         = var.cloudwatch_logging_enabled
      log_group_name  = var.log_group_name
      log_stream_name = var.log_stream_name
    }

    processing_configuration {
      enabled = var.processing_enabled

      processors {
        type = var.processor_type

        parameters {
          parameter_name  = var.processing_parameter_name
          parameter_value = var.processing_parameter_value
        }
      }
    }

    compression_format = var.compression_format
    role_arn           = var.role_arn

  }
}
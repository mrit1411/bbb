
# variable "regions" {
#   type = list(string)
# }

variable "resource_group_name_map" {
  type = map(string)
}

variable "recovery_vault_name_prefix" {
  description = "Prefix for naming (e.g., CCS)"
  type        = string
  default     = "CCS-RSV-"
}

variable "standard_backup_policy_type" {
  description = "Type of the backup policy"
  type        = string
  default     = "V1"
}

variable "enhanced_backup_policy_type" {
  description = "Type of the backup policy"
  type        = string
  default     = "V2"
}

variable "standard_policy_name" {
  description = "Name of the standard backup policy"
  type        = string
}

variable "enhanced_policy_name" {
  description = "Name of the enhanced backup policy"
  type        = string
}

variable "create_standard_policy" {
  type = bool
}

variable "create_enhanced_policy" {
  type = bool
}


variable "standard_policy" {
  type = object({
    timezone                       = optional(string, "UTC")
    schedule_frequency             = string
    schedule_time                  = string
    weekdays                       = optional(list(string))
    retention_daily                = optional(number)
    retention_weekly               = optional(object({ count = number, weekdays = list(string) }))
    retention_monthly              = optional(object({ count = number, weeks = list(string), weekdays = list(string), days = optional(list(number)) }))
    retention_yearly               = optional(object({ count = number, months = list(string), weeks = optional(list(string)), weekdays = optional(list(string)), days = optional(list(string)) }))
    instant_restore_retention_days = optional(number)
  })
  default = {
    timezone           = "UTC"
    schedule_frequency = "Daily"
    schedule_time      = "23:00"
    retention_daily    = 30
    retention_weekly   = { count = 5, weekdays = ["Sunday"] }
    retention_monthly  = { count = 12, weeks = ["First"], weekdays = ["Sunday"] }
  }
}


variable "enhanced_policy" {
  type = object({
    timezone                       = optional(string, "UTC")
    schedule_frequency             = string
    schedule_time                  = string
    hour_interval                  = optional(number)
    hour_duration                  = optional(number)
    weekdays                       = optional(list(string))
    retention_daily                = optional(number)
    retention_weekly               = optional(object({ count = number, weekdays = list(string) }))
    retention_monthly              = optional(object({ count = number, weeks = list(string), weekdays = list(string), days = optional(list(string)) }))
    retention_yearly               = optional(object({ count = number, months = list(string), weeks = optional(list(string)), weekdays = optional(list(string)), days = optional(list(string)) }))
    instant_restore_retention_days = optional(number)
  })
  default = {
    timezone           = "UTC"
    schedule_frequency = "Daily"
    schedule_time      = "23:00"
    retention_daily    = 30
    retention_weekly   = { count = 5, weekdays = ["Sunday"] }
    retention_monthly  = { count = 12, weeks = ["First"], weekdays = ["Sunday"] }
  }
}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

data "terraform_remote_state" "infra" {
  backend = "s3"
  config = {
    bucket = "ccs-draeger-transition-terraform-state-prod"
    key    = "terraform.tfstate"
    region = "eu-central-1"
  }
}
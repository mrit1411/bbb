data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  bucket_name = "ccs-${var.bucket_base_name}-${data.aws_caller_identity.current.account_id}-${var.region}"
}

# Create diagnostic settings based on the CSV data
resource "azurerm_monitor_diagnostic_setting" "paas_diagnostic_settings" {
  for_each                   = { for key, value in local.diagnostic_settings : key => value }
  name                       = var.diagnostic_settings_Name
  target_resource_id         = each.value.ResourceID
  log_analytics_workspace_id = var.log_analytics_workspace_id

  # enabled_log { category = "AddonAzureBackupJobs" }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
  lifecycle {
    ignore_changes = [metric]
  }
}

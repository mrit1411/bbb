import boto3

cloudwatch = boto3.client('cloudwatch')
ec2 = boto3.resource('ec2')

def lambda_handler(event, context):
    event_detail = event.get('detail')
    print('')
    print("Content of the trigger event details: {}".format(event_detail))

    instanceID = event["detail"]["instance-id"]
    print(" - EC2 instance ID: {}".format(instanceID))

    state = event["detail"]["state"]
    print(" - EC2 instance state: {}".format(state))

    if (state.lower() == "terminated"):
      print('')
      print ("Deleting cloudwatch alarms for ec2 instance {} ...".format(instanceID))
      delete_alarms_for_instance(instanceID)

def delete_alarms_for_instance(instanceID):
    response = cloudwatch.describe_alarms(AlarmNamePrefix = instanceID, AlarmTypes=[
                                          'CompositeAlarm','MetricAlarm'])

    if(response.get('CompositeAlarms') != None):
      composite_alarms = response['CompositeAlarms']
      composite_alarm_names = [alarm['AlarmName'] for alarm in composite_alarms]
      cloudwatch.delete_alarms(AlarmNames = composite_alarm_names)

    alarms = response['MetricAlarms']
    alarm_names = [alarm['AlarmName'] for alarm in alarms]
    cloudwatch.delete_alarms(AlarmNames = alarm_names)
    print (" - {}".format(alarm_names))

    print('')
    print('Done !')
resource "aws_sns_topic" "sns_topic" {
  name         = local.name
  display_name = local.name
  region = var.region
}
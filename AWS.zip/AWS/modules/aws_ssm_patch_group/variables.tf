variable "patch_group" {
  description = "The name of the patch group that should be registered with the patch baseline."
  type        = string
}
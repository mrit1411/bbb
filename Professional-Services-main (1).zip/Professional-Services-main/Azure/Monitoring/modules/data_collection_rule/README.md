﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_data_collection_rule.data_collection_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_context"></a> [context](#input\_context) | The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | The description of the data collection rule. | `string` | n/a | yes |
| <a name="input_destination_log_analytics_workspace_name"></a> [destination\_log\_analytics\_workspace\_name](#input\_destination\_log\_analytics\_workspace\_name) | The name of the Log Analytics workspace to which the data collection rule will send data.This name should be unique across all destinations regardless of type within the Data Collection Rule. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_index"></a> [index](#input\_index) | The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure Region where the Data Collection Rule should exist. Changing this forces a new Data Collection Rule to be created. | `string` | n/a | yes |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the Resource Group where the Data Collection Rule should exist. Changing this forces a new Data Collection Rule to be created. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | n/a | yes |
| <a name="input_workspace_resource_id"></a> [workspace\_resource\_id](#input\_workspace\_resource\_id) | The resource ID of the Log Analytics workspace to which the data collection rule will send data. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_dcr_resource_id"></a> [dcr\_resource\_id](#output\_dcr\_resource\_id) | n/a |

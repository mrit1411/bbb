resource "aws_secretsmanager_secret" "secretsmanager_secret" {
  description = var.description
  name        = var.context != null ? local.name : var.name
  region = var.region
}

resource "aws_secretsmanager_secret_version" "secretsmanager_secret_version" {
  secret_id                = aws_secretsmanager_secret.secretsmanager_secret.id
  secret_string_wo         = var.secret_string_wo
  secret_string_wo_version = var.secret_string_wo_version
  region = var.region
}


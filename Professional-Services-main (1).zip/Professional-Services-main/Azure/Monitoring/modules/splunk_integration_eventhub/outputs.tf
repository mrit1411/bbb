output "eventhub_namespace_name" {
  description = "The name of the Event Hub Namespace."
  value       = azurerm_eventhub_namespace.splunk_integration_eventhub_namespace.name
}

output "eventhub_name" {
  description = "The name of the Event Hub."
  value       = azurerm_eventhub.splunk_integration_eventhub.name
}

# output "eventhub_namespace_id" {
#   description = "The ID of the Event Hub Namespace."
#   value       = azurerm_eventhub_namespace.splunk_integration_eventhub_namespace.id
# }


# output "eventhub_id" {
#   description = "The ID of the Event Hub."
#   value       = azurerm_eventhub.splunk_integration_eventhub.id
# }

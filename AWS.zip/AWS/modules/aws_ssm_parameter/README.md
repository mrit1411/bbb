﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_parameter.ssm_parameter](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | Description of the SSM parameter | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | Name of the parameter. If the name contains a path (e.g., any forward slashes (/)), it must be fully qualified with a leading forward slash (/). | `string` | n/a | yes |
| <a name="input_parameter_file"></a> [parameter\_file](#input\_parameter\_file) | File name of the SSM parameter file | `string` | n/a | yes |
| <a name="input_tier"></a> [tier](#input\_tier) | Parameter tier to assign to the parameter. Valid tiers are Standard, Advanced, and Intelligent-Tiering. Downgrading an Advanced tier parameter to Standard will recreate the resource. | `string` | n/a | yes |
| <a name="input_type"></a> [type](#input\_type) | Type of the parameter. Valid types are String, StringList and SecureString. | `string` | `"String"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_ssm_parameter"></a> [aws\_ssm\_parameter](#output\_aws\_ssm\_parameter) | n/a |

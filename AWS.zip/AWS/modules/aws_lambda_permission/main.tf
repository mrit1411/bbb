resource "aws_lambda_permission" "lambda_permission" {
  function_name = var.function_name
  action        = var.action
  principal     = var.principal
  source_arn    = var.source_arn
  region = var.region
}
import boto3
import csv
import os
from datetime import datetime
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from botocore.config import Config
from botocore.exceptions import ClientError


# ------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------
sns_client = boto3.client('sns')

s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = os.environ.get('S3_LINK_EXPIRATION')
s3_sns_topic = os.environ.get('SNS_TOPIC_ARN')
TAGS_KEY = os.environ.get('TAGS_CONDITION_KEY','ccs_managed')
TAGS_VALUE = os.environ.get('TAGS_CONDITION_VALUE','yes')
current_region = os.environ.get('AWS_REGION')

CONFIG = Config(retries={"max_attempts": 6})

TAGS_KEY = os.environ.get("TAGS_CONDITION_KEY", "ccs_managed")
TAGS_VALUE = os.environ.get("TAGS_CONDITION_VALUE", "yes")

CPU_METRICS = ["Average", "Maximum"]
MEM_METRICS = ["Average", "Maximum", "Minimum"]

THREADS = 10  # Parallel execution


# ------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------
def create_clients(region):
    """Create all clients for a specific region."""
    return {
        "cw": boto3.client(
            "cloudwatch",
            region_name=region,
            config=CONFIG
        ),
        "ec2": boto3.client(
            "ec2",
            region_name=region,
        ),
        "ssm": boto3.client(
            "ssm",
            region_name=region,
        ),
        "ec2_resource": boto3.resource(
            "ec2",
            region_name=region,
        )
    }


def filter_instances(ec2_client):
    """Return only instances with matching CCS tag."""
    reservations = ec2_client.describe_instances(
        Filters=[{"Name": f"tag:{TAGS_KEY}", "Values": [TAGS_VALUE]}]
    )["Reservations"]

    instances = []
    for res in reservations:
        instances.extend(res["Instances"])
    return instances


def extract_tag(tags, key, default=""):
    """Extract tag value from instance tag list."""
    for t in tags or []:
        if t["Key"].lower() == key.lower():
            return t["Value"]
    return default


def batch_get_platforms(ssm_client):
    """SSM returns instance platform in pages. Build a dict."""
    result = {}
    next_token = None

    while True:
        params = {"MaxResults": 50}
        if next_token:
            params["NextToken"] = next_token

        resp = ssm_client.describe_instance_information(**params)
        for info in resp.get("InstanceInformationList", []):
            result[info["InstanceId"]] = info.get("PlatformType", "Linux")

        next_token = resp.get("NextToken")
        if not next_token:
            break

    return result


# ------------------------------------------------------------
# METRIC FETCHERS (BATCHED)
# ------------------------------------------------------------
def batch_metric_data(cw_client, queries, start_time, end_time):
    """Executes batched CloudWatch metric queries."""
    resp = cw_client.get_metric_data(
        MetricDataQueries=queries,
        StartTime=start_time,
        EndTime=end_time,
        ScanBy="TimestampDescending",
        # MaxDatapoints=500
        MaxDatapoints=1
    )
    return resp.get("MetricDataResults", [])


def build_metric_query(idx, namespace, metric, dims, stat):
    """Generate GetMetricData query format."""
    return {
        "Id": f"m{idx}",
        "MetricStat": {
            "Metric": {
                "Namespace": namespace,
                "MetricName": metric,
                "Dimensions": dims,
            },
            "Period": 2678400, #1 month #86400 #24h3600,  # Hourly metrics to reduce cost/time
            "Stat": stat,
        },
        "ReturnData": True,
    }


# ------------------------------------------------------------
# INSTANCE PROCESSOR (RUNS IN THREADS)
# ------------------------------------------------------------
def process_instance(instance, region_name, clients, start_time, end_time):
    # if instance["InstanceId"] not in ['i-0aa809004434750c2','i-09c4a07cab7631a8d']:#,'i-0d08a8bb6bb161989','i-0cbb53fbef485a81a','i-0bb42a7e11e3f5b23','i-0610dee6ff393bfa7','i-0c9fb3966c315199e','i-0a44fe2431f790bf5','i-09a9cc0c61b38168f','i-09f74323e7177358b','i-06d1e59d619bf5721','i-09cd5e1f5cd9414ab','i-0b152b87d576f5641','i-058aa10f001748c08','i-0a4da59dae1108f26','i-04a70709a6cd25256','i-08698a52d3bb6448f','i-01c840aa63abd21fa']:
    #     return
    print(f"process_instance: {instance["InstanceId"]}")
    ec2 = clients["ec2"]
    cw = clients["cw"]

    instance_id = instance["InstanceId"]
    tags = instance.get("Tags", [])
    name = extract_tag(tags, "Name", "")
    citrix_instance = False
    if extract_tag(tags,"dg-application").lower() .startswith("citrix cad:"):
        citrix_instance = True 
    state = instance.get("State", {}).get("Name", "")
    platform = "Linux"
    
    # platform comes from SSM (passed into instance obj)
    if "Platform" in instance:
        platform = instance["Platform"]

    # Base row
    base = {
        "Start Time": start_time,
        "End Time": end_time,
        "AWS Region": region_name,
        "Instance Id": instance_id,
        "Platform": platform,
        "Server Name": name,
        "Instance_State": state
    }

    # --------------------------------------------------------
    # Build batched metric queries: CPU + Memory
    # --------------------------------------------------------
    queries = []
    idx = 0

    # build_metric_query(idx, namespace, metric, dims, stat)
    MemoryDimentions = namespace = mem_metric_name = None

    if platform.lower().__contains__("linux"):
        # config = "Linux"
        namespace = 'CWAgent'
        mem_metric_name = 'mem_used_percent'
        MemoryDimentions = [
            {
                'Name': 'InstanceId',
                'Value': instance_id
            }
        ]
        disk_metric_name = 'disk_used_percent'
        disk_total = "disk_total"
        disk_free = "disk_free"
        disk_used = "disk_used"
        DiskInstance = "path"
        DiskDimentions = 'InstanceId'
        DiskDimensionValue = instance_id
        divisor = 1073741824
    elif citrix_instance :
        # config = "citrix"
        namespace = 'Citrix CAD Server new'
        mem_metric_name = 'MemoryInPercent'
        MemoryDimentions = [
            {'Name': 'host', 'Value': name},
            {'Name': 'objectname', 'Value': 'Memory'}
        ]
        disk_metric_name = 'DiskFree'
        disk_metric_bytes = 'DiskFreeMb'
        DiskInstance = "instance"
        DiskDimentions = 'host'
        DiskDimensionValue = name
        divisor = 1024
    else:
        # config = "Windows"
        namespace = 'CWAgent'
        mem_metric_name = 'Memory % Committed Bytes In Use'
        MemoryDimentions = [
            {
                'Name': 'InstanceId',
                'Value': instance_id
            },
            {
                'Name': 'objectname',
                'Value': 'Memory'
            }
        ]
        disk_metric_name = 'LogicalDisk % Free Space'
        disk_metric_bytes = 'LogicalDisk Free Megabytes'
        DiskInstance = "instance"
        DiskDimentions = 'InstanceId'
        DiskDimensionValue = instance_id
        divisor = 1024

    # CPU metrics
    for stat in CPU_METRICS:
        # print("cpu")
        queries.append(build_metric_query(
            idx, "AWS/EC2", "CPUUtilization",
            [{"Name": "InstanceId", "Value": instance_id}],
            stat
        ))
        idx += 1
    
    # Memory metrics (CWAgent)
    # mem_dims = [{"Name": "InstanceId", "Value": instance_id}]
    for stat in MEM_METRICS:
        # print("mem")
        queries.append(build_metric_query(
            idx, namespace, mem_metric_name, MemoryDimentions, stat
        ))
        idx += 1

    # --------------------------------------------------------
    # Execute batched request
    # --------------------------------------------------------
    results = batch_metric_data(cw, queries, start_time, end_time)

    # Attach CPU + Memory results to base row
    cpu_avg = cpu_max = ""
    mem_avg = mem_max = mem_min = ""

    for r in results:
        rid = r["Id"]
        vals = r.get("Values", [])
        if not vals:
            continue
        value = round(vals[0], 2)

        if rid == "m0":  # CPU Average
            cpu_avg = value
        elif rid == "m1":  # CPU Max
            cpu_max = value
        elif rid == "m2":  # Memory avg
            mem_avg = round(100 - value, 2)
        elif rid == "m3":  # Memory max
            mem_max = round(100 - value, 2)
        elif rid == "m4":  # Memory min
            mem_min = round(100 - value, 2)

    base["Average CPU Utilisation(%)"] = cpu_avg
    base["Maximum CPU Utilisation(%)"] = cpu_max
    base["Average free Memory(%)"] = mem_avg
    base["Maximum free Memory(%)"] = mem_max
    base["Minimum free Memory(%)"] = mem_min

    # --------------------------------------------------------
    # Disk Metrics — fetch reduces list_metrics calls
    # --------------------------------------------------------
    disks = clients["cw"].list_metrics(
        Namespace=namespace,
        MetricName=disk_metric_name,
        Dimensions=[{"Name": DiskDimentions, "Value": DiskDimensionValue}]
    )

    rows = []
    for metric in disks.get("Metrics", []):
        path = None
        fs_type = None
        ignore = False
        for d in metric["Dimensions"]:
            if d["Name"] == 'fstype' :
                fs_type = d["Value"]
                if d["Value"] in ['tmpfs','devtmpfs','overlay','mvfs']:
                    ignore = True
            if d["Name"] == DiskInstance and "/snap" not in d["Value"]:
                path_val = d["Value"]
        if not ignore:
            path = path_val
        if not path:
            continue

        # Batch 4 disk metrics
        disk_queries = []
        idx = 0
        dims = metric["Dimensions"]



        if platform.lower().__contains__("linux"):

            # build_metric_query(idx, namespace, metric, dims, stat)
            try:
                # print("linux_disk")
                
                # print("ql1")
                disk_queries.append(build_metric_query("avg"+str(idx), namespace, "disk_used", dims, "Average")); idx += 1
                # print("ql2")
                disk_queries.append(build_metric_query("max"+str(idx), namespace, "disk_used", dims, "Maximum")); idx += 1
                # print("ql3")
                disk_queries.append(build_metric_query(idx, namespace, 'disk_total', dims, "Average")); idx += 1
                # print("ql4")
                disk_queries.append(build_metric_query(idx, namespace, 'disk_used_percent', dims, "Average")); idx += 1
                # print("ql5")
                disk_queries.append(build_metric_query(idx, namespace, "disk_free", dims, "Average"))

                dres = batch_metric_data(cw, disk_queries, start_time, end_time)

                # print(dres)

                diskTotal = diskUsed = free = maxDiskUsed = freepct = minfree = ""
                for r in dres:
                    vals = r.get("Values", [])
                    if not vals:
                        continue
                    val = round(vals[0] / divisor, 2) if "disk_used_percent" not in r["Label"] else vals[0]

                    # if "disk_used" in r["Label"] and "max" in r["Id"]:
                    #     maxDiskUsed = val
                    # elif "disk_used" in r["Label"] and "avg" in r["Id"]:
                    #     diskUsed = val
                    # elif "disk_total" in r["Label"]:
                    #     diskTotal = val
                    # elif "disk_used_percent" in r["Label"]:
                    #     freepct = 100 - round(vals[0], 2)
                    # elif "disk_free" in r["Label"]:
                    #     free = val
                    
                    if "disk_used Maximum" == r["Label"]:
                        maxDiskUsed = val
                    elif "disk_used Average" == r["Label"]:
                        diskUsed = val
                    elif "disk_total" == r["Label"]:
                        diskTotal = val
                    elif "disk_used_percent" == r["Label"]:
                        freepct = 100 - round(vals[0], 2)
                    elif "disk_free" == r["Label"]:
                        free = val
            except Exception as e:
                print(f"Linux disk exception for {instance_id}, {e}")

        else:
            # build_metric_query(idx, namespace, metric, dims, stat)
            try:
                # print("windows_disk")

                # print("qw1")
                disk_queries.append(build_metric_query(idx, namespace, disk_metric_bytes, dims, "Average")); idx += 1
                # print("qw2")
                disk_queries.append(build_metric_query(idx, namespace, disk_metric_name, dims, "Average")); idx += 1
                # print("qw3")
                disk_queries.append(build_metric_query("min"+str(idx), namespace, disk_metric_bytes, dims, "Minimum"))

                dres = batch_metric_data(cw, disk_queries, start_time, end_time)

                # print(dres)

                diskTotal = diskUsed = free = maxDiskUsed = freepct = minfree = ""
                for r in dres:
                    vals = r.get("Values", [])
                    if not vals:
                        continue
                    val = round(vals[0] / divisor, 2) if disk_metric_bytes in r["Label"] else vals[0]

                    if disk_metric_bytes in r["Label"] and 'min' in r["Id"]:
                        minfree = val
                    elif disk_metric_bytes in r["Label"]:
                        free = val
                    elif disk_metric_name in r["Label"]:
                        freepct = round(vals[0], 2) 

                diskTotal = (free * 100) / freepct
                diskUsed = diskTotal - free
                maxDiskUsed = diskTotal - minfree
            except Exception as e:
                print(f"Windows disk exception for {instance_id}, {e}")

        
        rows.append({
            **base,
            "Drive Name": path,
            "fstype":fs_type,
            "Total Disk Space(GB)": diskTotal ,
            "Free Disk Space(GB)": free,
            "Utilised Disk Space(GB)": diskUsed,
            "Free Disk Space (%)": freepct,
            "Max Utilised Disk Space (GB)": maxDiskUsed
        })

    # If no disks found, return single row
    if not rows:
        rows.append({**base, "Drive Name": "","fstype":"", "Total Disk Space(GB)": "", "Free Disk Space(GB)": "",
                     "Utilised Disk Space(GB)": "", "Free Disk Space (%)": "", "Max Utilised Disk Space (GB)": ""})
        
    # print(rows)

    return rows


# ------------------------------------------------------------
# MAIN HANDLER
# ------------------------------------------------------------
def lambda_handler(event=None, context=None):
    filename = f"performance-report-{context.invoked_function_arn.split(":")[4]}-{datetime.today().strftime('%Y%m%d_%H%M')}.csv"
    #start_time=datetime(2021, 1, 1).replace(month=datetime.today().month, year=datetime.today().year) + relativedelta(months=-1)
    start_time = datetime(2026, 3, 1)
    end_time = start_time + relativedelta(months=1, seconds=-1)

    print('Start Time of report: {0}'.format(start_time))
    print('End Time of report: {0}'.format(end_time))
    print("report name: " + filename)

    with open("/tmp/"+filename, "w", newline="") as f:
        writer = csv.DictWriter(f, delimiter=",", fieldnames=[
            "Start Time", "End Time", "AWS Region", "Instance Id", "Platform", "Server Name",
            "Instance_State", "Average CPU Utilisation(%)", "Maximum CPU Utilisation(%)",
            "Average free Memory(%)", "Maximum free Memory(%)", "Minimum free Memory(%)",
            "Drive Name","fstype", "Total Disk Space(GB)", "Free Disk Space(GB)",
            "Utilised Disk Space(GB)", "Free Disk Space (%)", "Max Utilised Disk Space (GB)"
        ])
        writer.writeheader()

        # Loop regions
        regions = boto3.client("ec2").describe_regions()["Regions"]
        regions = [current_region]#["eu-central-1"]#["us-east-1"]
        for r in regions:
            region_name = r#["RegionName"]
            print(f"Processing region: {region_name}")

            clients = create_clients(region_name)
            instances = filter_instances(clients["ec2"])
            platform_map = batch_get_platforms(clients["ssm"])

            # Attach platform to instances
            for inst in instances:
                iid = inst["InstanceId"]
                # inst["Platform"] = platform_map.get(iid, "Linux")

            # Process instances concurrently
            with ThreadPoolExecutor(max_workers=THREADS) as ex:
                futures = {
                    ex.submit(process_instance, inst, region_name, clients, start_time, end_time): inst
                    for inst in instances
                }

                for fut in as_completed(futures):
                    try:
                        for row in fut.result():
                            writer.writerow(row)
                    except Exception as e:
                        print(f"Instance processing failed {inst["InstanceId"]}: {e}")

    print(f"Report generated: {filename}")

    try:
        s3_client = boto3.client("s3")
        print("upload report: "+filename)
        s3_client.upload_file("/tmp/" + filename, s3_destination_bucket, filename)
    except ClientError as e:
        print("Unexpected error: %s" % e)

    # -------------------------------------------------------------
    # send Email Notification
    # -------------------------------------------------------------
    try:
        presigned_url = s3_client.generate_presigned_url('get_object',
                                                            Params={'Bucket': s3_destination_bucket, 'Key': filename},
                                                            ExpiresIn=s3_presigned_link_expiration)
        sns_client.publish(TargetArn=s3_sns_topic, Message="Link to patching report (link is valid for " + str(
            int(int(s3_presigned_link_expiration) / 3600)) + " hours): " + presigned_url, MessageStructure='string')
        
    except ClientError as e:
        print("Unexpected error: %s" % e)

resource "aws_oam_sink" "oam_sink" {
  name   = local.oam_sink_name
  region = var.region
}

resource "aws_oam_sink_policy" "oam_sink_policy" {
  sink_identifier = aws_oam_sink.oam_sink.arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action   = ["oam:CreateLink", "oam:UpdateLink"]
        Effect   = "Allow"
        Resource = "*"
        Principal = {
          "AWS" = var.source_account_ids
        }
        Condition = {
          "ForAllValues:StringEquals" = {
            "oam:ResourceTypes" = ["AWS::CloudWatch::Metric", "AWS::Logs::LogGroup"]
          }
        }
      }
    ]
  })
}

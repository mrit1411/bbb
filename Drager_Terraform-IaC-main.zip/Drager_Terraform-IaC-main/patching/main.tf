module "windows_default_patch_baseline" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_baseline"
  region         = each.key
  patch_baseline = var.windows_baseline
}

module "linux_default_patch_baseline" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_baseline"
  region         = each.key
  patch_baseline = var.linux_baseline
}

module "windows_prod_patch_group" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_group"
  patch_group    = "windows_prod"
  region         = each.key
  patch_baseline = module.windows_default_patch_baseline[each.value].patch_baseline
}

module "linux_prod_patch_group" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_group"
  patch_group    = "linux_prod"
  region         = each.key
  patch_baseline = module.linux_default_patch_baseline[each.value].patch_baseline
}

module "windows_non_prod_patch_group" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_group"
  patch_group    = "windows_non_prod"
  region         = each.key
  patch_baseline = module.windows_default_patch_baseline[each.value].patch_baseline
}

module "linux_non_prod_patch_group" {
  for_each       = toset(var.regions)
  source         = "../modules/aws_ssm_patch_group"
  patch_group    = "linux_non_prod"
  region         = each.key
  patch_baseline = module.linux_default_patch_baseline[each.value].patch_baseline
}

module "modify_alarms_iam_role" {
  source = "../modules/aws_iam_role"

  description         = "Role created by CCS Patching Solution Deployment. Created for the AWS-ConfigureCloudWatchOnEC2Instance SSM Documents to assume. Grants permissions to enable and disable EC2 alarm actions"
  context             = "Modify-CloudWatch-Alarms"
  resource_type       = "SSM"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonSSMAutomationRole"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "ModifyAlarms"
      inline_policy      = file("../modules/aws_iam_role/inline_policies/modify_alarms.json")
    }
  }

}

module "task_publish_sns_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Used by Automation Docs to publish to Patching Results SNS Topic"
  context       = "Task-Publish-SNS"
  resource_type = "SSM"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "TaskPublishSNSPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/task_publish_sns_policy.tpl.json", {
        results_patching_sns_topic_arn = flatten([for r in var.regions : [
          module.results_patching_sns_topic[r].sns_topic_arn
          ]
        ])
      })
    }
  }

}

module "results_patching_sns_topic" {
  for_each = toset(var.regions)
  source   = "../modules/aws_sns_topic"
  name     = var.results_patching_sns_topic_name
  region   = each.key
}

module "result_patching_topic_lambda_subscription" {
  for_each = toset(var.regions)
  source   = "../modules/aws_sns_topic_subscription"

  topic_arn = module.results_patching_sns_topic[each.value].sns_topic_arn
  endpoint  = [module.report_patching_details_lambda_function[each.value].arn]
  protocol  = "lambda"
  region    = each.key
  depends_on = [ module.report_patching_details_lambda_function ]
}

module "report_patching_details_lambda_function" {
  for_each = toset(var.regions)
  source   = "../modules/aws_lambda_function"

  description              = "CCS Lambda Function that will generate instant compliance patch reports after a patching cycle has completed and send to SNS Topic arn variable"
  handler                  = "lambda_instant_patching_report.lambda_handler"
  region                   = each.key
  lambda_function_filename = "lambda_instant_patching_report"
  role                     = module.lambda_patching_instant_role.role_arn
  timeout                  = 10
  memory_size              = 128
  env_variables = {
    SNS_TOPIC_ARN = ""
    log_level     = var.log_level
  }

}

module "sns_permission_invoke_lambda" {
  for_each = toset(var.regions)
  source   = "../modules/aws_lambda_permission"

  function_name = module.report_patching_details_lambda_function[each.value].arn
  principal     = "sns.amazonaws.com"
  source_arn    = module.results_patching_sns_topic[each.value].sns_topic_arn
  region        = each.key

}

module "lambda_patching_instant_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Usedby CCS-Patching-instant-report-lambda to generate patching compliance information and send to SNOW SNS Topic"
  resource_type = "lambda"
  path          = "/service-role/"
  context       = "Lambda-Patching-Instant-Role"
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaPatchingInstantPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/lambda_patching_instant_policy.tpl.json", {
        snow_sns_topic_arn = flatten([for r in var.regions : [
          data.terraform_remote_state.infra.outputs.infra_snow_sns_topic[r].sns_topic_arn
          ]
        ])
      })
    }
  }
}

module "patch_reports_s3_bucket" {
  for_each         = toset(var.regions)
  source           = "../modules/aws_s3_bucket"
  bucket_base_name = var.patch_reports_bucket_name
  region           = each.key
}

module "patch_reports_s3_bucket_encryption_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_s3_bucket_server_side_encryption_configuration"
  bucket   = module.patch_reports_s3_bucket[each.value].bucket_id
  region   = each.key
}

module "patch_reports_s3_bucket_policy" {
  for_each = toset(var.regions)
  source   = "../modules/aws_s3_bucket_policy"
  bucket   = module.patch_reports_s3_bucket[each.value].bucket_id
  region   = each.key
}

module "patch_report_eventbridge_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Created for the Patch Report Eventbridge to assume. Grants permissions to run SSM Documents."
  context       = "Patch-Report-Eventbridge"
  resource_type = "events"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "PatchReportEventBridgePolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/patch_report_eventbridge_policy.tpl.json", {
        patch_report_ssm_iam_role_arn = module.patch_report_ssm_iam_role.role_arn
      })
    }
  }
}

module "patch_report_ssm_iam_role" {
  source = "../modules/aws_iam_role"

  description   = "Role created by CCS Patching Solution Deployment. Created for the AWS-ExportPatchReportToS3 SSM Documents to assume. Grants permissions to create and manage patch reports"
  context       = "Patch-Report-SSM"
  resource_type = "SSM"
  path          = "/service-role/"
  inline_policies = {
    policy0 = {
      inline_policy_name = "PatchReportSSMPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/patch_report_ssm_policy.tpl.json", {
        patch_report_s3_bucket_id = flatten([for r in var.regions : [
          module.patch_reports_s3_bucket[r].bucket_arn
          ]
        ]),
        account_id = data.aws_caller_identity.current.account_id
      })
    }
  }

}

module "patch_report_monthly_trigger" {
  for_each = toset(var.regions)
  source   = "../modules/aws_cloudwatch_event_rule"

  description            = "Event rule to trigger the patch report generation monthly"
  schedule               = var.patch_report_generation_schedule_monthly
  region                 = each.key
  eventbridge_target_id  = "PatchReports"
  eventbridge_target_arn = "arn:aws:ssm:${each.key}:${data.aws_caller_identity.current.account_id}:automation-definition/AWS-ExportPatchReportToS3"

  input = jsonencode({
    assumeRole   = [module.patch_report_ssm_iam_role.role_arn],
    reportName   = ["PatchReport"],
    s3BucketName = [module.patch_reports_s3_bucket[each.value].bucket_id],
    targets      = ["instanceids=*"]
  })

  context                     = "Patch-Report-Monthly-Trigger"
  eventbridge_target_role_arn = module.patch_report_eventbridge_iam_role.role_arn
}

module "windows_prod_maintenance_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_ssm_maintenance_configuration"

  window_name        = "windows-Prod-maintenance-window"
  window_description = "Prod Windows Maintenance Window for monthly maintenance on second Saturday at 2 AM UTC"
  # window_schedule    = "cron(0 2 ? * 7#2 *)" // Example cron expression for maintenance on second Saturday of every month at 2 AM UTC
  window_schedule = "cron(0 30 23 ? * TUE#3 *)" //11:30 PM the third Tuesday of each month
  #window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2026-04-09T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  schedule_offset           = 5
  window_target_name        = "default-windows-target"
  window_target_description = "Default Windows target for maintenance window, targets Windows EC2 with ccs_managed:yes tag and ccs_schedule:windows_default tag"
  region                    = each.key
  enabled                   = false
   
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["windows_prod"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot                            = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic[each.value].sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}

module "windows_non_prod_maintenance_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_ssm_maintenance_configuration"

  window_name        = "windows-Non-Prod-maintenance-window"
  window_description = "Non-Prod Windows Maintenance Window for monthly maintenance on second Saturday at 2 AM UTC"
  # window_schedule    = "cron(0 2 ? * 7#2 *)" // Example cron expression for maintenance on second Saturday of every month at 2 AM UTC
  window_schedule = "cron(0 30 23 ? * TUE#3 *)" //11:30 PM the third Tuesday of each month
  #window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2026-04-09T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  schedule_offset           = 4
  window_target_name        = "default-windows-target"
  window_target_description = "Default Windows target for maintenance window, targets Windows EC2 with ccs_managed:yes tag and ccs_schedule:windows_default tag"
  region                    = each.key
  enabled                   = false
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["windows_non_prod"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot                            = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic[each.value].sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}

module "linux_Prod_maintenance_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_ssm_maintenance_configuration"

  window_name        = "linux-prod-maintenance-window"
  window_description = "Prod Linux Maintenance Window for quarterly maintenance one day after every third wednesday at 2 AM UTC"
  window_schedule    = "cron(0 2 ? 2,5,8,11 Tue#3 *)" // Example cron expression for maintenance on third Thursday of every third month at 2 AM UTC
  # window_schedule           = "cron(0 2 ? 2,5,8,11 2#3)" // Example cron expression for maintenance on third Tuesday of Feb, May, Aug & Nov month at 2 AM UTC
  # window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2026-04-09T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  schedule_offset           = 5
  window_target_name        = "default-linux-target"
  window_target_description = "Default Linux target for maintenance window, targets Linux EC2 with ccs_managed:yes tag and ccs_schedule:linux_default tag"
  region                    = each.key
  enabled                   = false
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["linux_prod"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot                            = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic[each.value].sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}

module "linux_Non_Prod_maintenance_configuration" {
  for_each = toset(var.regions)
  source   = "../modules/aws_ssm_maintenance_configuration"

  window_name        = "linux-non-prod-maintenance-window"
  window_description = "Non-Prod Linux Maintenance Window for quarterly maintenance one day after every third wednesday at 2 AM UTC"
  window_schedule    = "cron(0 2 ? 2,5,8,11 Tue#3 *)" // Example cron expression for maintenance on third Thursday of every third month at 2 AM UTC
  # window_schedule           = "cron(0 2 ? 2,5,8,11 2#3)" // Example cron expression for maintenance on third Tuesday of Feb, May, Aug & Nov month at 2 AM UTC
  # window_schedule           = "cron(0 */2 * * ? *)" //cron for every 2 hours for testing purposes, change to above cron for production
  window_start_date         = "2026-04-09T07:00:00Z"
  window_end_date           = "9999-09-22T00:00:00Z"
  schedule_offset           = 4
  window_target_name        = "default-linux-target"
  window_target_description = "Default Linux target for maintenance window, targets Linux EC2 with ccs_managed:yes tag and ccs_schedule:linux_default tag"
  region                    = each.key
  enabled                   = false
  window_targets = [
    {
      key    = "ccs_managed"
      values = ["yes"]
    },
    {
      key    = "PatchGroup"
      values = ["linux_non_prod"]
    },
    {
      key    = "ccs_dependency_type"
      values = ["dependency"]
    }
  ]
  require_reboot                            = false
  modify_alarms_task_assume_role_arn        = module.modify_alarms_iam_role.role_arn
  patching_task_notification_arn            = module.results_patching_sns_topic[each.value].sns_topic_arn
  patching_task_invocation_service_role_arn = module.task_publish_sns_iam_role.role_arn
}

module "periodic_patching_reports_automation_trigger_monthly" {
  for_each               = toset(var.regions)
  source                 = "../modules/aws_cloudwatch_event_rule"
  context                = "PeriodicPatchingReports"
  description            = "EventRule for triggering CCS Periodic Patching Report Lambda Function to generate monthly Periodic Patching reports."
  schedule               = var.periodic_patching_report_generation_schedule_monthly
  eventbridge_target_arn = module.periodic_patching_reports_lambda_function[each.value].arn
  eventbridge_target_id  = "PeriodicPatchingReports"
  region                 = each.key
}

module "periodic_patching_report_sns_topic" {
  for_each = toset(var.regions)
  source   = "../modules/aws_sns_topic"
  name     = var.periodic_patching_report_sns_topic_name
  region   = each.key
}

module "periodic_patching_report_sns_topic_subscription" {
  for_each  = toset(var.regions)
  source    = "../modules/aws_sns_topic_subscription"
  topic_arn = module.periodic_patching_report_sns_topic[each.value].sns_topic_arn
  endpoint  = var.periodic_patching_report_recipient
  region    = each.key
}

module "periodic_patching_reports_lambda_function" {
  for_each                 = toset(var.regions)
  source                   = "../modules/aws_lambda_function"
  lambda_function_filename = "lambda_periodic_patching_reports"
  role                     = module.lambda_periodic_patching_reports_iam_role.role_arn
  description              = "CCS Developed Lambda Function. Will generate an Periodic Patching report when triggered, place into an S3 bucket and send a presigned URL to the topic ARN. Triggered automatically through monthly EventBridge rules."
  handler                  = "lambda_periodic_patching_reports.lambda_handler"
  timeout                  = 900
  memory_size              = 1024
  runtime                  = var.python_runtime
  env_variables = {
    SNS_TOPIC_ARN                = module.periodic_patching_report_sns_topic[each.value].sns_topic_arn
    S3_LINK_EXPIRATION           = var.s3_link_validity
    S3_BUCKET                    = module.patch_reports_s3_bucket[each.value].bucket_id
    TAGS_CONDITION_KEY           = var.tags_condition_key
    TAGS_CONDITION_VALUE         = var.tags_condition_value
  }
  region = each.key
  layers                   = [module.periodic_patching_lambda_layer[each.value].lambda_layer_arn,local.pandas_layer_arn[each.key]]
}

module "periodic_patching_reports_lambda_permission" {
  for_each      = toset(var.regions)
  source        = "../modules/aws_lambda_permission"
  function_name = module.periodic_patching_reports_lambda_function[each.value].arn
  source_arn    = module.periodic_patching_reports_automation_trigger_monthly[each.value].arn
  region        = each.key
}

module "lambda_periodic_patching_reports_iam_role" {
  source              = "../modules/aws_iam_role"
  description         = "Role created by CCS Periodic Patching Solution Deployment. Used by the Periodic Patching Reports Lambda Function to generate Periodic Patching reports, store in S3 and publish URL to SNS"
  context             = "Periodic-Patching-Reports"
  resource_type       = "Lambda"
  path                = "/service-role/"
  managed_policy_arns = ["arn:aws:iam::aws:policy/ResourceGroupsandTagEditorReadOnlyAccess"]
  inline_policies = {
    policy0 = {
      inline_policy_name = "LambdaPeriodicPatchingReportsInstantPolicy"
      inline_policy = templatefile("../modules/aws_iam_role/inline_policies/lambda_periodic_patching_reports_instant_policy.tpl.json", {
        periodic_patching_reports_sns_topic_arn = flatten([for r in var.regions : [
          module.periodic_patching_report_sns_topic[r].sns_topic_arn
          ]
        ]),
        s3_bucket_periodic_patching_reports_bucket_id = flatten([for r in var.regions : [
          module.patch_reports_s3_bucket[r].bucket_arn
          ]
        ]),
        s3_bucket_periodic_patching_reports_bucket_objects = flatten([for r in var.regions : [
          "${module.patch_reports_s3_bucket[r].bucket_arn}/*"
          ]
        ])
      })
    }
  }
}

module "periodic_patching_lambda_layer" {
  for_each            = toset(var.regions)
  source              = "../modules/aws_lambda_layer_version"
  description         = "Python xlsxwriter layer for periodic patching lambda function."
  filename            = "xlsxwriter"
  layer_name          = "ccs_periodic_patching_lambda_layer_xlsxwriter"
  compatible_runtimes = ["python3.11", "python3.12", "python3.13"]
  region              = each.key
}
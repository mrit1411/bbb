resource "aws_backup_plan" "backup_plan" {
  name = local.name
  region = var.region

  advanced_backup_setting {
    resource_type = var.backup_setting_resource_type
    backup_options = {
      WindowsVSS = var.backup_setting_windows_vss ? "enabled" : "disabled"
    }
  }

  dynamic "rule" {
    for_each = var.rules
    content {
      rule_name         = rule.value.rule_name
      schedule          = rule.value.schedule
      completion_window = rule.value.completion_window
      start_window      = rule.value.start_window
      target_vault_name = rule.value.target_vault_name
      lifecycle {
        delete_after = rule.value.delete_after
      }
      recovery_point_tags = rule.value.recovery_point_tags
    }
  }

  tags = var.tags
}
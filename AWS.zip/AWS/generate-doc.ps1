$modulesPath = ".\modules"

Get-ChildItem -Path $modulesPath -Directory | ForEach-Object {
    $modulePath = $_.FullName
    Write-Host "Generating docs for $modulePath"
    terraform-docs markdown $modulePath | Out-File -Encoding UTF8 "$modulePath\README.md"
}
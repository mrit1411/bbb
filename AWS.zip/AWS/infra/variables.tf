variable "tags_condition_key" {
  description = "Resources with this Tag Key will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "ccs_managed"
}

variable "tags_condition_value" {
  description = "Resources with this Tag Value will be managed by CCS Monitoring and SSM"
  type        = string
  default     = "yes"
}

variable "ssm_management_ec2_instance_profile_name" {
  description = "Name of the SSM Management EC2 Instance Profile"
  type        = string
  default     = "CCSEC2InstanceProfileforSSMManagement"
}

variable "snow_client_id" {
  description = "Provide the iPaaS API authentication ID. stored in Secret Manager. used by CCS-SNOW Lambda to authenticate with iPaaS cloud native endpoint"
  type        = string
}

variable "snow_client_secret" {
  description = "Provide the iPaaS API authentication secret. stored in Secret Manager. Used by CCS-SNOW Lambda to authenticate with iPaaS cloud native endpoint"
  type        = string

}

variable "snow_sns_topic_name" {
  description = "Provide name for SNS Topic that will be created and linked to CCS ServiceNow Lambda"
  type        = string
  default     = "SNOW-Monitoring"

}

variable "api_company_name" {
  description = "CCS-SNOW Lambda will populate the Company field in ServiceNow with this value. this must reflect the exact name of the intended company in ServiceNow"
  type        = string

}

variable "log_level" {
  description = "Allows various details of lambda events to be logged. Value must be in range:<0- no logging, 1- production, 2- dev, 3 maximum logging>"
  type        = number
  default     = 3

  validation {
    condition     = var.log_level >= 0 && var.log_level <= 3
    error_message = "Log level must be between 0 and 3."
  }
}

variable "regions" {
  description = "List of regions to deploy the SNS topic for Splunk Forwarder"
  type        = list(string)

}

variable "splunk_forwarder_sns_topic_name" {
  description = "Name of the SNS topic to be created for Splunk Forwarder"
  type        = string
  default     = "CCS-Splunk-Forwarder-Topic"

}

variable "aws_source_account_ids" {
  description = "List of AWS Account IDs that will be allowed to publish to the Splunk Forwarder SNS Topic"
  type        = list(string)
  default     = ["471112573064"]
}

variable "oam_sink_region" {
  description = "The AWS region where the OAM sink will be created."
  type        = string
  default     = "us-east-1"
}

variable "oam_source_account_ids" {
  description = "List of AWS account IDs that are allowed to create and update links to this OAM sink."
  type        = list(string)
  default     = ["471112573064"]
}

variable "oam_link_region" {
  description = "The AWS region where the OAM link will be created."
  type        = string
  default     = "us-east-1"

}
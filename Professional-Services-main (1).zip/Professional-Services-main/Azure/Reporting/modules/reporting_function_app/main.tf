resource "azurerm_service_plan" "app_service_plan" {
  name                         = local.aspname
  location                     = var.location
  os_type                      = var.service_plan_os_type
  resource_group_name          = var.resource_group_name
  sku_name                     = var.service_plan_sku_name
  maximum_elastic_worker_count = var.maximum_elastic_worker_count
  per_site_scaling_enabled     = var.per_site_scaling_enabled
  tags                         = var.tags

  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_windows_function_app" "reporting_function_app" {
  name                = local.faname
  resource_group_name = var.resource_group_name
  location            = var.location
  service_plan_id     = azurerm_service_plan.app_service_plan.id

  identity {
    type         = "SystemAssigned, UserAssigned"
    identity_ids = var.user_assigned_identity_ids
  }

  functions_extension_version = var.functions_extension_version
  storage_account_name        = var.storage_account_name
  storage_account_access_key  = var.storage_account_access_key
  client_certificate_enabled  = var.client_certificate_enabled
  daily_memory_time_quota     = var.daily_memory_time_quota
  https_only                  = var.https_only

  site_config {
    application_stack {
      powershell_core_version = var.powershell_core_version
    }
  }

  app_settings = {
    "WEBSITE_RUN_FROM_PACKAGE"                     = "${var.blob_url}"
    "WEBSITE_CONTENTSHARE"                         = "${lower(local.faname)}ab71"
    "WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID" = var.user_assigned_identity_resource_id
    "APPINSIGHTS_INSTRUMENTATIONKEY"               = azurerm_application_insights.application_insights.instrumentation_key
    "APPLICATIONINSIGHTS_CONNECTION_STRING"        = azurerm_application_insights.application_insights.connection_string
    "AZURE_CLIENT_ID"                              = var.client_id
  }

  tags = var.tags


    
lifecycle {
  ignore_changes = [
    tags,
    site_config[0].cors,   # CORS managed in portal
    identity[0].principal_id,
    identity[0].tenant_id
  ]
}

  }


resource "azurerm_application_insights" "application_insights" {
  name                = "${local.faname}-ain"
  location            = var.location
  resource_group_name = var.resource_group_name
  application_type    = "web"
  tags                = var.tags
  #workspace_id        = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/ai_report-p-weu-01-org-func-ain_bfde4e16-23a4-46da-978d-3499acd0c43f_managed/providers/Microsoft.OperationalInsights/workspaces/managed-report-p-weu-01-org-func-ain-ws"

  lifecycle {
    ignore_changes = [tags]
  }
}
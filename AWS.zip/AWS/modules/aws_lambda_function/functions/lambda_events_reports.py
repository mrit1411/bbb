import boto3
import time
import csv
import os
import json
from datetime import datetime, timedelta
from botocore.config import Config
from botocore.exceptions import ClientError
from dateutil.relativedelta import *


cloudwatch_client = boto3.client("cloudwatch")
ec2_client = boto3.client("ec2")


s3_destination_bucket = os.environ.get('S3_BUCKET')


def lambda_handler(event, context):

    s3_client = boto3.client("s3")
   
    alarm_data=[": EC2:Over 80% CPU Utilization detected over a period of 30 minutes",": EC2:Over 90% CPU Utilization detected over a period of 30 minutes",": EC2:System Uptime is less than 20 seconds",": EC2:Over 90% Memory Utilization detected over a period of 15 minutes",": EC2:Over 90% Disk Utilization detected over a period of 15 minutes",": EC2:Status Check Fail detected",":EC2 CPU Utilisation"]             
    start_date =datetime(2021, 1, 1).replace(month=datetime.today().month, year=datetime.today().year) + relativedelta(months=-1)
    end_date = start_date + relativedelta(months=1,seconds=-1)

    fieldnames = ["Start Time","End Time","Region Name","Server Name","Problem","DateTime"]
    filename = "Events-report-" + context.invoked_function_arn.split(":")[4] + "-" + datetime.today().strftime("%d-%m-%Y_%H:%M.%f") + ".csv"
    try:
      with open("/tmp/" + filename, 'w+') as temp_file:
        csvdata = csv.DictWriter(temp_file, delimiter=';', fieldnames=fieldnames, extrasaction='ignore')
        csvdata.writeheader()
        alarm_history_details = {}
        for region in boto3.client('ec2').describe_regions()['Regions']:
            ec2_client = boto3.client('ec2', region_name=region['RegionName'])
            cloudtrail_client = boto3.client('cloudtrail', region_name=region['RegionName'])
            cloudwatch_client = boto3.client('cloudwatch', region_name=region['RegionName'])
            instance_dict = get_instance_ids(start_date,end_date,ec2_client,cloudtrail_client,region["RegionName"])
            for instance_id in instance_dict:
                alarm_history_details['Start Time'] = start_date
                alarm_history_details['End Time'] = end_date
                alarm_history_details['Region Name'] = region['RegionName']
                alarm_history_details['Server Name'] = get_server_name(instance_id, ec2_client)
                for alarm in alarm_data:
                    for metric in get_metric_history(cloudwatch_client,instance_id,start_date,end_date,alarm):
                        alarm_history_details["Problem"] =metric["AlarmName"]
                        alarm_history_details["DateTime"] =metric["TimeStamp"]
                        csvdata.writerow(alarm_history_details)

        temp_file.close()
    except Exception as e:
        print("Error opening csv file: %s" % e)
        exit(1)
    try:
        print("Upload report to S3 bucket: " + s3_destination_bucket)
        s3_client.upload_file("/tmp/" + filename, s3_destination_bucket, filename)

    except ClientError as e:
        print("Unexpected error: %s" % e)

    return 0


def get_metric_history(cloudwatch_client,instance_id,start_date,end_date,alarm):
    response = cloudwatch_client.describe_alarm_history(
    AlarmName= instance_id + alarm, 
    HistoryItemType='StateUpdate',
    StartDate=start_date,
    EndDate=end_date
    )
    print(response)
    information = []
    short_information={}
    for alarms in range(len(response["AlarmHistoryItems"])):
        if (response["AlarmHistoryItems"][alarms]["HistorySummary"]):
            short_information["AlarmName"] = response["AlarmHistoryItems"][alarms]["AlarmName"]
            short_information["TimeStamp"] = response["AlarmHistoryItems"][alarms]["Timestamp"].strftime('%d-%m-%Y %H:%M')
            short_information["HistorySummary"] = response["AlarmHistoryItems"][alarms]["HistorySummary"]
            information.append(short_information)
            short_information={}
    return information

def get_server_name(instance_id, ec2):
    server_name = 'undefined'
    try:
            response = ec2.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [instance_id]
                    }
                ]
            )
            for Tag in response['Tags']:
                if Tag['Key'] == 'Name':
                    server_name = Tag['Value']
    except Exception as e:
        print("Error while reading instance tags: %s" % e)
    return server_name
    
def get_instance_ids(start_date,end_date,ec2,cloudtrail,region):
    instance_list = []
    try:
        #instances that were terminated in the last 30 days
        response_terimnated = cloudtrail.lookup_events(
            LookupAttributes=[
                {
                    'AttributeKey': 'EventName',
                    'AttributeValue': 'TerminateInstances'
                },
            ],
            StartTime=start_date,
            EndTime=end_date
            )
        for event in response_terimnated['Events']:
          for resource in event['Resources']:
                instance_list.append(resource["ResourceName"])     
        # instances that are running or stopped
        response_current = ec2.describe_instances()
        for reservation in response_current['Reservations']:
            for instance in reservation['Instances']:
                instance_list.append(instance['InstanceId'])           
    except Exception as e:
        print(f"Fetching instances for region: {region} failed")
    return instance_list
    

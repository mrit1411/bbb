output "id" {
  value = azurerm_maintenance_configuration.maintenance_configuration.id
}
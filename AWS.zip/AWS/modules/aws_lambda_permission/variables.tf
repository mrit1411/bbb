variable "function_name" {
  description = "The name of the Lambda function to which the permission will be added."
  type        = string
}

variable "action" {
  description = "Lambda action to allow in this statement"
  type        = string
  default     = "lambda:InvokeFunction"
}

variable "principal" {
  description = "AWS service or account that invokes the function"
  type        = string
  default     = "events.amazonaws.com"
}

variable "source_arn" {
  description = "ARN of the source resource granting permission to invoke the Lambda function"
  type        = string
}

variable "region" {
  description = "The AWS region where the Lambda function is deployed."
  type        = string
}
﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_ssm_document.ssm_document](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_document) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_content"></a> [content](#input\_content) | The content of the SSM document in JSON or YAML format. | `string` | n/a | yes |
| <a name="input_document_type"></a> [document\_type](#input\_document\_type) | The type of the SSM document. Valid values are Command \| Policy \| Automation \| Session \| Package \| ApplicationConfiguration \| ApplicationConfigurationSchema \| DeploymentStrategy \| ChangeCalendar \| Automation.ChangeTemplate \| ProblemAnalysis \| ProblemAnalysisTemplate \| CloudFormation \| ConformancePackTemplate \| QuickSetup \| ManualApprovalPolicy \| AutoApprovalPolicy. | `string` | `"Automation"` | no |
| <a name="input_name"></a> [name](#input\_name) | The name of the SSM document. | `string` | n/a | yes |
| <a name="input_target_type"></a> [target\_type](#input\_target\_type) | The target type which defines the kinds of resources the document can run on. For example, /AWS::EC2::Instance | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_name"></a> [name](#output\_name) | n/a |

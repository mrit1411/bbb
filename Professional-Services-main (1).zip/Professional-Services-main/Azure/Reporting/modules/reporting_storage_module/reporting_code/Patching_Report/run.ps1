# Input bindings are passed in via param block.
param($Timer)

Import-Module Az.ResourceGraph

$query = @"
patchinstallationresources
| where type has "softwarepatches"
| extend vmName = tostring(split(id, "/")[8]),
         rgName = tostring(split(id, "/")[4]),
         subId  = tostring(split(id, "/")[2])
| extend vmId = tolower(strcat('/subscriptions/', subId,
                               '/resourceGroups/', rgName,
                               '/providers/Microsoft.Compute/virtualMachines/', vmName))
| extend prop = parse_json(properties)
| extend TimeGenerated     = todatetime(prop.lastModifiedDateTime),
         patchName         = tostring(prop.patchName),
         kbId              = tostring(prop.kbId),
         installationState = tostring(prop.installationState),
         classifications   = tostring(prop.classifications[0])
| join kind=inner (
    resources
    | where type =~ "microsoft.compute/virtualmachines"
    | where tostring(tags["ccs_managed"]) == "yes"
    | extend vmId = tolower(id)
    | project vmId, resourceType = type
) on vmId
 | where TimeGenerated >= startofmonth(datetime(now), -1)
   and TimeGenerated <= endofmonth(datetime(now), -1)
// Last 7 days
//| where TimeGenerated >= ago(7d)
//| extend TimeGenerated = format_datetime(TimeGenerated, 'dd-MM-yyyy HH:mm:ss')
| project TimeGenerated,
          RunID        = tostring(split(id, "/")[10]),
          machineName  = vmName,
          rgName,
          resourceType,
          patchName,
          kbId,
          classifications,
          installationState
| order by RunID asc
"@



$querydata = @()
try
{
    $queryRG = Search-AzGraph -Query $query -ErrorAction Stop -First 1000
    $querydata = $queryRG.data
    $querytoken = $queryRG.SkipToken

    while ($querytoken -ne $null){
        Write-Host "loop"
        $queryRG = Search-AzGraph -Query $query -SkipToken $querytoken -ErrorAction Stop -First 1000
        $querydata += $queryRG.data
        $querytoken = $queryRG.SkipToken 
    }
} 
Catch
{
    Write-Host "An error occurred:"
    Write-Host $_
}
$queryResult = $querydata | Convertto-json | convertfrom-json | convertto-csv

# Write-Host $queryResult

Push-OutputBinding -Name outputBlob -Value ($queryResult -join "`n")




output "assignment_id" {
  value = azurerm_subscription_policy_assignment.policy_assignment.id
}

output "assignment_name" {
  value = azurerm_subscription_policy_assignment.policy_assignment.name
}
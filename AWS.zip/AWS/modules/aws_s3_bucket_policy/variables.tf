variable "bucket" {
  description = "ID (name) of the bucket"
  type        = string
}

variable "region" {
  description = "The AWS region where the S3 bucket is located"
  type        = string
}
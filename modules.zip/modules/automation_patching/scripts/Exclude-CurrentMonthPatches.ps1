Param(
    [object] $WebhookData
)
Write-Output "WebhookData:`n$WebhookData"

$subscriptionId = "63efd7f0-f279-403a-acf5-666ed15b72ab"
Connect-AzAccount -Identity -AccountId "40b62928-c0a3-46c2-9b2a-1caf00c4e924" -Subscription $subscriptionId

$AutomationAccountName = "PatchingAutomationRunbook"
$AutomationAccountRg   = "Barts-Patching-Test"
$VariableName          = "ApprovedPatchKBIDs"

if ($null -eq $WebhookData) {
    Write-Output "No WebhookData - this is the monthly timer run. Refreshing approved KB list."

    $CurrentMonthKQLQuery = "patchassessmentresources `
| where type in~ (`"microsoft.compute/virtualmachines/patchassessmentresults/softwarePatches`") `
| where not(isempty(properties[`"publishedDateTime`"])) `
| where todatetime(properties[`"publishedDateTime`"]) >= startofmonth(datetime_add('month', -1, now())) `
| where todatetime(properties[`"publishedDateTime`"]) < startofmonth(now()) `
| project [`"KBID`"] = properties[`"kbId`"] `
| where KBID != `"`"` `
| summarize by tostring(KBID)"

    $approvedKBIDs = @($(Search-AzGraph -Query $CurrentMonthKQLQuery).KBID)
    Write-Output "Monthly refresh - approved KBIDs for this cycle: $approvedKBIDs"

    $jsonValue = ($approvedKBIDs | ConvertTo-Json -Compress)
    Set-AzAutomationVariable -ResourceGroupName $AutomationAccountRg -AutomationAccountName $AutomationAccountName `
        -Name $VariableName -Value $jsonValue -Encrypted $false

    Write-Output "ApprovedPatchKBIDs variable updated successfully for this cycle."
    exit 0
}

$EventData = $WebhookData.RequestBody | ConvertFrom-Json
$EventItem = $EventData
if ($null -ne $EventData[0]) {
    $EventItem = $EventData[0]
}

if ($EventItem.eventType -ne "Microsoft.Maintenance.PreMaintenanceEvent") {
    Write-Output "Not Pre Maintenance event"
    exit 0
}

$MaintenanceConfigurationMatches = $EventItem.topic.ToLower() -match ".*resourcegroups/(.*)/providers.*/maintenanceconfigurations/(.*)"
if (-not $MaintenanceConfigurationMatches) {
    Write-Error "Failed to extract Maintenance Configuration resource group and name"
    exit 1
}
$MaintenanceConfigurationRgName = $Matches.1
$MaintenanceConfigurationName   = $Matches.2

try {
    $storedVar = Get-AzAutomationVariable -ResourceGroupName $AutomationAccountRg -AutomationAccountName $AutomationAccountName -Name $VariableName
    $kbNumbersToInclude = @($storedVar.Value | ConvertFrom-Json)
} catch {
    Write-Error "Failed to read '$VariableName'. Cannot proceed."
    exit 1
}

if (-not $kbNumbersToInclude -or $kbNumbersToInclude.Count -eq 0) {
    Write-Error "No approved KB list found in '$VariableName' for maintenance configuration '$MaintenanceConfigurationName'. Monthly refresh may not have run yet. Failing this run."
    exit 1
}

Write-Output "Applying approved KBIDs: $kbNumbersToInclude"

$body = @{
    properties = @{
        installPatches = @{
            windowsParameters = @{
                kbNumbersToInclude = @($kbNumbersToInclude)
                kbNumbersToExclude = @()
            }
        }
    }
} | ConvertTo-Json -Depth 10

$apiVersion = "2023-04-01"
$uri = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$MaintenanceConfigurationRgName/providers/Microsoft.Maintenance/maintenanceConfigurations/$MaintenanceConfigurationName`?api-version=$apiVersion"

$token = (Get-AzAccessToken -ResourceUrl "https://management.azure.com").Token
$handler = New-Object System.Net.Http.HttpClientHandler
$client  = New-Object System.Net.Http.HttpClient($handler)
$client.Timeout = New-TimeSpan -Minutes 10

$request = New-Object System.Net.Http.HttpRequestMessage("PATCH", $uri)
$request.Headers.Add("Authorization", "Bearer $token")
$request.Content = New-Object System.Net.Http.StringContent($body, [System.Text.Encoding]::UTF8, "application/json")

$response = $client.SendAsync($request).Result
$responseBody = $response.Content.ReadAsStringAsync().Result
Write-Output "REST API Response:`n$responseBody"
Write-Output "Maintenance Configuration $MaintenanceConfigurationName updated successfully"
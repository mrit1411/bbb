import boto3
import time
import csv
import os
import json
from datetime import datetime, timedelta
from botocore.config import Config
from botocore.exceptions import ClientError

sns_client = boto3.client('sns')

s3_destination_bucket = os.environ.get('S3_BUCKET')
s3_presigned_link_expiration = int(os.environ.get('S3_LINK_EXPIRATION', '3600'))
s3_sns_topic_arn = os.environ.get('SNS_TOPIC_ARN')


def lambda_handler(event, context):
    secret_response = json.loads(get_secret())

    s3_client = boto3.client(
        "s3",
        config=Config(signature_version='s3v4'),
        region_name=os.environ.get("AWS_REGION"),
        aws_access_key_id=secret_response["ACCESS_KEY"],
        aws_secret_access_key=secret_response["SECRET_KEY"]
    )

    # end_date = datetime.today().replace(day=1, hour=23, minute=59, second=59) - timedelta(days=1)
    # start_date = datetime.today().replace(day=1, hour=0, minute=0, second=0) - timedelta(days=end_date.day)
    start_date = datetime(2025, 9, 1, 0, 0, 0)
    end_date = datetime(2025, 9, 30, 23, 59, 59)

    print(f"Fetching data from {start_date} to {end_date}")

    account_id = context.invoked_function_arn.split(":")[4]
    fieldnames = ["Start Time", "End Time", "Hostgroup Name", "Server Name", "Region Name", "Resource Id", "Down %", "Up %", "Total Hours", "Uptime Hours"]

    filename = f"availability-report-{account_id}-{datetime.today().strftime('%Y%m%d_%H%M.%f')}.csv"

    try:
        availability_data = get_availability_data(start_date, end_date, account_id)
        
        if not availability_data:
            print("No availability data found.")
            return
        else:
            print("availability data is ",availability_data)
        
        with open('/tmp/'+filename, 'a', newline='') as temp_file:
            csv_writer = csv.DictWriter(temp_file, fieldnames=fieldnames)
            csv_writer.writeheader()
            csv_writer.writerows(availability_data)

        print(f"Generated report file: {filename}")

        print(f"Uploading report to S3: {s3_destination_bucket}")
        s3_client.upload_file("/tmp/"+filename, s3_destination_bucket, filename)

        presigned_url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': s3_destination_bucket, 'Key': filename},
            ExpiresIn=s3_presigned_link_expiration
        )

        sns_client.publish(
            TargetArn=s3_sns_topic_arn,
            Message=f"Link to availability report (valid for {s3_presigned_link_expiration // 3600} hours): {presigned_url}",
            MessageStructure='string'
        )

    except Exception as e:
        print(f"Error: {e}")

    return


def get_availability_data(start_date, end_date, account_id):
    availability_data = []
    regions = boto3.client('ec2').describe_regions()['Regions']

    for region in regions:
        region_name = region['RegionName']
        print(f"Processing region: {region_name}")

        ec2_client = boto3.client('ec2', region_name=region_name)
        cloudwatch_client = boto3.client('cloudwatch', region_name=region_name)

        instance_dict = get_instance_ids(start_date, end_date, ec2_client, region_name)

        for instance_id, instance_info in instance_dict.items():
            start_instance_date = instance_info['start-date']
            end_instance_date = instance_info['end-date']

            print(f"Processing instance: {instance_id}")

            sum_failed_minutes, sum_active_minutes = 0, 1

            while start_instance_date <= end_instance_date:
                check_failed_minutes, active_minutes = get_metrics(instance_id, start_instance_date, cloudwatch_client)
                sum_failed_minutes += check_failed_minutes
                sum_active_minutes += active_minutes
                start_instance_date += timedelta(days=1)

            sla_up = round(((sum_active_minutes - sum_failed_minutes) * 100) / sum_active_minutes, 2) if sum_active_minutes > 1 else 0
            sla_down = 100 - sla_up
            hostgroup_name, server_name = get_hostgroup_and_server_name(instance_id, account_id, ec2_client)


            availability_data.append({
                'Start Time': instance_info['start-date'].strftime('%Y-%m-%d'),
                'End Time': instance_info['end-date'].strftime('%Y-%m-%d'),
                'Hostgroup Name': hostgroup_name,
                'Server Name': server_name,
                'Region Name': region_name,
                'Resource Id': instance_id,
                'Down %': sla_down,
                'Up %': sla_up,
                'Total Hours': round(sum_active_minutes / 60),
                'Uptime Hours': round((sum_active_minutes - sum_failed_minutes) / 60)
            })
        if not availability_data:
            print("No availability data found csv will be empty")
        else:
            print(f"Data found: {len(availability_data)} entries")

    return availability_data


def get_instance_ids(start_date, end_date, ec2_client, region_name):
    print("Inside the get_instance_ids")
    instance_dict = {}

    try:
        response = ec2_client.describe_instances()

        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                launch_time = instance['LaunchTime'].replace(tzinfo=None)

                if launch_time < end_date:
                    instance_dict[instance_id] = {
                        'start-date': max(start_date, launch_time),
                        'end-date': end_date
                    }

    except ClientError as e:
        print(f"Error fetching instances for region {region_name}: {e}")
    print(f"Instance Dict for Demo: {instance_dict}")

    return instance_dict


def get_metrics(instance_id, start_date, cloudwatch_client):
    try:
        response = cloudwatch_client.get_metric_statistics(
            Namespace='AWS/EC2',
            MetricName='StatusCheckFailed',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
            StartTime=start_date.strftime('%Y-%m-%dT00:00:00Z'),
            EndTime=start_date.strftime('%Y-%m-%dT23:59:59Z'),
            Period=3600,
            Statistics=['Sum', 'SampleCount']
        )
        print(f"Response for {instance_id}:", response)

        minutes_with_check_failed = sum(data['Sum'] * (data['Period'] / 60) for data in response['Datapoints'])
        active_minutes = sum(data['SampleCount'] for data in response['Datapoints'])

    except Exception as e:
        print(f"Error fetching metrics for {instance_id}: {e}")
        return 0, 1
    print(f"Instance: {instance_id}, Failed Minutes: {minutes_with_check_failed}, Active Minutes: {active_minutes}")
    print(f"Instance: {instance_id}, Date: {start_date}, Failed Minutes: {minutes_with_check_failed}, Active Minutes: {active_minutes}")

    return minutes_with_check_failed, active_minutes

def get_hostgroup_and_server_name(instance_id,account_id, ec2):
    env_type = 'undefined'
    server_name = 'undefined'
    account_name = os.environ.get('ACCOUNT_NAME')

    try:
            response = ec2.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [instance_id]
                    }
                ]
            )
            for Tag in response['Tags']:
                if Tag['Key'] == 'Name':
                    server_name = Tag['Value']
                if Tag['Key'] == 'environment':
                    env_type = Tag['Value']
    except Exception as e:
            print("Error while reading instance tags: %s" % e)

    return f'{account_name}/aws/{account_id}/{env_type}', server_name


def get_secret():
    secret_name = f"ccs-availability-user-{os.environ.get('AWS_REGION')}"

    try:
        client = boto3.client('secretsmanager', region_name=os.environ.get("AWS_REGION"))
        secret_value_response = client.get_secret_value(SecretId=secret_name)
        return secret_value_response['SecretString']

    except ClientError as e:
        print(f"Error retrieving secret: {e}")
        return "{}"

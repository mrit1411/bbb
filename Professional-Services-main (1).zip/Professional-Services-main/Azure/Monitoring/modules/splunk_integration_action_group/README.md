﻿## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_action_group.action_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_azure_function_receiver_name"></a> [azure\_function\_receiver\_name](#input\_azure\_function\_receiver\_name) | The name of the Azure Function receiver. | `string` | n/a | yes |
| <a name="input_context"></a> [context](#input\_context) | The contextual identifier which should be used for this resource. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment in which to deploy. | `string` | n/a | yes |
| <a name="input_function_app_name"></a> [function\_app\_name](#input\_function\_app\_name) | The name of the Splunk Integration Azure Function App. | `string` | n/a | yes |
| <a name="input_function_app_resource_id"></a> [function\_app\_resource\_id](#input\_function\_app\_resource\_id) | The Resource ID of the Splunk Integration Azure Function App. | `string` | n/a | yes |
| <a name="input_function_default_host_key"></a> [function\_default\_host\_key](#input\_function\_default\_host\_key) | The default host key of the Splunk Integration Azure Function. | `string` | n/a | yes |
| <a name="input_function_name"></a> [function\_name](#input\_function\_name) | The name of the Splunk Integration Azure Function. | `string` | n/a | yes |
| <a name="input_index"></a> [index](#input\_index) | The index which should be used for this resource. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_org"></a> [org](#input\_org) | The owning org. | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which the Splunk Integration Action Group should be created. | `string` | n/a | yes |
| <a name="input_short_name"></a> [short\_name](#input\_short\_name) | The short name of the Splunk Integration Action Group. This will be used in SMS messages. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(any)` | n/a | yes |
| <a name="input_use_common_alert_schema"></a> [use\_common\_alert\_schema](#input\_use\_common\_alert\_schema) | Whether to use the common alert schema for the Azure Function receiver. | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_action_group_id"></a> [action\_group\_id](#output\_action\_group\_id) | The ID of the action group. |

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.3.0"
    }
  }
}

provider "aws" {
  # Configuration options
  region = "us-east-1"

  default_tags {
    tags = {
      ccs_managed = "yes"
    }
  }
}

provider "aws" {
  alias = "monitoring_account"

  region  = "us-east-1"
  profile = "monitoring_account"
  default_tags {
    tags = {
      ccs_managed = "yes"
    }
  }
}
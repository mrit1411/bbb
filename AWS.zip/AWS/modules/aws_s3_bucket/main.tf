resource "aws_s3_bucket" "s3_bucket" {
  bucket        = lower(local.bucket_name)
  region = var.region
  force_destroy = var.force_destroy

  tags = var.tags

  lifecycle {
    precondition {
      condition     = length(local.bucket_name) <= 63
      error_message = "Bucket name must not exceed 63 characters."
    }
  }

}

resource "aws_s3_bucket_lifecycle_configuration" "s3_bucket_lifecycle_configuration" {
  bucket = aws_s3_bucket.s3_bucket.id
  region = var.region
  rule {
    filter {}

    expiration {
      days = var.expiration_days
    }

    dynamic "transition" {
      for_each = var.enable_transition ? [1] : []
      content {
        days          = var.transition_in_days
        storage_class = var.transition_storage_class
      }
    }

    id     = var.rule_id
    status = var.rule_status ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_public_access_block" "s3_bucket_public_access_block" {
  bucket                  = aws_s3_bucket.s3_bucket.id
  region = var.region
  block_public_acls       = var.block_public_acls
  block_public_policy     = var.block_public_policy
  ignore_public_acls      = var.ignore_public_acls
  restrict_public_buckets = var.restrict_public_buckets
}
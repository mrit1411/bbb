$baseDirs = @("Patching", "Monitoring", "Backup", "Dashboards", "Reporting")

foreach ($baseDir in $baseDirs) {
    $modulesPath = ".\$baseDir\modules"

    Get-ChildItem -Path $modulesPath -Directory -Recurse | ForEach-Object {
        $modulePath = $_.FullName
        Write-Host "Generating docs for $modulePath"
        terraform-docs markdown $modulePath | Out-File -Encoding UTF8 "$modulePath\README.md"
    }
}
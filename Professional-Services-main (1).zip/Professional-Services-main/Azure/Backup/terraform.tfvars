azure_policy_Backup_definition_name = "CCS Backup For VM test"
azure_policy_Backup_assignment_name = "CCS Backup For VM test"

backup_tag_name_standard = "ccs_backup_standard"
backup_tag_name_enhanced = "ccs_backup_enhanced"
backup_tag_value         = "yes"

policy_assignment_user_assigned_identity_ids = ["/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/Guild-COS-Development/providers/Microsoft.ManagedIdentity/userAssignedIdentities/tftest-main"]
policy_management_group_id                   = "/providers/microsoft.management/managementgroups/cb53a056-cedb-4fc1-a09f-c0b85cc0a527"


# old backup_map variable
# backup_map = {
#   sub1 = {
#     sub_id  = "fb63f824-3311-4bd9-bd21-54708346da51"

#     regions = {
#       eastus      = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/CGCOS_RG/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-eastus/backupPolicies/CCS-Backup-Policy"
#       norwayeast  = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/CGCOS_RG/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-norwayeast/backupPolicies/CCS-Backup-Policy"
#       canadacentral = "/subscriptions/fb63f824-3311-4bd9-bd21-54708346da51/resourceGroups/CGCOS_RG/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-canadacentral/backupPolicies/CCS-Backup-Policy"
#     }
#   }
#   sub2 = {
#     sub_id  = "63efd7f0-f279-403a-acf5-666ed15b72ab" 
#     regions = {
#       eastus   = "/subscriptions/63efd7f0-f279-403a-acf5-666ed15b72ab/resourceGroups/AzureBackupRG_eastus_1/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-eastus/backupPolicies/CCS-Backup-Policy"
#       westus2  = "/subscriptions/63efd7f0-f279-403a-acf5-666ed15b72ab/resourceGroups/AzureServices_group/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-westus2/backupPolicies/CCS-Backup-Policy"
#     }
#   }
# }

# New backup_map variable to include backup policy IDs for each region

# standard_backup_map = {
#   sub1 = {
#     sub_id = "84f2d25e-f251-4492-8df9-77cf3b48a151"
#     regions = {
#       centralindia = "/subscriptions/84f2d25e-f251-4492-8df9-77cf3b48a151/resourceGroups/rg-demo-dev/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-centralindia/backupPolicies/CCS-Backup-Policy-Standard"
#       # centralindia = "/subscriptions/84f2d25e-f251-4492-8df9-77cf3b48a151/resourceGroups/rg-demo-dev/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-centralindia/backupPolicies/CCS-Backup-Policy-Standard"
#       #  eastus = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Standard"
#       # norwayeast = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Standard"
#       # canadacentral = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Standard"
#     }
#   }
# }

# enhanced_backup_map = {
#   sub1 = {
#     sub_id = "84f2d25e-f251-4492-8df9-77cf3b48a151"
#     regions = {
#       centralindia = "/subscriptions/84f2d25e-f251-4492-8df9-77cf3b48a151/resourceGroups/rg-demo-dev/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-centralindia/backupPolicies/CCS-Backup-Policy-Enhanced"
#       # centralindia = "/subscriptions/84f2d25e-f251-4492-8df9-77cf3b48a151/resourceGroups/rg-demo-dev/providers/Microsoft.RecoveryServices/vaults/CCS-RSV-centralindia/backupPolicies/CCS-Backup-Policy-Enhanced"
#       # eastus = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Enhanced"
#       # norwayeast = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Enhanced"
#       # canadacentral = "/subscriptions/.../backupPolicies/CCS-Backup-Policy-Enhanced"
#     }
#   }
# }
############################END##############################

subscriptions = {
  sub1 = {
    subscription_id         = "84f2d25e-f251-4492-8df9-77cf3b48a151"
    resource_group_name_map = { centralindia = "rg-demo-dev" }

    standard_policy_name = "CCS-Backup-Policy-Standard"
    enhanced_policy_name = "CCS-Backup-Policy-Enhanced"

    standard_policy = {
      timezone                       = "UTC"
      schedule_frequency             = "Daily"
      schedule_time                  = "01:00"
      instant_restore_retention_days = 2
      retention_daily                = 14
      # retention_weekly               = { count = 12, weekdays = ["Sunday"] }
      retention_monthly = {
        count = 6
        # weeks = null
        # weekdays = null
        days = [28]
      }
      # retention_yearly = { count = 5, months = ["January"], weeks = ["First"], weekdays = ["Sunday"] }

    }


    enhanced_policy = {
      timezone           = "UTC"
      schedule_frequency = "Daily"
      schedule_time      = "01:00"
      # hour_interval                  = 4
      # hour_duration                  = 24
      instant_restore_retention_days = 2
      retention_daily                = 14
      # retention_weekly               = { count = 5, weekdays = ["Sunday"] }
      retention_monthly = { count = 6, days = [28] }
      # retention_yearly               = { count = 5, months = ["January"], weeks = ["First"], weekdays = ["Sunday"] }
    }


  }
  sub2 = {
    subscription_id         = "63efd7f0-f279-403a-acf5-666ed15b72ab"
    resource_group_name_map = { eastus = "AzureBackupRG_eastus_1", westus2 = "AzureServices_group" }

    standard_policy_name = null
    enhanced_policy_name = null

    standard_policy = null
    enhanced_policy = null

  }
}

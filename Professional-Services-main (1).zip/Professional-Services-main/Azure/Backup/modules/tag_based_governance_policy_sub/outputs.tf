# output "vm_backup_policy" {
#   value =  azurerm_policy_definition.vm_backup_policy.name #  <---  Replace 'example' with your actual resource name
#   description = "The Name of the backup policy"
# }
data "aws_region" "current" {}

locals {
  name = "${var.resource_type}-${var.context}"

  default_assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "${lower(var.resource_type)}.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })
}
locals {
  name = "CCS-Glue-Trigger-${var.client_name}"
}

variable "name" {
  description = "The name which should be used for this Dynamic Maintenance Assignment. Changing this forces a new Dynamic Maintenance Assignment to be created."
  type        = string
}

variable "maintenance_configuration_id" {
  description = "The ID of the Maintenance Configuration Resource. Changing this forces a new Dynamic Maintenance Assignment to be created."
  type        = string
}

variable "resource_group_name" {
  description = "Resource Group Name"
  type        = string
}

variable "location" {
  description = "Azure Region"
  type        = string
}

variable "tag_filters" {
  description = "A list of tag-based filters used to dynamically scope maintenance assignments. Each filter specifies a tag key and a list of acceptable values to target specific virtual machines."
  type = list(object({
    tag    = string
    values = list(string)
  }))
}

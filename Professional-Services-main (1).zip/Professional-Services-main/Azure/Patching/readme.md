

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.22.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | ~>3.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_linux_dynamic_scope_august_1_dependency"></a> [linux\_dynamic\_scope\_august\_1\_dependency](#module\_linux\_dynamic\_scope\_august\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_august_1_non_dependency"></a> [linux\_dynamic\_scope\_august\_1\_non\_dependency](#module\_linux\_dynamic\_scope\_august\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_august_2_dependency"></a> [linux\_dynamic\_scope\_august\_2\_dependency](#module\_linux\_dynamic\_scope\_august\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_august_2_non_dependency"></a> [linux\_dynamic\_scope\_august\_2\_non\_dependency](#module\_linux\_dynamic\_scope\_august\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_november_1_dependency"></a> [linux\_dynamic\_scope\_november\_1\_dependency](#module\_linux\_dynamic\_scope\_november\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_november_1_non_dependency"></a> [linux\_dynamic\_scope\_november\_1\_non\_dependency](#module\_linux\_dynamic\_scope\_november\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_november_2_dependency"></a> [linux\_dynamic\_scope\_november\_2\_dependency](#module\_linux\_dynamic\_scope\_november\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_november_2_non_dependency"></a> [linux\_dynamic\_scope\_november\_2\_non\_dependency](#module\_linux\_dynamic\_scope\_november\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_dynamic_scope_test_dependency"></a> [linux\_dynamic\_scope\_test\_dependency](#module\_linux\_dynamic\_scope\_test\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_linux_maintenance_configuration_august_1_dependency"></a> [linux\_maintenance\_configuration\_august\_1\_dependency](#module\_linux\_maintenance\_configuration\_august\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_august_1_non_dependency"></a> [linux\_maintenance\_configuration\_august\_1\_non\_dependency](#module\_linux\_maintenance\_configuration\_august\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_august_2_dependency"></a> [linux\_maintenance\_configuration\_august\_2\_dependency](#module\_linux\_maintenance\_configuration\_august\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_august_2_non_dependency"></a> [linux\_maintenance\_configuration\_august\_2\_non\_dependency](#module\_linux\_maintenance\_configuration\_august\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_november_1_dependency"></a> [linux\_maintenance\_configuration\_november\_1\_dependency](#module\_linux\_maintenance\_configuration\_november\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_november_1_non_dependency"></a> [linux\_maintenance\_configuration\_november\_1\_non\_dependency](#module\_linux\_maintenance\_configuration\_november\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_november_2_dependency"></a> [linux\_maintenance\_configuration\_november\_2\_dependency](#module\_linux\_maintenance\_configuration\_november\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_november_2_non_dependency"></a> [linux\_maintenance\_configuration\_november\_2\_non\_dependency](#module\_linux\_maintenance\_configuration\_november\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_linux_maintenance_configuration_test_dependency"></a> [linux\_maintenance\_configuration\_test\_dependency](#module\_linux\_maintenance\_configuration\_test\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_dynamic_scope_august_1_dependency"></a> [windows\_dynamic\_scope\_august\_1\_dependency](#module\_windows\_dynamic\_scope\_august\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_august_1_non_dependency"></a> [windows\_dynamic\_scope\_august\_1\_non\_dependency](#module\_windows\_dynamic\_scope\_august\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_august_2_dependency"></a> [windows\_dynamic\_scope\_august\_2\_dependency](#module\_windows\_dynamic\_scope\_august\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_august_2_non_dependency"></a> [windows\_dynamic\_scope\_august\_2\_non\_dependency](#module\_windows\_dynamic\_scope\_august\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_august_3_dependency"></a> [windows\_dynamic\_scope\_august\_3\_dependency](#module\_windows\_dynamic\_scope\_august\_3\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_august_3_non_dependency"></a> [windows\_dynamic\_scope\_august\_3\_non\_dependency](#module\_windows\_dynamic\_scope\_august\_3\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_1_dependency"></a> [windows\_dynamic\_scope\_november\_1\_dependency](#module\_windows\_dynamic\_scope\_november\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_1_non_dependency"></a> [windows\_dynamic\_scope\_november\_1\_non\_dependency](#module\_windows\_dynamic\_scope\_november\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_2_dependency"></a> [windows\_dynamic\_scope\_november\_2\_dependency](#module\_windows\_dynamic\_scope\_november\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_2_non_dependency"></a> [windows\_dynamic\_scope\_november\_2\_non\_dependency](#module\_windows\_dynamic\_scope\_november\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_3_dependency"></a> [windows\_dynamic\_scope\_november\_3\_dependency](#module\_windows\_dynamic\_scope\_november\_3\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_november_3_non_dependency"></a> [windows\_dynamic\_scope\_november\_3\_non\_dependency](#module\_windows\_dynamic\_scope\_november\_3\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_1_dependency"></a> [windows\_dynamic\_scope\_october\_1\_dependency](#module\_windows\_dynamic\_scope\_october\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_1_non_dependency"></a> [windows\_dynamic\_scope\_october\_1\_non\_dependency](#module\_windows\_dynamic\_scope\_october\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_2_dependency"></a> [windows\_dynamic\_scope\_october\_2\_dependency](#module\_windows\_dynamic\_scope\_october\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_2_non_dependency"></a> [windows\_dynamic\_scope\_october\_2\_non\_dependency](#module\_windows\_dynamic\_scope\_october\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_3_dependency"></a> [windows\_dynamic\_scope\_october\_3\_dependency](#module\_windows\_dynamic\_scope\_october\_3\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_october_3_non_dependency"></a> [windows\_dynamic\_scope\_october\_3\_non\_dependency](#module\_windows\_dynamic\_scope\_october\_3\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_1_dependency"></a> [windows\_dynamic\_scope\_september\_1\_dependency](#module\_windows\_dynamic\_scope\_september\_1\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_1_non_dependency"></a> [windows\_dynamic\_scope\_september\_1\_non\_dependency](#module\_windows\_dynamic\_scope\_september\_1\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_2_dependency"></a> [windows\_dynamic\_scope\_september\_2\_dependency](#module\_windows\_dynamic\_scope\_september\_2\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_2_non_dependency"></a> [windows\_dynamic\_scope\_september\_2\_non\_dependency](#module\_windows\_dynamic\_scope\_september\_2\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_3_dependency"></a> [windows\_dynamic\_scope\_september\_3\_dependency](#module\_windows\_dynamic\_scope\_september\_3\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_september_3_non_dependency"></a> [windows\_dynamic\_scope\_september\_3\_non\_dependency](#module\_windows\_dynamic\_scope\_september\_3\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_dynamic_scope_test_non_dependency"></a> [windows\_dynamic\_scope\_test\_non\_dependency](#module\_windows\_dynamic\_scope\_test\_non\_dependency) | ./modules/dynamic_scope | n/a |
| <a name="module_windows_maintenance_configuration_august_1_dependency"></a> [windows\_maintenance\_configuration\_august\_1\_dependency](#module\_windows\_maintenance\_configuration\_august\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_august_1_non_dependency"></a> [windows\_maintenance\_configuration\_august\_1\_non\_dependency](#module\_windows\_maintenance\_configuration\_august\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_august_2_dependency"></a> [windows\_maintenance\_configuration\_august\_2\_dependency](#module\_windows\_maintenance\_configuration\_august\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_august_2_non_dependency"></a> [windows\_maintenance\_configuration\_august\_2\_non\_dependency](#module\_windows\_maintenance\_configuration\_august\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_august_3_dependency"></a> [windows\_maintenance\_configuration\_august\_3\_dependency](#module\_windows\_maintenance\_configuration\_august\_3\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_august_3_non_dependency"></a> [windows\_maintenance\_configuration\_august\_3\_non\_dependency](#module\_windows\_maintenance\_configuration\_august\_3\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_1_dependency"></a> [windows\_maintenance\_configuration\_november\_1\_dependency](#module\_windows\_maintenance\_configuration\_november\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_1_non_dependency"></a> [windows\_maintenance\_configuration\_november\_1\_non\_dependency](#module\_windows\_maintenance\_configuration\_november\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_2_dependency"></a> [windows\_maintenance\_configuration\_november\_2\_dependency](#module\_windows\_maintenance\_configuration\_november\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_2_non_dependency"></a> [windows\_maintenance\_configuration\_november\_2\_non\_dependency](#module\_windows\_maintenance\_configuration\_november\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_3_dependency"></a> [windows\_maintenance\_configuration\_november\_3\_dependency](#module\_windows\_maintenance\_configuration\_november\_3\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_november_3_non_dependency"></a> [windows\_maintenance\_configuration\_november\_3\_non\_dependency](#module\_windows\_maintenance\_configuration\_november\_3\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_1_dependency"></a> [windows\_maintenance\_configuration\_october\_1\_dependency](#module\_windows\_maintenance\_configuration\_october\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_1_non_dependency"></a> [windows\_maintenance\_configuration\_october\_1\_non\_dependency](#module\_windows\_maintenance\_configuration\_october\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_2_dependency"></a> [windows\_maintenance\_configuration\_october\_2\_dependency](#module\_windows\_maintenance\_configuration\_october\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_2_non_dependency"></a> [windows\_maintenance\_configuration\_october\_2\_non\_dependency](#module\_windows\_maintenance\_configuration\_october\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_3_dependency"></a> [windows\_maintenance\_configuration\_october\_3\_dependency](#module\_windows\_maintenance\_configuration\_october\_3\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_october_3_non_dependency"></a> [windows\_maintenance\_configuration\_october\_3\_non\_dependency](#module\_windows\_maintenance\_configuration\_october\_3\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_1_dependency"></a> [windows\_maintenance\_configuration\_september\_1\_dependency](#module\_windows\_maintenance\_configuration\_september\_1\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_1_non_dependency"></a> [windows\_maintenance\_configuration\_september\_1\_non\_dependency](#module\_windows\_maintenance\_configuration\_september\_1\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_2_dependency"></a> [windows\_maintenance\_configuration\_september\_2\_dependency](#module\_windows\_maintenance\_configuration\_september\_2\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_2_non_dependency"></a> [windows\_maintenance\_configuration\_september\_2\_non\_dependency](#module\_windows\_maintenance\_configuration\_september\_2\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_3_dependency"></a> [windows\_maintenance\_configuration\_september\_3\_dependency](#module\_windows\_maintenance\_configuration\_september\_3\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_september_3_non_dependency"></a> [windows\_maintenance\_configuration\_september\_3\_non\_dependency](#module\_windows\_maintenance\_configuration\_september\_3\_non\_dependency) | ./modules/maintenance_configuration | n/a |
| <a name="module_windows_maintenance_configuration_test_non_dependency"></a> [windows\_maintenance\_configuration\_test\_non\_dependency](#module\_windows\_maintenance\_configuration\_test\_non\_dependency) | ./modules/maintenance_configuration | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | Azure region for resources | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the existing resource group | `string` | n/a | yes |
| <a name="input_sub_id"></a> [sub\_id](#input\_sub\_id) | Subscription ID to be ammended to Dynamic Scope name | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | n/a | yes |

## Outputs

No outputs.

## Steps to Deploy Dynamic Scopes Across Azure Subscriptions

The "create_dynamic_scopes.sh" script automates the deployment of Terraform modules for dynamic scope maintenance assignments across multiple Azure subscriptions.

### Why This Script Is Needed

Azure **does not support** creating Dynamic Scopes at the **Management Group level**. The dynamic scopes must be created at the **subscription level**, which makes centralized deployment challenging. This script solves that by iterating through each subscription and applying the necessary Terraform modules individually.


### Steps to Use the Script

**Step 1: Prepare Your Environment**
- Ensure your Terraform configuration and modules are in the same directory as the script.
- Authenticate with Azure CLI and confirm access to all listed subscriptions.

**Step 2: Review the Subscription List**
- The script contains a hardcoded list of subscription IDs.
- Update the list as needed to match the subscriptions where you want to deploy dynamic scopes.

**Step 3: Run the Script**
- Execute the script from the terminal:
  ```bash
  ./deploy_dynamic_scopes.sh
  ```

Note: When adding new Management Groups, the role assignment scopes of the "az-umi-org-no-ps-terraform-p-01" managed identity will also have to be updated.
<!-- END_TF_DOCS -->
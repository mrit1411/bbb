# AZURE

## Access Requirements

Access is required at the **Management Group** level.

## Identity Requirements

The following identities are required:

- 1 Service Principal / Managed Identity
- User Managed Identities (UMIs) for:
  - Azure Policy
  - Monitoring Agent (AMA)
  - Reporting Function App
  - SNOW Function App

---

# Service Principal / Managed Identity Access

## Monitoring Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Read management group ID, Tenant ID | Reader | Management Group |
| Create Log Analytics Workspace | Monitoring Contributor | Resource Group |
| Create Action Group | Monitoring Contributor | Resource Group |
| Create Alert Rules | Monitoring Contributor | Resource Group |
| Create Data Collection Rule | Monitoring Contributor | Resource Group |
| Create Storage Account | Storage Account Contributor | Resource Group |
| Upload blobs to Storage Account | Storage Blob Data Contributor | Resource Group |
| Create App Service Plan | Web Plan Contributor | Resource Group |
| Create Function App | Website Contributor | Resource Group |
| Create Key Vault | Key Vault Contributor | Resource Group |
| Create Secrets inside Key Vault | Key Vault Secrets Officer | Resource Group |
| Create Azure Policy Definitions | Resource Policy Contributor | Management Group |
| Create Azure Policy Assignments | Resource Policy Contributor | Management Group |
| Create Policy Remediation Tasks | Resource Policy Contributor | Management Group |
| Assign Managed Identities | Managed Identity Operator | Management Group |

---

## Reporting Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Read management group ID, Tenant ID | Reader | Management Group |
| Create Storage Account | Storage Account Contributor | Resource Group |
| Upload blobs to Storage Account | Storage Blob Data Contributor | Resource Group |
| Create App Service Plan | Web Plan Contributor | Resource Group |
| Create Function App | Website Contributor | Resource Group |
| Create Application Insights | Application Insights Component Contributor | Resource Group |
| Assign Managed Identities | Managed Identity Operator | Management Group |

---

## Dashboards Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Create Workbooks | Workbook Contributor | Resource Group |

---

## VM Creation Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Read management group ID, Tenant ID | Reader | Management Group |
| Create Storage Account (for diagnostics) | Storage Account Contributor | Resource Group |
| Create Public IP / NIC / VNet / Subnet | Network Contributor | Resource Group |
| Create Linux/Windows Virtual Machine | Virtual Machine Contributor | Resource Group |
| Attach Public IP/NIC to VM | Network Contributor | Resource Group |
| Assign Boot Diagnostics (Storage usage) | Storage Blob Data Contributor | Resource Group |
| Manage VM Diagnostics + Monitoring | Monitoring Contributor | Resource Group |

---

## Patching Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Read management group ID, Tenant ID | Reader | Management Group |
| Assign Assessment mode while VM Provisioning | Virtual Machine Contributor | Management Group |
| Create Dynamic Scope | Scheduled Patching Contributor | Management Group |
| Create Maintenance Configuration | Scheduled Patching Contributor | Resource Group |
| Create Azure Policy Definitions | Resource Policy Contributor | Management Group |
| Create Azure Policy Assignments | Resource Policy Contributor | Management Group |
| Create Policy Remediation Tasks | Resource Policy Contributor | Management Group |
| Creation of Automation Account and Runbook (N-1 patching) | Automation Contributor | Resource Group |
| Creation of Event Grid System Topic and Event Grid System Topic Subscription (N-1 patching) | Event Grid Contributor | Resource Group |
| Assign Managed Identities | Managed Identity Operator | Management Group |

---

## Backup Terraform Module Deployment

| Usage | Azure Role | Scope |
|---|---|---|
| Read management group ID | Reader | Management Group |
| Create Azure Policy Definitions | Resource Policy Contributor | Management Group |
| Create Azure Policy Assignments | Resource Policy Contributor | Management Group |
| Create Policy Remediation Tasks | Resource Policy Contributor | Management Group |
| Create Recovery Services Vault (RSV) | Backup Contributor | Resource Group |
| Read Backup-related VM Data | Reader | Management Group |
| Tenant ID | Reader | Management Group |
| Enable Backup on VMs | Backup Contributor | Management Group |
| Configure Backup Policies | Backup Contributor | Management Group |
| Read Vault details | Reader | Management Group |

---

# Access for UMI Related to Policy

| Policy | Role | Scope |
|---|---|---|
| Windows Dependency Agent | Virtual Machine Contributor | Management Group |
| Windows DCR Association | Monitoring Contributor | Management Group |
| Windows AMA Agent | Managed Identity Operator | Management Group |
| Windows AMA Agent | Virtual Machine Contributor | Management Group |
| Linux Dependency Agent | Virtual Machine Contributor | Management Group |
| Linux DCR Association | Monitoring Contributor | Management Group |
| Linux AMA Agent | Managed Identity Operator | Management Group |
| Linux AMA Agent | Virtual Machine Contributor | Management Group |
| Tagging Policy | Tag Contributor | Management Group |
| Backup Policy | Backup Contributor | Management Group |
| Backup Policy | Virtual Machine Contributor | Management Group |
| RSV Diagnostic Settings | Log Analytics Contributor | Management Group |
| RSV Diagnostic Settings | Monitoring Contributor | Management Group |

---

# Access for UMI Related to Monitoring Agent (AMA Agent)

| Role | Scope |
|---|---|
| Virtual Machine Contributor | Management Group |

---

# Access for UMI Related to Reporting Function App

| Role | Scope |
|---|---|
| Reader | Management Group |
| Log Analytics Reader | Management Group |
| Storage Blob Data Contributor | Management Group |

---

# Access for UMI Related to SNOW Function App

| Role | Scope |
|---|---|
| Reader | Management Group |
| Key Vault Secrets User | Management Group |
| Storage Blob Data Reader | Management Group |

---
